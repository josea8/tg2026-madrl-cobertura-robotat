# Demo del obstáculo móvil: protocolo de laboratorio L0–L2

**Estado:** fijado ANTES de la sesión.
- Decisiones de José del 2026-10-02, 03-10 y 07-10.
- Rige porque la 2.ª corrida del conjunto de confirmación pasó el criterio de la Fase 0 (`REPORTE_2026-10-02_obstaculo_fase0.md`).
- Respaldo de la versión anterior a la colocación automática: `PROTOCOLO_L0_L2_respaldo_20261007_preColocacion.md`.

**Código:** `primerafase_webots/controllers/coordinador_enjambre/demo_obstaculo_movil.py` y `colocacion_con_obstaculo.py`.
- Formulación F2: predictor con τ_c = 0.65 s, peso de giro condicional y rescate del QP.
- Factor 0.40.
- Freno de respaldo ACTIVO en la L2. Es una capa redundante: la separación la sostiene el filtro de los agentes.
- Salidas en `resultados_demo_obstaculo/`, con nombres fechados: nada se pisa.

**Robot obstáculo: el 4** (decisión de José, 2026-10-07: el 7 lo está usando otro compañero).
- **Todos los comandos llevan `--robot-obstaculo 4`.** La bandera es obligatoria: sin ella el programa no arranca.
- El 4 usa el marcador 4 (regla N ↔ N) y el enlace `192.168.50.104:9090`. No es agente del enjambre (1, 5, 8, 6, 9).
- **Su offset de rumbo, +81.90°, es el de la tabla y nunca se verificó.** La L0 lo mide (§L0). En el 8 la tabla erraba 5.0° y en el 1, 1.6°.
- **El 7 no tiene que estar en la arena:** el programa no lo ve, y sería un obstáculo sin seguimiento.

**Colocación AUTOMÁTICA en la L1 y la L2** (OK de José, 2026-10-07: Fase B de `PROPUESTA_colocacion_autonoma_obstaculo.md`).
- **Los 5 agentes van solos** a sus blancos alrededor del 4 **quieto**:
  - los blancos quedan a ≥ 0.65 m del 4;
  - lo rodean si lo tienen en el camino;
  - la barrera del 4 es la fila del Exp O;
  - entre agentes, el 50/50 de siempre.
- **El 4 no se mueve solo,** porque la Fase A no está implementada. En la L2 arranca desde donde lo dejó la toma anterior, que es la proyección de su pose sobre el círculo. Si está fuera de su envolvente (±6 cm del círculo, ±25° de la tangente), la sesión pide colocarlo **a mano** y dice dónde.
- **Un Enter por toma,** con el aviso "Los agentes van a ir SOLOS…", que nombra el robot, el marcador y la IP del obstáculo. Antes de ese Enter la sesión **descarta lo que se haya tecleado de más**.
- **Antes de colocar, espera a que el 4 quede quieto,** hasta 3 s. Al terminar una toma sigue andando por el retardo.
- **Durante la colocación todo se detiene con regla de parada** (exige la "s") si:
  - hay contacto (< 0.15 m entre centros medidos);
  - el 4 se mueve ("NO FRENA");
  - el marcador del 4 se congela o se pierde;
  - el enlace del 4 o el de un agente se cae.
- **Después de colocar,** los chequeos de siempre, más:
  - marcador congelado durante la colocación;
  - quietud de todos;
  - agentes a ≤ 0.12 m de su blanco;
  - el 4 en su envolvente.

  Si algo falla, hay reintento: corregir a mano y Enter, y se vuelven a colocar solos, hasta 5 veces sin gastar el intento. El que no avanzó rodea por el otro lado o primero se aleja 10 cm.
- **Con `--colocacion manual`** todo es como antes, con la guía y a mano.

**Seguridad, en todas las etapas:**
- Una persona junto a la arena, lista para levantar al obstáculo.
- La parada por software no es una parada de emergencia (README §S1).

---

## L0: el 4 solo

```text
python demo_obstaculo_movil.py --modo L0 --robot-obstaculo 4
```

**Procedimiento:**
1. La sesión pide colocar al 4 **a mano** en (1.5, 0.9) del env, mirando +x, con ±8 cm y ±30°, y lo verifica. En la L0 la colocación sigue siendo a mano, porque la Fase A no está.
2. Después hace 10 arranques desde parado.
   - Cada uno dura 6 s desde el primer mando, patada incluida (0.08 m/s, ≤ 1 s).
   - Sigue el círculo de R 0.60 en (1.5, 1.5), a 0.05 m/s, en sentido antihorario.
   - Entre arranques hay 2 s de pausa.
3. El enjambre fuera de la arena.

**Criterio:**
- **10 de 10 arranques:** cada uno se mueve ≥ 3 mm antes de 1.5 s.
- **Error radial máximo < 5 cm,** sin contar los 2 s de enganche de cada marcha.
- **Offset de rumbo a ≤ 3° de la tabla** (decisión de José): la L0 lo mide en los tramos de crucero comparando la dirección del desplazamiento con el rumbo medido, con ≥ 20 pares.
- **Aborto inmediato:** si en algún momento, enganche incluido, el error radial supera 10 cm, la L0 frena y termina con FALLO. También aborta si el marcador se congela, si se pierde la pose o si la colocación falla 6 veces.

**Resultado:** `<fecha>_L0_resumen.csv`, con veredicto, arranques, error radial, ω saturado y la diferencia de offset. Se escribe en todos los caminos.

**La L0 habilita la L1 y la L2.**
- El programa **no arranca la L1 ni la L2** (sale con código 6) si la última L0 del 4 no dio OK, o si su offset difiere más de 3° de la tabla o no se pudo medir.
- Si difiere más de 3°, **se frena antes de la L1:** la consola imprime la corrección propuesta para `config_robotat.py`, que se aplica sólo con el OK de José.
- `--forzar` saltea este chequeo.

## L1: el 4 ENCENDIDO y quieto en el centro (el Exp O en físico)

```text
python demo_obstaculo_movil.py --modo L1 --tomas 3 --intentos 6 --robot-obstaculo 4
```

- **Opción (b) de José:** el 4 va **encendido y conectado**.
  - Durante las tomas se le manda (0,0) en cada decisión y se lo vigila.
  - Si se mueve ("NO FRENA") o se le cae el enlace, la toma se aborta y salta la regla de parada.
- **El 4 se coloca a mano UNA vez** en el centro, (1.5, 1.5) ±8 cm. Es siempre el mismo punto y no se mueve entre tomas.
- **Los agentes van solos,** con blancos a ≥ 0.65 m del 4.
- **Cada toma** son 500 decisiones de política + CBF + escape, con la barrera del obstáculo quieto. Es la **geometría** de la fila del Exp O (D_o = 0.33, sin término de velocidad), evaluada con F2: sobre la pose predicha del agente, con peso de giro y rescate. No es el filtro del Exp O bit a bit; ése sería F1.
- **Criterio:** el mismo de la L2, con 3 tomas. No se exige recorrido del obstáculo.

## L2: el 4 en movimiento (la demo)

```text
python demo_obstaculo_movil.py --modo L2 --tomas 10 --intentos 20 --robot-obstaculo 4
```

**Criterio, fijado antes de la sesión (decisión de José):**

| | definición |
|---|---|
| **Validez de la medición** | la toma corre completa por el lazo del laboratorio (`_correr_episodio`, con todas sus reglas y la regla de 10 s arreglada). Cualquier aborto la invalida, con su motivo. |
| **Toma válida para la demo** | válida, Y **sin intervención del freno de respaldo**, Y ningún agente a < 0.15 m del obstáculo, Y el obstáculo recorrió al menos la mitad de lo comandado (esto último sólo si lo comandado es ≥ 0.20 m) |
| **Métrica principal** | **distancia mínima agente–obstáculo** por toma, entre centros, medida por el mocap a 10 Hz (`d_min_obst_medida`) |
| **Objetivo** | 10 tomas válidas para la demo, en hasta 20 intentos |

**Qué se informa** (`python analizar_sesion_demo.py <…_L2_tomas.csv>`):
- las dos validez por separado, con los motivos;
- las tomas con freno, aparte, como "intervención del freno de respaldo";
- la distancia mínima de cada toma y su distribución sobre las válidas para la medición (mínimo, mediana y máximo), con cuántas quedan bajo 0.185 y bajo 0.15 m;
- aparte, los contactos en tomas no válidas y las reglas de parada que se dispararon, con la respuesta del operador, también las de la colocación.

No hay umbral de aprobación sobre la métrica: se informa.

**Expectativa, del simulador, que no es criterio:**
- Las 120 tomas con política de la Fase 0 quedaron ≥ 0.2696 m, sin ningún freno. Ese simulador no tenía zona muerta de rueda.
- En los ensayos finales con colocación automática y zona muerta (L2 y L1, τ = 0.45 y 0.85 s), 26 de 26 tomas válidas, sin frenos y con un mínimo de 0.3052 m al obstáculo.
- En un ensayo intermedio con τ = 0.85 s hubo 1 freno de respaldo en una toma, con un mínimo de 0.2093 m. Con un solo caso no se puede atribuir a la zona muerta.
- El hardware anduvo 3.5 cm más cerca de la pared que su réplica el 30-09. No sería raro ver ~0.23 m.

**Reglas de parada en la sesión. Desde el 03-10 las aplica el programa.**
- Después de cada toma corrida, válida o no, y durante la colocación: si se cumple una regla, la sesión frena todo y muestra "⛔ REGLA DE PARADA — …". Después pregunta "¿Seguir con la sesión?".
- **Mientras espera la respuesta, sigue frenando cada 1 s** y mantiene vivos los enlaces.
- **Si no pudo confirmar que algún robot frenó, lo dice:** "⚠ NO SE PUDO CONFIRMAR LA DETENCIÓN: … LEVANTARLO / CORTAR ALIMENTACIÓN A MANO".
- **Sólo "s" la continúa.** Enter, "si" o cualquier otra respuesta la termina, con veredicto DETENIDA.
- La regla y la respuesta quedan en el CSV de tomas (`regla_parada`, `parada_respuesta`).

Las reglas:
1. **Contacto:** algún agente a < 0.15 m del obstáculo, en la distancia medida. En la colocación, también entre agentes.
2. **Freno de respaldo en dos tomas corridas seguidas.**
3. **Aborto por el obstáculo:** no se mueve, no frena, enlace caído (también si se reabrió al frenar), se salió del círculo o marcador perdido. Hay que revisar el 4 antes de seguir.
   - Si el aborto fue por pose vencida del 4 con consultas de poses fallidas, se rotula como probable hipo del servidor de poses. Igual se detiene.
4. **Toma corrida sin distancia medida:** no se puede descartar un contacto.
5. **En la colocación:** el enlace de un agente que se cae.

**Qué hace el operador:**
- Revisa la causa antes de contestar, y contesta "s" sólo si está entendida y resuelta.
- La línea `>>> TOMA k` dice por qué una toma no vale.
- Ctrl+C también corta, y los CSV se guardan igual.
- El programa decide **entre tomas** y durante la colocación, no durante la toma. La parada de emergencia sigue siendo la persona junto a la arena.

**Si hay que relanzar una sesión cortada:**

```text
python demo_obstaculo_movil.py --modo L2 --tomas <faltantes> --intentos 20 --intento-inicial <siguiente> --robot-obstaculo 4
```

- Siguen la numeración, las semillas y la cuenta contra el tope de 20.
- La rampa vuelve en la 1.ª toma de la sesión nueva, y la cuenta de frenos seguidos arranca de cero.
- Resumen de las dos sesiones juntas: `python analizar_sesion_demo.py <tomas_1.csv> <tomas_2.csv>`.

**Tener en cuenta:**
- La rampa de arranque seguro existe sólo en la **primera** toma de la sesión, porque cuenta por canal. Desde la 2.ª, el obstáculo arranca en la decisión 0. La Fase 0 lo cubrió con las variantes "sin rampa".
- **Sin resolver:**
  - **el 4 se coloca a mano** cuando está fuera de su envolvente: en la L0, en la L1 (una vez) y en la primera toma de la L2 si viene del centro. Moverlo solo es la Fase A, que no está implementada;
  - el retroceso por pose repetida va sin CBF, y lo mitiga el freno del 4 a 0.60 m (en la L2; en la Fase 0 no se ejercitó);
  - el offset de rumbo del 4 lo mide la L0.
