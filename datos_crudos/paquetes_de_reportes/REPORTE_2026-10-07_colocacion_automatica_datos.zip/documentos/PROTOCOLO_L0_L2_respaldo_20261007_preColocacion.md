# Demo del obstáculo móvil: protocolo de laboratorio L0–L2

**Estado:** fijado ANTES de la sesión, con la decisión de José del 2026-10-02.
- Rige sólo si la 2.ª corrida del conjunto de confirmación pasa el criterio de la Fase 0.
- Ver `REPORTE_2026-10-02_obstaculo_fase0.md`.

**Código:** `primerafase_webots/controllers/coordinador_enjambre/demo_obstaculo_movil.py`.
- Formulación F2: predictor con τ_c = 0.65 s, peso de giro condicional y rescate del QP.
- Factor 0.40. Freno de respaldo ACTIVO en la L2. En la L1 no hay freno, porque el 7 está apagado y sin conexión.
- Salidas en `resultados_demo_obstaculo/`, con nombres fechados: nada se pisa.

**Robot obstáculo: el 4, no el 7** (decisión de José, 2026-10-07: el 7 lo está usando otro compañero).
- **Todos los comandos llevan `--robot-obstaculo 4`, también la L1.** En la L1 el 4 va apagado, pero su marcador es el que da la posición del obstáculo.
- El 4 usa el marcador 4 (regla N ↔ N) y el enlace `192.168.50.104:9090`, y no es agente del enjambre (1, 5, 8, 6, 9).
- Su offset de rumbo, +81.90°, es el de la tabla del laboratorio y **nunca se verificó**. En el 8 la tabla erraba 5.0° y en el 1, 1.6°. Si está mal, se nota en la L0 como error radial.
- El 7 no tiene que estar en la arena: el programa no lo ve, y sería un obstáculo sin seguimiento.
- Donde este protocolo dice "el 7", léase "el 4".

**Seguridad, en todas las etapas:**
- Una persona junto a la arena, lista para levantar al obstáculo.
- La parada por software no es una parada de emergencia (README §S1).

---

## L0: el obstáculo solo

```text
python demo_obstaculo_movil.py --modo L0
```

Con el robot de reserva se agrega `--robot-obstaculo 4`.

**Procedimiento:**
1. La sesión pide colocar al 7 en (1.5, 0.9) del env, mirando +x, con ±8 cm y ±30°, y lo verifica.
2. Después hace 10 arranques desde parado. Cada uno dura 6 s desde el primer mando, patada incluida (0.08 m/s, ≤ 1 s), por el círculo de R 0.60 en (1.5, 1.5) a 0.05 m/s, antihorario. Entre arranques hay 2 s de pausa.

**Criterio:**
- **10 de 10 arranques:** cada uno se mueve ≥ 3 mm antes de 1.5 s.
- **Error radial máximo < 5 cm**, sin contar los 2 s de enganche de cada marcha.
- Se informa además, por consola, la fracción de decisiones con ω saturado. Cuenta todas las decisiones, patada y enganche incluidos.
- **Aborto inmediato:** si en algún momento, enganche incluido, el error radial supera 10 cm, la L0 frena y termina con FALLO sin completar los arranques. También aborta si el marcador se congela, si se pierde la pose o si la colocación falla 6 veces.

**Si falla, no se sigue.** El programa sale con código 1 (FALLO), pero nada impide lanzar la L1 o la L2: **ese corte lo hace el operador**. El veredicto y las cifras quedan en `<fecha>_L0_resumen.csv`.
- Si un arranque no sale, primero se revisa batería y rueda.
- Si el error radial es grande, se revisa el offset de rumbo del 7, que es el de la tabla y nunca se midió (etapa 3).

## L1: el 7 apagado y quieto en el centro (el Exp O en físico)

```text
python demo_obstaculo_movil.py --modo L1 --tomas 3 --intentos 6
```

- Colocación manual con la guía: los 5 agentes en sus blancos, que quedan a ≥ 0.50 m del 7, y el 7 en (1.5, 1.5).
- Cada toma son 500 decisiones de política + CBF + escape, con la barrera del obstáculo quieto.
  - Es la **geometría** de la fila del Exp O (D_o = 0.33, sin término de velocidad), evaluada con F2: sobre la pose predicha del agente, con peso de giro y rescate. No es el filtro del Exp O bit a bit; ése sería F1.
- **Criterio:** el mismo de la L2, con 3 tomas. Sin freno, la condición "sin intervención del freno" se cumple sola, y no se exige recorrido del obstáculo.

## L2: el 7 en movimiento (la demo)

```text
python demo_obstaculo_movil.py --modo L2 --tomas 10 --intentos 20
```

**Criterio, fijado antes de la sesión (decisión de José):**

| | definición |
|---|---|
| **Validez de la medición** | la toma corre completa por el lazo del laboratorio (`_correr_episodio`, con todas sus reglas y la regla de 10 s arreglada). Cualquier aborto la invalida, con su motivo. |
| **Toma válida para la demo** | válida, Y **sin intervención del freno de respaldo**, Y ningún agente a < 0.15 m del obstáculo, Y el obstáculo recorrió al menos la mitad de lo comandado (esto último sólo si lo comandado es ≥ 0.20 m) |
| **Métrica principal** | **distancia mínima agente–obstáculo** por toma, entre centros, medida por el mocap a 10 Hz (`d_min_obst_medida`) |
| **Objetivo** | 10 tomas válidas para la demo, en hasta 20 intentos |

**Qué se informa** (`python analizar_sesion_demo.py <…_L2_tomas.csv>`):
- las dos validez por separado, con los motivos;
- las tomas con freno, aparte, como "intervención del freno de respaldo";
- la distancia mínima de cada toma y su distribución sobre las válidas para la medición (mínimo, mediana y máximo), con cuántas quedan bajo 0.185 y bajo 0.15 m;
- aparte, los contactos en tomas no válidas y las reglas de parada que se dispararon, con la respuesta del operador.

No hay umbral de aprobación sobre la métrica: se informa.

**Expectativa, del simulador, que no es criterio:**
- Las 120 tomas con política (diseño y las dos corridas de confirmación) quedaron ≥ 0.2696 m, sin ningún freno.
- El hardware anduvo 3.5 cm más cerca de la pared que su réplica el 30-09. No sería raro ver ~0.23 m.

**Reglas de parada en la sesión. Desde el 03-10 las aplica el programa** (OK de José; antes dependían de que el operador estuviera mirando la consola).
- Después de cada toma corrida, válida o no, si se cumple una regla, la sesión frena todo y muestra "⛔ REGLA DE PARADA — …". Después pregunta "¿Seguir con la sesión?".
- **Mientras espera la respuesta, sigue frenando cada 1 s** (el mismo latido de la colocación) y mantiene vivos los enlaces.
- **Si no pudo confirmar que algún robot frenó, lo dice:** "⚠ NO SE PUDO CONFIRMAR LA DETENCIÓN: … LEVANTARLO / CORTAR ALIMENTACIÓN A MANO". Si lo confirmó, dice "detención de los robots confirmada".
- **Sólo "s" la continúa** (da igual mayúscula o minúscula). Enter, "si" o cualquier otra respuesta la termina, con veredicto DETENIDA.
- La regla y la respuesta quedan en el CSV de tomas, en las columnas `regla_parada` y `parada_respuesta`.

Las reglas:
1. **Contacto:** algún agente a < 0.15 m del obstáculo, en la distancia medida.
2. **Freno de respaldo en dos tomas corridas seguidas.**
3. **Aborto por el obstáculo:** no se mueve, no frena, enlace caído (también si se reabrió al frenar), se salió del círculo o marcador perdido. Hay que revisar el robot 7 antes de seguir.
   - Si el aborto fue por pose vencida del 7 con consultas de poses fallidas, se rotula como probable hipo del servidor de poses. Igual se detiene.
4. **Toma corrida sin distancia medida:** no se puede descartar un contacto.

**Qué hace el operador:**
- Revisa la causa antes de contestar, y contesta "s" sólo si está entendida y resuelta.
- La línea `>>> TOMA k` dice por qué una toma no vale: el motivo de la medición o el de la demo.
- Ctrl+C también corta, y los CSV se guardan igual.
- El programa decide **entre tomas**, no durante. La parada de emergencia sigue siendo la persona junto a la arena.

**Si hay que relanzar una sesión cortada:**

```text
python demo_obstaculo_movil.py --modo L2 --tomas <faltantes> --intentos 20 --intento-inicial <siguiente>
```

- Siguen la numeración, las semillas y la cuenta contra el tope de 20.
- La rampa vuelve en la 1.ª toma de la sesión nueva, y la cuenta de frenos seguidos arranca de cero.
- Resumen de las dos sesiones juntas: `python analizar_sesion_demo.py <tomas_1.csv> <tomas_2.csv>`.

**La L0 deja un resumen** en `<fecha>_L0_resumen.csv`, con veredicto, arranques, error radial y ω saturado. Lo escribe también si aborta o no puede conectar. **Que la L0 dé FALLO no bloquea la L1:** no seguir es decisión del operador.

**Tener en cuenta:**
- La rampa de arranque seguro existe sólo en la **primera** toma de la sesión, porque cuenta por canal. Desde la 2.ª, el obstáculo arranca en la decisión 0. La Fase 0 lo cubrió con las variantes "sin rampa".
- **Sin resolver:**
  - la colocación autónoma no ve al 7, por eso es manual;
  - el retroceso por pose repetida va sin CBF, y lo mitiga el freno del 7 a 0.60 m (en la L2; en la Fase 0 no se ejercitó);
  - los offsets de rumbo del 7 y del 4 son los de la tabla.
