import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""1) Métricas del HARDWARE (sin réplica) de los 50 válidos del 30-09 (S1..S5)
y del control 26-09 (10 válidos). Tabla por episodio con recálculo desde el CSV
de decisiones (verificación), resúmenes por sesión y total, tablas markdown y
comparación con el 26-09 (Welch, Mann-Whitney y ajustada por semilla).
Cruce con los resúmenes de consola (ddof 0) de S1, S2, S3, S5 y 26-09
(S4: consola no pegada → sin dato). NO usa 'cobertura_replica'."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import re
import numpy as np
import pandas as pd
from scipy import stats
from a30f_metricas_comun import (SES, S30, VALIDOS_ESPERADOS, ROBOT, leer_ep, leer_dec,
                                 arreglos, dist_pares, ols, dummies, md_tabla, SP)

pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 60)
pd.set_option("display.max_rows", 400)

filas = []
for ses, (fe, fd, orden) in SES.items():
    E = leer_ep(fe)
    D = leer_dec(fd)
    for r in E:
        ep = int(r["episodio"])
        s = D[D.episodio == ep].sort_values(["agente", "paso"])
        P = arreglos(s)
        dd, _ = dist_pares(P)
        c15 = int((dd < 0.15).any(axis=0).sum())
        c22 = int((dd < 0.22).any(axis=0).sum())
        dp_ag = s.groupby("agente")["d_pared"].min()
        # recorrido por agente (suma de |Δp| entre decisiones consecutivas)
        rec = np.linalg.norm(np.diff(P[:, :, :2], axis=0), axis=-1).sum(axis=0)
        act = 0
        for ag, t in s.groupby("agente"):
            e = t.en_escape.to_numpy()
            act += int(((e[1:] == 1) & (e[:-1] == 0)).sum() + (e[0] == 1))
        errs = [float(r[f"col_err_m_a{i}"]) for i in range(5)]
        fuera = [i for i in range(5) if r[f"col_estado_a{i}"] != "listo"]
        filas.append(dict(
            ses=ses, orden=orden, ep=ep, semilla=int(r["semilla"]), valido=int(r["valido"]),
            motivo=r["motivo"][:60], dec=int(r["decisiones"]), dur=float(r["duracion_s"]),
            cob=float(r["cobertura_aoi"]),
            c15=int(r["colisiones_015"]), c22=int(r["colisiones_022"]),
            dpmin=float(r["d_pared_min"]), viola=int(r["viola_018"]),
            cbf=float(r["frac_cbf"]), esc=int(r["n_escape"]), act=act,
            vec=float(r["frac_vecino"]),
            drec_min=float(r["dist_min_robot"]), drec_max=float(r["dist_max_robot"]),
            dmin_par=float(dd.min()),
            p95=float(r["ciclo_p95_ms"]), s100=int(r["ciclos_sobre_100ms"]),
            pf=int(r["poses_fallidas"]), prech=int(r["poses_rechazadas"]),
            dec_ret=int(r["decisiones_retroceso"]), n_rep=int(s.repetida.sum()),
            f010=float((s.d_pared < 0.10).mean()), f018=float((s.d_pared < 0.18).mean()),
            col_listos=int(r["col_listos"]), col_t=float(r["col_t_s"]) if r["col_t_s"] else np.nan,
            col_err_max=max(errs), col_err_med=float(np.mean(errs)),
            fuera="".join(f"r{ROBOT[i]}" for i in fuera) or "-",
            # verificaciones contra decisiones
            ok_n=len(s) == 5 * int(r["decisiones"]),
            ok_dp=abs(dp_ag.min() - float(r["d_pared_min"])) < 1e-9,
            ok_vi=int((dp_ag < 0.18).sum()) == int(r["viola_018"]),
            ok_cbf=abs(s.cbf_intervino.mean() - float(r["frac_cbf"])) < 1e-9,
            ok_esc=int(s.en_escape.sum()) == int(r["n_escape"]),
            ok_vec=abs(s.con_vecino.mean() - float(r["frac_vecino"])) < 1e-9,
            ok_c=(c15 == int(r["colisiones_015"]) and c22 == int(r["colisiones_022"])),
            err_rec=max(abs(rec.min() - float(r["dist_min_robot"])),
                        abs(rec.max() - float(r["dist_max_robot"]))),
        ))
T = pd.DataFrame(filas)
T.to_csv(SP + r"\a30f_metricas_tabla.csv", index=False)

print("Definiciones (desde sesion_robotat.py, líneas ~2830–3030, leído sin modificar):")
print("  cob = cobertura_aoi (1 − fracción de celdas AoI sin cubrir al final); c15/c22 = nº de PARES distintos\n"
      "  que en alguna decisión estuvieron a < 0.15/0.22 m (centro a centro); dpmin = mín sobre agentes y\n"
      "  decisiones de min(x,3−x,y,3−y); viola = nº de agentes con d_pared mín < 0.18; cbf = fracción de\n"
      "  decisiones-agente con intervención CBF; esc = n_escape = nº de DECISIONES-AGENTE en escape (la consola\n"
      "  lo rotula 'activaciones de escape', pero es suma de en_escape); act = activaciones reales (0→1);\n"
      "  vec = frac_vecino = fracción de decisiones-agente con algún vecino en la observación (obs[8:16] ≠ 0);\n"
      "  drec_min = dist_min_robot = RECORRIDO acumulado (m, marco env) del robot que MENOS recorrió — NO es\n"
      "  una distancia de separación; dmin_par = separación mínima entre pares (recalculada de decisiones).")

print("\n=== verificación de las métricas del CSV de episodios contra el CSV de decisiones (todos los episodios) ===")
print(T[["ok_n", "ok_dp", "ok_vi", "ok_cbf", "ok_esc", "ok_vec", "ok_c"]].all().to_string())
print(f"  máx |recorrido recalculado − dist_min/max_robot|: válidos {T[T.valido == 1].err_rec.max():.3e} m · "
      f"inválidos {T[T.valido == 0].err_rec.max():.3e} m (el lazo aborta a mitad de la última decisión)")

print("\n=== válidos observados vs esperados ===")
for ses in S30:
    obs = T[(T.ses == ses) & (T.valido == 1)].ep.tolist()
    print(f"  {ses}: {obs}  {'OK' if obs == VALIDOS_ESPERADOS[ses] else '≠ ESPERADO ' + str(VALIDOS_ESPERADOS[ses])}"
          f" · intentos {int((T.ses == ses).sum())}")
v26 = T[(T.ses == "26-09") & (T.valido == 1)]
print(f"  26-09: {v26.ep.tolist()} (n={len(v26)}) · semillas {v26.semilla.tolist()}")

V = T[T.valido == 1].copy()
V30 = V[V.ses.isin(S30)]
print(f"\n  total 30-09 válidos: {len(V30)} · semillas distintas {V30.semilla.nunique()} "
      f"({sorted(V30.semilla.unique().tolist())})")
print("  semilla = 420000 + ep − 1 en todos los episodios de las 6 sesiones:",
      bool((T.semilla == 420000 + T.ep - 1).all()))

print("\n=== TABLA POR EPISODIO (válidos) ===")
cols = ["ses", "ep", "semilla", "cob", "c15", "c22", "dpmin", "viola", "cbf", "esc", "act", "vec",
        "drec_min", "dmin_par", "p95", "s100", "n_rep", "dec_ret", "f010", "col_listos", "fuera"]
print(V[cols].to_string(index=False, float_format=lambda v: f"{v:.4f}"))

# ── resúmenes ───────────────────────────────────────────────────────────
GR = [(s, V[V.ses == s]) for s in S30] + [("Total 30-09", V30), ("26-09", V[V.ses == "26-09"])]
M = [("cob", "cobertura_aoi"), ("c15", "colisiones_015"), ("c22", "colisiones_022"),
     ("dpmin", "d_pared_min [m]"), ("viola", "viola_018"), ("cbf", "frac_cbf"),
     ("esc", "n_escape (dec-agente)"), ("act", "activaciones escape"), ("vec", "frac_vecino"),
     ("drec_min", "dist_min_robot [m]"), ("dmin_par", "separación mín. par [m]"),
     ("p95", "ciclo_p95_ms"), ("s100", "ciclos >100 ms"), ("f010", "frac filas d_pared<0.10")]
print("\n=== RESUMEN DE VÁLIDOS: media ± sd(ddof=1) · mediana · mín–máx · suma ===")
for g, sub in GR:
    print(f"--- {g} (n={len(sub)}) ---")
    for k, nom in M:
        a = sub[k].to_numpy(float)
        print(f"   {nom:26s} {a.mean():9.4f} ± {a.std(ddof=1):8.4f} · med {np.median(a):8.4f} · "
              f"{a.min():.4f}–{a.max():.4f} · suma {a.sum():.4f}")

f4 = lambda v: f"{v:.4f}"
print("\n=== TABLA MARKDOWN 1 — cobertura AoI del hardware (válidos) ===")
fil = []
for g, sub in GR:
    a = sub.cob.to_numpy()
    fil.append([g, len(sub), f4(a.mean()), f4(a.std(ddof=1)), f4(a.min()), f4(a.max()),
                f4(np.median(a))])
print(md_tabla(["Sesión", "n", "media", "sd (ddof 1)", "mín", "máx", "mediana"], fil))

print("\n=== TABLA MARKDOWN 2 — seguridad y actividad de capas (válidos; media ± sd ddof 1) ===")
fil = []
for g, sub in GR:
    ms = lambda k, f="{:.4f}": f"{f.format(sub[k].mean())} ± {f.format(sub[k].std(ddof=1))}"
    fil.append([g, len(sub),
                f"{int(sub.c15.sum())} ({int((sub.c15 > 0).sum())} eps)",
                f"{int(sub.c22.sum())} ({int((sub.c22 > 0).sum())} eps)",
                ms("dpmin"), f4(sub.dpmin.min()), ms("viola", "{:.2f}"), ms("cbf", "{:.3f}"),
                ms("esc", "{:.1f}"), ms("act", "{:.1f}"), ms("vec", "{:.3f}"), ms("drec_min", "{:.2f}"),
                ms("dmin_par", "{:.3f}")])
print(md_tabla(["Sesión", "n", "colisiones_015 (suma)", "colisiones_022 (suma)", "d_pared_min [m]",
                "d_pared_min mín [m]", "viola_018", "frac_cbf", "n_escape", "activaciones escape",
                "frac_vecino", "dist_min_robot [m] (recorrido)", "separación mín. par [m]"], fil))

print("\n=== TABLA MARKDOWN 3 — operación (válidos; media ± sd ddof 1) ===")
fil = []
for g, sub in GR:
    fil.append([g, len(sub), f"{sub.p95.mean():.1f} ± {sub.p95.std(ddof=1):.1f}",
                f"{int(sub.s100.sum())}", f"{sub.dur.mean():.2f} ± {sub.dur.std(ddof=1):.2f}",
                f"{int(sub.pf.sum())}", f"{int(sub.prech.sum())}", f"{int(sub.n_rep.sum())}",
                f"{int(sub.dec_ret.sum())}", f"{int((sub.fuera != '-').sum())}"])
print(md_tabla(["Sesión", "n", "ciclo p95 [ms]", "ciclos >100 ms (suma)", "duración [s]",
                "poses fallidas (suma)", "poses rechazadas (suma)", "filas pose repetida (suma)",
                "decisiones-agente en retroceso (suma)", "eps con robot fuera del blanco"], fil))

# ── comparación con el 26-09 ────────────────────────────────────────────
print("\n=== COMPARACIÓN Total 30-09 (n=50) − 26-09 (n=10), válidos ===")
A26 = V[V.ses == "26-09"]
W = pd.concat([V30.assign(g30=1.0), A26.assign(g30=0.0)])
S, _ = dummies(W.semilla)
one = np.ones((len(W), 1))
fil = []
for k, nom in M:
    a, b = V30[k].to_numpy(float), A26[k].to_numpy(float)
    if a.std() == 0 and b.std() == 0:
        print(f"   {nom:26s} constante en ambos ({a.mean():.4f} vs {b.mean():.4f})")
        fil.append([nom, f4(a.mean()), f4(b.mean()), "—", "—", "—", "—"])
        continue
    w = stats.ttest_ind(a, b, equal_var=False)
    ci = w.confidence_interval(0.95)
    mw = stats.mannwhitneyu(a, b, alternative="two-sided")
    # ajustada por semilla: y ~ semilla + g30
    X = np.hstack([one, S, W[["g30"]].to_numpy()])
    y = W[k].to_numpy(float)
    ss, beta = ols(X, y)
    gl = len(y) - np.linalg.matrix_rank(X)
    cov = ss / gl * np.linalg.pinv(X.T @ X)
    ee = np.sqrt(cov[-1, -1])
    tq = stats.t.ppf(0.975, gl)
    pa = 2 * stats.t.sf(abs(beta[-1] / ee), gl)
    print(f"   {nom:26s} 30-09 {a.mean():9.4f} · 26-09 {b.mean():9.4f} · dif {a.mean()-b.mean():+9.4f} "
          f"IC95 Welch [{ci.low:+.4f}, {ci.high:+.4f}] p {w.pvalue:.4f} · MW p {mw.pvalue:.4f} · "
          f"ajust. semilla {beta[-1]:+.4f} IC95 [{beta[-1]-tq*ee:+.4f}, {beta[-1]+tq*ee:+.4f}] p {pa:.4f} (gl {gl})")
    fil.append([nom, f4(a.mean()), f4(b.mean()), f"{a.mean()-b.mean():+.4f}",
                f"[{ci.low:+.4f}, {ci.high:+.4f}] p={w.pvalue:.3f}", f"{mw.pvalue:.3f}",
                f"{beta[-1]:+.4f} [{beta[-1]-tq*ee:+.4f}, {beta[-1]+tq*ee:+.4f}] p={pa:.3f}"])
print("\n=== TABLA MARKDOWN 4 — 30-09 (n=50) vs 26-09 (n=10) ===")
print(md_tabla(["Métrica", "30-09", "26-09", "dif.", "IC95 Welch", "Mann-Whitney p",
                "dif. ajustada por semilla [IC95]"], fil))
print(f"   semillas del 26-09 válidas: {sorted(A26.semilla.tolist())}")

# ── cruce con las consolas (ddof 0) ─────────────────────────────────────
print("\n=== CRUCE CON LOS RESÚMENES DE CONSOLA (la consola imprime media y desvío ddof 0) ===")
CONS = {"26-09": "consola_20260926.txt", "S1": "consola_20260930.txt", "S2": "consola_20260930_02.txt",
        "S3": "consola_20260930_03.txt", "S4": None, "S5": "consola_20260930_05.txt"}
ETQ = [("cobertura AoI", "cob", 4), ("colisiones < 0.15 m", "c15", 2), ("colisiones < 0.22 m", "c22", 2),
       ("d_pared mínima [m]", "dpmin", 6), ("agentes que violan 0.18", "viola", 2),
       ("intervención CBF", "cbf", 3), ("activaciones de escape", "esc", 1),
       ("decisiones con vecino", "vec", 3), ("distancia mín. por robot [m]", "drec_min", 2),
       ("ciclo p95 [ms]", "p95", 1)]
for ses, fn in CONS.items():
    if fn is None:
        print(f"  {ses}: consola NO pegada → sin dato (no se cruza)")
        continue
    txt = open(SP + "\\" + fn, encoding="utf-8", errors="replace").read().splitlines()
    i0 = max(i for i, l in enumerate(txt) if l.startswith("métrica") and "media" in l)
    sub = V[V.ses == ses]
    malos = []
    for et, k, dec in ETQ:
        l = next(l for l in txt[i0:i0 + 15] if l.startswith(et))
        m_c, s_c = [float(x) for x in re.findall(r"-?\d+\.\d+", l[len(et):])[:2]]
        m_m, s_m = round(sub[k].mean(), dec), round(sub[k].std(ddof=0), dec)
        if abs(m_c - m_m) > 1.01 * 10 ** -dec or abs(s_c - s_m) > 1.01 * 10 ** -dec:
            malos.append(f"{k}: consola {m_c}±{s_c} vs CSV {m_m}±{s_m}")
    print(f"  {ses}: {len(ETQ)} métricas cruzadas · discrepancias {len(malos)} {malos if malos else ''}")
print("\n→ a30f_metricas_tabla.csv")
