import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico (8): coordenadas de laboratorio de los puntos citados (calibración de la tarea)."""
import numpy as np
ANG, ESC, TRAS = 0.0084726, 1.0166876, np.array([1.5061547, 1.2563353])
def env_a_lab(p):
    c, s = np.cos(-ANG), np.sin(-ANG)
    d = np.asarray(p) - TRAS
    return np.array([c * d[0] - s * d[1], s * d[0] + c * d[1]]) / ESC
for nom, p in (("mínimos de r5 (env)", (2.73, 0.11)), ("esquina (3,0) del env", (3.0, 0.0)),
               ("grupo E (env)", (2.826, 2.741)), ("C (env)", (2.52, 2.79))):
    l = env_a_lab(p)
    print(f"{nom:24s} env ({p[0]:.3f}, {p[1]:.3f}) → lab ({l[0]:+.3f}, {l[1]:+.3f}) m")
