import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): reimplementación PROPIA con numpy del chequeo de diversidad
(diversidad_arranques.evaluar + sesion_robotat.sortear_poses_arranque), sin importar nada del
proyecto (importar diversidad_arranques cargaría sesion_robotat -> la pila). Se valida contra los
percentiles que imprimieron las consolas reales (s1, s2, s3, s5) y luego se recalculan los casos
de A15/A16. SOLO LECTURA."""
import sys
sys.dont_write_bytecode = True
import csv, os, math
from collections import Counter
import numpy as np

D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
EPI = {1: "20260930_sesion-evaluacion_etapa7_episodios.csv", 2: "20260930_sesion-evaluacion_etapa7_episodios_02.csv",
       3: "20260930_sesion-evaluacion_etapa7_episodios_03.csv", 4: "20260930_sesion-evaluacion_etapa7_episodios_04.csv",
       5: "20260930_sesion-evaluacion_etapa7_episodios_05.csv"}
LO, HI, GR = 0.45, 2.55, 4
MARGEN, SEP, ARENA = 0.45, 0.45, 3.0
EST = [("celdas_cubiertas", "baja"), ("disp_centroide", "baja"), ("vecino_medio", "ambas"),
       ("resultante_rumbo", "alta"), ("ks_x", "alta"), ("ks_y", "alta")]
out = []
P = out.append


def sortear(n, rng):
    puestos = []
    for _ in range(n):
        for _t in range(400):
            c = np.array([rng.uniform(MARGEN, ARENA - MARGEN), rng.uniform(MARGEN, ARENA - MARGEN)])
            if all(np.linalg.norm(c - p) > SEP for p in puestos):
                puestos.append(c)
                break
        else:
            raise RuntimeError
    return puestos


def sesion_mc(n_ep, n_ag, rng):
    s = []
    for _ in range(n_ep):
        b = sortear(n_ag, rng)
        th = rng.uniform(-math.pi, math.pi, size=n_ag)
        s.append(np.array([[b[i][0], b[i][1], th[i]] for i in range(n_ag)]))
    return s


def ks(a, b):
    a, b = np.sort(a), np.sort(b)
    t = np.concatenate([a, b])
    return float(np.max(np.abs(np.searchsorted(a, t, side="right") / len(a) - np.searchsorted(b, t, side="right") / len(b))))


def stats_(eps, rx, ry):
    T = np.concatenate(eps)
    x, y, th = T[:, 0], T[:, 1], T[:, 2]
    cel = lambda v: np.clip(((v - LO) / (HI - LO) * GR).astype(int), 0, GR - 1)
    cub = len(set(zip(cel(x).tolist(), cel(y).tolist())))
    cen = np.array([e[:, :2].mean(0) for e in eps])
    vec = []
    for e in eps:
        p = e[:, :2]
        d = np.linalg.norm(p[:, None] - p[None], axis=2)
        np.fill_diagonal(d, np.inf)
        vec += d.min(1).tolist()
    return {"celdas_cubiertas": cub / GR ** 2, "disp_centroide": float(cen.std(0).mean()),
            "vecino_medio": float(np.mean(vec)), "resultante_rumbo": float(abs(np.mean(np.exp(1j * th)))),
            "ks_x": ks(x, rx), "ks_y": ks(y, ry)}


def evaluar(eps, semilla=0, nref=1000):
    n_ep, n_ag = len(eps), eps[0].shape[0]
    rng = np.random.default_rng(semilla)
    g = np.concatenate(sesion_mc(400, n_ag, rng))
    rx, ry = g[:, 0], g[:, 1]
    v = stats_(eps, rx, ry)
    sims = [stats_(sesion_mc(n_ep, n_ag, rng), rx, ry) for _ in range(nref)]
    pct, band = {}, []
    for nom, cola in EST:
        d = np.array([s[nom] for s in sims])
        p = 100 * (np.mean(d < v[nom]) + 0.5 * np.mean(d == v[nom]))
        pct[nom] = p
        if (cola == "baja" and p < 5) or (cola == "alta" and p > 95) or (cola == "ambas" and (p < 2.5 or p > 97.5)):
            band.append(nom)
    ext = [n for n in band if pct[n] < 0.5 or pct[n] > 99.5]
    if not band:
        ver = "compatible"
    elif len(band) == 1 and not ext:
        ver = "aviso (1 estadístico en la cola)"
    else:
        ver = "⚠ POCO REPRESENTATIVOS"
    return v, pct, band, ver


def linea(nombre, eps, **kw):
    v, pct, band, ver = evaluar(eps, **kw)
    P(f"{nombre} (n={len(eps)}): " + " ".join(f"{k}={v[k]:.3f}(p{pct[k]:.1f})" for k, _ in EST) + f" -> banderas={band} veredicto={ver}")
    return v, pct, band, ver


E = {}
for s, a in EPI.items():
    with open(os.path.join(D, a), encoding="utf-8", newline="") as fh:
        E[s] = list(csv.DictReader(fh))
f = lambda r, c: float(r[c])


def mat(r, pref=("x0", "y0", "th0")):
    return np.array([[f(r, f"{pref[0]}_a{i}"), f(r, f"{pref[1]}_a{i}"), f(r, f"{pref[2]}_a{i}")] for i in range(5)])


# --- reproducción de los blancos desde la semilla ---
err = 0.0
for s in E:
    for r in E[s]:
        b = sortear(5, np.random.default_rng(int(r["semilla"])))
        for i in range(5):
            err = max(err, abs(b[i][0] - f(r, f"blanco_x_a{i}")), abs(b[i][1] - f(r, f"blanco_y_a{i}")))
P(f"error máximo blanco sorteado vs CSV (57 filas): {err:.3e} m")

# --- validación contra consolas (percentiles impresos por el código real) ---
P("VALIDACIÓN (consola s1: celdas p68.5, disp p19.5, vecino 0.717 p28.7, rumbo p85.1, ks_x p24.1, ks_y p6.9; "
  "s2: vecino 0.677 p4.2, rumbo p3.2; s3: vecino 0.743 p55.4, ks_x p4.9; s5: vecino 0.693 p10.8, ks_y p5.5)")
por_ses = {}
for s in [1, 2, 3, 4, 5]:
    val = [mat(r) for r in E[s] if r["valido"].strip() == "1"]
    por_ses[s] = linea(f"s{s} válidos x0", val)
    bl = [mat(r, ("blanco_x", "blanco_y", "blanco_th")) for r in E[s]]
    linea(f"s{s} blancos de los {len(bl)} intentos", bl)

# --- casos del analista ---
val50 = []; val45 = []; val50b = []
for s in [1, 2, 3, 4, 5]:
    for r in E[s]:
        if r["valido"].strip() != "1":
            continue
        m = mat(r)
        val50.append(m)
        est = [r[f"col_estado_a{i}"].strip() for i in range(5)]
        pares = min(np.hypot(*(m[i, :2] - m[j, :2])) for i in range(5) for j in range(i + 1, 5))
        if pares >= 0.31:
            val45.append(m)
        mb = m.copy()
        for i in range(5):
            if est[i] != "listo":
                mb[i] = [f(r, f"blanco_x_a{i}"), f(r, f"blanco_y_a{i}"), f(r, f"blanco_th_a{i}")]
        val50b.append(mb)
linea("50 válidos x0", val50)
linea("45 válidos sin fuera de soporte", val45)
linea("50 válidos con no-listo en su blanco", val50b)
bl57 = [mat(r, ("blanco_x", "blanco_y", "blanco_th")) for s in [1, 2, 3, 4, 5] for r in E[s]]
linea("blancos 57 intentos", bl57)
sem = {}
for s in [1, 2, 3, 4, 5]:
    for r in E[s]:
        sem.setdefault(int(r["semilla"]), mat(r, ("blanco_x", "blanco_y", "blanco_th")))
cnt = Counter(int(r["semilla"]) for s in [1, 2, 3, 4, 5] for r in E[s])
cntv = Counter(int(r["semilla"]) for s in [1, 2, 3, 4, 5] for r in E[s] if r["valido"].strip() == "1")
P(f"repeticiones por semilla (57 intentos): {dict(sorted(cnt.items()))}")
P(f"repeticiones por semilla (50 válidos): {dict(sorted(cntv.items()))}  distintas={len(cntv)}")
b12 = [sem[k] for k in sorted(sem)]
linea("12 configuraciones distintas (blancos)", b12)
T = np.concatenate(b12)
cel = lambda v: np.clip(((v - LO) / (HI - LO) * GR).astype(int), 0, GR - 1)
ocup = set(zip(cel(T[:, 0]).tolist(), cel(T[:, 1]).tolist()))
vac = [(i, j) for i in range(GR) for j in range(GR) if (i, j) not in ocup]
w = (HI - LO) / GR
P("celdas vacías (12 configs): " + str([((LO + i * w, LO + (i + 1) * w), (LO + j * w, LO + (j + 1) * w)) for i, j in vac]))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "a30f_verif_robots_4_diversidad_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
