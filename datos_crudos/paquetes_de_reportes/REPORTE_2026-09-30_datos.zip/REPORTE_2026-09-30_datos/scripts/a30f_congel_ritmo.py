import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_congel_ritmo.py — ¿los congelamientos coinciden con un "hipo" de ritmo del lazo?
Firma buscada (vista en s5 ep9 157 y s4 ep9 270): en la decisión ANTERIOR todos los
agentes avanzan ~2-2.5× lo normal (consulta tardía) y en la del evento los agentes NO
congelados avanzan ~1 mm (dos consultas casi seguidas). SÓLO LECTURA.

Métrica por decisión (ses, ep, paso):
  Δ_k(paso) = |p_k(paso) − p_k(paso−1)| (mm) de cada agente k.
  m(paso)   = mediana de Δ sobre los agentes NO repetidos en ese paso.
  ref(paso) = mediana de m(q) para q ∈ [paso−10, paso+10] salvo {paso−1, paso, paso+1}.
  r(paso)   = m(paso)/ref ; r_prev = m(paso−1)/ref.
  HIPO en paso si r < 0.30 y r_prev > 1.6 (paso ≥ 12 para tener ventana).
Denominador: decisiones con los 5 agentes presentes.
"""
import math, sys
from collections import Counter, defaultdict
import numpy as np
from scipy import stats
sys.stdout.reconfigure(encoding='utf-8')
import a30f_congel_comun as K
S, E, I = K.S, K.E, K.I

R_BAJO, R_ALTO = 0.30, 1.6


def tabla_delta(ses):
    """{ep: {paso: {ag: (Δmm, rep)}}}"""
    out = defaultdict(lambda: defaultdict(dict))
    for (ep, ag), s in S[ses].items():
        f = s['f']
        for k in range(1, len(f)):
            a, b = f[k - 1], f[k]
            if b['paso'] != a['paso'] + 1:
                continue
            out[ep][b['paso']][ag] = (1000 * math.hypot(b['x'] - a['x'], b['y'] - a['y']), b['rep'])
    return out


T = {ses: tabla_delta(ses) for ses in S}


def m_de(ses, ep, paso, excluir=()):
    d = T[ses][ep].get(paso, {})
    v = [dm for ag, (dm, rep) in d.items() if not rep and ag not in excluir]
    return float(np.median(v)) if v else float('nan')


def ref_de(ses, ep, paso, excluir=()):
    v = [m_de(ses, ep, q, excluir) for q in range(paso - 10, paso + 11) if abs(q - paso) > 1]
    v = [x for x in v if not math.isnan(x)]
    return float(np.median(v)) if v else float('nan')


print('=' * 118)
print('1) CADA EVENTO: movimiento de los OTROS agentes (no congelados) en la decisión del evento y en la anterior')
print('   m = mediana Δ (mm) de los otros agentes; ref = mediana de m en ±10 decisiones (sin paso−1..paso+1)')
RES = []
for ses in S:
    for it in I[ses]:
        ep, p = it['ep'], it['r']['paso']
        congel = {x['ag'] for x in I[ses] if x['ep'] == ep and x['r']['paso'] == p}
        m0 = m_de(ses, ep, p, congel); mp = m_de(ses, ep, p - 1, congel); ref = ref_de(ses, ep, p, congel)
        r0, rp = m0 / ref if ref else float('nan'), mp / ref if ref else float('nan')
        hipo = (r0 < R_BAJO and rp > R_ALTO)
        it['r_otros'], it['rprev_otros'], it['hipo'] = r0, rp, hipo
        # Δ propio en la decisión anterior (paso−1): ¿la última viva llegó tras un salto?
        dprop = T[ses][ep].get(p - 1, {}).get(it['ag'], (float('nan'), False))[0]
        RES.append(it)
        print(f"  {ses:6s} ep{ep:2d} a{it['ag']}/r{it['robot']} paso {p:3d} ({it['tipo']}) racha {it['racha']:2d}  otros: m(p−1) {mp:5.1f}  m(p) {m0:5.1f}  ref {ref:5.1f}"
              f"  → r_prev {rp:4.2f}  r {r0:4.2f}  {'HIPO' if hipo else ''}   Δ propio en p−1 {dprop:5.1f} mm")

print('=' * 118)
print('2) TASA BASE DE HIPOS por sesión (todas las decisiones con los 5 agentes; paso ≥ 12)')
TOT = {}
HIPOS = []
for ses in S:
    for grupo, cond in [('válidos', '1'), ('abortados', '0')]:
        n = 0; hip = []; rep_en_hipo = 0; rep_fuera = 0; dec_rep = 0
        for ep, pasos in T[ses].items():
            if E[ses][ep]['valido'] != cond:
                continue
            for p, d in pasos.items():
                if p < 12 or len(d) < 5:
                    continue
                n += 1
                m0 = m_de(ses, ep, p); mp = m_de(ses, ep, p - 1); ref = ref_de(ses, ep, p)
                if not ref or math.isnan(ref) or math.isnan(m0) or math.isnan(mp):
                    continue
                es_hipo = m0 / ref < R_BAJO and mp / ref > R_ALTO
                hay_ini = any(x['ep'] == ep and x['r']['paso'] == p for x in I[ses])
                if es_hipo:
                    HIPOS.append((ses, ep, p, hay_ini))
                    hip.append((ep, p, round(mp / ref, 2), round(m0 / ref, 2), hay_ini))
                    rep_en_hipo += hay_ini
                else:
                    rep_fuera += hay_ini
        TOT[(ses, grupo)] = (n, len(hip), rep_en_hipo, rep_fuera)
        if n:
            print(f"  {ses:6s} {grupo:9s} decisiones {n:5d}  hipos {len(hip):3d} ({1000*len(hip)/n:.2f} ‰)  hipos con inicio de congelamiento {rep_en_hipo}"
                  f"  | decisiones no-hipo con inicio {rep_fuera}")
            if hip:
                print('       hipos (ep, paso, r_prev, r, ¿inicio?): ' + ' '.join(str(h) for h in hip))

print('=' * 118)
print('3) ASOCIACIÓN hipo ↔ inicio de congelamiento (decisiones con ≥1 inicio), por sesión y 30-09 agregado')
for grupo in ['válidos', 'abortados']:
    agg = np.zeros(4, int)
    for ses in S:
        n, h, rh, rf = TOT[(ses, grupo)]
        if n == 0:
            continue
        if ses in K.SES30:
            agg += np.array([n, h, rh, rf])
    n, h, rh, rf = agg
    if n:
        tabla = [[rh, h - rh], [rf, (n - h) - rf]]
        _, p = stats.fisher_exact(tabla)
        print(f"  30-09 {grupo}: inicio|hipo {rh}/{h} = {rh/max(h,1):.3f}  vs  inicio|no-hipo {rf}/{n-h} = {rf/max(n-h,1):.5f}   Fisher p {p:.3g}")
n, h, rh, rf = [sum(TOT[('26-09', g)][k] for g in ['válidos', 'abortados']) for k in range(4)]
print(f"  26-09 todos: hipos {h}/{n}; inicio|hipo {rh}/{h}; inicio|no-hipo {rf}/{n-h}")

print('=' * 118)
print('4) Umbral alternativo (robustez): r < 0.5 y r_prev > 1.4 — eventos que cumplen')
for ses in S:
    for it in I[ses]:
        if it['r_otros'] < 0.5 and it['rprev_otros'] > 1.4:
            print(f"  {ses} ep{it['ep']} a{it['ag']}/r{it['robot']} paso {it['r']['paso']} ({it['tipo']}) r_prev {it['rprev_otros']:.2f} r {it['r_otros']:.2f}")

print('=' * 118)
print('5) s3 ep3 (aborto por antigüedad SIN pose repetida, sin fallidas ni rechazos): últimas decisiones')
for p in range(371, 381):
    d = T['s3'][3].get(p, {})
    print(f"  paso {p}: Δ mm por agente " + '  '.join(f"a{ag}:{d[ag][0]:.1f}{'R' if d[ag][1] else ''}" for ag in sorted(d))
          + f"   m {m_de('s3', 3, p):.1f}")
print(f"  ref (mediana de m en 360–370): {np.median([m_de('s3', 3, q) for q in range(360, 371)]):.1f} mm")

print('=' * 118)
print('6) HIPOS y ciclos > 100 ms (columna ciclos_sobre_100ms del CSV de episodios), por episodio (30-09 y 26-09)')
porep = Counter((s, e) for s, e, p, h in HIPOS)
xs, ys = [], []
for ses in S:
    for ep, e in sorted(E[ses].items()):
        c100 = int(e['ciclos_sobre_100ms'] or 0)
        nh = porep[(ses, ep)]
        if ses in K.SES30:
            xs.append(c100); ys.append(nh)
        if nh or c100:
            print(f"  {ses:6s} ep{ep:2d} válido={e['valido']} hipos {nh}  ciclos>100ms {c100}  ciclo_p95 {float(e['ciclo_p95_ms']):.1f} ms"
                  f"  pasos de hipo {[p for s2, e2, p, h in HIPOS if (s2, e2) == (ses, ep)]}")
rho, p = stats.spearmanr(xs, ys)
con = sum(1 for x, y in zip(xs, ys) if y > 0 and x > 0); hip_tot = sum(1 for y in ys if y > 0)
print(f"  30-09 (57 episodios): episodios con hipo {hip_tot}, de ellos con ciclos>100ms > 0: {con};"
      f" Spearman(ciclos>100ms, hipos) rho {rho:.3f} p {p:.3g}")
print(f"  hipos totales 30-09: {sum(1 for s, e, p, h in HIPOS if s in K.SES30)}; con inicio de congelamiento: {sum(1 for s, e, p, h in HIPOS if s in K.SES30 and h)}")
