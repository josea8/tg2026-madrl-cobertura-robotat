import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico de completitud (a30f_critico_): huecos cruzados entre deriva, congelamientos,
robots y métricas. SOLO LECTURA de los CSV de evaluación del 26-09 y 30-09.
NO lee ningún archivo de réplica y NO usa cobertura_replica (cegado).
Uso: python -B a30f_critico_1.py > a30f_critico_1_salida.txt"""
import sys
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SES = {
    "26-09": ("20260926_sesion-evaluacion_etapa7_episodios.csv",
              "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
    "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones.csv"),
    "S2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_02.csv"),
    "S3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_03.csv"),
    "S4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_04.csv"),
    "S5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_05.csv"),
}
S30 = ["S1", "S2", "S3", "S4", "S5"]
ROB = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
ANG, ESC, TRAS = 0.0084726, 1.0166876, np.array([1.5061547, 1.2563353])
FACTOR, DT, DEC_RAMPA = 0.40, 0.1, 50


def env_a_lab(x, y):
    c, s = np.cos(-ANG), np.sin(-ANG)
    dx, dy = np.asarray(x) - TRAS[0], np.asarray(y) - TRAS[1]
    return (c * dx - s * dy) / ESC, (s * dx + c * dy) / ESC


E, D = {}, {}
for s, (fe, fd) in SES.items():
    e = pd.read_csv(f"{RS}\\{fe}")
    e["ses"] = s
    E[s] = e
    d = pd.read_csv(f"{RS}\\{fd}")
    d["ses"] = s
    d = d.sort_values(["episodio", "agente", "paso"]).reset_index(drop=True)
    x, y = d.pose_env_x.to_numpy(), d.pose_env_y.to_numpy()
    d["dp"] = np.minimum.reduce([x, 3 - x, y, 3 - y])
    g = d.groupby(["episodio", "agente"])
    same = ((d.pose_env_x == g.pose_env_x.shift()) & (d.pose_env_y == g.pose_env_y.shift())
            & (d.pose_env_th == g.pose_env_th.shift()))
    d["rep"] = same.fillna(False).astype(bool)
    d["ini"] = d.rep & ~d.groupby(["episodio", "agente"]).rep.shift().fillna(False).astype(bool)
    lx, ly = env_a_lab(x, y)
    d["lx"], d["ly"] = lx, ly
    d["r_lab0"] = np.hypot(lx, ly)
    D[s] = d
EP = pd.concat(E.values(), ignore_index=True)
DE = pd.concat(D.values(), ignore_index=True)
val = EP[EP.valido == 1].copy()
v30 = val[val.ses.isin(S30)].copy()
v26 = val[val.ses == "26-09"].copy()
print(f"válidos 30-09 {len(v30)} · 26-09 {len(v26)} · intentos 30-09 {int(EP.ses.isin(S30).sum())}")


def sep(t):
    print("\n" + "=" * 100 + f"\n{t}\n" + "=" * 100)


# ---------------------------------------------------------------- P0
sep("P0. Régimen y calibración constantes entre sesiones (factor, rpm_aborto, colocación, robots, offsets)")
cols = ["factor", "rpm_aborto", "colocacion"] + [f"robot_a{i}" for i in range(5)] \
    + [f"offset_deg_a{i}" for i in range(5)] + [f"offset_origen_a{i}" for i in range(5)] + ["decisiones"]
for c in cols:
    vals = {s: sorted(set(E[s][E[s].valido == 1][c].astype(str))) for s in SES}
    uniq = set(sum(vals.values(), []))
    print(f"  {c:18s} {'CONSTANTE' if len(uniq) == 1 else 'VARÍA'}: {sorted(uniq)[:6]}")

# ---------------------------------------------------------------- P1
sep("P1. Rampa de arranque (primeras 50 decisiones de la SESIÓN a 25 % de V_MAX; config_robotat.py 466–474)")
filas = []
for s in SES:
    e = E[s].sort_values("episodio")
    prev = 0
    for _, r in e.iterrows():
        n_r = max(0, DEC_RAMPA - prev)
        if n_r > 0:
            filas.append((s, int(r.episodio), int(r.valido), int(r.semilla), n_r, float(r.cobertura_aoi)))
        prev += int(r.decisiones) if not pd.isna(r.decisiones) else 0
for f in filas:
    print(f"  {f[0]:5s} ep {f[1]:2d} válido {f[2]} semilla {f[3]} decisiones con rampa {f[4]:2d} · cob {f[5]:.4f}")
ramp_val30 = [(f[0], f[1]) for f in filas if f[2] == 1 and f[0] in S30]
es_r = v30.apply(lambda r: (r.ses, int(r.episodio)) in ramp_val30, axis=1)
sem0 = v30[v30.semilla == 420000]
print(f"  válidos 30-09 con rampa: {int(es_r.sum())}/50 · semilla 420000 válidos: {len(sem0)} "
      f"(con rampa {int(es_r[v30.semilla == 420000].sum())})")
print(f"  cobertura media 50 válidos {v30.cobertura_aoi.mean():.4f} · sin los de rampa "
      f"{v30[~es_r].cobertura_aoi.mean():.4f} (n={int((~es_r).sum())})")
sm = v30.groupby("semilla").cobertura_aoi.mean()
print(f"  media semilla 420000 {sm.loc[420000]:.4f} · rango de medias de las otras 11 semillas "
      f"{sm.drop(420000).min():.4f}–{sm.drop(420000).max():.4f} (orden {int((sm < sm.loc[420000]).sum()) + 1}/12 de menor a mayor)")

# ---------------------------------------------------------------- P2
sep("P2. Margen de pared del CBF 0.18 m ('sim: nunca < 0.18', sesion_robotat.py 1451 y 1893)")


def filas_validas(ses_list):
    out = []
    for s in ses_list:
        vv = set(E[s][E[s].valido == 1].episodio)
        out.append(D[s][D[s].episodio.isin(vv)])
    return pd.concat(out, ignore_index=True)


for nom, sl in (("30-09", S30), ("26-09", ["26-09"])):
    dv = filas_validas(sl)
    ev = val[val.ses.isin(sl)]
    bajo = dv.dp < 0.18
    print(f"  {nom}: episodios con ≥1 agente < 0.18: {int((ev.viola_018 > 0).sum())}/{len(ev)} · agentes-episodio "
          f"{int(ev.viola_018.sum())}/{5 * len(ev)} · filas < 0.18 {bajo.mean() * 100:.2f} % ({int(bajo.sum())}/{len(dv)})"
          f" · filas < 0.15 {(dv.dp < 0.15).mean() * 100:.2f} %")
    # rachas contiguas bajo 0.18
    rach = []
    for (s, ep, a), gg in dv.groupby(["ses", "episodio", "agente"]):
        b = (gg.dp.to_numpy() < 0.18).astype(int)
        if b.any():
            dif = np.diff(np.r_[0, b, 0])
            ini, fin = np.where(dif == 1)[0], np.where(dif == -1)[0]
            rach += list(fin - ini)
    rach = np.array(rach)
    print(f"     rachas bajo 0.18: n {len(rach)} · mediana {np.median(rach) * DT:.1f} s · p90 {np.percentile(rach, 90) * DT:.1f} s"
          f" · máx {rach.max() * DT:.1f} s")
    bj = dv[bajo]
    print(f"     en filas < 0.18: en_escape {bj.en_escape.mean() * 100:.1f} % · cbf_intervino {bj.cbf_intervino.mean() * 100:.1f} %"
          f" · ninguna de las dos {((bj.en_escape == 0) & (bj.cbf_intervino == 0)).mean() * 100:.1f} %")
    por_rob = bj.groupby("robot").size() / len(bj) * 100
    print("     reparto por robot de las filas < 0.18: " + "  ".join(f"r{int(k)} {v:.1f} %" for k, v in por_rob.items()))
    # quién fija el mínimo del episodio
    quien = []
    for (s, ep), gg in dv.groupby(["ses", "episodio"]):
        i = gg.dp.idxmin()
        quien.append((int(gg.loc[i, "robot"]), float(gg.loc[i, "pose_env_x"]), float(gg.loc[i, "pose_env_y"]),
                      int(gg.loc[i, "en_escape"])))
    q = pd.DataFrame(quien, columns=["robot", "x", "y", "esc"])
    print("     robot que fija el mínimo de pared del episodio: " + "  ".join(
        f"r{k} {v}" for k, v in q.robot.value_counts().sort_index().items()))
    q5 = q[q.robot == 5]
    if len(q5):
        print(f"     r5 como mínimo: x {q5.x.min():.2f}–{q5.x.max():.2f} · y {q5.y.min():.3f}–{q5.y.max():.3f} · en escape {int(q5.esc.sum())}/{len(q5)}")

# ---------------------------------------------------------------- P3
sep("P3. 26-09 vs 30-09: fracción de filas < 0.18 por episodio, cruda y ajustada por semilla (OLS con efectos fijos)")


def f018_ep(s, ep):
    d = D[s]
    return float((d[d.episodio == ep].dp < 0.18).mean())


val["f018"] = [f018_ep(r.ses, int(r.episodio)) for _, r in val.iterrows()]
val["act_esc"] = 0
for i, r in val.iterrows():
    d = D[r.ses]
    dd = d[d.episodio == r.episodio]
    n = 0
    for a, gg in dd.groupby("agente"):
        e_ = gg.sort_values("paso").en_escape.to_numpy()
        n += int(((e_[1:] == 1) & (e_[:-1] == 0)).sum() + (e_[0] == 1))
    val.loc[i, "act_esc"] = n
v30 = val[val.ses.isin(S30)].copy()
v26 = val[val.ses == "26-09"].copy()


def fe_ols(df, y, x_cols, fe_cols, cl="semilla"):
    X = [np.ones(len(df))]
    for c in x_cols:
        X.append(df[c].to_numpy(float))
    for f in fe_cols:
        Dm = pd.get_dummies(df[f].astype(str), drop_first=True).to_numpy(float)
        X += list(Dm.T)
    X = np.column_stack(X)
    yv = df[y].to_numpy(float)
    b, *_ = np.linalg.lstsq(X, yv, rcond=None)
    res = yv - X @ b
    n, k = X.shape
    rank = np.linalg.matrix_rank(X)
    XtXi = np.linalg.pinv(X.T @ X)
    s2 = res @ res / (n - rank)
    se = np.sqrt(np.diag(XtXi) * s2)
    gl = n - rank
    t = b[1] / se[1]
    p = 2 * stats.t.sf(abs(t), gl)
    q = stats.t.ppf(0.975, gl)
    return b[1], b[1] - q * se[1], b[1] + q * se[1], p, gl


val["dia30"] = val.ses.isin(S30).astype(int)
for y in ("f018", "d_pared_min", "viola_018", "act_esc", "frac_cbf", "cobertura_aoi"):
    c = v30[y].mean() - v26[y].mean()
    b, lo, hi, p, gl = fe_ols(val, y, ["dia30"], ["semilla"])
    print(f"  {y:14s} 30-09 {v30[y].mean():.4f} · 26-09 {v26[y].mean():.4f} · cruda {c:+.4f} · ajustada semilla {b:+.4f} "
          f"[{lo:+.4f}, {hi:+.4f}] p {p:.3f} (gl {gl}) · MW p {stats.mannwhitneyu(v30[y], v26[y]).pvalue:.3f}")
comp = sorted(set(v26.semilla) & set(v30.semilla))
print(f"  semillas compartidas {comp}: el ajuste por semilla sólo usa {int(v26.semilla.isin(comp).sum())} episodios del 26-09")

# ---------------------------------------------------------------- P4
sep("P4. ¿La latencia del lazo explica algo DENTRO del 30-09? pendiente por +10 ms de ciclo_p95 (OLS, efectos fijos)")
v30["p95_10"] = v30.ciclo_p95_ms / 10.0
for y in ("cobertura_aoi", "d_pared_min", "f018", "viola_018", "act_esc", "frac_cbf"):
    b1, lo1, hi1, p1, g1 = fe_ols(v30, y, ["p95_10"], ["semilla"])
    b2, lo2, hi2, p2, g2 = fe_ols(v30, y, ["p95_10"], ["semilla", "ses"])
    print(f"  {y:14s} FE semilla: {b1:+.4f} [{lo1:+.4f}, {hi1:+.4f}] p {p1:.3f} · FE semilla+sesión: {b2:+.4f} "
          f"[{lo2:+.4f}, {hi2:+.4f}] p {p2:.3f}")
rng = v30.ciclo_p95_ms
print(f"  rango de p95 en los 50 válidos: {rng.min():.1f}–{rng.max():.1f} ms (26-09: {v26.ciclo_p95_ms.min():.1f}–{v26.ciclo_p95_ms.max():.1f})")
baja = v30[v30.ciclo_p95_ms < 25]
print(f"  válidos 30-09 con p95 < 25 ms: {len(baja)} ({', '.join(f'{r.ses} ep{int(r.episodio)} {r.ciclo_p95_ms:.1f}' for _, r in baja.iterrows())})")
v30["baja"] = (v30.ciclo_p95_ms < 25).astype(int)
for y in ("cobertura_aoi", "d_pared_min", "f018", "act_esc"):
    b, lo, hi, p, gl = fe_ols(v30, y, ["baja"], ["semilla"])
    print(f"    p95<25 vs resto, ajustado semilla, {y:14s} {b:+.4f} [{lo:+.4f}, {hi:+.4f}] p {p:.3f}")

# ---------------------------------------------------------------- P5
sep("P5. S5 (con arreglo de detención) vs S1–S4, ajustado por semilla (descriptivo; el arreglo actúa fuera del episodio)")
v30["s5"] = (v30.ses == "S5").astype(int)
for y in ("cobertura_aoi", "d_pared_min", "f018", "act_esc", "frac_cbf"):
    b, lo, hi, p, gl = fe_ols(v30, y, ["s5"], ["semilla"])
    print(f"  {y:14s} S5 {v30[v30.s5 == 1][y].mean():.4f} · S1–S4 {v30[v30.s5 == 0][y].mean():.4f} · ajustada {b:+.4f} "
          f"[{lo:+.4f}, {hi:+.4f}] p {p:.3f}")

# ---------------------------------------------------------------- P6
sep("P6. Colocación por sesión: 'no avanza' (robot-intento) y duración col_t_s (todos los intentos)")
for s in SES:
    e = E[s]
    est = pd.concat([e[f"col_estado_a{i}"] for i in range(5)])
    na = int((est == "no avanza").sum())
    print(f"  {s:5s} intentos {len(e):2d} · no avanza {na:2d}/{5 * len(e)} · col_t_s mediana {e.col_t_s.median():.1f} s "
          f"(p90 {e.col_t_s.quantile(.9):.1f}) · colocaciones con ≥1 no avanza {int((pd.concat([e[f'col_estado_a{i}'] == 'no avanza' for i in range(5)], axis=1).any(axis=1)).sum())}")
pre = pd.concat([E[s] for s in ["S1", "S2", "S3", "S4"]])
post = E["S5"]
print(f"  col_t_s S1–S4 vs S5 (Mann-Whitney): p {stats.mannwhitneyu(pre.col_t_s, post.col_t_s).pvalue:.3f}")

# ---------------------------------------------------------------- P7
sep("P7. Grupo del CENTRO (≤ 0.10 m del origen del lab): inicios y pasadas, por robot y día (válidos + abortados)")
for nom, sl in (("26-09", ["26-09"]), ("30-09", S30)):
    dd = DE[DE.ses.isin(sl)]
    ini = dd[dd.ini & (dd.r_lab0 <= 0.10)]
    print(f"  {nom}: inicios a ≤0.10 m del origen lab: {len(ini)} → " + "; ".join(
        f"{r.ses} ep{int(r.episodio)} r{int(r.robot)} p{int(r.paso)} ({r.lx:+.3f},{r.ly:+.3f}) d={r.r_lab0:.3f}"
        for _, r in ini.iterrows()))
    for rb in (1, 5, 8, 6, 9):
        z = dd[dd.robot == rb]
        pas = z[z.r_lab0 <= 0.10].groupby(["ses", "episodio"]).size()
        con = ini[ini.robot == rb].groupby(["ses", "episodio"]).size()
        print(f"     r{rb}: episodios que pasan a ≤0.10 m {len(pas):2d} · con inicio ahí {len(con)} · filas a ≤0.10 m {int((z.r_lab0 <= 0.10).sum())}")
ini_all = DE[DE.ini]
for nom, sl in (("26-09", ["26-09"]), ("30-09", S30)):
    z = ini_all[ini_all.ses.isin(sl)]
    print(f"  inicios por robot {nom} (todos): " + "  ".join(f"r{k} {v}" for k, v in z.robot.value_counts().sort_index().items())
          + f" · total {len(z)}")

# ---------------------------------------------------------------- P8
sep("P8. Ganancia de actuación por robot: Σ|Δp| / Σ(|v_ejecutada|·factor·dt), válidos, sin filas repetidas ni rampa")
res = []
for nom, sl in (("26-09", ["26-09"]), ("30-09", S30)):
    for s in sl:
        vv = set(E[s][E[s].valido == 1].episodio)
        d = D[s][D[s].episodio.isin(vv)]
        for (ep, a), gg in d.groupby(["episodio", "agente"]):
            gg = gg.sort_values("paso")
            xy = gg[["pose_env_x", "pose_env_y"]].to_numpy()
            dp = np.linalg.norm(np.diff(xy, axis=0), axis=1)
            v = np.abs(gg.v_ejecutada.to_numpy()[:-1]) * FACTOR * DT
            ok = ~(gg.rep.to_numpy()[1:] | gg.rep.to_numpy()[:-1]) & (gg.paso.to_numpy()[:-1] >= 60)
            res.append((nom, s, ep, int(gg.robot.iloc[0]), dp[ok].sum(), v[ok].sum()))
R = pd.DataFrame(res, columns=["dia", "ses", "ep", "robot", "med", "cmd"])
tab = R.groupby(["dia", "robot"])[["med", "cmd"]].sum()
tab["g"] = tab.med / tab.cmd
for dia in ("26-09", "30-09"):
    print(f"  {dia}: " + "  ".join(f"r{rb} {tab.loc[(dia, rb), 'g']:.3f}" for rb in (1, 5, 8, 6, 9)))
R["g"] = R.med / R.cmd
r30 = R[R.dia == "30-09"]
kw = stats.kruskal(*[r30[r30.robot == rb].g for rb in (1, 5, 8, 6, 9)])
print(f"  30-09 por episodio: Kruskal entre robots p {kw.pvalue:.2e} · mediana r5 {r30[r30.robot == 5].g.median():.3f} vs resto {r30[r30.robot != 5].g.median():.3f}")
print("  (el escalado env/lab 1.0167 afecta a todos por igual; incluye el recorrido del retraso de actuación en ambos extremos)")
