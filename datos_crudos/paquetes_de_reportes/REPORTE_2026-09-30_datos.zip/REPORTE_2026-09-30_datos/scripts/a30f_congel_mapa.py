import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_congel_mapa.py — mapa de los inicios de congelamiento: agrupamiento (enlace simple,
radio 8 cm), comparación con los puntos ciegos A, B, C del 26-09, exposición (filas vivas y
pasadas) por punto y sesión, y figura a30f_congel_mapa.png. SÓLO LECTURA de la tesis.

Puntos agrupados = eventos con mecanismo 'Motive' o 'caché-rechazo' (los que dependen del
lugar). Los de 'caché-fallida' (5 robots a la vez) e 'hipo' se listan aparte; como control,
se repite el agrupamiento incluyéndolos.
Pasada = corrida de filas VIVAS consecutivas dentro del disco (las repetidas no la cortan);
una pasada "con congelamiento" contiene un inicio del conjunto agrupado.
"""
import math, os, sys
from collections import Counter, defaultdict
import numpy as np
from scipy import stats
sys.stdout.reconfigure(encoding='utf-8')
import a30f_congel_clase as CL
K = CL.K
S, E, I = K.S, K.E, K.I
RAD = 0.08
ORDEN = ['26-09', 's1', 's2', 's3', 's4', 's5']

todos = [it for ses in ORDEN for it in I[ses]]
esp = [it for it in todos if it['mec'] in ('Motive', 'caché-rechazo')]


def grupos(pts, rad=RAD):
    n = len(pts); padre = list(range(n))

    def raiz(a):
        while padre[a] != a:
            padre[a] = padre[padre[a]]; a = padre[a]
        return a
    for a in range(n):
        for b in range(a + 1, n):
            if math.hypot(pts[a]['r']['x'] - pts[b]['r']['x'], pts[a]['r']['y'] - pts[b]['r']['y']) <= rad:
                padre[raiz(a)] = raiz(b)
    g = defaultdict(list)
    for a in range(n):
        g[raiz(a)].append(pts[a])
    return sorted(g.values(), key=lambda m: (-len(m), m[0]['r']['x']))


def centro(m):
    return sum(it['r']['x'] for it in m) / len(m), sum(it['r']['y'] for it in m) / len(m)


def nombre(m):
    cx, cy = centro(m)
    for P, (px, py) in K.PUNTOS.items():
        if math.hypot(cx - px, cy - py) <= RAD:
            return P
    return None


print('=' * 118)
print(f'1) AGRUPAMIENTO (enlace simple, {100*RAD:.0f} cm) de los {len(esp)} inicios "de lugar" (Motive + caché-rechazo), 6 días de sesión')
G = grupos(esp)
nuevos = iter(['D', 'E', 'F', 'G', 'H', 'J', 'K', 'M'])
ETQ = {}
for m in G:
    nm = nombre(m)
    if nm is None:
        nm = next(nuevos) if len(m) >= 2 else f"aislado"
    cx, cy = centro(m)
    xl, yl = K.env2lab(cx, cy)
    diam = max([math.hypot(a['r']['x'] - b['r']['x'], a['r']['y'] - b['r']['y']) for a in m for b in m] + [0])
    dref = ', '.join(f"{P} {100*math.hypot(cx-px, cy-py):.1f} cm" for P, (px, py) in K.PUNTOS.items())
    ses_c = Counter(it['ses'] for it in m); rob = Counter(it['robot'] for it in m)
    for it in m:
        ETQ[id(it)] = nm
    print(f"  [{nm}] n={len(m)} centro env ({cx:.3f}, {cy:.3f}) lab ({xl:+.3f}, {yl:+.3f}) diámetro {100*diam:.1f} cm d_pared "
          f"{min(it['r']['d'] for it in m):.3f}–{max(it['r']['d'] for it in m):.3f}; sesiones {dict(ses_c)}; robots {dict(rob)}; a {dref}")
    for it in m:
        r = it['r']
        print(f"       {it['ses']:6s} ep{it['ep']:2d} (V={it['valido']}) r{it['robot']} paso {r['paso']:3d} ({r['x']:.3f}, {r['y']:.3f}) racha {it['racha']:2d}"
              f" d {r['d']:.3f} [{it['tipo_f']}/{it['mec']}{' inferido' if it['inferido'] and it['mec']!='Motive' else ''}]"
              f"  a A {100*math.hypot(r['x']-2.54, r['y']-2.20):.1f} B {100*math.hypot(r['x']-2.82, r['y']-2.49):.1f} C {100*math.hypot(r['x']-2.52, r['y']-2.79):.1f} cm")
print('  --- eventos NO agrupados (no dependen del lugar, por hipótesis):')
for it in todos:
    if it['mec'] in ('Motive', 'caché-rechazo'):
        continue
    r = it['r']
    dmin = min((math.hypot(r['x'] - q['r']['x'], r['y'] - q['r']['y']), ETQ[id(q)]) for q in esp)
    print(f"       {it['ses']:6s} ep{it['ep']:2d} r{it['robot']} paso {r['paso']:3d} ({r['x']:.3f}, {r['y']:.3f}) [{it['tipo_f']}/{it['mec']}]"
          f"  inicio 'de lugar' más cercano: {100*dmin[0]:.1f} cm ({dmin[1]})")
print('  --- control: agrupamiento incluyendo también los de hipo (sin los de caché-fallida)')
G2 = grupos([it for it in todos if it['mec'] != 'caché-fallida'])
for m in G2:
    if len(m) >= 2 and any(it['mec'] == 'hipo' for it in m):
        print(f"       grupo con hipo: " + '; '.join(f"{it['ses']} ep{it['ep']} r{it['robot']} ({it['r']['x']:.3f}, {it['r']['y']:.3f}) {it['mec']}" for it in m))
print(f"       n.º de grupos: sin hipo {len(G)} ; con hipo {len(G2)}")

# ------------------------------------------------------------------ exposición
print('=' * 118)
print(f'2) EXPOSICIÓN por punto (disco de {100*RAD:.0f} cm): filas vivas, pasadas, pasadas con congelamiento "de lugar", por sesión')
PTS = dict(K.PUNTOS)
for m in G:
    nm = ETQ[id(m[0])]
    if nm not in PTS and len(m) >= 2:
        PTS[nm] = centro(m)
ini_lugar = {(it['ses'], it['ep'], it['ag'], it['r']['paso']) for it in esp}


def pasadas(ses, cx, cy, rad=RAD):
    out = []
    for (ep, ag), s in S[ses].items():
        f = s['f']; cur = None
        for r in f:
            if r['rep']:
                if cur is not None and (ses, ep, ag, r['paso']) in ini_lugar:
                    cur['cong'] = True
                continue
            dentro = math.hypot(r['x'] - cx, r['y'] - cy) < rad
            if dentro:
                if cur is None:
                    cur = dict(ep=ep, ag=ag, robot=s['robot'], n=0, cong=False, val=E[ses][ep]['valido'] == '1')
                cur['n'] += 1
            elif cur is not None:
                out.append(cur); cur = None
        if cur is not None:
            out.append(cur)
    return out


EXPO = {}
for P, (cx, cy) in PTS.items():
    print(f'--- {P} env ({cx:.3f}, {cy:.3f}) lab ({K.env2lab(cx, cy)[0]:+.3f}, {K.env2lab(cx, cy)[1]:+.3f}) d_pared {K.pared(cx, cy)[1]:.3f}')
    for ses in ORDEN:
        viv = sum(1 for s in S[ses].values() for r in s['f'] if not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < RAD)
        ps = pasadas(ses, cx, cy)
        ev = [it for it in esp if it['ses'] == ses and math.hypot(it['r']['x'] - cx, it['r']['y'] - cy) < RAD]
        pc = sum(p['cong'] for p in ps)
        rob = Counter(p['robot'] for p in ps)
        robc = Counter(p['robot'] for p in ps if p['cong'])
        EXPO[(P, ses)] = dict(viv=viv, pas=len(ps), pc=pc, ev=len(ev), rob=rob, robc=robc)
        print(f"   {ses:6s} vivas {viv:4d}  pasadas {len(ps):3d} (con cong. {pc})  inicios a <{100*RAD:.0f} cm {len(ev)}"
              f"  pasadas por robot {dict(sorted(rob.items()))}  con cong. {dict(sorted(robc.items()))}")
    k1, n1 = EXPO[(P, '26-09')]['pc'], EXPO[(P, '26-09')]['pas']
    k2 = sum(EXPO[(P, s)]['pc'] for s in K.SES30); n2 = sum(EXPO[(P, s)]['pas'] for s in K.SES30)
    if n1 and n2:
        _, p = stats.fisher_exact([[k1, n1 - k1], [k2, n2 - k2]])
        print(f"   Fisher pasadas con cong./pasadas: 26-09 {k1}/{n1} vs 30-09 (5 ses.) {k2}/{n2}  p {p:.3g}")
    # por robot dentro del 30-09
    rc = Counter(); rt = Counter()
    for s in K.SES30:
        rc.update(EXPO[(P, s)]['robc']); rt.update(EXPO[(P, s)]['rob'])
    if sum(rc.values()):
        top = rc.most_common(1)[0][0]
        a, b = rc[top], rt[top]; c_, d_ = sum(rc.values()) - a, sum(rt.values()) - b
        _, p = stats.fisher_exact([[a, b - a], [c_, d_ - c_]])
        print(f"   30-09 por robot: pasadas {dict(sorted(rt.items()))} con cong. {dict(sorted(rc.items()))}; r{top} {a}/{b} vs otros {c_}/{d_} Fisher p {p:.3g}")
    rc = Counter(); rt = Counter()
    for s in ORDEN:
        rc.update(EXPO[(P, s)]['robc']); rt.update(EXPO[(P, s)]['rob'])
    if sum(rc.values()):
        top = rc.most_common(1)[0][0]
        a, b = rc[top], rt[top]; c_, d_ = sum(rc.values()) - a, sum(rt.values()) - b
        _, p = stats.fisher_exact([[a, b - a], [c_, d_ - c_]])
        print(f"   6 días por robot: r{top} {a}/{b} vs otros {c_}/{d_} Fisher p {p:.3g}")

# ------------------------------------------------------------------ figura
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
from matplotlib.lines import Line2D

SURF, TXT, TXT2, GRID = '#fcfcfb', '#0b0b0b', '#52514e', '#dcdbd6'
COL = {'Motive': '#2a78d6', 'caché-rechazo': '#eb6834', 'hipo': '#1baf7a', 'caché-fallida': '#52514e'}
MK = {'Motive': 'o', 'caché-rechazo': 's', 'hipo': '^', 'caché-fallida': 'x'}
TIT = {'26-09': '26-09 (control)', 's1': '30-09 s1', 's2': '30-09 s2', 's3': '30-09 s3 (réplica en paralelo)',
       's4': '30-09 s4 (sin consola)', 's5': '30-09 s5 (con arreglo)'}

fig = plt.figure(figsize=(17.5, 9.4), facecolor=SURF)
gs = fig.add_gridspec(2, 4, width_ratios=[1, 1, 1, 1.25], wspace=0.18, hspace=0.22)


def tamano(it, grande=False):
    base = 34 if not grande else 70
    return base * (1 + 0.55 * math.sqrt(max(0, it['racha'] - 1)))


def refs(ax, etiquetas=True):
    for P, (cx, cy) in PTS.items():
        ref = P in K.PUNTOS
        ax.add_patch(Circle((cx, cy), RAD, fill=False, ec=TXT2, lw=0.9, ls='--' if ref else ':', zorder=2))
        if etiquetas:
            ax.annotate(P, (cx + RAD * 0.75, cy + RAD * 0.75), fontsize=8.5, color=TXT2, zorder=6)


for k, ses in enumerate(ORDEN):
    ax = fig.add_subplot(gs[k // 3, k % 3]); ax.set_facecolor(SURF)
    vx = [r['x'] for s in S[ses].values() for r in s['f'] if not r['rep']]
    vy = [r['y'] for s in S[ses].values() for r in s['f'] if not r['rep']]
    ax.scatter(vx, vy, s=0.25, c=GRID, linewidths=0, zorder=1, rasterized=True)
    ax.add_patch(Rectangle((0, 0), 3, 3, fill=False, ec=TXT2, lw=1.0, zorder=2))
    refs(ax, etiquetas=True)
    for it in I[ses]:
        mec = it['mec']
        if mec == 'caché-fallida':
            ax.scatter(it['r']['x'], it['r']['y'], marker='x', s=38, c=COL[mec], linewidths=1.3, zorder=4)
        else:
            ax.scatter(it['r']['x'], it['r']['y'], marker=MK[mec], s=tamano(it), c=COL[mec], edgecolors=SURF, linewidths=1.2, zorder=5)
    nv = sum(1 for e in E[ses].values() if e['valido'] == '1')
    ax.set_title(f"{TIT[ses]} · {len(I[ses])} inicios · {nv}/{len(E[ses])} válidos", color=TXT, fontsize=9.5, loc='left')
    ax.set_xlim(-0.06, 3.06); ax.set_ylim(-0.06, 3.06); ax.set_aspect('equal')
    ax.tick_params(colors=TXT2, labelsize=7.5)
    for sp in ax.spines.values():
        sp.set_visible(False)
    if k % 3 == 0:
        ax.set_ylabel('y del entorno [m]', color=TXT2, fontsize=8.5)
    if k // 3 == 1:
        ax.set_xlabel('x del entorno [m]', color=TXT2, fontsize=8.5)

SHORT = {'26-09': '26', 's1': 's1', 's2': 's2', 's3': 's3', 's4': 's4', 's5': 's5'}


def columnas(pts, y0, y1, gap):
    """Posiciones de etiqueta en columna: orden por y, sin solaparse (gap en m)."""
    pts = sorted(pts, key=lambda q: q[1])
    ys = []
    for q in pts:
        ys.append(max(q[1], (ys[-1] + gap) if ys else y0))
    exceso = ys[-1] - y1 if ys else 0
    if exceso > 0:
        ys = [y - exceso for y in ys]
        for k in range(len(ys) - 2, -1, -1):
            ys[k] = min(ys[k], ys[k + 1] - gap)
    return list(zip(pts, ys))


def zoom(ax, x0, x1, y0, y1, titulo, corte, xizq, xder, gap, ylab):
    ax.set_facecolor(SURF)
    for ses in ORDEN:
        vx = [r['x'] for s in S[ses].values() for r in s['f'] if not r['rep'] and x0 <= r['x'] <= x1 and y0 <= r['y'] <= y1]
        vy = [r['y'] for s in S[ses].values() for r in s['f'] if not r['rep'] and x0 <= r['x'] <= x1 and y0 <= r['y'] <= y1]
        ax.scatter(vx, vy, s=0.5, c=GRID, linewidths=0, zorder=1, rasterized=True)
    ax.add_patch(Rectangle((0, 0), 3, 3, fill=False, ec=TXT2, lw=1.2, zorder=2))
    refs(ax, etiquetas=True)
    izq, der = [], []
    for ses in ORDEN:
        for it in I[ses]:
            x, y = it['r']['x'], it['r']['y']
            if not (x0 <= x <= x1 and y0 <= y <= y1) or it['mec'] == 'caché-fallida':
                continue
            ax.scatter(x, y, marker=MK[it['mec']], s=tamano(it, True), c=COL[it['mec']], edgecolors=SURF, linewidths=1.5, zorder=5)
            txt = f"{SHORT[ses]} ep{it['ep']} r{it['robot']} ×{it['racha']}"
            (izq if x < corte else der).append((x, y, txt))
    for grupo, xt, ha in [(izq, xizq, 'right'), (der, xder, 'left')]:
        if not grupo:
            continue
        for (x, y, txt), yl in columnas(grupo, ylab[0], ylab[1], gap):
            ax.annotate(txt, (x, y), xytext=(xt, yl), fontsize=7.4, color=TXT, zorder=6, ha=ha, va='center',
                        arrowprops=dict(arrowstyle='-', color=TXT2, lw=0.45, shrinkA=1, shrinkB=3))
    ax.set_xlim(x0, x1); ax.set_ylim(y0, y1); ax.set_aspect('equal')
    ax.set_title(titulo, color=TXT, fontsize=9.5, loc='left')
    ax.tick_params(colors=TXT2, labelsize=7.5)
    for sp in ax.spines.values():
        sp.set_visible(False)


ax = fig.add_subplot(gs[0, 3])
zoom(ax, 1.92, 3.36, 2.06, 2.92, 'Esquina +x+y, 6 días (día ep robot ×racha)', 2.70, 2.36, 3.04, 0.043, (2.10, 2.90))
ax = fig.add_subplot(gs[1, 3])
zoom(ax, 1.22, 1.74, 1.13, 1.37, 'Centro (origen del lab), 6 días', 1.48, 1.395, 1.575, 0.022, (1.16, 1.35))
ax.plot([K.TX], [K.TY], marker='+', ms=12, color=TXT, zorder=7)
ax.annotate('lab (0, 0)', (K.TX, K.TY), xytext=(K.TX + 0.006, K.TY - 0.016), fontsize=7.4, color=TXT2)

h = [Line2D([], [], marker='o', ls='', color=COL['Motive'], ms=8, label='retención de Motive (a)'),
     Line2D([], [], marker='s', ls='', color=COL['caché-rechazo'], ms=8, label='caché por pose rechazada, inclinación (c)'),
     Line2D([], [], marker='^', ls='', color=COL['hipo'], ms=8, label='hipo de ritmo del lazo (b/c)'),
     Line2D([], [], marker='x', ls='', color=COL['caché-fallida'], ms=8, mew=1.4, label='caché por consulta fallida, 5 robots (b)'),
     Line2D([], [], ls='--', color=TXT2, label='A, B, C del 26-09 (radio 8 cm)'),
     Line2D([], [], ls=':', color=TXT2, label='grupos nuevos (enlace simple 8 cm)'),
     Line2D([], [], marker='o', ls='', color=GRID, ms=5, label='filas vivas (exposición)')]
fig.legend(handles=h, loc='lower center', ncol=4, frameon=False, fontsize=8.6, labelcolor=TXT)
fig.suptitle('Inicios de congelamiento (pose repetida) — 26-09 y las 5 sesiones del 30-09; tamaño del marcador ∝ √racha',
             color=TXT, fontsize=12, x=0.01, ha='left')
fig.subplots_adjust(left=0.04, right=0.99, top=0.92, bottom=0.10)
OUT = os.path.join(K.SP, 'a30f_congel_mapa.png')
fig.savefig(OUT, dpi=140, facecolor=SURF)
print('=' * 118)
print('figura guardada', OUT)
