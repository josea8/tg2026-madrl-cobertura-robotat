import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_congel_eventos.py — eventos de congelamiento (pose repetida) en las 5 sesiones
del 30-09 y el control 26-09: tabla, clasificación (a/b/c), denominadores, cruce con
consola y CSV de episodios, casos nombrados. SÓLO LECTURA de la carpeta de la tesis.
Escribe sólo en el scratchpad: a30f_congel_eventos.csv (tabla de eventos).
"""
import csv, math, os, sys
from collections import Counter, defaultdict
sys.stdout.reconfigure(encoding='utf-8')
import a30f_congel_comun as K
S, E, C, I = K.S, K.E, K.C, K.I

print('=' * 120)
print('0) CONTROL DE CARGA')
print(f'   calibración usada: esc {K.ESC} rot {K.ROT} tras ({K.TX}, {K.TY})')
for P, (x, y) in K.PUNTOS.items():
    xl, yl = K.env2lab(x, y)
    print(f'   punto {P} env ({x:.2f}, {y:.2f}) -> lab ({xl:+.3f}, {yl:+.3f}), d_pared {K.pared(x, y)[1]:.2f}')
for ses in S:
    eps = E[ses]
    val = {ep for ep, e in eps.items() if e['valido'] == '1'}
    ok = '' if ses not in K.VALIDOS_ESPERADOS else ('  (= lista dada)' if val == K.VALIDOS_ESPERADOS[ses] else f'  ⚠ DISTINTO de la lista dada {sorted(K.VALIDOS_ESPERADOS[ses])}')
    mapeo = Counter((s['ag'], s['robot']) for s in S[ses].values())
    print(f'   {ses:6s} episodios {len(eps)}  válidos {len(val)} {sorted(val)}{ok}  mapeo agente→robot {sorted(mapeo)}')
    c = C[ses]
    if c is None:
        print('          consola: NO EXISTE (no se pegó) → todo lo que depende de consola: sin dato')
    else:
        print(f"          consola: {c['n_lineas']} líneas; [sync] {len(c['syncs'])}; '↩' {len(c['rets'])}; '▶' {len(c['vivas'])};"
              f" 'frenando por pose vencida' {len(c['venc'])}; 'conexión perdida' {len(c['perdidas'])}; cierres de episodio {len(c['cierres'])}")

print('=' * 120)
print('1) FILAS (decisiones-agente) Y EVENTOS POR SESIÓN, separando válidos / abortados')
print('   filas = todas; vivas = no repetidas; repetidas = (x,y,θ) idéntica a la fila anterior del agente')
TOT = defaultdict(Counter)
for ses in S:
    for grupo, cond in [('válidos', '1'), ('abortados', '0')]:
        F = [r for (ep, ag), s in S[ses].items() if E[ses][ep]['valido'] == cond for r in s['f']]
        rep = sum(r['rep'] for r in F); viv = len(F) - rep
        ret = sum(r['retro'] for r in F)
        ev = [it for it in I[ses] if str(it['valido']) == cond]
        ct = Counter(it['tipo'] for it in ev)
        TOT[(ses, grupo)].update(dict(filas=len(F), vivas=viv, rep=rep, retro=ret, ev=len(ev), a=ct['a'], b=ct['b'], c=ct['c']))
        neps = sum(1 for e in E[ses].values() if e['valido'] == cond)
        print(f'   {ses:6s} {grupo:9s} eps {neps:2d}  filas {len(F):6d}  vivas {viv:6d}  repetidas {rep:4d}  en_retroceso {ret:4d}'
              f'  inicios {len(ev):3d} (a {ct["a"]}, b {ct["b"]}, c {ct["c"]})')
print('   --- tasas por 1000 filas (‰): inicios / filas | inicios / vivas')
for ses in S:
    for grupo in ['válidos', 'abortados']:
        t = TOT[(ses, grupo)]
        if t['filas'] == 0:
            continue
        lin = []
        for k in ['ev', 'a', 'b', 'c']:
            lin.append(f"{k}: {t[k]}/{t['filas']} = {1000*t[k]/t['filas']:.3f} ‰ | {t[k]}/{t['vivas']} = {1000*t[k]/t['vivas']:.3f} ‰")
        print(f'   {ses:6s} {grupo:9s} ' + ' ; '.join(lin))
for grupo in ['válidos', 'abortados', 'todos']:
    t = Counter()
    for ses in K.SES30:
        if grupo == 'todos':
            t.update(TOT[(ses, 'válidos')]); t.update(TOT[(ses, 'abortados')])
        else:
            t.update(TOT[(ses, grupo)])
    print(f"   30-09 (5 sesiones) {grupo:9s} filas {t['filas']}  vivas {t['vivas']}  repetidas {t['rep']}  en_retroceso {t['retro']}  inicios {t['ev']}"
          f" (a {t['a']}, b {t['b']}, c {t['c']});  a: {1000*t['a']/t['filas']:.3f} ‰ de filas, {1000*t['a']/t['vivas']:.3f} ‰ de vivas;"
          f"  todos: {1000*t['ev']/t['filas']:.3f} ‰ de filas")
t = Counter(); t.update(TOT[('26-09', 'válidos')]); t.update(TOT[('26-09', 'abortados')])
print(f"   26-09 todos filas {t['filas']} vivas {t['vivas']} inicios {t['ev']} (a {t['a']}, b {t['b']}, c {t['c']}); a: {1000*t['a']/t['filas']:.3f} ‰ de filas")

print('=' * 120)
print('2) TABLA DE EVENTOS (inicio = primera fila repetida; pose = última viva, idéntica)')
print('   racha = filas repetidas consecutivas; s ≈ racha × (duración_ep / decisiones_ep)')
filas_csv = []
for ses in S:
    print(f'--- {ses}')
    for it in I[ses]:
        r = it['r']; det = it['det']
        dtxt = f"{det['p_ini']}-{det['p_fin']} {det['dur']}s {det['cm']}cm {det['res']}" if det else 'SIN entrada en retrocesos_detalle'
        cr = it['cons_ret']
        ctxt = 'sin consola' if cr == 'sin consola' else (f"↩ consola ({cr['x']:.2f}, {cr['y']:.2f}) d {cr['d']:.2f} ventana {cr['ventana']} s + {cr['margen']} s, {cr['cm']} cm" if cr else 'SIN línea ↩ en consola')
        print(f"  ep{it['ep']:2d} (válido={it['valido']}) a{it['ag']}/r{it['robot']} paso {r['paso']:3d} racha {it['racha']:2d} fila(s) ≈ {it['racha']*it['dt']:.2f} s"
              f"{' HASTA EL FIN' if it['hasta_fin'] else ''}  env ({r['x']:.3f}, {r['y']:.3f}) θ {math.degrees(r['th']):+.1f}°  lab ({it['xl']:+.3f}, {it['yl']:+.3f})"
              f"  d_pared {r['d']:.3f} [{r['pared']}]")
        print(f"      tipo ({it['tipo']}) {it['sub']} — inicios en la misma decisión: {it['n_ini_paso']}/{it['n_ag']}, filas repetidas en esa decisión: {it['n_rep_paso']}"
              f" — evidencia: {it['evid']}")
        print(f"      retroceso CSV: {dtxt} | {ctxt}")
        filas_csv.append(dict(sesion=ses, episodio=it['ep'], valido=it['valido'], agente=it['ag'], robot=it['robot'], paso=r['paso'],
                              racha=it['racha'], racha_s=round(it['racha'] * it['dt'], 3), hasta_fin=int(it['hasta_fin']),
                              x_env=r['x'], y_env=r['y'], th_env=r['th'], x_lab=round(it['xl'], 4), y_lab=round(it['yl'], 4),
                              d_pared=round(r['d'], 4), pared=r['pared'], n_ini_paso=it['n_ini_paso'], n_rep_paso=it['n_rep_paso'],
                              tipo=it['tipo'], sub=it['sub'], evidencia=it['evid'],
                              ret_p_fin=det['p_fin'] if det else '', ret_dur_s=det['dur'] if det else '',
                              ret_cm=det['cm'] if det else '', ret_res=det['res'] if det else ''))
with open(os.path.join(K.SP, 'a30f_congel_eventos.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=list(filas_csv[0].keys()))
    w.writeheader(); w.writerows(filas_csv)
print(f'   -> a30f_congel_eventos.csv ({len(filas_csv)} filas)')

print('=' * 120)
print('3) RESUMEN POR TIPO (30-09, 5 sesiones)')
ev30 = [it for ses in K.SES30 for it in I[ses]]
for tipo in ['a', 'b', 'c']:
    ev = [it for it in ev30 if it['tipo'] == tipo]
    val = [it for it in ev if it['valido'] == 1]
    rob = Counter(it['robot'] for it in ev)
    ses = Counter(it['ses'] for it in ev)
    rach = Counter(it['racha'] for it in ev)
    print(f"   ({tipo}) {len(ev)} inicios ({len(val)} en válidos, {len(ev)-len(val)} en abortados); por sesión {dict(sorted(ses.items()))};"
          f" por robot {dict(sorted(rob.items()))}; rachas {dict(sorted(rach.items()))}")
    if ev:
        ds = sorted(it['r']['d'] for it in ev)
        print(f"        d_pared: {', '.join(f'{d:.3f}' for d in ds)}")
# episodios con al menos un evento
print('   episodios con ≥1 inicio (30-09): ' + ', '.join(sorted({f"{it['ses']}ep{it['ep']}({'V' if it['valido'] else 'A'})" for it in ev30})))
# en válidos: eventos por tipo y racha total
for tipo in ['a', 'b', 'c']:
    ev = [it for it in ev30 if it['tipo'] == tipo and it['valido'] == 1]
    print(f"   válidos, tipo ({tipo}): {len(ev)} inicios, {sum(it['racha'] for it in ev)} filas repetidas en total,"
          f" racha máx {max([it['racha'] for it in ev], default=0)}")

print('=' * 120)
print('4) CONSOLA: [sync] (pose vieja), ↩, ▶, pose vencida — cruce con el CSV')
for ses in S:
    c = C[ses]
    if c is None:
        print(f'   {ses}: sin consola (sin dato)')
        continue
    print(f'   --- {ses}')
    for s in c['syncs']:
        e = E[ses].get(s['ep'], {})
        ev = [it for it in I[ses] if it['ep'] == s['ep'] and it['r']['paso'] == s['paso']]
        rep = [(ag, fr['paso']) for (ep, ag), sq in S[ses].items() if ep == s['ep'] for fr in sq['f'] if fr['paso'] == s['paso'] and fr['rep']]
        print(f"     [sync] ep{s['ep']} tick {s['tick']} antig {s['antig']} ticks → paso {s['paso']} (línea {s['linea']});"
              f" filas repetidas en ese paso: agentes {[a for a, _ in rep]}; inicios CSV: {[(it['ag'], it['tipo']) for it in ev]};"
              f" ep: fallidas {e.get('poses_fallidas')}, rechazadas {e.get('poses_rechazadas')} {e.get('poses_rechazos_motivo')!r}")
    for v in c['venc']:
        print(f"     pose vencida ep{v['ep']} agentes {v['ags']} (línea {v['linea']})")
    # ↩ sin evento CSV
    for q in c['rets']:
        ev = [it for it in I[ses] if it['ep'] == q['ep'] and it['ag'] == q['ag'] and it['r']['paso'] == q['paso']]
        if not ev:
            print(f"     ⚠ ↩ sin inicio CSV: ep{q['ep']} a{q['ag']} paso {q['paso']}")
    n_ret = len(c['rets']); n_ev = len(I[ses])
    print(f"     líneas ↩ {n_ret} vs inicios CSV {n_ev}; ▶ {len(c['vivas'])}")
# eventos CSV sin retroceso
print('   inicios CSV sin entrada en retrocesos_detalle: ' +
      (', '.join(f"{it['ses']} ep{it['ep']} a{it['ag']} paso {it['r']['paso']}" for ses in S for it in I[ses] if it['det'] is None) or 'ninguno'))
# retrocesos_detalle sin evento CSV
sobr = []
for ses in S:
    for ep, e in E[ses].items():
        for d in K.detalle(e):
            if not [it for it in I[ses] if it['ep'] == ep and it['ag'] == d['ag'] and it['r']['paso'] == d['p_ini']]:
                sobr.append(f'{ses} ep{ep} a{d["ag"]} {d["p_ini"]}')
print('   entradas de retrocesos_detalle sin inicio CSV: ' + (', '.join(sobr) or 'ninguna'))

print('=' * 120)
print('5) CASOS NOMBRADOS — filas de los 5 agentes alrededor del evento (R = repetida, * = en_retroceso)')


def ventana(ses, ep, p0, p1):
    for ag in range(5):
        s = S[ses].get((ep, ag))
        if s is None:
            continue
        f = [r for r in s['f'] if p0 <= r['paso'] <= p1]
        prev = {r['paso']: r for r in s['f']}
        txt = []
        for r in f:
            q = prev.get(r['paso'] - 1)
            dd = 1000 * math.hypot(r['x'] - q['x'], r['y'] - q['y']) if q else float('nan')
            txt.append(f"{r['paso']}{'R' if r['rep'] else ''}{'*' if r['retro'] else ''}:{dd:.1f}")
        print(f"     a{ag}/r{s['robot']}  Δ mm por fila: " + '  '.join(txt))


for ses, ep, p0, p1, nombre in [('s5', 9, 152, 162, 's5 ep9 decisión 157 (robots 1 y 8 simultáneos)'),
                                 ('s5', 6, 395, 405, 's5 ep6 decisión 400 (a3/r6)'),
                                 ('s5', 6, 468, 477, 's5 ep6 decisión 475 (a2/r8; inválido por antigüedad)'),
                                 ('s4', 9, 265, 275, 's4 ep9 decisión 270 (simultáneo, sin consola)'),
                                 ('s4', 7, 198, 205, 's4 ep7 decisión 203 (rechazo inferido, sin consola)')]:
    e = E[ses][ep]
    print(f'--- {nombre}: ep válido={e["valido"]} motivo={e["motivo"]!r} decisiones {e["decisiones"]} fallidas {e["poses_fallidas"]}'
          f' rechazadas {e["poses_rechazadas"]} {e["poses_rechazos_motivo"]!r} consultas {e["poses_consultas"]} detalle {e["retrocesos_detalle"]!r}')
    ventana(ses, ep, p0, p1)
    for it in [it for it in I[ses] if it['ep'] == ep and p0 <= it['r']['paso'] <= p1]:
        r = it['r']
        print(f"     inicio a{it['ag']}/r{it['robot']} paso {r['paso']} env ({r['x']:.4f}, {r['y']:.4f}) lab ({it['xl']:+.3f}, {it['yl']:+.3f}) d_pared {r['d']:.3f}"
              f" [{r['pared']}] racha {it['racha']} tipo ({it['tipo']}) {it['sub']}; {it['evid']}")
        for P, (cx, cy) in K.PUNTOS.items():
            print(f"        distancia a {P}: {100*math.hypot(r['x']-cx, r['y']-cy):.1f} cm", end='')
        print()
    c = C[ses]
    if c is not None:
        for s in c['syncs']:
            if s['ep'] == ep:
                print(f"     consola [sync] ep{ep} paso {s['paso']} antig {s['antig']} (línea {s['linea']})")
        print(f"     consola: [sync] en ep{ep} con paso en [{p0},{p1}]: {[s['paso'] for s in c['syncs'] if s['ep']==ep and s['paso'] is not None and p0<=s['paso']<=p1]}")

print('=' * 120)
print('6) ABORTOS POR ANTIGÜEDAD y otros abortos (30-09): ¿hubo pose repetida?')
for ses in K.SES30:
    for ep, e in sorted(E[ses].items()):
        if e['valido'] == '1':
            continue
        ev = [it for it in I[ses] if it['ep'] == ep]
        ult = []
        for ag in range(5):
            s = S[ses].get((ep, ag))
            if s:
                ult.append('R' if s['f'][-1]['rep'] else '-')
        # ciclo de las demás del mismo día
        otros = [float(x['ciclo_p95_ms']) for x in E[ses].values() if x['valido'] == '1']
        c = C[ses]
        venc = [v['ags'] for v in c['venc'] if v['ep'] == ep] if c else 'sin consola'
        sy = [(s['paso'], s['antig']) for s in c['syncs'] if s['ep'] == ep] if c else 'sin consola'
        print(f"   {ses} ep{ep}: motivo {e['motivo'][:70]!r}; decisiones {e['decisiones']}; fallidas {e['poses_fallidas']} rechazadas {e['poses_rechazadas']}"
              f" {e['poses_rechazos_motivo']!r}; inicios CSV {[(it['ag'], it['r']['paso'], it['tipo']) for it in ev]}; última fila repetida por agente {ult};"
              f" ciclo_p95 {float(e['ciclo_p95_ms']):.1f} ms (válidos del día: {min(otros):.1f}–{max(otros):.1f}), ciclos>100ms {e['ciclos_sobre_100ms']};"
              f" [sync] (paso, antig) {sy}; vencida {venc}")
print('   ciclo_p95_ms y ciclos_sobre_100ms por sesión (válidos): ')
for ses in S:
    v = [(float(e['ciclo_p95_ms']), int(e['ciclos_sobre_100ms'])) for e in E[ses].values() if e['valido'] == '1']
    print(f"     {ses:6s} p95 {min(a for a,_ in v):.1f}–{max(a for a,_ in v):.1f} ms; ciclos>100 ms total {sum(b for _,b in v)} (máx por ep {max(b for _,b in v)})")
