# a30f_robots_wlan.ps1 — SOLO LECTURA del registro de eventos de Windows (WLAN-AutoConfig).
# Para la hipótesis del adaptador WiFi: ¿qué adaptador estaba conectado a la red del
# Robotat en cada sesión, y hubo reconexiones / cambios de adaptador / roaming DURANTE
# las 5 sesiones del 30-09 (11:54–13:39) y la del 26-09 (10:45–11:34)?
# No toca archivos del proyecto. Salida: a30f_robots_wlan_salida.txt (la redirige quien lo llama).
$ErrorActionPreference = 'SilentlyContinue'
function Ventana($ini, $fin) {
  "== WLAN-AutoConfig $ini .. $fin =="
  $ev = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-WLAN-AutoConfig/Operational'; StartTime=(Get-Date $ini); EndTime=(Get-Date $fin)} -ErrorAction SilentlyContinue | Sort-Object TimeCreated
  if (-not $ev) { "  (sin eventos)"; return }
  "  eventos: $($ev.Count)  por id: " + (($ev | Group-Object Id | Sort-Object Name | ForEach-Object { "$($_.Name)x$($_.Count)" }) -join ' ')
  foreach ($e in $ev) {
    $m = $e.Message -replace '\s+', ' '
    $ad = if ($m -match 'Network Adapter: (.+?) Interface GUID') { $matches[1] } else { '?' }
    $ssid = if ($m -match 'SSID: (.+?) ') { $matches[1] } else { '' }
    $razon = if ($m -match 'Reason: (.+?)( Connection| Local| $)') { $matches[1] } else { '' }
    "  {0:yyyy-MM-dd HH:mm:ss.fff} id={1,-5} {2} | SSID={3} | {4}" -f $e.TimeCreated, $e.Id, $ad, $ssid, $razon
  }
}
Ventana '2026-09-26 10:30' '2026-09-26 11:40'
Ventana '2026-09-30 11:40' '2026-09-30 13:45'
"== Conexiones (8001) a cualquier red desde el 2026-09-08, con adaptador =="
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-WLAN-AutoConfig/Operational'; Id=8001; StartTime=(Get-Date '2026-09-08')} -ErrorAction SilentlyContinue | Sort-Object TimeCreated | ForEach-Object {
  $m = $_.Message -replace '\s+', ' '
  $ad = if ($m -match 'Network Adapter: (.+?) Interface GUID') { $matches[1] } else { '?' }
  $ssid = if ($m -match 'SSID: (.+?) ') { $matches[1] } else { '' }
  $guid = if ($m -match 'Interface GUID: (\{[0-9a-fA-F\-]+\})') { $matches[1] } else { '' }
  "  {0:yyyy-MM-dd HH:mm:ss} {1} GUID={2} SSID={3}" -f $_.TimeCreated, $ad, $guid, $ssid
}
"== Adaptadores de red ahora (consulta {0:yyyy-MM-dd HH:mm:ss}) ==" -f (Get-Date)
Get-NetAdapter | Sort-Object Name | ForEach-Object { "  {0,-10} {1,-52} {2,-10} {3,-14} {4}" -f $_.Name, $_.InterfaceDescription, $_.Status, $_.LinkSpeed, $_.MacAddress }
"== Perfil de energía del adaptador USB (si lo expone) =="
Get-NetAdapterPowerManagement -Name * -ErrorAction SilentlyContinue | ForEach-Object { "  {0,-10} AllowComputerToTurnOffDevice={1} SelectiveSuspend={2}" -f $_.Name, $_.AllowComputerToTurnOffDevice, $_.SelectiveSuspend }
