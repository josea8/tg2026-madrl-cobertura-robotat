import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico (2): (a) rachas largas bajo el margen 0.18; (b) comparación 26-09 vs 30-09 por semilla
compartida (pareada, sin modelo) y Holm; (c) dónde fija r5 el mínimo de pared.
SOLO LECTURA; sin réplica. Uso: python -B a30f_critico_2.py > a30f_critico_2_salida.txt"""
import sys
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SES = {
    "26-09": ("20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
    "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv"),
    "S2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv", "20260930_sesion-evaluacion_etapa7_decisiones_02.csv"),
    "S3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv", "20260930_sesion-evaluacion_etapa7_decisiones_03.csv"),
    "S4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv", "20260930_sesion-evaluacion_etapa7_decisiones_04.csv"),
    "S5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv", "20260930_sesion-evaluacion_etapa7_decisiones_05.csv"),
}
S30 = ["S1", "S2", "S3", "S4", "S5"]
DT, FACTOR = 0.1, 0.40
E, DV = {}, []
for s, (fe, fd) in SES.items():
    e = pd.read_csv(f"{RS}\\{fe}"); e["ses"] = s; E[s] = e
    d = pd.read_csv(f"{RS}\\{fd}"); d["ses"] = s
    d = d[d.episodio.isin(set(e[e.valido == 1].episodio))]
    d = d.sort_values(["episodio", "agente", "paso"])
    x, y = d.pose_env_x.to_numpy(), d.pose_env_y.to_numpy()
    d["dp"] = np.minimum.reduce([x, 3 - x, y, 3 - y])
    d["pared"] = np.array(["x=0", "x=3", "y=0", "y=3"])[np.argmin(np.c_[x, 3 - x, y, 3 - y], axis=1)]
    DV.append(d)
DV = pd.concat(DV, ignore_index=True)
EP = pd.concat(E.values(), ignore_index=True)
V = EP[EP.valido == 1].copy()


def sep(t):
    print("\n" + "=" * 100 + f"\n{t}\n" + "=" * 100)


sep("(a) Rachas contiguas bajo 0.18 m (válidos): largas (≥ 5 s) — quién, dónde y qué hacen las capas")
R = []
for (s, ep, a), g in DV.groupby(["ses", "episodio", "agente"]):
    b = (g.dp.to_numpy() < 0.18).astype(int)
    if not b.any():
        continue
    dif = np.diff(np.r_[0, b, 0]); ini, fin = np.where(dif == 1)[0], np.where(dif == -1)[0]
    for i0, i1 in zip(ini, fin):
        z = g.iloc[i0:i1]
        xy = z[["pose_env_x", "pose_env_y"]].to_numpy()
        rec = np.linalg.norm(np.diff(xy, axis=0), axis=1).sum() if len(z) > 1 else 0.0
        R.append(dict(dia="26-09" if s == "26-09" else "30-09", ses=s, ep=int(ep), robot=int(z.robot.iloc[0]),
                      n=len(z), dur=len(z) * DT, dmin=z.dp.min(), dmed=z.dp.median(), pared=z.pared.mode().iloc[0],
                      x=z.pose_env_x.mean(), y=z.pose_env_y.mean(), esc=z.en_escape.mean(), cbf=z.cbf_intervino.mean(),
                      vcmd=(z.v_ejecutada.abs() * FACTOR).mean(), rec=rec, neto=np.linalg.norm(xy[-1] - xy[0])))
R = pd.DataFrame(R)
for dia in ("26-09", "30-09"):
    z = R[R.dia == dia]
    tot = z.n.sum()
    print(f"  {dia}: rachas {len(z)} · ≥5 s {int((z.dur >= 5).sum())} · ≥10 s {int((z.dur >= 10).sum())} · "
          f"filas en rachas ≥5 s {z[z.dur >= 5].n.sum() / tot * 100:.1f} % de las filas < 0.18")
L = R[R.dur >= 10].sort_values("dur", ascending=False)
print("  rachas ≥ 10 s:")
for _, r in L.iterrows():
    print(f"    {r.ses:5s} ep{r.ep:2d} r{r.robot} {r.dur:4.1f} s · pared {r.pared} en ({r.x:.2f},{r.y:.2f}) · d mín {r.dmin:.3f} med {r.dmed:.3f}"
          f" · escape {r.esc * 100:3.0f} % cbf {r.cbf * 100:3.0f} % · |v| cmd {r.vcmd:.3f} m/s · recorrido {r.rec:.2f} m neto {r.neto:.2f} m")
z = R[(R.dia == "30-09") & (R.dur >= 5)]
print(f"  30-09 rachas ≥5 s por robot: " + "  ".join(f"r{k} {v}" for k, v in z.robot.value_counts().sort_index().items()))
print(f"  30-09 rachas ≥5 s: recorrido/duración mediana {np.median(z.rec / z.dur):.3f} m/s (se mueven a lo largo de la pared)")

sep("(b) 26-09 vs 30-09 PAREADO por semilla compartida (media 30-09 de la semilla − episodio 26-09)")
V["f018"] = [float((DV[(DV.ses == r.ses) & (DV.episodio == r.episodio)].dp < 0.18).mean()) for _, r in V.iterrows()]
act = []
for _, r in V.iterrows():
    dd = DV[(DV.ses == r.ses) & (DV.episodio == r.episodio)]
    n = 0
    for a, g in dd.groupby("agente"):
        e_ = g.en_escape.to_numpy(); n += int(((e_[1:] == 1) & (e_[:-1] == 0)).sum() + (e_[0] == 1))
    act.append(n)
V["act_esc"] = act
v30, v26 = V[V.ses.isin(S30)], V[V.ses == "26-09"]
comp = sorted(set(v26.semilla) & set(v30.semilla))
mets = ["cobertura_aoi", "d_pared_min", "viola_018", "f018", "frac_cbf", "act_esc", "n_escape", "frac_vecino",
        "dist_min_robot"]
filas = []
for m in mets:
    difs = [v30[v30.semilla == s_][m].mean() - float(v26[v26.semilla == s_][m].iloc[0]) for s_ in comp]
    neg = sum(d_ < 0 for d_ in difs)
    p_sig = stats.binomtest(neg, len(difs), 0.5).pvalue if 0 < len(difs) else np.nan
    filas.append((m, difs, neg, p_sig))
    print(f"  {m:14s} difs por semilla " + " ".join(f"{d_:+.3f}" for d_ in difs) + f" · negativas {neg}/{len(difs)} · signo p {p_sig:.3f}"
          f" · media {np.mean(difs):+.4f}")
print(f"  semillas compartidas {comp}")
# Holm sobre las p ajustadas por semilla (OLS) de las 9 métricas de comportamiento
print("\n  Holm sobre OLS con efectos fijos de semilla (9 métricas de comportamiento, excluye ciclo p95 y ciclos>100 ms):")
V["dia30"] = V.ses.isin(S30).astype(int)
ps = []
for m in mets:
    X = np.column_stack([np.ones(len(V)), V.dia30] + list(pd.get_dummies(V.semilla.astype(str), drop_first=True).to_numpy(float).T))
    yv = V[m].to_numpy(float)
    b, *_ = np.linalg.lstsq(X, yv, rcond=None)
    res = yv - X @ b
    rk = np.linalg.matrix_rank(X); gl = len(yv) - rk
    se = np.sqrt(np.diag(np.linalg.pinv(X.T @ X)) * (res @ res / gl))
    ps.append(2 * stats.t.sf(abs(b[1] / se[1]), gl))
orden = np.argsort(ps); k = len(ps); ajust = np.empty(k); acc = 0
for j, i in enumerate(orden):
    acc = max(acc, min(1.0, (k - j) * ps[i])); ajust[i] = acc
for m, p, pa in zip(mets, ps, ajust):
    print(f"    {m:14s} p {p:.4f} → Holm {pa:.4f}")

sep("(c) ¿Dónde fija r5 el mínimo de pared del episodio? (30-09 válidos)")
q = []
for (s, ep), g in DV[DV.ses.isin(S30)].groupby(["ses", "episodio"]):
    i = g.dp.idxmin()
    q.append(dict(ses=s, ep=int(ep), semilla=int(V[(V.ses == s) & (V.episodio == ep)].semilla.iloc[0]), robot=int(g.loc[i, "robot"]),
                  x=g.loc[i, "pose_env_x"], y=g.loc[i, "pose_env_y"], pared=g.loc[i, "pared"], paso=int(g.loc[i, "paso"]),
                  dmin=g.loc[i, "dp"]))
q = pd.DataFrame(q)
q5 = q[q.robot == 5]
print("  paredes de los mínimos de r5: " + "  ".join(f"{k} {v}" for k, v in q5.pared.value_counts().items()))
cerca = q5[(q5.pared == "y=0") & (q5.x > 2.0)]
print(f"  r5 en pared y=0 con x > 2.0: {len(cerca)}/{len(q5)} · x {cerca.x.min():.2f}–{cerca.x.max():.2f}")
print("  semillas de los mínimos de r5: " + "  ".join(f"{k} {v}" for k, v in q5.semilla.value_counts().sort_index().items()))
nv = V[V.ses.isin(S30)].semilla.value_counts()
print("  válidos por semilla:            " + "  ".join(f"{k} {v}" for k, v in nv.sort_index().items()))
# ¿el blanco del agente 1 (r5) está cerca de esa esquina?
e30 = EP[EP.ses.isin(S30) & (EP.valido == 1)].drop_duplicates("semilla").set_index("semilla")
print("  blanco del agente 1 (r5) por semilla: " + "  ".join(
    f"{s_}:({e30.loc[s_, 'blanco_x_a1']:.2f},{e30.loc[s_, 'blanco_y_a1']:.2f})" for s_ in sorted(e30.index)))

cerca5 = q5[(q5.pared == "y=0") & (q5.x > 2.0)]
print("  r5 mínimos en (≈2.73, y=0): " + "; ".join(f"{r.ses} ep{r.ep} sem{r.semilla} paso {r.paso} ({r.x:.3f},{r.dmin:.3f})" for _, r in cerca5.iterrows()))
# ¿qué hace r5 alrededor de ese punto? filas de r5 a <0.15 m de (2.73, 0.11)
z = DV[DV.ses.isin(S30) & (DV.robot == 5)]
cer = z[np.hypot(z.pose_env_x - 2.73, z.pose_env_y - 0.11) < 0.15]
print(f"  filas de r5 a <0.15 m de (2.73,0.11): {len(cer)} en {cer.groupby(['ses','episodio']).ngroups} episodios · en_escape {cer.en_escape.mean()*100:.0f} % · cbf {cer.cbf_intervino.mean()*100:.0f} %")
for rb in (1, 8, 6, 9):
    zz = DV[DV.ses.isin(S30) & (DV.robot == rb)]
    cc = zz[np.hypot(zz.pose_env_x - 2.73, zz.pose_env_y - 0.11) < 0.15]
    print(f"    r{rb}: filas {len(cc)} en {cc.groupby(['ses','episodio']).ngroups} episodios")
z26 = DV[(DV.ses == "26-09") & (DV.robot == 5)]
c26 = z26[np.hypot(z26.pose_env_x - 2.73, z26.pose_env_y - 0.11) < 0.15]
print(f"  26-09 r5 filas a <0.15 m de (2.73,0.11): {len(c26)} en {c26.groupby(['ses','episodio']).ngroups} episodios")
