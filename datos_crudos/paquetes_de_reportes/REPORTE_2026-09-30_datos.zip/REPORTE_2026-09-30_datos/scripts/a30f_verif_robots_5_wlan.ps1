# VERIFICADOR a30f_verif_robots_: consulta PROPIA (solo lectura) del registro WLAN-AutoConfig.
# A20: adaptador conectado a Robotat el 26-09 y el 30-09; eventos durante las sesiones del 30-09.
# Omisión a chequear: ¿estaba el NIC interno (Realtek) conectado a otra red a la vez?
$log = 'Microsoft-Windows-WLAN-AutoConfig/Operational'
function Lista($ini, $fin) {
  "== $ini .. $fin =="
  $ev = Get-WinEvent -FilterHashtable @{LogName=$log; StartTime=(Get-Date $ini); EndTime=(Get-Date $fin)} -ErrorAction SilentlyContinue | Sort-Object TimeCreated
  if (-not $ev) { "  (sin eventos)"; return }
  "  n=$($ev.Count)"
  foreach ($e in $ev) {
    $m = $e.Message -replace '\s+', ' '
    $ad = ''; if ($m -match 'Network Adapter: (.+?) Interface GUID: (\{[^}]+\})') { $ad = $matches[1] + ' ' + $matches[2].Substring(0,9) }
    $ssid = ''; if ($m -match 'SSID: (\S+)') { $ssid = $matches[1] }
    "  {0:yyyy-MM-dd HH:mm:ss.fff} id={1,-5} {2} SSID={3}" -f $e.TimeCreated, $e.Id, $ad, $ssid
  }
}
# 26-09: desde la medianoche hasta el fin de la sesión (11:34) para ver si el Realtek estaba conectado
Lista '2026-09-25 18:00' '2026-09-26 11:40'
# 30-09: toda la mañana hasta 13:45 (s5 termina 13:38)
Lista '2026-09-30 00:00' '2026-09-30 13:45'
"== eventos 8003 (desconexión) y 8001 (conexión) del Realtek entre 25-09 18:00 y 26-09 11:40 =="
Get-WinEvent -FilterHashtable @{LogName=$log; Id=8001,8003; StartTime=(Get-Date '2026-09-25 18:00'); EndTime=(Get-Date '2026-09-26 11:40')} -ErrorAction SilentlyContinue | Sort-Object TimeCreated | ForEach-Object {
  $m = $_.Message -replace '\s+', ' '
  $ad = ''; if ($m -match 'Network Adapter: (.+?) Interface GUID') { $ad = $matches[1] }
  $ssid = ''; if ($m -match 'SSID: (\S+)') { $ssid = $matches[1] }
  "  {0:yyyy-MM-dd HH:mm:ss} id={1} {2} SSID={3}" -f $_.TimeCreated, $_.Id, $ad, $ssid
}
"== conexiones (8001) a SSID=Robotat desde 2026-09-08 =="
Get-WinEvent -FilterHashtable @{LogName=$log; Id=8001; StartTime=(Get-Date '2026-09-08')} -ErrorAction SilentlyContinue | Sort-Object TimeCreated | ForEach-Object {
  $m = $_.Message -replace '\s+', ' '
  if ($m -match 'SSID: Robotat') {
    $ad = ''; if ($m -match 'Network Adapter: (.+?) Interface GUID: (\{[^}]+\})') { $ad = $matches[1] + ' ' + $matches[2] }
    "  {0:yyyy-MM-dd HH:mm:ss} {1}" -f $_.TimeCreated, $ad
  }
}
"== día de la semana =="
"  2026-09-26: " + (Get-Date '2026-09-26').DayOfWeek
"  2026-09-30: " + (Get-Date '2026-09-30').DayOfWeek
