import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Instantánea de mtimes/tamaños de la carpeta del coordinador (raíz, __pycache__
y resultados_sesion) para comprobar que el análisis a30f_metricas_ no modificó
nada. Uso: python a30f_metricas_mtimes.py <salida.txt>  |  --comparar a b"""
import os
import sys
sys.dont_write_bytecode = True
C = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
SP = (r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis"
      r"\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")

if sys.argv[1] == "--comparar":
    a = open(os.path.join(SP, sys.argv[2]), encoding="utf-8").read().splitlines()
    b = open(os.path.join(SP, sys.argv[3]), encoding="utf-8").read().splitlines()
    da = {l.split(" ", 2)[2]: l for l in a}
    db = {l.split(" ", 2)[2]: l for l in b}
    cambios = [k for k in sorted(set(da) | set(db)) if da.get(k) != db.get(k)]
    print(f"antes {len(a)} archivos · después {len(b)} archivos · diferencias {len(cambios)}")
    for k in cambios:
        print("  ", da.get(k, "(no existía)"), "→", db.get(k, "(ya no existe)"))
    sys.exit(0)

out = []
for sub in ("", "__pycache__", "resultados_sesion"):
    d = os.path.join(C, sub)
    for n in sorted(os.listdir(d)):
        p = os.path.join(d, n)
        if os.path.isfile(p):
            st = os.stat(p)
            out.append(f"{st.st_mtime_ns} {st.st_size} {sub}/{n}")
open(os.path.join(SP, sys.argv[1]), "w", encoding="utf-8").write("\n".join(out) + "\n")
print(len(out), "archivos")
