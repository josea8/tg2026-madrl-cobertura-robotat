import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): omisión posible — ¿los 5 válidos que arrancan con un par a
< 0.31 m (fuera del soporte) cargan las métricas de seguridad (colisiones_022/015, dist_min_robot,
frac_cbf) por el arranque mismo? Descriptivo, sólo CSV de episodios (hw). SOLO LECTURA."""
import sys
sys.dont_write_bytecode = True
import csv, os
import numpy as np

D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
EPI = {1: "20260930_sesion-evaluacion_etapa7_episodios.csv", 2: "20260930_sesion-evaluacion_etapa7_episodios_02.csv",
       3: "20260930_sesion-evaluacion_etapa7_episodios_03.csv", 4: "20260930_sesion-evaluacion_etapa7_episodios_04.csv",
       5: "20260930_sesion-evaluacion_etapa7_episodios_05.csv"}
out = []
P = out.append
g = {True: [], False: []}
for s, a in EPI.items():
    with open(os.path.join(D, a), encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            if r["valido"].strip() != "1":
                continue
            pos = np.array([[float(r[f"x0_a{i}"]), float(r[f"y0_a{i}"])] for i in range(5)])
            dmin = min(np.hypot(*(pos[i] - pos[j])) for i in range(5) for j in range(i + 1, 5))
            fuera = dmin < 0.31
            fila = dict(s=s, ep=int(r["episodio"]), dmin0=dmin, c015=int(r["colisiones_015"]), c022=int(r["colisiones_022"]),
                        dmr=float(r["dist_min_robot"]), fcbf=float(r["frac_cbf"]), fvec=float(r["frac_vecino"]))
            g[fuera].append(fila)
for k in (True, False):
    L = g[k]
    P(f"{'FUERA de soporte' if k else 'resto'} n={len(L)}: colisiones_022 total={sum(x['c022'] for x in L)} (episodios con >0: {sum(1 for x in L if x['c022']>0)}), "
      f"colisiones_015 total={sum(x['c015'] for x in L)}, dist_min_robot mediana={np.median([x['dmr'] for x in L]):.3f} min={min(x['dmr'] for x in L):.3f}, "
      f"frac_cbf media={np.mean([x['fcbf'] for x in L]):.3f}")
for x in g[True]:
    P(f"   s{x['s']} ep{x['ep']}: par mínimo en x0={x['dmin0']:.3f} c015={x['c015']} c022={x['c022']} dist_min_robot={x['dmr']:.3f} frac_cbf={x['fcbf']:.3f}")
open(os.path.join(r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad", "a30f_verif_robots_9_seguridad_arranque_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
