"""
Recalcula las cifras de REPORTE_2026-09-30.md desde los datos crudos de este paquete.

Corre cada `verificar_<sección>.py` de esta carpeta (uno por sección del reporte;
cada uno lee sólo ../csv y ../consola), guarda su salida en
../derivados/verificar_<sección>_salida.txt y junta sus líneas RESUMEN.

Uso:  cd scripts && python -B verificar_cifras.py
Requiere Python ≥ 3.9, numpy y scipy. Sale con código 1 si alguna cifra falla.
"""
import re
import subprocess
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
DERIVADOS = AQUI.parent / "derivados"

total_ok = total_fallas = total_nr = 0
problemas = []
for script in sorted(AQUI.glob("verificar_s*.py")):
    seccion = script.stem.replace("verificar_", "")
    r = subprocess.run([sys.executable, "-B", script.name], cwd=AQUI,
                       capture_output=True, text=True, encoding="utf-8")
    salida = r.stdout + (("\n[stderr]\n" + r.stderr) if r.stderr.strip() else "")
    (DERIVADOS / f"verificar_{seccion}_salida.txt").write_text(salida, encoding="utf-8")
    m = re.search(r"RESUMEN \S+: (\d+) ok, (\d+) fallas, (\d+) no recalculables", r.stdout)
    if r.returncode != 0 or m is None:
        problemas.append(f"{script.name}: terminó con código {r.returncode} o sin línea RESUMEN")
        print(f"{seccion:14s} ERROR (ver derivados/verificar_{seccion}_salida.txt)")
        continue
    ok, fallas, nr = map(int, m.groups())
    total_ok += ok; total_fallas += fallas; total_nr += nr
    print(f"{seccion:14s} {ok:4d} ok   {fallas:3d} fallas   {nr:3d} no recalculables")
    if fallas:
        problemas += [f"{seccion}: {ln}" for ln in r.stdout.splitlines() if ln.rstrip().endswith("FALLA")]

print(f"\nTOTAL: {total_ok} ok, {total_fallas} fallas, {total_nr} no recalculables "
      f"(las no recalculables salen del registro de Windows, del código o de horas de archivos; ver derivados/)")
for p in problemas:
    print("  ✘", p)
sys.exit(1 if (total_fallas or problemas) else 0)
