# -*- coding: utf-8 -*-
"""
verificar_s6_congel.py — verificación INDEPENDIENTE de las cifras del §6 (congelamientos y
retrocesos) y del ítem 5 del §1 de REPORTE_2026-09-30.md.

Sólo lee csv/ y consola/ del paquete (rutas relativas a este archivo). No escribe nada:
la salida va por stdout (se guarda en derivados/verificar_s6_congel_salida.txt).

Definiciones (las del reporte / del pedido de verificación):
* válido = columna 'valido' en ('1', 'True'); semilla = 420000 + ep − 1; agentes 0..4 = robots 1, 5, 8, 6, 9.
* Fila REPETIDA = (x, y, θ) idéntica a la fila anterior del mismo agente y episodio.
  INICIO = primera fila repetida de una racha; su pose es la última viva. Racha = filas repetidas seguidas.
* d_pared = min(x, 3−x, y, 3−y) (marco env). Calibración env = R(rot)·(esc·lab) + tras.
* Mecanismo de cada inicio:
    caché por consulta fallida = todos los agentes del episodio inician en la misma decisión y el episodio
                                 tiene poses_fallidas > 0;
    caché por rechazo          = episodio con poses_rechazadas > 0 y [sync] en la consola de ese episodio
                                 (s4 no tiene consola: se infiere sólo de poses_rechazadas > 0);
    hipo                       = firma de ritmo: con m(p) = mediana del avance |Δp| de los agentes NO
                                 congelados en la decisión p y ref = mediana de m(q), q ∈ [p−10, p+10] salvo
                                 p−1..p+1: m(p−1)/ref > 1.6 y m(p)/ref < 0.30 (umbrales del análisis original;
                                 se informa también la sensibilidad a 0.2);
    retención de Motive        = el resto.
* Pasada por un disco = racha de filas VIVAS consecutivas dentro del disco (las repetidas no la cortan);
  "con congelamiento" = contiene un inicio "de lugar" (Motive o caché por rechazo).
* Neto a la reaparición: u = dirección de entrada (de la viva 5 filas vivas antes hasta la última viva);
  a_lo_largo = (P_reaparición − P_congelada)·u; "adelante" = a_lo_largo > 0, "detrás" = < 0.
Tolerancia de cada comparación = media unidad del último decimal mostrado en el reporte.
"""
import csv, json, math, re, sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

BASE = Path(__file__).resolve().parent.parent
DCSV = BASE / 'csv'
DCON = BASE / 'consola'
SECCION = 's6_congel'

# ------------------------------------------------------------------ calibración
_cal = {}
try:
    _cal = json.loads((DCSV / 'calibracion_medida.json').read_text(encoding='utf-8'))
except Exception:
    _cal = {}
ESC = float(_cal.get('escala_posicion', 1.0166876))
ROT = float(_cal.get('rotacion_marco_rad', 0.0084726))
TX = float(_cal.get('traslacion_x_m', 1.5061547))
TY = float(_cal.get('traslacion_y_m', 1.2563353))


def env2lab(x, y):
    dx, dy = x - TX, y - TY
    c, s = math.cos(ROT), math.sin(ROT)
    return (c * dx + s * dy) / ESC, (-s * dx + c * dy) / ESC


ROBOT_DE = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
PUNTO = {'A': (2.54, 2.20), 'B': (2.82, 2.49), 'C': (2.52, 2.79)}
RAD = 0.08
R_BAJO, R_ALTO = 0.30, 1.6

SESIONES = [
    ('26-09', '20260926_sesion-evaluacion_etapa7', '', 'consola_20260926.txt'),
    ('s1', '20260930_sesion-evaluacion_etapa7', '', 'consola_20260930.txt'),
    ('s2', '20260930_sesion-evaluacion_etapa7', '_02', 'consola_20260930_02.txt'),
    ('s3', '20260930_sesion-evaluacion_etapa7', '_03', 'consola_20260930_03.txt'),
    ('s4', '20260930_sesion-evaluacion_etapa7', '_04', None),
    ('s5', '20260930_sesion-evaluacion_etapa7', '_05', 'consola_20260930_05.txt'),
]
ORDEN = [s[0] for s in SESIONES]
S30 = ['s1', 's2', 's3', 's4', 's5']

# ------------------------------------------------------------------ registro de comparaciones
LINEAS = []
CUENTA = Counter()


def _tol(txt):
    """Media unidad del último decimal mostrado (admite notación 9.9e-9)."""
    t = txt.strip().replace('−', '-').replace(' ', '')
    m = re.match(r'^[+-]?(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$', t)
    if not m:
        raise ValueError(f'no sé leer {txt!r}')
    d = len(m.group(2) or '')
    e = int(m.group(3) or 0)
    return 0.5 * 10.0 ** (-d) * 10.0 ** e, float(t)


def chk(idn, desc, rep_txt, calc, fmt='{:.6g}'):
    tol, rep = _tol(rep_txt)
    ok = calc is not None and not (isinstance(calc, float) and math.isnan(calc)) and abs(calc - rep) <= tol + 1e-12
    est = 'OK' if ok else 'FALLA'
    CUENTA[est] += 1
    LINEAS.append(f'{idn} | {desc} | {rep_txt} | {fmt.format(calc) if calc is not None else "—"} | {est}')


def chk_txt(idn, desc, rep_txt, calc_txt, ok):
    est = 'OK' if ok else 'FALLA'
    CUENTA[est] += 1
    LINEAS.append(f'{idn} | {desc} | {rep_txt} | {calc_txt} | {est}')


def no_rec(idn, desc, rep_txt, fuente):
    CUENTA['NR'] += 1
    LINEAS.append(f'{idn} | {desc} | {rep_txt} | — | NO RECALCULABLE (fuente: {fuente})')


def nota(txt):
    LINEAS.append(f'   · {txt}')


def titulo(txt):
    LINEAS.append('')
    LINEAS.append('=' * 100)
    LINEAS.append(txt)
    LINEAS.append('=' * 100)


# ------------------------------------------------------------------ carga
def es_valido(v):
    return str(v).strip() in ('1', 'True')


def cargar_episodios(pref, suf):
    with open(DCSV / f'{pref}_episodios{suf}.csv', newline='', encoding='utf-8-sig') as fh:
        return {int(r['episodio']): r for r in csv.DictReader(fh)}


def cargar_decisiones(pref, suf):
    g = defaultdict(list)
    with open(DCSV / f'{pref}_decisiones{suf}.csv', newline='', encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            g[(int(r['episodio']), int(r['agente']))].append(
                (int(r['paso']), float(r['pose_env_x']), float(r['pose_env_y']), float(r['pose_env_th']),
                 int(r.get('en_retroceso') or 0), int(r['robot'])))
    seqs = {}
    for k, f in g.items():
        f.sort(key=lambda q: q[0])
        rep = [False] + [f[t][1:4] == f[t - 1][1:4] for t in range(1, len(f))]
        seqs[k] = dict(paso=[q[0] for q in f], x=[q[1] for q in f], y=[q[2] for q in f], th=[q[3] for q in f],
                       retro=[q[4] for q in f], rep=rep, robot=f[0][5], idx={q[0]: t for t, q in enumerate(f)})
    return seqs


RX_HDR = re.compile(r'^EPISODIO (\d+)\s+\(')
RX_SYNC = re.compile(r'\[sync\] Decisi\S* con pose vieja: antig\S*=(\d+) ticks')
RX_RET = re.compile(r'↩ agente (\d+) \(robot (\d+)\): pose repetida.*\(decisi\S* (\d+)\)')


def leer_consola(nombre):
    if nombre is None:
        return None
    lin = (DCON / nombre).read_text(encoding='utf-8', errors='replace').splitlines()
    ep = None
    eventos = []   # (tipo, ep, datos, n_línea)
    for k, l in enumerate(lin):
        m = RX_HDR.match(l)
        if m:
            ep = int(m.group(1))
            continue
        m = RX_SYNC.search(l)
        if m:
            eventos.append(('sync', ep, int(m.group(1)), k))
            continue
        m = RX_RET.search(l)
        if m:
            eventos.append(('ret', ep, (int(m.group(1)), int(m.group(2)), int(m.group(3))), k))
    sync_ep = Counter(e[1] for e in eventos if e[0] == 'sync')
    rets = [e for e in eventos if e[0] == 'ret']
    # cada [sync] se ancla a la decisión del primer ↩ que le sigue en el mismo episodio
    sync_dec = set()
    for n, e in enumerate(eventos):
        if e[0] != 'sync':
            continue
        for f in eventos[n + 1:]:
            if f[1] != e[1]:
                break
            if f[0] == 'ret':
                sync_dec.add((e[1], f[2][2]))
                break
    return dict(sync_ep=sync_ep, sync_dec=sync_dec, rets=[(e[1], e[2][0], e[2][1], e[2][2]) for e in rets], n=len(lin))


EP, DEC, CON = {}, {}, {}
for ses, pref, suf, cons in SESIONES:
    EP[ses] = cargar_episodios(pref, suf)
    DEC[ses] = cargar_decisiones(pref, suf)
    CON[ses] = leer_consola(cons)

# controles de carga
for ses in ORDEN:
    for (ep, ag), s in DEC[ses].items():
        assert ROBOT_DE[ag] == s['robot'], (ses, ep, ag, s['robot'])
    for ep, e in EP[ses].items():
        assert int(e['semilla']) == 420000 + ep - 1, (ses, ep)


def valido(ses, ep):
    return es_valido(EP[ses][ep]['valido'])


RX_DET = re.compile(r'a(\d+):(\d+)-(\d+)\(([\d.]+)s,([\d.]+)cm,([a-z_]+)\)')


def retrocesos(ses, ep):
    return [dict(ag=int(m.group(1)), p0=int(m.group(2)), p1=int(m.group(3)), dur=float(m.group(4)),
                 cm=float(m.group(5)), res=m.group(6))
            for m in RX_DET.finditer(EP[ses][ep].get('retrocesos_detalle') or '')]


# ------------------------------------------------------------------ inicios
INI = {}
for ses in ORDEN:
    lst = []
    for (ep, ag), s in DEC[ses].items():
        rep = s['rep']
        for t in range(1, len(rep)):
            if rep[t] and not rep[t - 1]:
                j = t
                while j < len(rep) and rep[j]:
                    j += 1
                lst.append(dict(ses=ses, ep=ep, ag=ag, robot=s['robot'], t=t, j=j, racha=j - t, paso=s['paso'][t],
                                x=s['x'][t], y=s['y'][t], th=s['th'][t], val=valido(ses, ep)))
    n_ag = Counter(ep for (ep, ag) in DEC[ses])
    por_dec = Counter((it['ep'], it['paso']) for it in lst)
    for it in lst:
        it['n_dec'] = por_dec[(it['ep'], it['paso'])]
        it['n_ag'] = n_ag[it['ep']]
        it['xl'], it['yl'] = env2lab(it['x'], it['y'])
        it['rlab'] = math.hypot(it['xl'], it['yl'])
    INI[ses] = sorted(lst, key=lambda it: (it['ep'], it['paso'], it['ag']))

# ------------------------------------------------------------------ ritmo (hipo)
DELTA = {}   # (ses, ep) -> {paso: {ag: (Δmm, rep)}}
for ses in ORDEN:
    for (ep, ag), s in DEC[ses].items():
        d = DELTA.setdefault((ses, ep), defaultdict(dict))
        for t in range(1, len(s['paso'])):
            if s['paso'][t] != s['paso'][t - 1] + 1:
                continue
            d[s['paso'][t]][ag] = (1000.0 * math.hypot(s['x'][t] - s['x'][t - 1], s['y'][t] - s['y'][t - 1]), s['rep'][t])

_mcache = {}


def m_dec(ses, ep, p, excl=frozenset()):
    key = (ses, ep, p, excl)
    if key in _mcache:
        return _mcache[key]
    d = DELTA[(ses, ep)].get(p, {})
    v = [dm for ag, (dm, rp) in d.items() if not rp and ag not in excl]
    r = float(np.median(v)) if v else float('nan')
    _mcache[key] = r
    return r


def ref_dec(ses, ep, p, excl=frozenset()):
    v = [m_dec(ses, ep, q, excl) for q in range(p - 10, p + 11) if abs(q - p) > 1]
    v = [a for a in v if not math.isnan(a)]
    return float(np.median(v)) if v else float('nan')


# firma de cada inicio (excluyendo a los agentes que inician en esa decisión)
for ses in ORDEN:
    for it in INI[ses]:
        excl = frozenset(x['ag'] for x in INI[ses] if x['ep'] == it['ep'] and x['paso'] == it['paso'])
        ref = ref_dec(ses, it['ep'], it['paso'], excl)
        it['r'] = m_dec(ses, it['ep'], it['paso'], excl) / ref if ref else float('nan')
        it['rprev'] = m_dec(ses, it['ep'], it['paso'] - 1, excl) / ref if ref else float('nan')
        it['ref'] = ref
        it['excl'] = excl
        it['hipo'] = (it['r'] < R_BAJO) and (it['rprev'] > R_ALTO)


# ------------------------------------------------------------------ clasificación de mecanismo
def clasificar(it):
    ses, ep = it['ses'], it['ep']
    e = EP[ses][ep]
    pf = int(e['poses_fallidas'] or 0)
    pr = int(e['poses_rechazadas'] or 0)
    c = CON[ses]
    if it['n_dec'] >= 2:
        if it['n_dec'] == it['n_ag'] and pf > 0:
            return 'fallida', False
        if it['hipo']:
            return 'hipo', c is None
        return 'simultaneo_sin_explicar', False
    if pr > 0:
        if c is None:
            return 'rechazo', True              # inferido: sin consola
        if c['sync_ep'][ep] > 0:
            return 'rechazo', False
    if it['hipo']:
        return 'hipo', c is None
    return 'motive', False


for ses in ORDEN:
    for it in INI[ses]:
        it['mec'], it['inferido'] = clasificar(it)

LUGAR = [it for ses in ORDEN for it in INI[ses] if it['mec'] in ('motive', 'rechazo')]


def filas(ses, cond=None):
    return sum(len(s['paso']) for (ep, ag), s in DEC[ses].items() if cond is None or valido(ses, ep) == cond)


# =================================================================== 0) control
titulo('0) CONTROL DE CARGA')
for ses in ORDEN:
    nv = sum(valido(ses, ep) for ep in EP[ses])
    c = CON[ses]
    ctxt = 'SIN CONSOLA' if c is None else f"consola {c['n']} líneas, [sync] {sum(c['sync_ep'].values())}, ↩ {len(c['rets'])}"
    LINEAS.append(f'   {ses:6s} episodios {len(EP[ses]):2d}  válidos {nv:2d}  filas {filas(ses):6d}  inicios {len(INI[ses]):2d}  {ctxt}')
LINEAS.append(f'   calibración: esc {ESC:.7f} rot {ROT:.7f} tras ({TX:.7f}, {TY:.7f})')
# ↩ de consola contra inicios del CSV (deben coincidir 1 a 1)
for ses in ORDEN:
    c = CON[ses]
    if c is None:
        continue
    a = sorted((ep, ag, d) for ep, ag, rb, d in c['rets'])
    b = sorted((it['ep'], it['ag'], it['paso']) for it in INI[ses])
    LINEAS.append(f'   {ses}: ↩ de consola = inicios del CSV (episodio, agente, decisión): {"sí" if a == b else "NO"} ({len(a)} vs {len(b)})')
LINEAS.append('   Inicios por sesión y mecanismo (V = válido):')
for ses in ORDEN:
    for it in INI[ses]:
        LINEAS.append(f"     {ses:6s} ep{it['ep']:2d} {'V' if it['val'] else 'A'} a{it['ag']}/r{it['robot']} paso {it['paso']:3d} racha {it['racha']:2d}"
                      f" env ({it['x']:.3f}, {it['y']:.3f}) lab ({it['xl']:+.3f}, {it['yl']:+.3f}) en la decisión {it['n_dec']}/{it['n_ag']}"
                      f" r_prev {it['rprev']:.2f} r {it['r']:.2f} → {it['mec']}{' (inferido, sin consola)' if it['inferido'] else ''}")
sin_expl = [it for ses in ORDEN for it in INI[ses] if it['mec'] == 'simultaneo_sin_explicar']
LINEAS.append(f'   simultáneos sin explicar: {len(sin_expl)}')

# =================================================================== 1) tabla por sesión
titulo('1) TABLA DEL §6 POR SESIÓN (inicios, mecanismos, retrocesos)')
REP_TABLA = {   # inicios, Motive, fallida, rechazo, hipo, recuperados, sigue_congelada
    '26-09': (12, 11, 0, 1, 0, 5, 6),
    's1': (12, 2, 10, 0, 0, 2, 0),
    's2': (2, 1, 0, 0, 1, 2, 0),
    's3': (3, 3, 0, 0, 0, 3, 0),
    's4': (8, 5, 0, 1, 2, 7, 0),
    's5': (4, 0, 0, 2, 2, 3, 0),
}
COLS = ['inicios', 'retención de Motive', 'caché por consulta fallida', 'caché por pose rechazada', 'hipo del lazo',
        'retrocesos recuperados', '"sigue congelada"']
for ses in ORDEN:
    m = Counter(it['mec'] for it in INI[ses])
    dets = [d for ep in EP[ses] for d in retrocesos(ses, ep)]
    res = Counter(d['res'] for d in dets)
    calc = (len(INI[ses]), m['motive'], m['fallida'], m['rechazo'], m['hipo'], res['recuperada'], res['sigue_congelada'])
    for k, (col, rv, cv) in enumerate(zip(COLS, REP_TABLA[ses], calc)):
        extra = ' (inferido de poses_rechazadas, sin consola)' if (ses == 's4' and k == 3) else ''
        chk(f'T-{ses}-{k + 1}', f'tabla §6, {ses}, {col}{extra}', str(rv), cv, '{:d}')
# detalle s1: los 10 de caché fallida son ep 1 y 2, los 5 a la vez
s1f = Counter((it['ep'], it['paso']) for it in INI['s1'] if it['mec'] == 'fallida')
chk_txt('T-s1-det', 'tabla §6, s1: caché fallida = ep 1 y 2, los 5 a la vez', 'ep 1 y 2, 5 + 5',
        ', '.join(f'ep {ep} decisión {p}: {n}' for (ep, p), n in sorted(s1f.items())),
        sorted(ep for ep, p in s1f) == [1, 2] and all(n == 5 for n in s1f.values()))
no_rec('T-s4-sync', 'tabla §6, s4: confirmación con [sync] del rechazo de s4 ep 7', '1 (inferido, sin consola)',
       'consola de la s4, que no existe; sólo se infiere de poses_rechazadas = 2 en el CSV')
# coherencia retrocesos_detalle ↔ inicios
n_det = sum(len(retrocesos(s, ep)) for s in ORDEN for ep in EP[s])
n_ini = sum(len(INI[s]) for s in ORDEN)
nota(f'retrocesos_detalle tiene {n_det} entradas y hay {n_ini} inicios (6 días): un retroceso por inicio')

# =================================================================== 2) tasas
titulo('2) TASAS')
f30v = sum(filas(s, True) for s in S30)
f30 = sum(filas(s) for s in S30)
f26 = filas('26-09')
f26v = filas('26-09', True)
ini30v = [it for s in S30 for it in INI[s] if it['val']]
mot30v = [it for it in ini30v if it['mec'] == 'motive']
mot30 = [it for s in S30 for it in INI[s] if it['mec'] == 'motive']
mot26 = [it for it in INI['26-09'] if it['mec'] == 'motive']
mot26v = [it for it in mot26 if it['val']]
chk('TA-1', 'válidos 30-09: inicios', '16', len(ini30v), '{:d}')
chk('TA-2', 'válidos 30-09: filas', '125000', f30v, '{:d}')
chk('TA-3', 'válidos 30-09: inicios por mil filas (‰)', '0.128', 1000 * len(ini30v) / f30v, '{:.4f}')
chk('TA-4', 'válidos 30-09: retenciones de Motive', '11', len(mot30v), '{:d}')
chk('TA-5', 'válidos 30-09: Motive por mil filas (‰)', '0.088', 1000 * len(mot30v) / f30v, '{:.4f}')
chk('TA-6', 'todos los episodios 26-09: Motive por mil filas (‰)', '0.321', 1000 * len(mot26) / f26, '{:.4f}')
chk('TA-7', 'todos los episodios 30-09: Motive por mil filas (‰)', '0.082', 1000 * len(mot30) / f30, '{:.4f}')
ep_m26 = {it['ep'] for it in mot26}
ep_m30 = {(it['ses'], it['ep']) for it in mot30}
n26, n30 = len(EP['26-09']), sum(len(EP[s]) for s in S30)
chk('TA-8', 'episodios 26-09 con algún inicio de Motive', '9', len(ep_m26), '{:d}')
chk('TA-9', 'episodios 26-09 (denominador)', '19', n26, '{:d}')
chk('TA-10', 'episodios 30-09 con algún inicio de Motive', '7', len(ep_m30), '{:d}')
chk('TA-11', 'episodios 30-09 (denominador)', '57', n30, '{:d}')
p_ep = stats.fisher_exact([[len(ep_m26), n26 - len(ep_m26)], [len(ep_m30), n30 - len(ep_m30)]])[1]
chk('TA-12', 'Fisher episodios con Motive 9/19 vs 7/57 (p)', '0.0026', p_ep, '{:.5f}')
# contexto para las observaciones
p_filas_v = stats.fisher_exact([[len(mot26v), f26v - len(mot26v)], [len(mot30v), f30v - len(mot30v)]])[1]
ep_m26v = {it['ep'] for it in mot26v}
nv26 = sum(valido('26-09', ep) for ep in EP['26-09'])
nv30 = sum(valido(s, ep) for s in S30 for ep in EP[s])
p_ep_v = stats.fisher_exact([[len(ep_m26v), nv26 - len(ep_m26v)], [len(ep_m30), nv30 - len(ep_m30)]])[1]
p_filas_t = stats.fisher_exact([[len(mot26), f26 - len(mot26)], [len(mot30), f30 - len(mot30)]])[1]
nota(f'contexto: Motive en VÁLIDOS 26-09 {len(mot26v)}/{f26v} = {1000*len(mot26v)/f26v:.3f} ‰ vs 30-09 {len(mot30v)}/{f30v} = '
     f'{1000*len(mot30v)/f30v:.3f} ‰, Fisher p {p_filas_v:.3f}; por episodio válido {len(ep_m26v)}/{nv26} vs {len(ep_m30)}/{nv30}, p {p_ep_v:.3f}')
nota(f'contexto: Motive en TODOS 26-09 {len(mot26)}/{f26} vs 30-09 {len(mot30)}/{f30}, Fisher por fila p {p_filas_t:.4f} (orientativo)')
nota(f'todas las retenciones de Motive del 30-09 están en válidos: {len(mot30)} = {len(mot30v)}')

# =================================================================== 3) lugares A, B, C (pasadas)
titulo('3) LUGARES A, B, C: pasadas por un disco de 8 cm')
INI_LUGAR = {(it['ses'], it['ep'], it['ag'], it['paso']) for it in LUGAR}


def pasadas(ses, cx, cy, rad=RAD):
    out = []
    for (ep, ag), s in DEC[ses].items():
        cur = None
        for t in range(len(s['paso'])):
            if s['rep'][t]:
                if cur is not None and (ses, ep, ag, s['paso'][t]) in INI_LUGAR:
                    cur['cong'] = True
                continue
            if math.hypot(s['x'][t] - cx, s['y'][t] - cy) < rad:
                if cur is None:
                    cur = dict(ep=ep, ag=ag, robot=s['robot'], cong=False)
            elif cur is not None:
                out.append(cur)
                cur = None
        if cur is not None:
            out.append(cur)
    return out


PAS = {}
for P, (cx, cy) in PUNTO.items():
    p26 = pasadas('26-09', cx, cy)
    p30 = [q for s in S30 for q in pasadas(s, cx, cy)]
    PAS[P] = (p26, p30)
REP_PAS = {'A': ('4', '9', '0', '65'), 'B': ('2', '8', '0', '47'), 'C': ('3', '9', '1', '39')}
for P in 'ABC':
    p26, p30 = PAS[P]
    r = REP_PAS[P]
    if P != 'C':
        chk(f'L-{P}-1', f'{P}: pasadas con congelamiento 26-09', r[0], sum(q['cong'] for q in p26), '{:d}')
        chk(f'L-{P}-2', f'{P}: pasadas 26-09', r[1], len(p26), '{:d}')
    chk(f'L-{P}-3', f'{P}: pasadas con congelamiento 30-09 (5 sesiones)', r[2], sum(q['cong'] for q in p30), '{:d}')
    chk(f'L-{P}-4', f'{P}: pasadas 30-09 (5 sesiones)', r[3], len(p30), '{:d}')
for P in 'ABC':
    nota(f"{P}: las {len(PAS[P][1])} pasadas del 30-09 vienen de {len({(s_, q['ep'], q['ag']) for s_ in S30 for q in pasadas(s_, *PUNTO[P])})} robot-episodios distintos (no son independientes)")
c30 = [it for it in LUGAR if it['ses'] in S30 and math.hypot(it['x'] - PUNTO['C'][0], it['y'] - PUNTO['C'][1]) < RAD]
pc = [q for s in S30 for q in pasadas(s, *PUNTO['C']) if q['cong']]
chk_txt('L-C-5', 'C reapareció en s3 ep 1, r8', 's3 ep 1, r8',
        '; '.join(f"{it['ses']} ep {it['ep']} r{it['robot']} paso {it['paso']}" for it in c30),
        {(it['ses'], it['ep'], it['robot']) for it in c30} == {('s3', 1, 8)} and len(pc) == 1)
nota(f'en esa única pasada de C con congelamiento hay {len(c30)} inicios (pasos {", ".join(str(it["paso"]) for it in c30)})')
# coordenadas A, B, C = centroides de los grupos del 26-09 (enlace simple 8 cm)


def grupos(pts, rad=RAD):
    n = len(pts)
    padre = list(range(n))

    def raiz(a):
        while padre[a] != a:
            padre[a] = padre[padre[a]]
            a = padre[a]
        return a
    for a in range(n):
        for b in range(a + 1, n):
            if math.hypot(pts[a]['x'] - pts[b]['x'], pts[a]['y'] - pts[b]['y']) <= rad:
                padre[raiz(a)] = raiz(b)
    g = defaultdict(list)
    for a in range(n):
        g[raiz(a)].append(pts[a])
    return list(g.values())


G26 = grupos([it for it in LUGAR if it['ses'] == '26-09'])
for P, (px, py) in PUNTO.items():
    cand = [g for g in G26 if len(g) >= 2 and math.hypot(np.mean([q['x'] for q in g]) - px, np.mean([q['y'] for q in g]) - py) < RAD]
    if cand:
        g = cand[0]
        chk(f'L-{P}-x', f'{P}: x env = centroide del grupo del 26-09 (n={len(g)})', f'{px:.2f}', float(np.mean([q['x'] for q in g])), '{:.4f}')
        chk(f'L-{P}-y', f'{P}: y env = centroide del grupo del 26-09 (n={len(g)})', f'{py:.2f}', float(np.mean([q['y'] for q in g])), '{:.4f}')
    else:
        chk_txt(f'L-{P}-xy', f'{P}: grupo del 26-09 cerca de ({px}, {py})', f'({px}, {py})', 'ningún grupo', False)

# =================================================================== 4) centro del laboratorio
titulo('4) CENTRO DEL LABORATORIO (≤ 10 cm del origen lab) y grupo E')
cen30 = [it for s in S30 for it in INI[s] if it['rlab'] <= 0.10]
cen26 = [it for it in INI['26-09'] if it['rlab'] <= 0.10]
chk('C-1', 'inicios del 30-09 a ≤ 10 cm del origen lab', '7', len(cen30), '{:d}')
chk_txt('C-2', 'todos del robot 6', 'sólo el robot 6', str(sorted({it['robot'] for it in cen30})), {it['robot'] for it in cen30} == {6})
chk('C-3', 'de ellos, retenciones de Motive en válidos', '6', sum(1 for it in cen30 if it['mec'] == 'motive' and it['val']), '{:d}')
rc = [it for it in cen30 if it['mec'] == 'rechazo']
chk_txt('C-4', 'y 1 pose rechazada en s5 ep 6', '1 (s5 ep 6)', '; '.join(f"{it['ses']} ep {it['ep']} {'V' if it['val'] else 'A'}" for it in rc),
        len(rc) == 1 and (rc[0]['ses'], rc[0]['ep']) == ('s5', 6))
# exposición por robot (todas las filas del 30-09, válidos y abortados)
eps_rob = defaultdict(set)
filas_rob = Counter()
for s in S30:
    for (ep, ag), q in DEC[s].items():
        n = 0
        for t in range(len(q['paso'])):
            xl, yl = env2lab(q['x'][t], q['y'][t])
            if math.hypot(xl, yl) <= 0.10:
                n += 1
        if n:
            eps_rob[q['robot']].add((s, ep))
            filas_rob[q['robot']] += n
eps_r6_ini = {(it['ses'], it['ep']) for it in cen30 if it['robot'] == 6}
otros_ep = sum(len(v) for r, v in eps_rob.items() if r != 6)
otros_filas = sum(v for r, v in filas_rob.items() if r != 6)
otros_ini = sum(1 for it in cen30 if it['robot'] != 6)
chk('C-5', 'episodios en que el r6 pasó a ≤ 10 cm del origen lab', '8', len(eps_rob[6]), '{:d}')
chk('C-6', 'episodios del r6 con inicio ahí', '5', len(eps_r6_ini), '{:d}')
chk('C-7', 'robot-episodios de los otros robots a ≤ 10 cm', '16', otros_ep, '{:d}')
chk('C-8', 'filas de los otros robots a ≤ 10 cm', '395', otros_filas, '{:d}')
chk('C-9', 'inicios de los otros robots ahí', '0', otros_ini, '{:d}')
chk('C-10', '26-09: inicios a ≤ 10 cm del origen lab', '0', len(cen26), '{:d}')
nota('exposición por robot 30-09 (episodios, filas): ' + ', '.join(f'r{r} ({len(eps_rob[r])}, {filas_rob[r]})' for r in (1, 5, 8, 6, 9)))
p_c = stats.fisher_exact([[len(eps_r6_ini), len(eps_rob[6]) - len(eps_r6_ini)], [0, otros_ep]])[1]
nota(f'r6 {len(eps_r6_ini)}/{len(eps_rob[6])} episodios con inicio vs otros 0/{otros_ep}: Fisher p {p_c:.4f}')
# 26-09: exposición del r6
eps26 = defaultdict(set)
for (ep, ag), q in DEC['26-09'].items():
    if any(math.hypot(*env2lab(q['x'][t], q['y'][t])) <= 0.10 for t in range(len(q['paso']))):
        eps26[q['robot']].add(ep)
p_nuevo = stats.fisher_exact([[0, len(eps26[6])], [len(eps_r6_ini), len(eps_rob[6]) - len(eps_r6_ini)]])[1]
nota(f'26-09: el r6 pasó por el centro en {len(eps26[6])} episodios sin inicio; 0/{len(eps26[6])} vs 5/8 del 30-09, Fisher p {p_nuevo:.3f}'
     ' ("nuevo" no es demostrable con esa exposición)')

# grupo E (enlace simple 8 cm sobre los inicios "de lugar" de los 6 días)
G = grupos(LUGAR)
gE = [g for g in G if any((q['ses'], q['ep'], q['ag'], q['paso']) == ('s4', 1, 2, 439) for q in g)][0]
cxE, cyE = float(np.mean([q['x'] for q in gE])), float(np.mean([q['y'] for q in gE]))
xlE, ylE = env2lab(cxE, cyE)
chk('E-1', 'E: x env del centroide', '2.83', cxE, '{:.4f}')
chk('E-2', 'E: y env del centroide', '2.74', cyE, '{:.4f}')
chk('E-3', 'E: x lab del centroide', '+1.31', xlE, '{:+.4f}')
chk('E-4', 'E: y lab del centroide', '+1.45', ylE, '{:+.4f}')
chk('E-5', 'E: inicios', '4', len(gE), '{:d}')
chk('E-6', 'E: inicios del r8', '3', sum(1 for q in gE if q['robot'] == 8), '{:d}')
r9E = [q for q in gE if q['robot'] == 9]
chk_txt('E-7', 'E: un rechazo del r9', '1 rechazo del r9', '; '.join(f"{q['ses']} ep {q['ep']} {q['mec']}" for q in r9E),
        len(r9E) == 1 and r9E[0]['mec'] == 'rechazo')
nota('E: miembros ' + '; '.join(f"{q['ses']} ep {q['ep']} r{q['robot']} paso {q['paso']} ({q['mec']})" for q in gE)
     + f"; sesiones del 26-09 en E: {sum(1 for q in gE if q['ses'] == '26-09')}")
nuevos = [g for g in G if len(g) >= 2 and all(q['ses'] in S30 for q in g)]
chk('E-8', '§1: grupos nuevos (n ≥ 2, sólo con inicios del 30-09)', '2', len(nuevos), '{:d}')
# exposición en E por robot
pE26 = pasadas('26-09', cxE, cyE)
pE30 = [q for s in S30 for q in pasadas(s, cxE, cyE)]
r8c = sum(1 for q in pE30 if q['robot'] == 8 and q['cong'])
r8n = sum(1 for q in pE30 if q['robot'] == 8)
oc = sum(1 for q in pE30 if q['robot'] != 8 and q['cong'])
on = sum(1 for q in pE30 if q['robot'] != 8)
p_e = stats.fisher_exact([[r8c, r8n - r8c], [oc, on - oc]])[1]
nota(f'E (disco 8 cm): 30-09 r8 {r8c}/{r8n} pasadas con congelamiento vs otros {oc}/{on}, Fisher p {p_e:.3f};'
     f' 26-09: {sum(q["cong"] for q in pE26)}/{len(pE26)} pasadas, por robot {dict(Counter(q["robot"] for q in pE26))} (el r8 no pasó por E el 26-09)')

# =================================================================== 5) intermitencia
titulo('5) INTERMITENCIA: mismo agente, misma semilla, otras sesiones del 30-09, a ≤ 3 cm del punto de inicio')


def pareos(filtro):
    pares, distintos = [], set()
    for it in [x for x in LUGAR if x['ses'] in S30 and filtro(x)]:
        for s in S30:
            if s == it['ses'] or (it['ep'], it['ag']) not in DEC[s]:
                continue
            q = DEC[s][(it['ep'], it['ag'])]
            dmin = min(math.hypot(q['x'][t] - it['x'], q['y'][t] - it['y']) for t in range(len(q['paso'])) if not q['rep'][t])
            cong = any(x['ep'] == it['ep'] and x['ag'] == it['ag'] and math.hypot(x['x'] - it['x'], x['y'] - it['y']) < RAD
                       for x in LUGAR if x['ses'] == s)
            if dmin <= 0.03:
                pares.append((it['ses'], it['ep'], it['paso'], s, cong))
                distintos.add((s, it['ep'], it['ag']))
    return pares, distintos


esq = lambda it: it['x'] > 2.3 and it['y'] > 2.5
par_esq, dist_esq = pareos(esq)
par_tod, dist_tod = pareos(lambda it: True)
chk('I-1', 'pares (inicio, otra sesión) a ≤ 3 cm sin congelarse — esquina +x+y (C, E y rechazos de borde)', '20',
    sum(1 for p in par_esq if not p[4]), '{:d}')
chk('I-2', 'idem, contando TODOS los inicios "de lugar" del 30-09 (incluye el centro): "22 contando el centro"', '22', sum(1 for p in par_tod if not p[4]), '{:d}')
nota(f'de esos pares, con congelamiento: esquina {sum(p[4] for p in par_esq)}, todos {sum(p[4] for p in par_tod)}')
nota(f'robot-episodios distintos detrás de los pares: esquina {len(dist_esq)}, todos {len(dist_tod)} '
     '(los pares de s3 ep 1 y s4 ep 1 —misma semilla y agente— se cuentan dos veces cada uno)')

# =================================================================== 6) marcadores
titulo('6) RETENCIONES DE MOTIVE POR MARCADOR Y RECHAZOS POR INCLINACIÓN')
rob30 = Counter(it['robot'] for it in mot30v)
chk('M-1', 'Motive en válidos 30-09: marcadores distintos', '2', len(rob30), '{:d}')
chk('M-2', 'Motive en válidos 30-09: r6', '6', rob30[6], '{:d}')
chk('M-3', 'Motive en válidos 30-09: r8', '5', rob30[8], '{:d}')
r6c = all(it['rlab'] <= 0.10 for it in mot30v if it['robot'] == 6)
gC = [g for g in G if any(math.hypot(q['x'] - PUNTO['C'][0], q['y'] - PUNTO['C'][1]) < 0.03 for q in g)]
en_CE = lambda it: any(it in g for g in gC) or it in gE
r8ce = Counter(('C' if any(it in g for g in gC) else 'E' if it in gE else '?') for it in mot30v if it['robot'] == 8)
chk_txt('M-4', 'los 6 del r6 están en el centro; los 5 del r8 en C y E', 'r6 centro; r8 C y E',
        f'r6 en el centro: {r6c}; r8 por grupo: {dict(r8ce)}', r6c and set(r8ce) <= {'C', 'E'})
rob26 = Counter(it['robot'] for it in mot26)
chk_txt('M-5', '26-09: Motive repartidas entre r5, r6, r8 y r9', 'r5, r6, r8, r9', str(dict(sorted(rob26.items()))),
        set(rob26) == {5, 6, 8, 9})
rech30 = [it for s in S30 for it in INI[s] if it['mec'] == 'rechazo']
lug, etq = [], []
for it in rech30:
    dC = math.hypot(it['x'] - PUNTO['C'][0], it['y'] - PUNTO['C'][1])
    if it['rlab'] <= 0.10:
        e_ = 'centro'
    elif it in gE:
        e_ = 'E'
    elif dC < 0.12:
        e_ = 'cerca de C'
    else:
        e_ = 'otro'
    etq.append(f"r{it['robot']} {e_}")
    lug.append(f"r{it['robot']} {it['ses']} ep {it['ep']}: {e_} (a {100*dC:.1f} cm de C, {100*it['rlab']:.1f} cm del origen lab)")
okr = sorted(etq) == ['r6 centro', 'r8 cerca de C', 'r9 E']
chk_txt('M-6', 'rechazos del 30-09: r6 en el centro, r8 cerca de C, r9 en E', 'r6 centro; r8 cerca de C; r9 E', '; '.join(lug), okr)
no_rec('M-7', 'umbral de inclinación de los rechazos', '> 30°', 'código del adaptador; el CSV sólo trae "inclinación:n" y la consola no lo imprime')
no_rec('M-8', 'hipótesis: cuerpos rígidos 6 y 8 mal definidos o dañados', 'hipótesis', 'Motive / inspección física; los CSV no lo pueden mostrar')

# =================================================================== 7) hipo
titulo('7) HIPO DEL LAZO')
HIPOS = []
nbase = Counter()
nnan = Counter()
for s in ORDEN:
    for (ses, ep), d in DELTA.items():
        if ses != s:
            continue
        for p, dd in d.items():
            if p < 12 or len(dd) < 5:
                continue
            v = valido(s, ep)
            nbase[(s, v)] += 1
            m0, mp, ref = m_dec(s, ep, p), m_dec(s, ep, p - 1), ref_dec(s, ep, p)
            con_ini = any(it['ep'] == ep and it['paso'] == p for it in INI[s])
            if any(math.isnan(a) for a in (m0, mp, ref)) or ref == 0:
                nnan[(s, v)] += 1
                HIPOS.append(dict(ses=s, ep=ep, p=p, val=v, hipo=False, nan=True, ini=con_ini, r=float('nan'), rp=float('nan')))
                continue
            HIPOS.append(dict(ses=s, ep=ep, p=p, val=v, hipo=(m0 / ref < R_BAJO and mp / ref > R_ALTO), nan=False, ini=con_ini,
                              r=m0 / ref, rp=mp / ref))
h30 = [h for h in HIPOS if h['ses'] in S30 and h['hipo']]
h30v = [h for h in h30 if h['val']]
h26 = [h for h in HIPOS if h['ses'] == '26-09' and h['hipo']]
n26d = nbase[('26-09', True)] + nbase[('26-09', False)]
chk('H-1', 'hipos del 30-09 (decisiones con los 5 agentes, paso ≥ 12)', '11', len(h30), '{:d}')
chk('H-2', 'hipos en válidos', '9', len(h30v), '{:d}')
chk('H-3', 'episodios válidos con hipo', '8', len({(h['ses'], h['ep']) for h in h30v}), '{:d}')
chk('H-4', 'hipos del 26-09', '0', len(h26), '{:d}')
chk('H-5', 'decisiones evaluadas del 26-09', '6624', n26d, '{:d}')
dv = [h for h in HIPOS if h['ses'] in S30 and h['val']]
nh = len(h30v)
hi = sum(h['ini'] for h in h30v)
nn = len(dv) - nh
ni = sum(1 for h in dv if not h['hipo'] and h['ini'])
chk('H-6', 'válidos: hipos con inicio', '3', hi, '{:d}')
chk('H-7', 'válidos: decisiones sin hipo con inicio', '10', ni, '{:d}')
chk('H-8', 'válidos: decisiones sin hipo', '24391', nn, '{:d}')
p_h = stats.fisher_exact([[hi, nh - hi], [ni, nn - ni]])[1]
chk('H-9', 'Fisher hipo ↔ inicio (p)', '9.9e-9', p_h, '{:.3e}')
excl2 = {('s5', 9, 157), ('s4', 9, 270)}
dv2 = [h for h in dv if (h['ses'], h['ep'], h['p']) not in excl2]
nh2 = sum(h['hipo'] for h in dv2)
hi2 = sum(1 for h in dv2 if h['hipo'] and h['ini'])
nn2 = len(dv2) - nh2
ni2 = sum(1 for h in dv2 if not h['hipo'] and h['ini'])
p_h2 = stats.fisher_exact([[hi2, nh2 - hi2], [ni2, nn2 - ni2]])[1]
chk('H-10', 'Fisher sin las 2 decisiones que motivaron la firma (p)', '0.003', p_h2, '{:.5f}')
nota(f'sin esas 2: {hi2}/{nh2} hipos con inicio vs {ni2}/{nn2}; decisiones con NaN (excluidas del hipo): {dict(nnan)}')
no_rec('H-11', 'los umbrales se fijaron después de ver dos casos', 'dos casos', 'historia del análisis (docstring de a30f_congel_ritmo.py), no los datos')
# firma de los eventos de hipo
ev_h = [it for s in S30 for it in INI[s] if it['mec'] == 'hipo']
chk('H-12', 'firma: avance relativo en la decisión anterior, mínimo', '1.65', min(it['rprev'] for it in ev_h), '{:.4f}')
chk('H-13', 'firma: avance relativo en la decisión anterior, máximo', '2.72', max(it['rprev'] for it in ev_h), '{:.4f}')
chk('H-14', 'firma: avance relativo de los no congelados en la del evento, mínimo', '0.08', min(it['r'] for it in ev_h), '{:.4f}')
chk('H-15', 'firma: avance relativo de los no congelados en la del evento, máximo', '0.16', max(it['r'] for it in ev_h), '{:.4f}')
# ¿"todos los agentes"? ratio individual
indiv = []
for key in sorted({(it['ses'], it['ep'], it['paso']) for it in ev_h}):
    s, ep, p = key
    it0 = [it for it in ev_h if (it['ses'], it['ep'], it['paso']) == key][0]
    d1, d0 = DELTA[(s, ep)][p - 1], DELTA[(s, ep)][p]
    prev = {ag: d1[ag][0] / it0['ref'] for ag in d1}
    cur = {ag: d0[ag][0] / it0['ref'] for ag in d0 if ag not in it0['excl']}
    indiv.append((key, prev, cur))
    nota(f"{s} ep {ep} decisión {p}: avance/ref en p−1 por agente " + ', '.join(f'a{a} {v:.2f}' for a, v in sorted(prev.items()))
         + ' | en p (no congelados) ' + ', '.join(f'a{a} {v:.2f}' for a, v in sorted(cur.items())))
min_prev_ind = min(min(v for v in pr.values()) for _, pr, _ in indiv)
max_prev_ind = max(max(v for v in pr.values()) for _, pr, _ in indiv)
min_cur_ind = min(min(v for v in cu.values()) for _, _, cu in indiv)
max_cur_ind = max(max(v for v in cu.values()) for _, _, cu in indiv)
chk_txt('H-16', 'firma, agente por agente en la decisión anterior: "0.69–2.96"', '0.69–2.96',
        f'individual {min_prev_ind:.3f}–{max_prev_ind:.3f} (el 1.65–2.72 es la MEDIANA de los no congelados)',
        round(min_prev_ind, 2) == 0.69 and round(max_prev_ind, 2) == 2.96)
chk_txt('H-17', 'firma, agente por agente en la decisión del evento: "0.02–0.17"', '0.02–0.17',
        f'individual {min_cur_ind:.3f}–{max_cur_ind:.3f} (el 0.08–0.16 es la MEDIANA)',
        round(min_cur_ind, 2) == 0.02 and round(max_cur_ind, 2) == 0.17)
# sensibilidad: criterio literal "todos los agentes" (cada agente > 1.6× en p−1 y cada no repetido < 0.30× en p)
lit = []
for (s, ep), d in DELTA.items():
    if s not in S30:
        continue
    for p, dd in d.items():
        if p < 12 or len(dd) < 5 or (p - 1) not in d:
            continue
        ref = ref_dec(s, ep, p)
        if not ref or math.isnan(ref):
            continue
        prev = [dm / ref for ag, (dm, rp) in d[p - 1].items() if not rp]
        cur = [dm / ref for ag, (dm, rp) in dd.items() if not rp]
        if prev and cur and min(prev) > R_ALTO and max(cur) < R_BAJO:
            lit.append((s, ep, p, valido(s, ep), any(it['ep'] == ep and it['paso'] == p for it in INI[s])))
nota(f'criterio literal "todos los agentes" (cada uno > 1.6× antes y < 0.30× en el evento): hipos 30-09 {len(lit)}, válidos '
     f'{sum(1 for q in lit if q[3])}, con inicio {sum(1 for q in lit if q[4])} → {sorted((q[0], q[1], q[2]) for q in lit if q[4])}')
# casos s5 ep9 157 y s4 ep9 270
for idn, s, ep, p, rob_rep in [('H-18', 's5', 9, 157, '{1, 8}'), ('H-19', 's4', 9, 270, '{5, 6}')]:
    its = [it for it in INI[s] if it['ep'] == ep and it['paso'] == p]
    rob = sorted(it['robot'] for it in its)
    mecs = {it['mec'] for it in its}
    e = EP[s][ep]
    chk_txt(idn, f'{s} ep {ep} decisión {p}: robots simultáneos, hipo', f'r{rob_rep}, hipo',
            f'robots {rob}, mecanismo {sorted(mecs)}, fallidas {e["poses_fallidas"]}, rechazadas {e["poses_rechazadas"]}',
            set(rob) == set(int(t) for t in re.findall(r'\d+', rob_rep)) and mecs == {'hipo'}
            and int(e['poses_fallidas'] or 0) == 0 and int(e['poses_rechazadas'] or 0) == 0)
chk('H-20', 's5 ep 9: líneas [sync] en la consola', '0', CON['s5']['sync_ep'][9], '{:d}')
no_rec('H-21', 'el lazo atrasado no duerme para recuperar', 'adaptadores_robotat.py 1276–1297', 'código del adaptador (no está en el paquete csv/consola)')
nota(f'hipo con umbral r < 0.2 (en vez de 0.30): 30-09 {sum(1 for h in HIPOS if h["ses"] in S30 and h["hipo"] and h["r"] < 0.2)},'
     f' válidos {sum(1 for h in h30v if h["r"] < 0.2)}; rango del 30-09 r_prev {min(h["rp"] for h in h30):.2f}–{max(h["rp"] for h in h30):.2f},'
     f' r {min(h["r"] for h in h30):.2f}–{max(h["r"] for h in h30):.2f}')
LINEAS.append('   hipos del 30-09 (sesión, ep, decisión, válido, r_prev, r, ¿inicio?): ' +
              ' '.join(f"({h['ses']},{h['ep']},{h['p']},{'V' if h['val'] else 'A'},{h['rp']:.2f},{h['r']:.2f},{'sí' if h['ini'] else 'no'})" for h in h30))

# =================================================================== 8) retrocesos
titulo('8) RETROCESOS')
D30 = [(s, ep, d) for s in S30 for ep in EP[s] for d in retrocesos(s, ep)]
D30v = [x for x in D30 if valido(x[0], x[1])]
D30a = [x for x in D30 if not valido(x[0], x[1])]
chk('R-1', 'retrocesos del 30-09', '29', len(D30), '{:d}')
chk('R-2', 'retrocesos en válidos', '16', len(D30v), '{:d}')
chk('R-3', 'recuperados en válidos', '16', sum(1 for x in D30v if x[2]['res'] == 'recuperada'), '{:d}')
fret = sum(sum(q['retro']) for s in S30 for (ep, ag), q in DEC[s].items() if valido(s, ep))
chk('R-4', 'filas en_retroceso en válidos', '64', fret, '{:d}')
chk('R-5', 'filas en_retroceso / filas de válidos (%)', '0.051', 100 * fret / f30v, '{:.4f}')
col = sum(int(EP[s][ep]['decisiones_retroceso'] or 0) for s in S30 for ep in EP[s] if valido(s, ep))
nota(f'columna decisiones_retroceso de los válidos = {col} (debe coincidir con {fret})')


def filas_del_retroceso(s, ep, d):
    q = DEC[s][(ep, d['ag'])]
    return sum(q['retro'][t] for t in range(len(q['paso'])) if d['p0'] <= q['paso'][t] <= d['p1'])


hip_ret = []
for s, ep, d in D30v:
    its = [it for it in INI[s] if it['ep'] == ep and it['ag'] == d['ag'] and it['paso'] == d['p0']]
    if its and its[0]['mec'] == 'hipo':
        hip_ret.append(filas_del_retroceso(s, ep, d))
chk('R-6', 'retrocesos de válidos disparados por un hipo', '5', len(hip_ret), '{:d}')
chk_txt('R-7', 'filas en_retroceso de cada retroceso por hipo', '1 cada uno', str(hip_ret), hip_ret and all(v == 1 for v in hip_ret))
chk('R-8', 'retrocesos en abortados', '13', len(D30a), '{:d}')
chk('R-9', 'abortados: cerrados por el aborto (episodio_abortado)', '12', sum(1 for x in D30a if x[2]['res'] == 'episodio_abortado'), '{:d}')
chk('R-10', 'abortados: no cerrados por el aborto ("salvo 1")', '1', sum(1 for x in D30a if x[2]['res'] != 'episodio_abortado'), '{:d}')
chk('R-11', '"sigue congelada" en el 30-09', '0', sum(1 for x in D30 if x[2]['res'] == 'sigue_congelada'), '{:d}')
chk('R-12', '"sigue congelada" en el 26-09', '6', sum(1 for ep in EP['26-09'] for d in retrocesos('26-09', ep) if d['res'] == 'sigue_congelada'), '{:d}')


def neto(it, k=5):
    s = DEC[it['ses']][(it['ep'], it['ag'])]
    t, j = it['t'], it['j']
    if j >= len(s['paso']):
        return None
    viv = [u for u in range(t) if not s['rep'][u]]
    a, b = viv[max(0, len(viv) - 1 - k)], viv[-1]
    dx, dy = s['x'][b] - s['x'][a], s['y'][b] - s['y'][a]
    n = math.hypot(dx, dy)
    ux, uy = (dx / n, dy / n) if n > 1e-9 else (math.cos(it['th']), math.sin(it['th']))
    return 100 * ((s['x'][j] - it['x']) * ux + (s['y'][j] - it['y']) * uy)   # cm, + = adelante


cortas = [it for it in mot30 if it['racha'] <= 3 and neto(it) is not None]
largas = [it for it in mot30 if it['racha'] >= 10 and neto(it) is not None]
al_c = [neto(it) for it in cortas]
al_l = [neto(it) for it in largas]
chk('R-13', 'Motive, rachas ≤ 0.3 s (≤ 3 filas): n', '8', len(al_c), '{:d}')
chk('R-14', 'rachas ≤ 0.3 s: reaparece adelante en promedio (cm)', '2.4', float(np.mean(al_c)), '{:.3f}')
chk('R-15', 'rachas ≤ 0.3 s: casos adelante', '6', sum(1 for v in al_c if v > 0), '{:d}')
chk('R-16', 'Motive, rachas ≥ 1 s (≥ 10 filas): n', '3', len(al_l), '{:d}')
chk('R-17', 'rachas ≥ 1 s: reaparece detrás, mínimo (cm)', '1.2', -max(al_l), '{:.3f}')
chk('R-18', 'rachas ≥ 1 s: reaparece detrás, máximo (cm)', '2.1', -min(al_l), '{:.3f}')
chk('R-19', 'rachas ≥ 1 s: casos detrás', '3', sum(1 for v in al_l if v < 0), '{:d}')
nota('a lo largo (cm, + adelante), Motive ≤ 3 filas: ' + ', '.join(f'{v:+.1f}' for v in al_c)
     + ' | ≥ 10 filas: ' + ', '.join(f'{v:+.1f}' for v in al_l))
dur = [d['dur'] for s, ep, d in D30 for it in cortas if (it['ses'], it['ep'], it['ag'], it['paso']) == (s, ep, d['ag'], d['p0'])]
nota(f'duración del retroceso (retrocesos_detalle) de las 8 rachas cortas: {sorted(dur)}')
for k in (3, 10):
    c_k = [neto(it, k) for it in cortas]
    l_k = [neto(it, k) for it in largas]
    nota(f'sensibilidad a la dirección de entrada (k = {k} filas vivas): cortas media {np.mean(c_k):+.2f} cm, adelante {sum(v > 0 for v in c_k)}/8;'
         f' largas {", ".join(f"{v:+.1f}" for v in l_k)}')
hip_al = [neto(it) for it in ev_h if neto(it) is not None]
nota('los 5 de hipo, a lo largo (cm, + adelante): ' + ', '.join(f'{v:+.1f}' for v in hip_al))
nota(f'si se suman los 5 de hipo (racha 1): rachas ≤ 3 filas n = {len(al_c) + len(hip_al)}, media {np.mean(al_c + hip_al):+.2f} cm, adelante {sum(v > 0 for v in al_c + hip_al)}')

# =================================================================== 9) §1 ítem 5
titulo('9) §1 ÍTEM 5 (Resumen)')
chk('S1-1', 'Motive en válidos (‰)', '0.088', 1000 * len(mot30v) / f30v, '{:.4f}')
chk('S1-2', 'A: pasadas con congelamiento el 30-09 ("no reapareció")', '0', sum(q['cong'] for q in PAS['A'][1]), '{:d}')
chk('S1-3', 'B: pasadas con congelamiento el 30-09 ("no reapareció")', '0', sum(q['cong'] for q in PAS['B'][1]), '{:d}')
chk('S1-4', 'C: reapareció ("una sola vez")', '1', sum(q['cong'] for q in PAS['C'][1]), '{:d}')
chk('S1-5', 'grupos nuevos', '2', len(nuevos), '{:d}')
chk('S1-6', 'retrocesos disparados por el hipo ("5 retrocesos falsos")', '5', len(hip_ret), '{:d}')
chk('S1-7', 'retrocesos de los válidos', '16', len(D30v), '{:d}')
chk('S1-8', 'retrocesos de los válidos recuperados', '16', sum(1 for x in D30v if x[2]['res'] == 'recuperada'), '{:d}')
chk_txt('S1-9', 'grupos nuevos: r6 en el centro y r8 junto a (3, 3)', 'r6 centro; r8 (3, 3)',
        '; '.join(f"n={len(g)} robots {dict(Counter(q['robot'] for q in g))} centro ({np.mean([q['x'] for q in g]):.2f}, {np.mean([q['y'] for q in g]):.2f})" for g in nuevos),
        any(Counter(q['robot'] for q in g) == Counter({6: len(g)}) for g in nuevos) and any(Counter(q['robot'] for q in g).most_common(1)[0][0] == 8 for g in nuevos))

# =================================================================== salida
for l in LINEAS:
    print(l)
print()
print(f"RESUMEN {SECCION}: {CUENTA['OK']} ok, {CUENTA['FALLA']} fallas, {CUENTA['NR']} no recalculables")
