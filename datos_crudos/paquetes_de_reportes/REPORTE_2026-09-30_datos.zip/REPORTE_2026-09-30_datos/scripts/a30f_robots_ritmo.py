import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Tarea 4 (hipótesis del adaptador): ritmo del lazo (ciclo_p95_ms = latencia de la
consulta de poses + _decidir_y_actuar) por sesión y por episodio, en orden, con el
adaptador WiFi que el registro de Windows muestra conectado a 'Robotat' ese día
(a30f_robots_wlan_salida.txt). SOLO LECTURA de CSV de episodios (ninguna réplica).
Uso: python -B a30f_robots_ritmo.py"""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import csv, os
from a30f_robots_comun import RS, fl, media_de, mediana

# adaptador conectado a SSID=Robotat según WLAN-AutoConfig 8001 (a30f_robots_wlan_salida.txt)
MU = "MU-MIMO {af7051bf}"
USB = "USB {58c68cd4}"
SESIONES = [
    ("11-09", "20260911_sesion-evaluacion_etapa7_episodios.csv", MU, "código anterior (sin retroceso ni cerrojo)"),
    ("22-09a", "20260922_sesion-evaluacion_etapa7_episodios.csv", MU, "código anterior"),
    ("22-09b", "20260922_sesion-evaluacion_etapa7_episodios_02.csv", MU, "código anterior"),
    ("22-09c", "20260922_sesion-evaluacion_etapa7_episodios_03.csv", MU, "código anterior"),
    ("24-09", "20260924_sesion-evaluacion_etapa7_episodios.csv", MU, "robot 5 fuera de la red 5.4 min (bitácora): p95 inflado por reconexiones"),
    ("26-09", "20260926_sesion-evaluacion_etapa7_episodios.csv", MU, "mismo código que 30-09 s1–s4"),
    ("30-09 s1", "20260930_sesion-evaluacion_etapa7_episodios.csv", USB, ""),
    ("30-09 s2", "20260930_sesion-evaluacion_etapa7_episodios_02.csv", USB, ""),
    ("30-09 s3", "20260930_sesion-evaluacion_etapa7_episodios_03.csv", USB, "réplica simulada en paralelo 12:32–12:48"),
    ("30-09 s4", "20260930_sesion-evaluacion_etapa7_episodios_04.csv", USB, "sin consola"),
    ("30-09 s5", "20260930_sesion-evaluacion_etapa7_episodios_05.csv", USB, "con el arreglo de detención"),
]
UMBRAL_RAPIDO = 25.0   # ms: por encima del máximo de todo el 26-09 (21.3) y por debajo de casi todo el 30-09

filas_resumen = []
print(f"Umbral 'episodio rápido' = p95 < {UMBRAL_RAPIDO} ms (el 26-09 entero, 19 intentos, queda por debajo).")
for nom, arch, ad, nota in SESIONES:
    ruta = os.path.join(RS, arch)
    with open(ruta, encoding="utf-8", newline="") as fh:
        E = list(csv.DictReader(fh))
    p95 = [(int(f.get("episodio") or i + 1), f["valido"], fl(f.get("ciclo_p95_ms")), int(fl(f.get("ciclos_sobre_100ms"), 0)),
            int(fl(f.get("decisiones"), 0))) for i, f in enumerate(E)]
    p95 = [t for t in p95 if t[2] == t[2]]
    if not p95:
        print(f"{nom}: sin ciclo_p95_ms")
        continue
    todos = [t[2] for t in p95]
    val = [t[2] for t in p95 if t[1] == "1"]
    rap = [t for t in p95 if t[2] < UMBRAL_RAPIDO]
    s100 = sum(t[3] for t in p95)
    dec = sum(t[4] for t in p95)
    m, sd = media_de(val) if val else (float("nan"), float("nan"))
    print(f"{nom:<9} adaptador {ad:<18} n={len(p95):2d} p95 mediana {mediana(todos):6.1f} [{min(todos):5.1f}–{max(todos):6.1f}] "
          f"· válidos {len(val):2d}: media {m:6.1f} ± {sd:5.1f} (ddof1) · episodios < {UMBRAL_RAPIDO:.0f} ms: {len(rap):2d}/{len(p95)} "
          f"· >100 ms: {s100}/{dec}   {nota}")
    print("          orden de episodios (ep:p95): " + " ".join(f"{t[0]}{'' if t[1]=='1' else '*'}:{t[2]:.1f}" for t in p95))
    filas_resumen.append((nom, ad, todos))

print()
mu = [x for n, a, v in filas_resumen if a == MU and n in ("26-09",) for x in v]
usb = [x for n, a, v in filas_resumen if a == USB for x in v]
print(f"26-09 (MU-MIMO, mismo código): todos los {len(mu)} episodios con p95 ≤ {max(mu):.1f} ms")
print(f"30-09 (USB): {len(usb)} episodios, {sum(1 for x in usb if x < UMBRAL_RAPIDO)} con p95 < {UMBRAL_RAPIDO:.0f} ms: "
      f"{sorted(round(x, 1) for x in usb if x < UMBRAL_RAPIDO)}")
mu_hist = [x for n, a, v in filas_resumen if a == MU and n != "26-09" for x in v]
print(f"MU-MIMO en sesiones previas (11-09, 22-09, 24-09): {len(mu_hist)} episodios, {sum(1 for x in mu_hist if x >= UMBRAL_RAPIDO)} con p95 ≥ "
      f"{UMBRAL_RAPIDO:.0f} ms (mediana {mediana(mu_hist):.1f}, máx {max(mu_hist):.1f})")

# Día de la semana y ventana horaria de cada sesión (hora de fin = mtime del CSV de episodios;
# conexión a 'Robotat' = evento 8001 de a30f_robots_wlan_salida.txt)
import datetime
print()
DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
for nom, arch, ad, _ in SESIONES:
    ruta = os.path.join(RS, arch)
    fin = datetime.datetime.fromtimestamp(os.path.getmtime(ruta))
    print(f"{nom:<9} {DIAS[fin.weekday()]:<10} CSV escrito {fin:%Y-%m-%d %H:%M:%S}  adaptador {ad}")
# ¿el p95 cambia con la posición del episodio dentro de la sesión (calentamiento)? 30-09, válidos
from scipy.stats import spearmanr
for nom, arch, ad, _ in SESIONES[6:]:
    with open(os.path.join(RS, arch), encoding="utf-8", newline="") as fh:
        E = [f for f in csv.DictReader(fh) if f["valido"] == "1"]
    rho, p = spearmanr([int(f["episodio"]) for f in E], [fl(f["ciclo_p95_ms"]) for f in E])
    print(f"{nom}: Spearman(episodio, p95) en válidos rho={rho:+.2f} p={p:.2f}")
