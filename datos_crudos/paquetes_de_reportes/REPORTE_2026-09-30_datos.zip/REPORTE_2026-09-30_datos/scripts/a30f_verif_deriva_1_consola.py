import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_verif_deriva_1_consola.py — VERIFICADOR ADVERSARIAL (escrito desde cero). SOLO LECTURA.
# Parseo propio de las consolas (26-09, s1, s2, s3, s5) + CSV de decisiones/episodios.
# Diferencias de diseño respecto del analista (a propósito):
#   · las impresiones de la guía se agrupan por LÍNEA EN BLANCO (el latido hace print() antes de cada tabla),
#     y la línea "✘ robot N: marcador CONGELADO (pose repetida en x, y)" se trata como UNA FILA MÁS de la
#     impresión (estado 'congelado'), no como separador;
#   · se registra todo texto intercalado y todo robot repetido dentro de una impresión (anomalías);
#   · se buscan impresiones ANTES del prompt (el hilo del latido arranca antes de esperar_enter).
import csv, math, re, os, sys
from collections import Counter, defaultdict
import numpy as np
from scipy.stats import mannwhitneyu

RES = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
SCR = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
AG_ROB = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
ROB_AG = {r: a for a, r in AG_ROB.items()}
SESIONES = [
    # nombre, consola, episodios.csv, decisiones.csv, con_arreglo
    ("26-09", "consola_20260926.txt", "20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv", False),
    ("s1", "consola_20260930.txt", "20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv", False),
    ("s2", "consola_20260930_02.txt", "20260930_sesion-evaluacion_etapa7_episodios_02.csv", "20260930_sesion-evaluacion_etapa7_decisiones_02.csv", False),
    ("s3", "consola_20260930_03.txt", "20260930_sesion-evaluacion_etapa7_episodios_03.csv", "20260930_sesion-evaluacion_etapa7_decisiones_03.csv", False),
    ("s4", None, "20260930_sesion-evaluacion_etapa7_episodios_04.csv", "20260930_sesion-evaluacion_etapa7_decisiones_04.csv", False),
    ("s5", "consola_20260930_05.txt", "20260930_sesion-evaluacion_etapa7_episodios_05.csv", "20260930_sesion-evaluacion_etapa7_decisiones_05.csv", True),
]
VALIDOS_ESPERADOS = {"s1": [3, 4, 5, 6, 7, 8, 9, 10, 11, 12], "s2": [1, 4, 5, 6, 7, 8, 9, 10, 11, 12],
                     "s3": [1, 2, 4, 5, 6, 7, 8, 9, 10, 11], "s4": [1, 2, 3, 4, 5, 6, 8, 9, 10, 11],
                     "s5": [1, 2, 3, 4, 5, 7, 8, 9, 10, 11]}

H = re.compile(r"^EPISODIO (\d+)\s+\(válidos hasta ahora: (\d+)/(\d+)\)")
PROMPT = "[Enter para seguir]"
R_ESTA = re.compile(r"^\s*(?:✔\s+)?robot (\d+): está \((-?\d+\.\d+), (-?\d+\.\d+)\)")
R_CONG = re.compile(r"^\s*✘ robot (\d+): marcador CONGELADO \(pose repetida en (-?\d+\.\d+), (-?\d+\.\d+)\)")
R_SIN = re.compile(r"^\s*robot (\d+): SIN POSE")
R_BLANCO = re.compile(r"^\s+robot (\d+): \((-?\d+\.\d+), (-?\d+\.\d+)\)\s*$")
R_FINRONDA = re.compile(r"^\s*(\[colocación\s+\d+ s\]|colocación: |⚠ colocación|✘ no se arranca)")
R_RES = re.compile(r"^\s*>>> EPISODIO (\d+): (VÁLIDO|INVÁLIDO)")
R_COB = re.compile(r"cobertura AoI (\d+\.\d+)\s+·\s+colisiones <0\.15 (\d+)\s+·\s+d_pared mín (-?\d+\.\d+)")
R_COLSUM = re.compile(r"^\s+colocación: ")
DET = "detención enviada a los 5 robots"
NODET = "NO SE PUDO CONFIRMAR LA DETENCI"

salida = []
def P(*a):
    s = " ".join(str(x) for x in a)
    salida.append(s); print(s)

def dpar(x, y):
    return min(x, 3.0 - x, y, 3.0 - y)

def leer_csv(nombre):
    with open(os.path.join(RES, nombre), encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))

def impresiones(lineas, i0, i1):
    """Agrupa las tablas de la guía entre lineas[i0:i1] por línea en blanco. Devuelve (grupos, anomalías)."""
    grupos, cur, anom = [], {}, []
    for j in range(i0, i1):
        l = lineas[j]
        m1, m2, m3 = R_ESTA.match(l), R_CONG.match(l), R_SIN.match(l)
        if m1 or m2 or m3:
            m = m1 or m2 or m3
            r = int(m.group(1))
            if r in cur:
                anom.append((j + 1, "robot repetido sin línea en blanco"))
                grupos.append(cur); cur = {}
            if m1:
                cur[r] = ("esta", float(m1.group(2)), float(m1.group(3)))
            elif m2:
                cur[r] = ("congelado", float(m2.group(2)), float(m2.group(3)))
            else:
                cur[r] = ("sin_pose", None, None)
        elif l.strip() == "":
            if cur:
                grupos.append(cur); cur = {}
        else:
            if cur and "dale Enter" not in l:
                anom.append((j + 1, "texto intercalado dentro de una impresión: " + l.strip()[:60]))
            elif not cur and l.strip() not in (".",):
                anom.append((j + 1, "texto entre impresiones: " + l.strip()[:60]))
    if cur:
        grupos.append(cur)
    return grupos, anom

def parse(ruta):
    L = open(ruta, encoding="utf-8").read().splitlines()
    hs = [i for i, l in enumerate(L) if H.match(l)]
    bloques = []
    for n, h in enumerate(hs):
        fin = hs[n + 1] if n + 1 < len(hs) else len(L)
        m = H.match(L[h])
        b = {"k": int(m.group(1)), "val_prev": int(m.group(2)), "l0": h, "l1": fin}
        prompts = [i for i in range(h, fin) if PROMPT in L[i]]
        b["n_prompts"] = len(prompts)
        # blancos antes del primer prompt
        b["blancos"] = {}
        lim = prompts[0] if prompts else fin
        for i in range(h, lim):
            mb = R_BLANCO.match(L[i])
            if mb:
                b["blancos"][int(mb.group(1))] = (float(mb.group(2)), float(mb.group(3)))
        b["esta_antes_prompt"] = sum(1 for i in range(h, lim) if R_ESTA.match(L[i]) or R_CONG.match(L[i]))
        # 1.ª ronda: desde el primer prompt hasta el primer marcador de colocación
        if prompts:
            p0 = prompts[0]
            f0 = next((i for i in range(p0 + 1, fin) if R_FINRONDA.match(L[i])), fin)
            b["ronda1"] = (p0 + 1, f0)
            b["imps"], b["anom"] = impresiones(L, p0 + 1, f0)
        else:
            b["ronda1"], b["imps"], b["anom"] = None, [], []
        # rondas repetidas
        b["no_se_gasta"] = [i for i in range(h, fin) if "no se gasta el intento" in L[i]]
        b["corregi"] = [i for i in range(h, fin) if "Corregí lo que impide" in L[i]]
        b["no_arranca"] = [i for i in range(h, fin) if "no se arranca este episodio" in L[i]]
        # resultado
        ir = [i for i in range(h, fin) if R_RES.match(L[i])]
        b["n_res"] = len(ir)
        b["res"] = None; b["cob"] = None
        if ir:
            i = ir[0]
            mr = R_RES.match(L[i]); b["res"] = (int(mr.group(1)), mr.group(2)); b["i_res"] = i
            for jj in range(i, min(i + 6, fin)):
                mc = R_COB.search(L[jj])
                if mc:
                    b["cob"] = (float(mc.group(1)), int(mc.group(2)), float(mc.group(3))); break
            cs = [jj for jj in range(h, i) if R_COLSUM.match(L[jj])]
            b["i_colsum"] = cs[-1] if cs else None
            b["det_entre"] = [jj + 1 for jj in range(cs[-1] + 1, i) if DET in L[jj]] if cs else None
            b["det_tras_res"] = [jj + 1 for jj in range(i + 1, fin) if DET in L[jj]]
            reps = [jj for jj in range(h, fin) if "réplica simulada" in L[jj]]
            b["replica"] = reps
            b["replica_tras_res"] = all(jj > i for jj in reps)
        b["det_bloque"] = [jj + 1 for jj in range(h, fin) if DET in L[jj]]
        b["nodet_bloque"] = sum(1 for jj in range(h, fin) if NODET in L[jj])
        bloques.append(b)
    pre = sum(1 for i in range(0, hs[0] if hs else len(L)) if DET in L[i])
    tot = sum(1 for l in L if DET in l)
    totno = sum(1 for l in L if NODET in l)
    return L, bloques, pre, tot, totno

filas = []   # una por (sesión, k, robot) medible o no
det_resumen = {}
for nom, con, fep, fdec, arreglo in SESIONES:
    eps = leer_csv(fep)
    dec = defaultdict(list)
    mal_mapeo = 0; n_dec = 0
    for r in leer_csv(fdec):
        e, a = int(r["episodio"]), int(r["agente"])
        n_dec += 1
        if int(r["robot"]) != AG_ROB[a]:
            mal_mapeo += 1
        dec[(e, a)].append(r)
    for kk in dec:
        dec[kk].sort(key=lambda r: int(r["paso"]))
    pasos_dup = sum(1 for kk, rs in dec.items() if len(set(int(r["paso"]) for r in rs)) != len(rs))
    P("=" * 110)
    P(f"SESIÓN {nom}  consola={con}  arreglo={arreglo}  filas episodios={len(eps)}  filas decisiones={n_dec}")
    P(f"  mapeo agente→robot discordante en decisiones: {mal_mapeo} filas;  (episodio,agente) con 'paso' duplicado: {pasos_dup}")
    nums = [int(e["episodio"]) for e in eps]
    P(f"  episodios en CSV: {nums}")
    val = [int(e["episodio"]) for e in eps if e["valido"] == "1"]
    P(f"  válidos CSV: {val}  (n={len(val)})  coincide con la lista fija: {val == VALIDOS_ESPERADOS.get(nom, val)}")
    # filas de decisiones por episodio vs 'decisiones' del CSV
    difs = []
    for e in eps:
        k = int(e["episodio"])
        for a in range(5):
            nrow = len(dec.get((k, a), []))
            if nrow != int(e["decisiones"]):
                difs.append((k, a, nrow, e["decisiones"]))
    P(f"  (episodio,agente) cuyo n.º de filas ≠ 'decisiones' del CSV: {difs if difs else 'ninguno'}")
    if con is None:
        P("  SIN CONSOLA: deriva, impresiones y detenciones → SIN DATO")
        continue
    L, bloques, det_pre, det_tot, nodet_tot = parse(os.path.join(SCR, con))
    ks = [b["k"] for b in bloques]
    P(f"  encabezados 'EPISODIO k': {len(bloques)}  números {ks}  duplicados: {[k for k, c in Counter(ks).items() if c > 1]}")
    # ---- emparejamiento
    prob = []
    vprev = 0
    ep_by = {int(e["episodio"]): e for e in eps}
    n_blancos = 0; n_cob = 0
    for b in bloques:
        k = b["k"]; e = ep_by.get(k)
        if e is None:
            prob.append(f"bloque {k} sin fila CSV"); continue
        if b["val_prev"] != vprev: prob.append(f"k={k}: contador {b['val_prev']} vs CSV {vprev}")
        if b["n_res"] != 1: prob.append(f"k={k}: {b['n_res']} líneas '>>> EPISODIO'")
        if b["res"] is not None:
            if b["res"][0] != k: prob.append(f"k={k}: resultado dice {b['res'][0]}")
            if (b["res"][1] == "VÁLIDO") != (e["valido"] == "1"): prob.append(f"k={k}: resultado {b['res'][1]} vs valido={e['valido']}")
        if b["no_arranca"]: prob.append(f"k={k}: 'no se arranca este episodio'")
        if e["valido"] == "1":
            if b["cob"] is None: prob.append(f"k={k}: válido sin línea de cobertura")
            else:
                n_cob += 1
                if round(float(e["cobertura_aoi"]), 4) != b["cob"][0]: prob.append(f"k={k}: cobertura {b['cob'][0]} vs {e['cobertura_aoi']}")
                if round(float(e["d_pared_min"]), 6) != b["cob"][2]: prob.append(f"k={k}: d_pared {b['cob'][2]} vs {e['d_pared_min']}")
                if int(e["colisiones_015"]) != b["cob"][1]: prob.append(f"k={k}: colisiones {b['cob'][1]} vs {e['colisiones_015']}")
        for r, (x, y) in b["blancos"].items():
            a = ROB_AG[r]; n_blancos += 1
            if round(float(e[f"blanco_x_a{a}"]), 2) != x or round(float(e[f"blanco_y_a{a}"]), 2) != y:
                prob.append(f"k={k}: blanco robot {r} ({x},{y}) vs CSV ({e[f'blanco_x_a{a}']},{e[f'blanco_y_a{a}']})")
        if len(b["blancos"]) != 5: prob.append(f"k={k}: {len(b['blancos'])} blancos")
        # rondas repetidas: después de la 1.ª ronda
        for i in b["no_se_gasta"] + b["corregi"]:
            if b["ronda1"] is None or i < b["ronda1"][1]:
                prob.append(f"k={k}: ronda repetida en línea {i+1} ANTES del fin de la 1.ª ronda")
        vprev += int(e["valido"])
    faltan = sorted(set(ep_by) - set(ks))
    if faltan: prob.append(f"filas CSV sin bloque: {faltan}")
    P(f"  cotejo: cobertura/d_pared/colisiones en {n_cob} bloques válidos; blancos en {n_blancos} robots-bloque")
    P(f"  PROBLEMAS DE EMPAREJAMIENTO: {prob if prob else 'ninguno'}")
    rep = [(b['k'], len(b['no_se_gasta'])) for b in bloques if b['no_se_gasta']]
    P(f"  bloques con rondas repetidas ('no se gasta el intento'): {rep if rep else 'ninguno'};  prompts totales {sum(b['n_prompts'] for b in bloques)}")
    P(f"  impresiones ANTES del primer prompt (en cualquier bloque): {sum(b['esta_antes_prompt'] for b in bloques)}")
    an = [(b['k'], a) for b in bloques for a in b['anom']]
    P(f"  anomalías de agrupamiento en la 1.ª ronda: {len(an)}")
    for x in an[:15]:
        P(f"     bloque {x[0]}: línea {x[1][0]} → {x[1][1]}")
    # tamaño de impresiones
    tam = Counter(len(g) for b in bloques for g in b["imps"])
    P(f"  tamaño de las impresiones de la 1.ª ronda (robots por tabla): {dict(tam)}")
    congimp = [(b['k'], i, r) for b in bloques for i, g in enumerate(b['imps']) for r, v in g.items() if v[0] == 'congelado']
    P(f"  filas '✘ CONGELADO' dentro de impresiones de la 1.ª ronda: {len(congimp)}; en la 1.ª impresión: {[c for c in congimp if c[1]==0]}")
    sinp = [(b['k'], i, r) for b in bloques for i, g in enumerate(b['imps']) for r, v in g.items() if v[0] == 'sin_pose']
    P(f"  filas 'SIN POSE' en la 1.ª ronda: {sinp if sinp else 'ninguna'}")
    # ---- detenciones
    lst = []
    for b in bloques:
        e = ep_by[b["k"]]
        lst.append((b["k"], e["valido"] == "1", len(b["det_entre"]) if b.get("det_entre") is not None else None))
    det_resumen[nom] = lst
    s_entre = sum(x[2] or 0 for x in lst)
    s_tras_ult = len(bloques[-1].get("det_tras_res", []))
    s_otros = sum(len(b["det_bloque"]) for b in bloques) - s_entre - s_tras_ult
    P(f"  'detención enviada' total={det_tot}: antes del ep 1={det_pre}, entre último 'colocación:' y '>>>'={s_entre}, "
      f"tras el '>>>' del último episodio={s_tras_ult}, otras posiciones dentro de bloques={s_otros}")
    P(f"  'NO SE PUDO CONFIRMAR LA DETENCIÓN' total={nodet_tot}; por bloque: {[(b['k'], b['nodet_bloque']) for b in bloques if b['nodet_bloque']]}")
    cV = Counter(x[2] for x in lst if x[1]); cA = Counter(x[2] for x in lst if not x[1])
    P(f"  detenciones entre colocación y resultado → válidos {dict(cV)}  abortados {dict(cA)}")
    P(f"  bloques con 'réplica simulada': {sum(1 for b in bloques if b.get('replica'))}; todas después de '>>>': "
      f"{all(b.get('replica_tras_res', True) for b in bloques)}")
    # ---- deriva por robot
    for b in bloques:
        k = b["k"]; e = ep_by[k]
        tipo = "V" if e["valido"] == "1" else "A"
        bs = next((x for x in bloques if x["k"] == k + 1), None)
        for a in range(5):
            rob = AG_ROB[a]
            rs = dec[(k, a)]
            u = rs[-1]
            pu = (float(u["pose_env_x"]), float(u["pose_env_y"]), float(u["pose_env_th"]))
            racha = 1
            for i in range(len(rs) - 1, 0, -1):
                pa = (float(rs[i - 1]["pose_env_x"]), float(rs[i - 1]["pose_env_y"]), float(rs[i - 1]["pose_env_th"]))
                pb = (float(rs[i]["pose_env_x"]), float(rs[i]["pose_env_y"]), float(rs[i]["pose_env_th"]))
                if pa == pb: racha += 1
                else: break
            fila = {"sesion": nom, "arreglo": arreglo, "k": k, "tipo": tipo, "robot": rob, "agente": a,
                    "paso_ult": int(u["paso"]), "x": pu[0], "y": pu[1], "dpar_ult": dpar(pu[0], pu[1]),
                    "v_ult": float(u["v_ejecutada"]), "racha_fin": racha, "cong_fin": racha >= 2,
                    "n_imp": None, "e1": None, "e2": None, "d1": None, "d2": None, "dp1": None, "dp2": None,
                    "d12": None, "dU": None, "medible": bs is not None}
            if bs is not None:
                im = bs["imps"]; fila["n_imp"] = len(im)
                g1 = im[0].get(rob) if len(im) > 0 else None
                g2 = im[1].get(rob) if len(im) > 1 else None
                gU = im[-1].get(rob) if im else None
                fila["e1"] = g1[0] if g1 else None; fila["e2"] = g2[0] if g2 else None
                if g1 and g1[0] == "esta":
                    fila["d1"] = math.hypot(g1[1] - pu[0], g1[2] - pu[1]) * 100; fila["dp1"] = dpar(g1[1], g1[2])
                    fila["x1"], fila["y1"] = g1[1], g1[2]
                if g2 and g2[0] == "esta":
                    fila["d2"] = math.hypot(g2[1] - pu[0], g2[2] - pu[1]) * 100; fila["dp2"] = dpar(g2[1], g2[2])
                    fila["x2"], fila["y2"] = g2[1], g2[2]
                if g1 and g2 and g1[0] == "esta" and g2[0] == "esta":
                    fila["d12"] = math.hypot(g2[1] - g1[1], g2[2] - g1[2]) * 100
                if gU and gU[0] == "esta":
                    fila["dU"] = math.hypot(gU[1] - pu[0], gU[2] - pu[1]) * 100
            filas.append(fila)

# =====================================================================================================
P("\n" + "=" * 110)
P("DERIVA POR EPISODIO k (mi parseo). d en cm; dp = d_pared de la impresión (m). 'cong' = robots con última fila idéntica a la anterior")
P("=" * 110)
for nom in ["26-09", "s1", "s2", "s3", "s5"]:
    for k in sorted(set(f["k"] for f in filas if f["sesion"] == nom)):
        fs = [f for f in filas if f["sesion"] == nom and f["k"] == k]
        if not fs[0]["medible"]:
            P(f"  {nom:5s} k={k:2d} {fs[0]['tipo']}  NO MEDIBLE (último episodio de la sesión)"); continue
        d1 = [f["d1"] for f in fs if f["d1"] is not None]; d2 = [f["d2"] for f in fs if f["d2"] is not None]
        cg = [f["robot"] for f in fs if f["cong_fin"]]
        e2 = Counter(f["e2"] for f in fs)
        mm = lambda v: f"{np.median(v):6.2f}/{max(v):6.2f}" if v else "     —/     —"
        P(f"  {nom:5s} k={k:2d} {fs[0]['tipo']} nimp={fs[0]['n_imp']:2d}  d1 med/máx {mm(d1)} (n={len(d1)})  d2 med/máx {mm(d2)} (n={len(d2)})  "
          f"dp1mín {min([f['dp1'] for f in fs if f['dp1'] is not None], default=float('nan')):5.2f} dp2mín {min([f['dp2'] for f in fs if f['dp2'] is not None], default=float('nan')):5.2f}  "
          f"cong={cg if cg else '-'}  estados imp2={dict(e2)}")

def grupo(fs):
    d1 = [f["d1"] for f in fs if f["d1"] is not None]; d2 = [f["d2"] for f in fs if f["d2"] is not None]
    p2 = [f["dp2"] for f in fs if f["dp2"] is not None]; p1 = [f["dp1"] for f in fs if f["dp1"] is not None]
    neps = len(set((f["sesion"], f["k"]) for f in fs))
    return neps, d1, d2, p1, p2

def linea(nombre, fs):
    neps, d1, d2, p1, p2 = grupo(fs)
    f2 = lambda v, fn: f"{fn(v):6.2f}" if v else "     —"
    P(f"  {nombre:34s} n_ep={neps:2d}  n_d1={len(d1):3d} d1 med {f2(d1, np.median)} máx {f2(d1, max)}  "
      f"n_d2={len(d2):3d} d2 med {f2(d2, np.median)} máx {f2(d2, max)}  dp1mín {f2(p1, min)} dp2mín {f2(p2, min)}  "
      f"n(dp2<0.05)={sum(1 for x in p2 if x < 0.05)} n(dp2<0)={sum(1 for x in p2 if x < 0)}")

med = [f for f in filas if f["medible"]]
P("\n" + "=" * 110)
P("TABLA 1 RECALCULADA (robot-nivel; mediana np.median). 'limpio' = se excluyen ROBOTS con cong_fin (no episodios)")
P("=" * 110)
for nom in ["26-09", "s1", "s2", "s3", "s5"]:
    for t in ("V", "A"):
        fs = [f for f in med if f["sesion"] == nom and f["tipo"] == t]
        if not fs: continue
        linea(f"{nom} {t} (todos)", fs)
        if any(f["cong_fin"] for f in fs):
            linea(f"{nom} {t} limpio", [f for f in fs if not f["cong_fin"]])
PRE = [f for f in med if not f["arreglo"]]; POS = [f for f in med if f["arreglo"]]
P("-" * 110)
linea("PRE válidos (todos)", [f for f in PRE if f["tipo"] == "V"])
linea("PRE válidos limpio", [f for f in PRE if f["tipo"] == "V" and not f["cong_fin"]])
linea("PRE abortados (todos)", [f for f in PRE if f["tipo"] == "A"])
linea("PRE abortados limpio (robot)", [f for f in PRE if f["tipo"] == "A" and not f["cong_fin"]])
linea("s5 válidos", [f for f in POS if f["tipo"] == "V"])
linea("s5 abortados limpio", [f for f in POS if f["tipo"] == "A" and not f["cong_fin"]])
linea("TODOS abortados limpio (robot)", [f for f in med if f["tipo"] == "A" and not f["cong_fin"]])
# episodios íntegramente limpios (ningún robot congelado)
eps_cong = set((f["sesion"], f["k"]) for f in med if f["cong_fin"])
linea("PRE abortados, EPISODIOS sin congelados", [f for f in PRE if f["tipo"] == "A" and (f["sesion"], f["k"]) not in eps_cong])
linea("TODOS abortados, EPISODIOS sin cong.", [f for f in med if f["tipo"] == "A" and (f["sesion"], f["k"]) not in eps_cong])
P(f"  episodios con ≥1 robot congelado al final: {sorted(eps_cong)}")

P("\n" + "=" * 110)
P("CASOS dp2 < 0.05 m (válidos pre-arreglo) y dp1 mínimo por sesión")
P("=" * 110)
for f in sorted([f for f in PRE if f["tipo"] == "V" and f["dp2"] is not None and f["dp2"] < 0.05], key=lambda f: (f["sesion"], f["k"])):
    P(f"  {f['sesion']:5s} k={f['k']:2d} robot {f['robot']}  dpar última pose {f['dpar_ult']:.3f}  imp1 ({f.get('x1')}, {f.get('y1')}) dp1 {f['dp1']:.2f}  "
      f"imp2 ({f.get('x2')}, {f.get('y2')}) dp2 {f['dp2']:.2f}  d2 {f['d2']:.2f}")
casos = [f for f in PRE if f["tipo"] == "V" and f["dp2"] is not None and f["dp2"] < 0.05]
P(f"  n(dp2<0.05)={len(casos)}  n(dp2<0)={sum(1 for f in casos if f['dp2'] < 0)}  mín dpar_ult entre ellos={min(f['dpar_ult'] for f in casos):.3f}")
for nom in ["26-09", "s1", "s2", "s3", "s5"]:
    fs = [f for f in med if f["sesion"] == nom and f["tipo"] == "V"]
    P(f"  {nom}: válidos dp1 mín {min(f['dp1'] for f in fs if f['dp1'] is not None):.2f}  dp2 mín {min(f['dp2'] for f in fs if f['dp2'] is not None):.2f}  "
      f"d1 rango [{min(f['d1'] for f in fs if f['d1'] is not None):.2f}, {max(f['d1'] for f in fs if f['d1'] is not None):.2f}]")

P("\n" + "=" * 110)
P("26-09 k=15 (bloque 16): efecto de descartar las coordenadas negativas (regex [\\d.]+ del script de referencia)")
P("=" * 110)
fs = [f for f in med if f["sesion"] == "26-09" and f["k"] == 15]
for f in fs:
    P(f"  robot {f['robot']}: imp1 ({f.get('x1')}, {f.get('y1')})  imp2 ({f.get('x2')}, {f.get('y2')})  d1 {f['d1']:.2f} d2 {f['d2']:.2f} dp2 {f['dp2']:.2f}")
d2t = [f["d2"] for f in fs]; d2s = [f["d2"] for f in fs if f["x2"] >= 0 and f["y2"] >= 0]
P(f"  con 5: d2 med {np.median(d2t):.2f} máx {max(d2t):.2f} dp2mín {min(f['dp2'] for f in fs):.2f}  |  sin negativos (n={len(d2s)}): d2 med {np.median(d2s):.2f} "
  f"máx {max(d2s):.2f} dp2mín {min(f['dp2'] for f in fs if f['x2'] >= 0 and f['y2'] >= 0):.2f}")
# réplica EXACTA del parseo de referencia (sólo el regex) sobre el bloque 16 para ver qué publicó
L26 = open(os.path.join(SCR, "consola_20260926.txt"), encoding="utf-8").read().splitlines()
neg_bloques = set()
for nom, con, *_ in SESIONES:
    if con is None: continue
    LL = open(os.path.join(SCR, con), encoding="utf-8").read().splitlines()
    epa = None
    for l in LL:
        m = H.match(l)
        if m: epa = int(m.group(1))
        if re.search(r"está \(-|, -\d", l):
            neg_bloques.add((nom, epa))
P(f"  bloques de consola con alguna coordenada 'está' negativa (cualquier ronda): {sorted(neg_bloques)}")

P("\n" + "=" * 110)
P("s1 k=1 y k=2 (abortos por antigüedad de pose) y robots congelados de 26-09")
P("=" * 110)
for f in [f for f in med if f["cong_fin"]]:
    P(f"  {f['sesion']:5s} k={f['k']:2d} {f['tipo']} robot {f['robot']} racha_final={f['racha_fin']:3d}  d1={f['d1'] if f['d1'] is None else round(f['d1'],2)}  "
      f"d2={f['d2'] if f['d2'] is None else round(f['d2'],2)}  e1={f['e1']} e2={f['e2']}  dU={f['dU'] if f['dU'] is None else round(f['dU'],1)}")
s1ex = [f for f in med if f["sesion"] == "s1" and f["k"] in (1, 2)]
P(f"  s1 k=1,2: n={len(s1ex)} todos cong_fin={all(f['cong_fin'] for f in s1ex)}  d1 med {np.median([f['d1'] for f in s1ex]):.2f} máx {max(f['d1'] for f in s1ex):.2f}  "
  f"d2 med {np.median([f['d2'] for f in s1ex]):.2f} máx {max(f['d2'] for f in s1ex):.2f}  |p2-p1| med {np.median([f['d12'] for f in s1ex]):.2f}")
c26 = [f for f in med if f["sesion"] == "26-09" and f["cong_fin"]]
P(f"  26-09 congelados: n={len(c26)}  d1 rango [{min(f['d1'] for f in c26):.2f}, {max(f['d1'] for f in c26):.2f}]  dU máx {max(f['dU'] for f in c26 if f['dU'] is not None):.1f}")

P("\n" + "=" * 110)
P("NIVEL EPISODIO: mediana por episodio (robots medidos) y Mann-Whitney (descriptivo)")
P("=" * 110)
def meds(fs, campo):
    d = defaultdict(list)
    for f in fs:
        if f[campo] is not None: d[(f["sesion"], f["k"])].append(f[campo])
    return {k: float(np.median(v)) for k, v in d.items()}
G = {
    "PRE válidos": [f for f in PRE if f["tipo"] == "V"],
    "s5 válidos": [f for f in POS if f["tipo"] == "V"],
    "TODOS abortados (sin filtrar)": [f for f in med if f["tipo"] == "A"],
    "TODOS abortados limpio (robot)": [f for f in med if f["tipo"] == "A" and not f["cong_fin"]],
    "TODOS abort. limpio sin s1k1-2": [f for f in med if f["tipo"] == "A" and not f["cong_fin"] and not (f["sesion"] == "s1" and f["k"] in (1, 2))],
}
for campo in ("d1", "d2"):
    P(f"-- {campo}")
    M = {n: meds(fs, campo) for n, fs in G.items()}
    for n, d in M.items():
        v = sorted(d.values())
        P(f"   {n:32s} n_ep={len(v):2d} med {np.median(v):6.2f}  rango [{v[0]:6.2f}, {v[-1]:6.2f}]  {[round(x, 2) for x in v]}")
    a = list(M["s5 válidos"].values())
    for n in ("TODOS abortados (sin filtrar)", "TODOS abortados limpio (robot)", "TODOS abort. limpio sin s1k1-2", "PRE válidos"):
        u = mannwhitneyu(a, list(M[n].values()), alternative="two-sided")
        P(f"   MW s5 válidos vs {n:32s} U={u.statistic:6.1f} p={u.pvalue:.4g}")
pv = meds(G["PRE válidos"], "d2"); sv = meds(G["s5 válidos"], "d2")
d2pre = [f["d2"] for f in G["PRE válidos"] if f["d2"] is not None]; d2s5 = [f["d2"] for f in G["s5 válidos"] if f["d2"] is not None]
P(f"  cociente de medianas robot-nivel d2: {np.median(d2pre):.2f}/{np.median(d2s5):.2f} = {np.median(d2pre)/np.median(d2s5):.2f}")

P("\n" + "=" * 110)
P("MOVIMIENTO ENTRE 1.ª Y 2.ª IMPRESIÓN y T_equiv = d/(|v_ult|·0.40), sólo |v_ult|>0.1")
P("=" * 110)
def mov(nombre, fs):
    v = [f["d12"] for f in fs if f["d12"] is not None]
    T1 = [f["d1"] / 100 / (abs(f["v_ult"]) * 0.40) for f in fs if f["d1"] is not None and abs(f["v_ult"]) > 0.1]
    T2 = [f["d2"] / 100 / (abs(f["v_ult"]) * 0.40) for f in fs if f["d2"] is not None and abs(f["v_ult"]) > 0.1]
    if not v:
        P(f"  {nombre:30s} sin pares"); return
    P(f"  {nombre:30s} pares={len(v):3d} |p2-p1| med {np.median(v):5.2f} máx {max(v):5.2f}  quietos(<0.5)={sum(1 for x in v if x < 0.5):3d}  "
      f"moviéndose(>=1.5)={sum(1 for x in v if x >= 1.5):3d}  T(d1) med {np.median(T1):.2f} (n={len(T1)})  T(d2) med {np.median(T2):.2f} (n={len(T2)})")
for nom in ["26-09", "s1", "s2", "s3", "s5"]:
    for t in ("V", "A"):
        fs = [f for f in med if f["sesion"] == nom and f["tipo"] == t and not f["cong_fin"]]
        if fs: mov(f"{nom} {t} limpio", fs)
P("-" * 110)
mov("PRE válidos limpio", [f for f in PRE if f["tipo"] == "V" and not f["cong_fin"]])
mov("PRE abortados limpio", [f for f in PRE if f["tipo"] == "A" and not f["cong_fin"]])
mov("s5 válidos", [f for f in POS if f["tipo"] == "V"])
mov("s5 abortados limpio", [f for f in POS if f["tipo"] == "A" and not f["cong_fin"]])
vmax = max(abs(f["v_ult"]) for f in filas)
P(f"  |v_ult| máx en las últimas filas: {vmax:.4f} (unidades del env; ×0.40 = {vmax*0.4:.4f} m/s)")

P("\n" + "=" * 110)
P("DETENCIONES: resumen por sesión (entre último 'colocación:' y '>>> EPISODIO k')")
P("=" * 110)
for nom, lst in det_resumen.items():
    P(f"  {nom:5s} válidos {dict(Counter(x[2] for x in lst if x[1]))} (n={sum(1 for x in lst if x[1])})  "
      f"abortados {dict(Counter(x[2] for x in lst if not x[1]))} (n={sum(1 for x in lst if not x[1])})")

with open(os.path.join(SCR, "a30f_verif_deriva_por_robot.csv"), "w", newline="", encoding="utf-8") as fh:
    campos = sorted(set().union(*[f.keys() for f in filas]))
    w = csv.DictWriter(fh, fieldnames=campos); w.writeheader(); w.writerows(filas)
open(os.path.join(SCR, "a30f_verif_deriva_1_consola_salida.txt"), "w", encoding="utf-8").write("\n".join(salida) + "\n")
