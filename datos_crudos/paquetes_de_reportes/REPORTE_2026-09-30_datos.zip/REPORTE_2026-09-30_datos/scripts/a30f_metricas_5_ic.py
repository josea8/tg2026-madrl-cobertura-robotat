import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""5) IC95 de la cobertura media del hardware (50 válidos del 30-09):
  (a) episodios como independientes (n = 50, t con 49 gl);
  (b) error estándar robusto por conglomerado = semilla (CR1, t con G−1 = 11 gl);
  (c) media de las 12 medias por semilla (peso igual por escenario, t con 11 gl);
  (d) bootstrap por conglomerado (se remuestrean semillas; percentil y BCa-simple);
  (e) modelo de efectos aleatorios de 1 vía (estimador ANOVA de σ²_b, σ²_w; pesos
      1/(σ²_b + σ²_w/n_g));
  (f) sensibilidad: conglomerado = sesión (sólo 5 → poco fiable) y doble
      conglomerado semilla × sesión (Cameron–Gelbach–Miller).
Efecto de diseño = (EE conglomerado / EE ingenuo)². Entrada: a30f_metricas_tabla.csv."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import numpy as np
import pandas as pd
from scipy import stats
from a30f_metricas_comun import S30, icc1, md_tabla, SP

T = pd.read_csv(SP + r"\a30f_metricas_tabla.csv")
V = T[(T.valido == 1) & T.ses.isin(S30)].copy()
y = V.cob.to_numpy()
N = len(y)
m = y.mean()
fil = []


def fila(nombre, est, ee, gl, extra=""):
    tq = stats.t.ppf(0.975, gl) if gl is not None else stats.norm.ppf(0.975)
    lo, hi = est - tq * ee, est + tq * ee
    print(f"   {nombre:58s} {est:.4f} ± {ee:.4f} (EE) · IC95 [{lo:.4f}, {hi:.4f}] · semiancho {tq*ee:.4f}"
          f"{' · gl ' + str(gl) if gl is not None else ''} {extra}")
    fil.append([nombre, f"{est:.4f}", f"{ee:.4f}", "—" if gl is None else str(gl), f"[{lo:.4f}, {hi:.4f}]",
                f"{tq*ee:.4f}", extra])
    return ee, tq * ee


def cr1(y, grupos):
    """EE robusto por conglomerado (CR1) de la media global."""
    u = y - y.mean()
    g = pd.Series(u).groupby(np.asarray(grupos)).sum().to_numpy()
    G = len(g)
    return np.sqrt(G / (G - 1) * (g ** 2).sum()) / len(y), G


print(f"=== IC95 de la cobertura media del hw — 30-09, {N} válidos, {V.semilla.nunique()} semillas, 5 sesiones ===")
ee_a, sa_a = fila("(a) episodios independientes (n=50)", m, y.std(ddof=1) / np.sqrt(N), N - 1)
ee_b, G = cr1(y, V.semilla)
_, sa_b = fila("(b) robusto por conglomerado = semilla (CR1)", m, ee_b, G - 1,
               f"Deff = {(ee_b/ee_a)**2:.2f}")
ms = V.groupby("semilla").cob.mean()
_, sa_c = fila("(c) media de medias por semilla (peso igual)", ms.mean(), ms.std(ddof=1) / np.sqrt(len(ms)),
               len(ms) - 1, f"n_eff = 12")
# (d) bootstrap por semilla
rng = np.random.default_rng(20260930)
sems = ms.index.to_numpy()
grp = {s: V[V.semilla == s].cob.to_numpy() for s in sems}
B = 20000
bm = np.empty(B)
for i in range(B):
    pick = rng.choice(sems, size=len(sems), replace=True)
    z = np.concatenate([grp[s] for s in pick])
    bm[i] = z.mean()
lo, hi = np.percentile(bm, [2.5, 97.5])
print(f"   {'(d) bootstrap por semilla (20000, percentil)':58s} {m:.4f} · IC95 [{lo:.4f}, {hi:.4f}] · "
      f"semiancho medio {(hi-lo)/2:.4f} · EE boot {bm.std(ddof=1):.4f}")
fil.append(["(d) bootstrap por semilla (20000, percentil)", f"{m:.4f}", f"{bm.std(ddof=1):.4f}", "—",
            f"[{lo:.4f}, {hi:.4f}]", f"{(hi-lo)/2:.4f}", "percentil; 12 conglomerados"])
# bootstrap por episodio (referencia ingenua)
be = np.array([rng.choice(y, size=N, replace=True).mean() for _ in range(B)])
lo_e, hi_e = np.percentile(be, [2.5, 97.5])
print(f"   {'    (ref.) bootstrap por episodio (20000, percentil)':58s} {m:.4f} · IC95 [{lo_e:.4f}, {hi_e:.4f}] · "
      f"semiancho medio {(hi_e-lo_e)/2:.4f}")
# (e) efectos aleatorios 1 vía
r = icc1(V, "cob")
s2b, s2w = r["sd_entre"] ** 2, r["msw"]
ng = V.groupby("semilla").size().to_numpy()
w = 1.0 / (s2b + s2w / ng)
mu_re = (w * ms.to_numpy()).sum() / w.sum()
_, sa_e = fila("(e) efectos aleatorios 1 vía (ANOVA, pesos 1/(σ²b+σ²w/n))", mu_re, np.sqrt(1 / w.sum()), len(ms) - 1,
               f"σb {np.sqrt(s2b):.4f} σw {np.sqrt(s2w):.4f}")
# Kish: 1 + (m̄_w − 1)·ICC
mbar_w = (ng ** 2).sum() / ng.sum()
print(f"   efecto de diseño de Kish 1 + (m̄_w − 1)·ICC = 1 + ({mbar_w:.3f} − 1)·{r['icc']:.3f} = {1 + (mbar_w - 1)*r['icc']:.2f}"
      f" → n efectivo ≈ {N/(1 + (mbar_w - 1)*r['icc']):.1f}")
# (f) sensibilidad
ee_s, Gs = cr1(y, V.ses)
fila("(f1) robusto por conglomerado = sesión (CR1; sólo 5)", m, ee_s, Gs - 1, "⚠ 5 conglomerados")
ee_int, _ = cr1(y, V.ses + "_" + V.semilla.astype(str))   # intersección = episodio (1 por celda)
v2 = ee_b ** 2 + ee_s ** 2 - ee_int ** 2
fila("(f2) doble conglomerado semilla × sesión (CGM)", m, np.sqrt(max(v2, 0)), min(G, Gs) - 1,
     "gl = min(G)−1 (conservador)")

print(f"\n   cociente de semianchos: (b)/(a) = {sa_b/sa_a:.2f} · (c)/(a) = {sa_c/sa_a:.2f} · (e)/(a) = {sa_e/sa_a:.2f}"
      f" · (d)/(ref. boot. episodio) = {(hi-lo)/(hi_e-lo_e):.2f}")
print("   Nota: las 50 observaciones son 12 escenarios repetidos (2–5 veces cada uno). (a) supone 50\n"
      "   observaciones independientes; (b)–(e) respetan que las repeticiones de un mismo escenario están\n"
      "   correlacionadas (ICC ≈ 0.4). (c) y (e) responden a 'media sobre escenarios' (población de semillas);\n"
      "   (a), (b) y (d) a 'media sobre episodios corridos' con el peso que dio el diseño.")

# referencia: 26-09 y 30-09 + 26-09
v26 = T[(T.valido == 1) & (T.ses == "26-09")].cob.to_numpy()
print(f"\n   (ref.) 26-09 n=10 episodios independientes: {v26.mean():.4f} IC95 "
      f"[{v26.mean() - stats.t.ppf(0.975, 9)*v26.std(ddof=1)/np.sqrt(10):.4f}, "
      f"{v26.mean() + stats.t.ppf(0.975, 9)*v26.std(ddof=1)/np.sqrt(10):.4f}]")

print("\n=== TABLA MARKDOWN 12 — IC95 de la cobertura media del hw (30-09, 50 válidos) ===")
print(md_tabla(["Método", "media", "EE", "gl", "IC95", "semiancho", "nota"], fil))
