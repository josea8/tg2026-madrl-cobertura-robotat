# -*- coding: utf-8 -*-
"""
verificar_s1_coherencia.py — crítico de COHERENCIA de REPORTE_2026-09-30.md.

Cubre lo que no tiene verificador propio:
  * cada cifra del §1 (Resumen) y del §8 (citable / declarar), recalculada desde csv/ y consola/;
  * contradicciones entre secciones (conteos, n, signos, unidades, estimadores);
  * cifras de otras secciones que el §1/§8 repiten o que se contradicen con otra sección;
  * el §9 (archivos crudos) contra lo que hay en el paquete.

Cálculo propio (no importa ni ejecuta ningún otro script del paquete).
Definiciones del encargo: válido = columna 'valido' en ('1','True'); semilla = 420000 + ep − 1;
agentes 0..4 = robots 1, 5, 8, 6, 9; d_pared = min(x, 3−x, y, 3−y) en el marco env;
inicio de congelamiento = primera fila de un agente con (x, y, θ) idéntica a la anterior del mismo
agente y episodio; desvíos con ddof = 1; env = R(rot)·(escala·lab) + tras.

Formato de salida: "id | descripción | valor en el reporte | recalculado | OK/FALLA"
(tolerancia = media unidad del último decimal mostrado). Líneas INFO = contexto, no cuentan.
Uso:  cd scripts && python -B verificar_s1_coherencia.py      (Python ≥ 3.8, numpy, scipy)
"""
import csv
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

BASE = Path(__file__).resolve().parent.parent
CSVD = BASE / "csv"
CONS = BASE / "consola"
SECCION = "s1_coherencia"

SUF = {"s1": "", "s2": "_02", "s3": "_03", "s4": "_04", "s5": "_05"}
SES30 = list(SUF)
MAPEO = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}

# ----------------------------------------------------------------------------- utilidades
CUENTA = {"ok": 0, "falla": 0, "nr": 0}


def _limpio(t):
    return (t.replace("−", "-").replace("–", "-").replace("+", "").replace("‰", "")
            .replace("%", "").replace("cm", "").replace("ms", "").replace("m", "").strip())


def _decimales(t):
    t = _limpio(t)
    return len(t.split(".")[1]) if "." in t else 0


def chk(i, desc, rep, val, tol=None, nota=""):
    """Compara el valor del reporte (texto) con el recalculado."""
    v = float(_limpio(rep))
    d = _decimales(rep)
    if tol is None:
        tol = 0.5 * 10 ** (-d)
    ok = abs(val - v) <= tol + 1e-12
    rec = f"{val:+.{d + 2}f}" if rep.strip()[:1] in "+−-" else f"{val:.{d + 2}f}"
    if nota:
        rec += f" ({nota})"
    CUENTA["ok" if ok else "falla"] += 1
    print(f"{i} | {desc} | {rep} | {rec} | {'OK' if ok else 'FALLA'}")
    return ok


def chk_ent(i, desc, rep, val, nota=""):
    ok = int(rep) == int(val)
    CUENTA["ok" if ok else "falla"] += 1
    print(f"{i} | {desc} | {rep} | {val}{(' (' + nota + ')') if nota else ''} | {'OK' if ok else 'FALLA'}")
    return ok


def chk_txt(i, desc, rep, rec, ok):
    CUENTA["ok" if ok else "falla"] += 1
    print(f"{i} | {desc} | {rep} | {rec} | {'OK' if ok else 'FALLA'}")
    return ok


def nr(i, desc, rep, fuente):
    CUENTA["nr"] += 1
    print(f"{i} | {desc} | {rep} | — | NO RECALCULABLE (fuente: {fuente})")


def info(txt):
    print(f"INFO | {txt}")


def seccion(t):
    print("#" * 100)
    print(f"# {t}")


def leer(nombre):
    with open(CSVD / nombre, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def es_valido(r):
    return str(r.get("valido", "")).strip() in ("1", "True")


def tci(x):
    x = np.asarray(x, float)
    n = len(x)
    m = x.mean()
    se = x.std(ddof=1) / math.sqrt(n)
    w = stats.t.ppf(0.975, n - 1) * se
    p = 2 * stats.t.sf(abs(m / se), n - 1) if se > 0 else float("nan")
    return m, m - w, m + w, p


def por_semilla(d, sem):
    g = defaultdict(list)
    for a, s in zip(d, sem):
        g[s].append(a)
    medias = [np.mean(v) for _, v in sorted(g.items())]
    return tci(medias) + (len(medias),)


def cr1(d, sem):
    d = np.asarray(d, float)
    m = d.mean()
    e = d - m
    g = defaultdict(float)
    for a, s in zip(e, sem):
        g[s] += a
    G = len(g)
    N = len(d)
    var = G / (G - 1) * sum(v * v for v in g.values()) / N ** 2
    se = math.sqrt(var)
    w = stats.t.ppf(0.975, G - 1) * se
    return m, m - w, m + w, 2 * stats.t.sf(abs(m / se), G - 1)


def ols_fe(y, x_cols, grupos):
    """y ~ x_cols + efectos fijos de grupo (sin intercepto). Devuelve (coef, se, p, gl) de cada x."""
    y = np.asarray(y, float)
    niveles = sorted(set(grupos))
    D = np.array([[1.0 if g == lv else 0.0 for lv in niveles] for g in grupos])
    X = np.column_stack([np.asarray(c, float) for c in x_cols] + [D])
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    res = y - X @ b
    rango = np.linalg.matrix_rank(X)
    gl = len(y) - rango
    s2 = res @ res / gl
    cov = s2 * np.linalg.pinv(X.T @ X)
    out = []
    for k in range(len(x_cols)):
        se = math.sqrt(cov[k, k])
        t = b[k] / se
        out.append((b[k], se, 2 * stats.t.sf(abs(t), gl), gl))
    return out


def dpared(x, y):
    return min(x, 3 - x, y, 3 - y)


# calibración env ↔ lab
try:
    _cal = json.load(open(CSVD / "calibracion_medida.json", encoding="utf-8"))
    ESC, ROT = float(_cal["escala_posicion"]), float(_cal["rotacion_marco_rad"])
    TX, TY = float(_cal["traslacion_x_m"]), float(_cal["traslacion_y_m"])
    LAT_ACT = float(_cal.get("latencia_actuacion_media_s", float("nan")))
except Exception:
    ESC, ROT, TX, TY, LAT_ACT = 1.0166876, 0.0084726, 1.5061547, 1.2563353, float("nan")


def env_a_lab(x, y):
    dx, dy = x - TX, y - TY
    c, s = math.cos(ROT), math.sin(ROT)
    return ((c * dx + s * dy) / ESC, (-s * dx + c * dy) / ESC)


# ----------------------------------------------------------------------------- carga
EP = {s: leer(f"20260930_sesion-evaluacion_etapa7_episodios{SUF[s]}.csv") for s in SES30}
RP = {s: leer(f"20260930_sesion-replica_etapa7_capas-on_de-20260930{SUF[s]}.csv") for s in SES30}
EP["26-09"] = leer("20260926_sesion-evaluacion_etapa7_episodios.csv")
RP["26-09"] = leer("20260926_sesion-replica_etapa7_capas-on_de-20260926.csv")
EP["11-09"] = leer("20260911_sesion-evaluacion_etapa7_episodios.csv")
RP["11-09"] = leer("20260912_sesion-replica_etapa7_capas-on.csv")


def cargar_dec(nombre):
    D = defaultdict(list)
    with open(CSVD / nombre, encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            D[(int(r["episodio"]), int(r["agente"]))].append(
                (int(r["paso"]), r["pose_env_x"], r["pose_env_y"], r["pose_env_th"],
                 float(r["pose_env_x"]), float(r["pose_env_y"]), int(float(r["en_escape"] or 0)),
                 int(r["robot"])))
    for k in D:
        D[k].sort()
    return D


DEC = {s: cargar_dec(f"20260930_sesion-evaluacion_etapa7_decisiones{SUF[s]}.csv") for s in SES30}
DEC["26-09"] = cargar_dec("20260926_sesion-evaluacion_etapa7_decisiones.csv")
VAL = {s: {int(r["episodio"]) for r in EP[s] if es_valido(r)} for s in EP}


def pares(ses):
    por = defaultdict(list)
    for r in RP[ses]:
        if es_valido(r):
            por[int(r["episodio"])].append(r)
    out = []
    for r in EP[ses]:
        if not es_valido(r):
            continue
        e = int(r["episodio"])
        reps = por.get(e, [])
        if not reps:
            continue
        m = lambda k: float(np.mean([float(x[k]) for x in reps]))
        out.append(dict(ses=ses, ep=e, sem=int(r["semilla"]), hw=float(r["cobertura_aoi"]), sim=m("cobertura_aoi"),
                        dp_hw=float(r["d_pared_min"]), dp_sim=m("d_pared_min"),
                        vi_hw=float(r["viola_018"]), vi_sim=m("viola_018"),
                        cbf_hw=float(r["frac_cbf"]), cbf_sim=m("frac_cbf"),
                        esc_hw=float(r["n_escape"]), esc_sim=m("n_escape"),
                        p95=float(r["ciclo_p95_ms"]), row=r))
    return out


P30 = [p for s in SES30 for p in pares(s)]
P26 = pares("26-09")
P11 = pares("11-09")
d30 = [p["hw"] - p["sim"] for p in P30]
sem30 = [p["sem"] for p in P30]
V30 = [r for s in SES30 for r in EP[s] if es_valido(r)]
V26 = [r for r in EP["26-09"] if es_valido(r)]

# ============================================================================= §1.1 y §8
seccion("§1.1 / §8 — conjunto de resultados")
n_int = sum(len(EP[s]) for s in SES30)
chk_ent("R1.01", "§1.1 válidos del 30-09", "50", len(V30))
chk_ent("R1.02", "§1.1 intentos del 30-09", "57", n_int)
chk("R1.03", "§1.1 tasa de validez", "0.877", len(V30) / n_int)
chk_ent("R1.04", "§1.1 válidos del 26-09", "10", len(V26))
chk_ent("R1.05", "§1.1 intentos del 26-09", "19", len(EP["26-09"]))
ok_sem = all(int(r["semilla"]) == 420000 + int(r["episodio"]) - 1 for s in SES30 for r in EP[s])
chk_txt("R1.06", "encabezado: semilla = 420000 + ep − 1 en las 57 filas", "sí", "sí" if ok_sem else "no", ok_sem)
cnt = defaultdict(int)
for r in V30:
    cnt[int(r["semilla"])] += 1
chk_ent("R1.07", "encabezado/§8: escenarios (semillas distintas) entre los 50", "12", len(cnt))
chk_txt("R1.08", "encabezado: cada escenario repetido de 2 a 5 veces", "2 a 5",
        f"{min(cnt.values())} a {max(cnt.values())}", (min(cnt.values()), max(cnt.values())) == (2, 5))
cob = np.array([float(r["cobertura_aoi"]) for r in V30])
for i, (rep, v) in enumerate([("0.3452", cob.mean()), ("0.0428", cob.std(ddof=1))]):
    chk(f"R1.{9 + i:02d}", f"§1.1 = §2 = §8 cobertura hw {'media' if i == 0 else 'desvío (ddof 1)'}", rep, v)
m, lo, hi, _ = cr1(cob, [int(r["semilla"]) for r in V30])
chk("R1.11", "§1.1 = §8 IC95 respetando las semillas (CR1), inferior", "0.3253", lo)
chk("R1.12", "§1.1 = §8 IC95 respetando las semillas (CR1), superior", "0.3651", hi)
chk_ent("R1.13", "§1.1 = §8 colisiones < 0.15 m en los 50", "0", sum(int(float(r["colisiones_015"])) for r in V30))
chk_ent("R1.14", "§1.1 = §8 colisiones < 0.22 m en los 50", "0", sum(int(float(r["colisiones_022"])) for r in V30))
nfilas = sum(len(DEC[s][(e, a)]) for s in SES30 for e in VAL[s] for a in range(5))
chk_ent("R1.15", "§1.1 decisiones-agente de los 50 válidos", "125000", nfilas)
mm, mlo, mhi, _, G = por_semilla(cob, [int(r["semilla"]) for r in V30])
info(f"estimador por escenario de la cobertura hw (peso igual por semilla): {mm:.4f} [{mlo:.4f}, {mhi:.4f}] "
     f"(= §2 'media de las 12 medias'); §1.1/§8 usan CR1 (peso por episodio) mientras §1.2/§8 usan por escenario para la brecha")

# ============================================================================= §1.2 y §8 — brecha
seccion("§1.2 / §3 / §8 — brecha sim-real en cobertura")
chk_ent("R2.01", "§1.2 pares del principal", "50", len(P30))
m, lo, hi, p, G = por_semilla(d30, sem30)
chk_ent("R2.02", "§1.2 escenarios del principal", "12", G)
chk("R2.03", "§1.2 principal por escenario: media", "+0.0123", m)
chk("R2.04", "§1.2 principal por escenario: IC95 inferior", "−0.0073", lo)
chk("R2.05", "§1.2 principal por escenario: IC95 superior", "+0.0318", hi)
SA_PE = (m, lo, hi)
m, lo, hi, p = tci(d30)
chk("R2.06", "§1.2 referencia, 50 independientes: media", "+0.0077", m)
chk("R2.07", "§1.2 referencia: IC95 inferior", "−0.0046", lo)
chk("R2.08", "§1.2 referencia: IC95 superior", "+0.0200", hi)
m, lo, hi, p = cr1(d30, sem30)
chk("R2.09", "§1.2 post hoc CR1: media", "+0.0077", m)
chk("R2.10", "§1.2 post hoc CR1: IC95 inferior", "−0.0091", lo)
chk("R2.11", "§1.2 post hoc CR1: IC95 superior", "+0.0244", hi)
CR1_D = (m, lo, hi)
chk("R2.12", "§1.2 'cota inferior −0.007 a −0.009 según el método': por escenario", "−0.007", SA_PE[1])
chk("R2.13", "§1.2 'cota inferior −0.007 a −0.009 según el método': CR1", "−0.009", CR1_D[1])
info(f"la tercera fila de la misma tabla (50 independientes) tiene cota inferior {tci(d30)[1]:+.4f}: "
     f"el rango '−0.007 a −0.009' sólo describe los dos métodos que agrupan por semilla")
# sensibilidades
fuera = []
for p_ in P30:
    r = p_["row"]
    pts = [(float(r[f"x0_a{i}"]), float(r[f"y0_a{i}"])) for i in range(5)]
    dmin = min(math.dist(a, b) for k, a in enumerate(pts) for b in pts[k + 1:])
    malos = any((r[f"col_estado_a{i}"] or "").strip() not in ("", "listo") or
                math.hypot(pts[i][0] - float(r[f"blanco_x_a{i}"]), pts[i][1] - float(r[f"blanco_y_a{i}"])) > 0.12
                for i in range(5))
    p_["fuera"] = dmin < 0.31 or malos
    p_["parmin"] = dmin
PA = [p_ for p_ in P30 if not p_["fuera"]]
mA = por_semilla([p_["hw"] - p_["sim"] for p_ in PA], [p_["sem"] for p_ in PA])
chk("R2.14", "§1.2 'ninguna sensibilidad cambia esto' → sens. A por escenario: IC95 inferior (cota ~0.01)", "−0.0110", mA[1])
info(f"sens. A por escenario {mA[0]:+.4f} [{mA[1]:+.4f}, {mA[2]:+.4f}]: la cota inferior pasa de −0.0073 a −0.0110 "
     f"(sigue '~0.01', pero ya no está en el rango '−0.007 a −0.009')")
# ANOVA de la diferencia por sesión vs ANOVA de la cobertura por sesión
gd = [[p_["hw"] - p_["sim"] for p_ in P30 if p_["ses"] == s] for s in SES30]
gc = [[float(r["cobertura_aoi"]) for r in EP[s] if es_valido(r)] for s in SES30]
pa_d = stats.f_oneway(*gd).pvalue
pa_c = stats.f_oneway(*gc).pvalue
chk("R2.15", "§1.2 'Las 5 sesiones no difieren entre sí (ANOVA p = 0.72)' = ANOVA de hw − réplica", "0.72", pa_d)
chk("R2.16", "§2 'Cobertura: ANOVA p = 0.870' = ANOVA de la cobertura hw (otra variable)", "0.870", pa_c)
info("dos ANOVA distintos con la misma redacción ('las sesiones no difieren'): §1.2 debe decir 'en la brecha hw − réplica'")
# cota previa n = 15
d_prev = [p_["hw"] - p_["sim"] for p_ in P26 + P11]
m, lo, hi, _ = tci(d_prev)
chk_ent("R2.17", "§1.2 n de la cota previa (11-09 + 26-09)", "15", len(d_prev))
chk("R2.18", "§1.2 cota previa: semiancho del IC95 por pares", "0.031", (hi - lo) / 2)
chk("R2.19", "§1.2 semiancho nuevo, extremo bajo (CR1)", "0.017", (CR1_D[2] - CR1_D[1]) / 2)
chk("R2.20", "§1.2 semiancho nuevo, extremo alto (por escenario)", "0.020", (SA_PE[2] - SA_PE[1]) / 2)
# §8
chk("R8.01", "§8 brecha por escenario (redondeo de §3)", "+0.012", SA_PE[0])
chk("R8.02", "§8 IC95 inferior", "−0.007", SA_PE[1])
chk("R8.03", "§8 IC95 superior", "+0.032", SA_PE[2])
chk("R8.04", "§8 media de 50 pares", "+0.008", CR1_D[0])
# §3 26-09 solo
m26 = np.mean([p_["hw"] - p_["sim"] for p_ in P26])
chk("R2.21", "§3 'mismo signo que el 26-09 (+0.013)'", "+0.013", m26)
# combinados
dd = [p_["hw"] - p_["sim"] for p_ in P30 + P26]
chk_ent("R2.22", "§3/§8 combinado 30-09 + 26-09: pares", "60", len(dd))
# preespecificación: estimación puntual del plan
info("plan (scripts/pareo_final_0930.py, docstring): 'Estimación puntual = media de los 50 d' (= +0.0077) e 'IC95 PRINCIPAL = "
     "por semilla' (centrado en +0.0123). §1.2 y §8 citan +0.0123/+0.012 como 'preespecificado'; §3 (nota 1) dice lo contrario")
nr("R2.23", "§1.2 / §8 / §8-decisión 1: '+0.0123 por escenario' rotulado como estimación preespecificada", "preespecificado",
   "scripts/pareo_final_0930.py (docstring): 'Estimación puntual = media de los 50 d' (+0.0077, R2.06) con 'IC95 PRINCIPAL = "
   "por semilla' (centrado en +0.0123, R2.03); lo preespecificado es la pareja +0.0077 / [−0.0073, +0.0318], como dice la nota 1 del §3")

# seed 420002
s420002 = sorted((p_["ses"], p_["hw"] - p_["sim"]) for p_ in P30 if p_["sem"] == 420002)
dif2 = [v for _, v in s420002]
chk("R3.01", "§3 semilla 420002: diferencia mínima de sus 3 sesiones", "+0.087", min(dif2))
chk("R3.02", "§3 semilla 420002: diferencia máxima de sus 3 sesiones", "+0.095", max(dif2))
# 'la semilla explica la mitad de la varianza'
def eta2(y, g):
    y = np.asarray(y, float)
    gm = defaultdict(list)
    for a, b in zip(y, g):
        gm[b].append(a)
    sst = ((y - y.mean()) ** 2).sum()
    ssb = sum(len(v) * (np.mean(v) - y.mean()) ** 2 for v in gm.values())
    return ssb / sst


chk("R3.03", "§3 'la semilla explica ~40 % de la varianza de la brecha' (η² una vía)", "0.40", eta2(d30, sem30),
    nota="η²; tolerancia de 'la mitad' = 0.05", tol=0.05)
info(f"η² de la semilla en la cobertura hw (una vía) = {eta2(cob, [int(r['semilla']) for r in V30]):.3f}; "
     "el 50.5 % del §2 es del modelo aditivo semilla + sesión de la cobertura hw, no de la brecha")
# latencia
sl = ols_fe(d30, [[p_["p95"] / 10 for p_ in P30]], sem30)[0]
chk("R7.05", "§1.7 / §3 'la latencia no predice la brecha': p de la pendiente (efectos fijos de semilla)", "0.67", sl[2])

# ============================================================================= §1.3 / §4 / §8 — seguridad
seccion("§1.3 / §4 / §8 — seguridad pareada")
dp = [p_["dp_hw"] - p_["dp_sim"] for p_ in P30]
m, lo, hi, _ = tci(dp)
m_pe = por_semilla(dp, sem30)[0]
chk("R3.04", "§1.3 = §8 'el hw anda 3.5 cm más cerca de la pared' (por escenario, cm)", "3.5", -100 * m_pe,
    nota=f"por pares {-100 * m:.3f} cm, que redondea a 3.6")
chk_ent("R3.05", "§1.3 = §8 episodios con hw < réplica en d_pared mín", "49", sum(1 for v in dp if v < 0))
m, lo, hi, _, _ = por_semilla(dp, sem30)
chk("R3.06", "§1.3 IC95 por semilla, inferior (cm)", "−4.3", 100 * lo)
chk("R3.07", "§1.3 IC95 por semilla, superior (cm)", "−2.8", 100 * hi)
chk("R3.08", "§1.3 más violaciones de 0.18 m por episodio (por pares)", "+0.43", tci([p_["vi_hw"] - p_["vi_sim"] for p_ in P30])[0])
chk("R3.09", "§1.3 más escape (decisiones-agente, por pares)", "+11", tci([p_["esc_hw"] - p_["esc_sim"] for p_ in P30])[0])
mc = tci([p_["cbf_hw"] - p_["cbf_sim"] for p_ in P30])
chk_txt("R3.10", "§1.3 'la fracción con CBF no cambia' (IC95 por pares contiene 0)", "no cambia",
        f"{mc[0]:+.4f} [{mc[1]:+.4f}, {mc[2]:+.4f}]", mc[1] < 0 < mc[2])
d11 = 100 * np.mean([p_["dp_hw"] - p_["dp_sim"] for p_ in P11])
d26 = 100 * np.mean([p_["dp_hw"] - p_["dp_sim"] for p_ in P26])
chk("R3.11", "§1.3 = §4 11-09: hw − réplica en d_pared mín (cm, valor absoluto)", "4.5", -d11)
chk("R3.12", "§1.3 = §4 26-09: hw − réplica en d_pared mín (cm, valor absoluto)", "2.6", -d26)
# §2 tabla de métricas: coherencia de las medias con §4
chk("R3.13", "§2 vs §4: d_pared mín hw − réplica a partir de las medias del §2 (0.1317 − 0.1672)", "−0.0355",
    np.mean([p_["dp_hw"] for p_ in P30]) - np.mean([p_["dp_sim"] for p_ in P30]))
chk("R3.14", "§2 vs §4: violaciones 2.00 − 1.57", "+0.43",
    np.mean([p_["vi_hw"] for p_ in P30]) - np.mean([p_["vi_sim"] for p_ in P30]))
chk("R3.15", "§2 vs §4: escape 40.2 − 28.8", "+11.4",
    np.mean([p_["esc_hw"] for p_ in P30]) - np.mean([p_["esc_sim"] for p_ in P30]))

# robot 5: ¿qué parte de qué diferencia?
def dmin_episodio(ses, ep, excluir=()):
    best = (9.0, None, None)
    for a in range(5):
        if a in excluir:
            continue
        for f in DEC[ses][(ep, a)]:
            v = dpared(f[4], f[5])
            if v < best[0]:
                best = (v, a, f)
    return best


r5_eps, r5_pts = [], []
dmin_all, dmin_sin_a1 = {}, {}
for ses in SES30 + ["26-09"]:
    for e in sorted(VAL[ses]):
        v, a, f = dmin_episodio(ses, e)
        dmin_all[(ses, e)] = v
        dmin_sin_a1[(ses, e)] = dmin_episodio(ses, e, excluir=(1,))[0]
        if ses in SES30 and a == 1:
            r5_eps.append((ses, e))
            r5_pts.append((f[4], f[5], f[6]))
chk_ent("R3.16", "§4 el r5 fija el mínimo de pared en N de los 50 válidos", "26", len(r5_eps))
caja = [(x, y, esc) for x, y, esc in r5_pts if 2.715 <= x <= 2.745 and 0.105 <= y <= 0.135]
chk_ent("R3.17", "§4 de esos 26, en el mismo punto env (2.72–2.74, 0.11–0.13)", "20", len(caja))
labs = [env_a_lab(x, y) for x, y, _ in caja]
lx, ly = np.mean([a for a, _ in labs]), np.mean([b for _, b in labs])
chk("R3.18", "§4 ese punto en el marco lab: x", "+1.19", lx)
chk("R3.19", "§4 ese punto en el marco lab: y", "−1.13", ly)
ok_csv = all(abs(dmin_all[(s, e)] - float(r["d_pared_min"])) < 1e-9
             for s in SES30 + ["26-09"] for r in EP[s] if es_valido(r) for e in [int(r["episodio"])])
info(f"control: d_pared mín por episodio recalculado desde decisiones = columna d_pared_min del CSV: {ok_csv}")
# diferencia de día ajustada por semilla, con y sin el agente 1 (robot 5)
eps_d = [(s, e) for s in SES30 + ["26-09"] for e in sorted(VAL[s])]
sem_d = [420000 + e - 1 for s, e in eps_d]
dia = [1.0 if s in SES30 else 0.0 for s, e in eps_d]
b_all = ols_fe([dmin_all[k] for k in eps_d], [dia], sem_d)[0]
b_sin = ols_fe([dmin_sin_a1[k] for k in eps_d], [dia], sem_d)[0]
chk("R3.20", "§4 30-09 − 26-09 en d_pared mín ajustado por semilla (m)", "−0.033", b_all[0])
frac_r5 = 1 - b_sin[0] / b_all[0]
chk_txt("R3.21", "§4 'el r5 aporta ~40 %': fracción de la diferencia de día que desaparece sin el r5 "
        "(criterio |fracción − 0.40| < 0.05)", "~40 %",
        f"{frac_r5:.2f} (sin r5: {b_sin[0]:+.4f}, p {b_sin[2]:.2f})", abs(frac_r5 - 0.40) < 0.05)
info(f"día 30-09 − 26-09 en d_pared mín: con r5 {b_all[0]:+.4f} (p {b_all[2]:.2g}); sin el agente 1 {b_sin[0]:+.4f} (p {b_sin[2]:.2f}) "
     f"→ el r5 aporta {100 * (1 - b_sin[0] / b_all[0]):.0f} %")
g_r5 = [p_["dp_hw"] - p_["dp_sim"] for p_ in P30 if (p_["ses"], p_["ep"]) in set(r5_eps)]
g_ot = [p_["dp_hw"] - p_["dp_sim"] for p_ in P30 if (p_["ses"], p_["ep"]) not in set(r5_eps)]
info(f"hw − réplica en d_pared mín: episodios donde el r5 fija el mínimo hw {100 * np.mean(g_r5):+.2f} cm (n={len(g_r5)}); "
     f"resto {100 * np.mean(g_ot):+.2f} cm (n={len(g_ot)}). La réplica sólo guarda el mínimo por episodio (sin agente)")
nr("R3.22", "§1.3 'Una parte la pone el robot 5' aplicado a la diferencia hw − réplica", "una parte",
   "la réplica con capas sólo guarda d_pared_min por episodio, sin agente: no se puede quitar el r5 de la réplica; "
   "la cifra del §4 (r5) es de la diferencia 30-09 − 26-09, no de hw − réplica")
nr("R3.23", "§4 hipótesis: el 3pi responde en ~450 ms", "~450 ms",
   f"medición fuera del paquete; csv/calibracion_medida.json trae latencia_actuacion_media_s = {1000 * LAT_ACT:.1f} ms")

# ============================================================================= §1.4 / §5 / §8 — deriva
seccion("§1.4 / §5 / §8 — deriva entre episodios (consola)")
RX_ESTA = re.compile(r"robot (\d+): está \((-?[\d.]+), (-?[\d.]+)\)")
RX_CONG = re.compile(r"robot (\d+): marcador CONGELADO \(pose repetida en (-?[\d.]+), (-?[\d.]+)\)")
CONSOLAS = {"26-09": "consola_20260926.txt", "s1": "consola_20260930.txt", "s2": "consola_20260930_02.txt",
            "s3": "consola_20260930_03.txt", "s5": "consola_20260930_05.txt"}


def bloques(nombre):
    lineas = (CONS / nombre).read_text(encoding="utf-8", errors="replace").splitlines()
    idx = []
    for i, l in enumerate(lineas):
        mm_ = re.match(r"^EPISODIO (\d+)\s+\(válidos hasta ahora", l)
        if mm_:
            idx.append((i, int(mm_.group(1))))
    out = {}
    for j, (i, k) in enumerate(idx):
        fin = idx[j + 1][0] if j + 1 < len(idx) else len(lineas)
        out[k] = lineas[i:fin]
    return out


def impresiones(bloque):
    i0 = next((i for i, l in enumerate(bloque) if "[Enter para seguir]" in l), None)
    if i0 is None:
        return []
    imps, cur = [], {}
    for l in bloque[i0 + 1:]:
        if "[colocación" in l or l.strip().startswith("colocación:"):
            break
        if not l.strip():
            if cur:
                imps.append(cur)
                cur = {}
            continue
        mm_ = RX_ESTA.search(l) or RX_CONG.search(l)
        if mm_:
            cur[int(mm_.group(1))] = (float(mm_.group(2)), float(mm_.group(3)))
    if cur:
        imps.append(cur)
    return imps


DER = []  # (ses, k, valido, robot, d1, d2, dpared2, congelado_al_final, ep_k)
for ses, nom in CONSOLAS.items():
    B = bloques(nom)
    validos = {int(r["episodio"]): es_valido(r) for r in EP[ses]}
    for k in sorted(validos):
        if k + 1 not in B:
            continue
        imps = impresiones(B[k + 1])
        for a in range(5):
            filas = DEC[ses].get((k, a), [])
            if not filas:
                continue
            u = filas[-1]
            cong = len(filas) > 1 and filas[-2][1:4] == u[1:4]
            rob = MAPEO[a]
            p1 = imps[0].get(rob) if len(imps) > 0 else None
            p2 = imps[1].get(rob) if len(imps) > 1 else None
            d1 = 100 * math.hypot(p1[0] - u[4], p1[1] - u[5]) if p1 else None
            d2 = 100 * math.hypot(p2[0] - u[4], p2[1] - u[5]) if p2 else None
            dp2 = round(dpared(*p2), 2) if p2 else None
            DER.append((ses, k, validos[k], rob, d1, d2, dp2, cong))

prev = [x for x in DER if x[0] in ("26-09", "s1", "s2", "s3") and x[2]]
d2p = [x[5] for x in prev if x[5] is not None]
d1p = [x[4] for x in prev if x[4] is not None]
chk_ent("R4.01", "§5 válidos antes del arreglo: medidas d2", "180", len(d2p))
chk("R4.02", "§1.4 = §5 válidos antes del arreglo: mediana d2 (cm)", "30.8", float(np.median(d2p)))
chk("R4.03", "§1.4 = §5 válidos antes del arreglo: máximo d2 (cm)", "61.9", max(d2p))
chk("R4.04", "§5 válidos antes del arreglo: mediana d1 (cm)", "27.5", float(np.median(d1p)))
chk("R4.05", "§5 válidos antes del arreglo: máximo d1 (cm)", "55.9", max(d1p))
fuera_ = [x for x in prev if x[6] is not None and x[6] < 0]
chk_ent("R4.06", "§1.4 = §5 robots fuera de la arena en la 2.ª impresión", "4", len(fuera_))
chk("R4.07", "§1.4 = §8 'hasta 6 cm afuera' (d_pared mín 2.ª impresión, m)", "−0.06", min(x[6] for x in prev if x[6] is not None))
bajo5 = [x for x in prev if x[6] is not None and x[6] < 0.05 - 1e-9]
chk_ent("R4.08", "§5 'otras 6 medidas quedaron a < 0.05 m' (además de las 4 de afuera)", "6", len(bajo5) - len(fuera_),
        nota=f"total < 0.05 m = {len(bajo5)}, que ya incluye las 4 negativas; impresas exactamente en 0.05: "
             f"{sum(1 for x in prev if x[6] is not None and abs(x[6] - 0.05) < 1e-9)}")
for ses_, rep_ in (("26-09", "41.5"), ("s1", "46.5"), ("s2", "38.0"), ("s3", "61.9")):
    v = [x[5] for x in prev if x[0] == ses_ and x[5] is not None]
    chk(f"R4.09{ses_}", f"§5 desglose {ses_}: máximo d2 (cm)", rep_, max(v))
chk("R4.10", "§8 'en s1–s4 … salieron de la arena': d_pared mín 2.ª impresión en s1–s3 (m)", "−0.03",
    min(x[6] for x in prev if x[0] in ("s1", "s2", "s3") and x[6] is not None))
s5v = [x for x in DER if x[0] == "s5" and x[2]]
chk("R4.11", "§1.4 = §5 s5 con arreglo: mediana d2 (cm)", "4.0", float(np.median([x[5] for x in s5v if x[5] is not None])))
chk("R4.12", "§1.4 = §5 s5 con arreglo: máximo d2 (cm)", "6.5", max(x[5] for x in s5v if x[5] is not None))
ab = [x for x in DER if not x[2] and not x[7]]
d2a = [x[5] for x in ab if x[5] is not None]
chk_ent("R4.13", "§5 abortados (robots no congelados al final): medidas d2", "58", len(d2a))
chk("R4.14", "§1.4 'el mismo nivel que tras un aborto' = §5 abortados: mediana d2 (cm)", "4.1", float(np.median(d2a)))
chk("R4.15", "§5 abortados: máximo d2 (cm)", "9.6", max(d2a))
ab_ep = defaultdict(list)
for x in ab:
    if x[5] is not None:
        ab_ep[(x[0], x[1])].append(x[5])
s5_ep = defaultdict(list)
for x in s5v:
    if x[5] is not None:
        s5_ep[x[1]].append(x[5])
pmw = stats.mannwhitneyu([np.median(v) for v in s5_ep.values()], [np.median(v) for v in ab_ep.values()],
                         alternative="two-sided").pvalue
chk("R4.16", "§5 s5 contra abortados, por episodio, 2.ª impresión: Mann-Whitney p", "0.46", pmw)
n_eps_cong = len({(x[0], x[1]) for x in DER if not x[2] and x[7]})
info(f"'abortados (… sin robots congelados)': la exclusión es por ROBOT (n = {len(d2a)}); "
     f"{n_eps_cong} de los {len({(x[0], x[1]) for x in DER if not x[2]})} abortados medibles tienen algún robot congelado y siguen incluidos")
nr("R4.17", "§1.4 'el arreglo no toca nada dentro del episodio' / §8 'actúa después de las métricas'", "después de las métricas",
   "codigo/arreglo_detencion_sesion_robotat.diff: detener_todo() queda después del lazo de decisiones pero ANTES de "
   "'tramo = registro[marca:]' y del cálculo de cobertura y duración (duracion_s ahora incluye la llamada)")

# ============================================================================= §1.5 / §6 — congelamientos
seccion("§1.5 / §6 — congelamientos, hipos y retrocesos")


def inicios(ses):
    out = []
    for (e, a), f in DEC[ses].items():
        for k in range(1, len(f)):
            rep = f[k][1:4] == f[k - 1][1:4]
            prev_rep = k >= 2 and f[k - 1][1:4] == f[k - 2][1:4]
            if rep and not prev_rep:
                out.append(dict(ses=ses, ep=e, ag=a, robot=MAPEO[a], paso=f[k][0], x=f[k][4], y=f[k][5]))
    return out


def tabla_delta(ses):
    T = defaultdict(lambda: defaultdict(dict))
    for (e, a), f in DEC[ses].items():
        for k in range(1, len(f)):
            if f[k][0] != f[k - 1][0] + 1:
                continue
            T[e][f[k][0]][a] = (1000 * math.hypot(f[k][4] - f[k - 1][4], f[k][5] - f[k - 1][5]), f[k][1:4] == f[k - 1][1:4])
    return T


def hipos(ses):
    """Decisiones con firma de hipo: mediana de Δ de los no repetidos < 0.30·ref y en la anterior > 1.6·ref."""
    T = tabla_delta(ses)
    H, ndec = set(), defaultdict(int)
    for e, pasos in T.items():
        mmed = {}
        for p_, dd_ in pasos.items():
            v = [dm for dm, rep in dd_.values() if not rep]
            mmed[p_] = float(np.median(v)) if v else float("nan")
        for p_, dd_ in pasos.items():
            if p_ < 12 or len(dd_) < 5:
                continue
            ndec[e] += 1
            ref = [mmed[q] for q in range(p_ - 10, p_ + 11) if abs(q - p_) > 1 and q in mmed and not math.isnan(mmed[q])]
            if not ref or (p_ - 1) not in mmed:
                continue
            ref = float(np.median(ref))
            if ref > 0 and mmed[p_] / ref < 0.30 and mmed[p_ - 1] / ref > 1.6:
                H.add((e, p_))
    return H, ndec


INI = {s: inicios(s) for s in SES30 + ["26-09"]}
HIP, NDEC = {}, {}
for s in SES30 + ["26-09"]:
    HIP[s], NDEC[s] = hipos(s)
fall = {s: {int(r["episodio"]) for r in EP[s] if float(r["poses_fallidas"] or 0) > 0} for s in SES30}
rech = {s: {int(r["episodio"]) for r in EP[s] if float(r["poses_rechazadas"] or 0) > 0} for s in SES30}
for s in SES30:
    for it in INI[s]:
        if it["ep"] in fall[s]:
            it["mec"] = "fallida"
        elif it["ep"] in rech[s]:
            it["mec"] = "rechazo"
        elif (it["ep"], it["paso"]) in HIP[s]:
            it["mec"] = "hipo"
        else:
            it["mec"] = "motive"
I30 = [it for s in SES30 for it in INI[s]]
Iv = [it for it in I30 if it["ep"] in VAL[it["ses"]]]
chk_ent("R5.01", "§6 inicios en los válidos del 30-09", "16", len(Iv))
chk("R5.02", "§6 tasa de inicios en válidos (‰)", "0.128", 1000 * len(Iv) / nfilas)
mot_v = [it for it in Iv if it["mec"] == "motive"]
chk_ent("R5.03", "§1.5 = §6 retenciones de Motive en válidos", "11", len(mot_v))
chk("R5.04", "§1.5 = §6 retención de Motive en válidos (‰)", "0.088", 1000 * len(mot_v) / nfilas)
hip_v = [it for it in Iv if it["mec"] == "hipo"]
chk_ent("R5.05", "§1.5 = §6 inicios (y retrocesos) en decisiones con firma de hipo, válidos", "5", len(hip_v))
nh_v = sum(1 for s in SES30 for (e, p_) in HIP[s] if e in VAL[s])
nh_eps = len({(s, e) for s in SES30 for (e, p_) in HIP[s] if e in VAL[s]})
chk_ent("R5.06", "§6 hipos en válidos", "9", nh_v)
chk_ent("R5.07", "§6 episodios válidos con hipo", "8", nh_eps)
chk_ent("R5.08", "§6 hipos el 30-09 (todos los intentos)", "11", sum(len(HIP[s]) for s in SES30))
chk_ent("R5.09", "§6 hipos el 26-09", "0", len(HIP["26-09"]))
chk_ent("R5.10", "§6 decisiones evaluables el 26-09", "6624", sum(NDEC["26-09"].values()))
# lugares (env)
A, B, C, E = (2.54, 2.20), (2.82, 2.49), (2.52, 2.79), (2.826, 2.741)
near = lambda it, P, r: math.hypot(it["x"] - P[0], it["y"] - P[1]) <= r
chk_ent("R5.11", "§1.5 = §6 'A no reapareció': inicios del 30-09 a ≤ 8 cm de A", "0", sum(near(it, A, 0.08) for it in I30))
chk_ent("R5.12", "§1.5 = §6 'B no reapareció': inicios del 30-09 a ≤ 8 cm de B", "0", sum(near(it, B, 0.08) for it in I30))
cC = {(it["ses"], it["ep"], it["ag"]) for it in I30 if near(it, C, 0.08)}
chk_ent("R5.13", "§1.5 = §6 'C, una sola vez': (sesión, ep, agente) con inicio a ≤ 8 cm de C", "1", len(cC), nota=str(sorted(cC)))
cen = [it for it in I30 if math.hypot(*env_a_lab(it["x"], it["y"])) <= 0.10]
chk_ent("R5.14", "§6 centro: inicios a ≤ 10 cm del origen lab", "7", len(cen))
chk_txt("R5.15", "§1.5 = §6 centro: todos del robot 6", "r6", str(sorted({it['robot'] for it in cen})),
        {it["robot"] for it in cen} == {6})
chk_ent("R5.16", "§6 centro: retenciones de Motive en válidos", "6", sum(1 for it in cen if it["mec"] == "motive"))
cE = [it for it in I30 if near(it, E, 0.08)]
chk_txt("R5.17", "§1.5 = §6 E junto a (3, 3): 4 inicios, 3 del r8 y 1 del r9", "4 (r8 ×3, r9 ×1)",
        f"{len(cE)} ({', '.join('r%d' % it['robot'] for it in cE)})",
        len(cE) == 4 and sorted(it["robot"] for it in cE) == [8, 8, 8, 9])
mot_rob = defaultdict(int)
for it in mot_v:
    mot_rob[it["robot"]] += 1
chk_txt("R5.18", "§6 las 11 retenciones de Motive en válidos son de r6 (6) y r8 (5)", "r6 6, r8 5",
        ", ".join(f"r{k} {v}" for k, v in sorted(mot_rob.items())), dict(mot_rob) == {6: 6, 8: 5})
# retrocesos
RX_RET = re.compile(r"a(\d):(\d+)-(\d+)\(([\d.]+)s,([\d.]+)cm,([a-z_]+)\)")
ret_v, ret_a = [], []
for s in SES30:
    for r in EP[s]:
        for mm_ in RX_RET.finditer(r["retrocesos_detalle"] or ""):
            (ret_v if es_valido(r) else ret_a).append((s, int(r["episodio"]), int(mm_.group(1)), int(mm_.group(2)), mm_.group(6)))
chk_ent("R5.19", "§6 retrocesos del 30-09", "29", len(ret_v) + len(ret_a))
chk_ent("R5.20", "§1.5 = §6 retrocesos en válidos", "16", len(ret_v))
chk_ent("R5.21", "§1.5 = §6 retrocesos en válidos recuperados", "16", sum(1 for x in ret_v if x[4] == "recuperada"))
chk_ent("R5.22", "§6 retrocesos de abortados recuperados ('salvo 1')", "1", sum(1 for x in ret_a if x[4] == "recuperada"))
chk_ent("R5.23", "§6 filas en_retroceso de los válidos", "64",
        sum(int(float(r["decisiones_retroceso"] or 0)) for r in V30))
# 26-09: retención de Motive (todas las filas, válidos, por episodio)
fal26 = {int(r["episodio"]) for r in EP["26-09"] if float(r["poses_fallidas"] or 0) > 0}
rec26 = {int(r["episodio"]) for r in EP["26-09"] if float(r["poses_rechazadas"] or 0) > 0}
mot26 = [it for it in INI["26-09"] if it["ep"] not in fal26 | rec26 and (it["ep"], it["paso"]) not in HIP["26-09"]]
filas26 = sum(len(v) for v in DEC["26-09"].values())
filas30 = sum(len(v) for s in SES30 for v in DEC[s].values())
mot30 = [it for it in I30 if it["mec"] == "motive"]
filas26v = sum(len(DEC["26-09"][(e, a)]) for e in VAL["26-09"] for a in range(5))
mot26v = [it for it in mot26 if it["ep"] in VAL["26-09"]]
chk("R5.25", "§6 retención de Motive, todos los episodios, 26-09 (‰)", "0.321", 1000 * len(mot26) / filas26)
chk("R5.26", "§6 retención de Motive, todos los episodios, 30-09 (‰)", "0.082", 1000 * len(mot30) / filas30)
pv = stats.fisher_exact([[len(mot26v), filas26v - len(mot26v)], [len(mot_v), nfilas - len(mot_v)]])[1]
info(f"§1.5 'bajó a 0.088 ‰ en los válidos': el 26-09 en válidos fue {len(mot26v)}/{filas26v} = "
     f"{1000 * len(mot26v) / filas26v:.3f} ‰ (Fisher por fila p = {pv:.2f}); la baja significativa es la de todos los episodios")
e26 = len({it["ep"] for it in mot26})
e30 = len({(it["ses"], it["ep"]) for it in mot30})
pe = stats.fisher_exact([[e26, len(EP["26-09"]) - e26], [e30, n_int - e30]])[1]
chk("R5.27", "§6 por episodio con algún inicio de Motive (9/19 contra 7/57): Fisher p", "0.0026", pe,
    nota=f"{e26}/{len(EP['26-09'])} contra {e30}/{n_int}")
nr("R5.24", "§1.5/§7 'el hipo … disparó 5 retrocesos falsos' (mecanismo)", "falsos",
   "la firma se mide (R5.05) pero el CSV no tiene el instante de cada consulta; §6 mismo: 'el mecanismo sigue siendo una hipótesis'")

# ============================================================================= §1.6 / §7 — colocación y arranques
seccion("§1.6 / §7 — colocación y arranques")
nf = [p_ for p_ in P30 if p_["fuera"]]
chk_ent("R6.01", "§1.6 = §7 arranques fuera del soporte en los 50", "5", len(nf))
chk_txt("R6.02", "§7 son los únicos con un par < 0.31 m", "únicos",
        f"{sum(1 for p_ in P30 if p_['parmin'] < 0.31)} con par < 0.31",
        {(p_["ses"], p_["ep"]) for p_ in P30 if p_["parmin"] < 0.31} == {(p_["ses"], p_["ep"]) for p_ in nf})
est = defaultdict(int)
for s in SES30:
    for r in EP[s]:
        for i in range(5):
            est[(r[f"col_estado_a{i}"] or "").strip()] += 1
chk_ent("R6.03", "§1.6 = §7 robot-intentos 'no avanza'", "15", est["no avanza"])
chk_ent("R6.04", "§7 robot-intentos 'listo'", "266", est["listo"])
chk_ent("R6.05", "§7 robot-intentos 'sin pose'", "4", est["sin pose"])
nr("R6.06", "§1.6 = §7 '14 de 15 son bloqueo del CBF robot-robot'", "14",
   "simulación de colocacion_autonoma (no está en el paquete); derivados/a30f_verif_robots_7_cbf_salida.txt: "
   "evidencia geométrica 14/15 y 7 de 14 dependen del supuesto de zona muerta")
chk("R6.07", "§7 cobertura hw de los otros 45 (descriptivo)", "0.342", np.mean([p_["hw"] for p_ in P30 if not p_["fuera"]]))
chk("R6.08", "§7 cobertura hw de los 5 fuera del soporte", "0.370", np.mean([p_["hw"] for p_ in nf]))
mA2 = tci([p_["hw"] - p_["sim"] for p_ in PA])
chk_txt("R6.09", "§1.6 'sin ellos no cambia la conclusión' (los IC de la sens. A siguen incluyendo 0)", "no cambia la conclusión",
        f"pares {mA2[0]:+.4f} [{mA2[1]:+.4f}, {mA2[2]:+.4f}] vs +0.0077; por escenario {mA[0]:+.4f} [{mA[1]:+.4f}, {mA[2]:+.4f}] vs "
        f"+0.0123 [−0.0073, +0.0318]; cobertura hw {np.mean([p_['hw'] for p_ in PA]):.4f} vs 0.3452; la conclusión no cambia, "
        f"las cifras sí", (mA[1] < 0 < mA[2]) and (mA2[1] < 0 < mA2[2]))
rampa = [r for r in V30 if int(r["episodio"]) == 1]
info(f"omisión: rampa de arranque (primeras 50 decisiones de cada sesión, 25 % de V_MAX × factor 0.40) en {len(rampa)} de los 50 "
     f"válidos (ep 1; semillas {sorted({int(r['semilla']) for r in rampa})}); cobertura hw sin ellos "
     f"{np.mean([float(r['cobertura_aoi']) for r in V30 if int(r['episodio']) != 1]):.4f} (n = {50 - len(rampa)}); "
     f"el reporte no la declara")
ab30 = [r for s in SES30 for r in EP[s] if not es_valido(r)]
cache = [r for r in ab30 if float(r["poses_fallidas"] or 0) > 0 or float(r["poses_rechazadas"] or 0) > 0]
chk_ent("R6.10", "§2 = §8 abortos con consulta fallida o pose rechazada (defecto de caché)", "4", len(cache))
chk_ent("R6.11", "§2 = §8 abortos del 30-09", "7", len(ab30))

# ============================================================================= §1.7 / §7 — ritmo del lazo
seccion("§1.7 / §7 — ritmo del lazo")
p95_30 = [float(r["ciclo_p95_ms"]) for r in V30]
p95_26 = [float(r["ciclo_p95_ms"]) for r in V26]
chk("R7.01", "§1.7 = §2 p95 del ciclo hw 30-09 (MEDIA de los válidos, ms)", "46.6", np.mean(p95_30))
chk("R7.02", "§1.7 = §2 p95 del ciclo hw 26-09 (MEDIA de los válidos, ms)", "15.5", np.mean(p95_26))
rp30 = [float(r["ciclo_p95_ms"]) for s in SES30 for r in RP[s] if es_valido(r)]
rp26 = [float(r["ciclo_p95_ms"]) for r in RP["26-09"] if es_valido(r)]
chk("R7.03", "§1.7 = §7 réplica 30-09 (MEDIANA de las corridas válidas, ms)", "16.3", float(np.median(rp30)))
chk("R7.04", "§1.7 = §7 réplica 26-09 (MEDIANA de las corridas válidas, ms)", "20.9", float(np.median(rp26)))
info(f"§1.7 compara medias del hw ({np.mean(p95_30):.1f} / {np.mean(p95_26):.1f}) con medianas de la réplica; "
     f"medianas del hw: {np.median(p95_30):.1f} / {np.median(p95_26):.1f} ms")
chk_ent("R7.06", "§3 corridas válidas de la réplica", "148", sum(1 for s in SES30 for r in RP[s] if es_valido(r)))
chk_ent("R7.07", "§3 corridas de la réplica", "150", sum(len(RP[s]) for s in SES30))
pmin, nom_min = 1.0, ""
for k in ("cobertura_aoi", "d_pared_min", "viola_018", "frac_cbf", "n_escape"):
    b = ols_fe([float(r[k]) for r in V30], [[float(r["ciclo_p95_ms"]) / 10 for r in V30]], [int(r["semilla"]) for r in V30])[0]
    info(f"latencia (+10 ms de p95) → {k}: {b[0]:+.4f} (p {b[2]:.3f})")
    if b[2] < pmin:
        pmin, nom_min = b[2], k
chk_txt("R7.08", "§7 'con efectos fijos de semilla, ninguna p < 0.05; la menor 0.24' (cobertura y seguridad)",
        "ninguna p < 0.05; mín 0.24", f"mín p = {pmin:.3f} ({nom_min})", pmin >= 0.05 and abs(pmin - 0.24) < 0.005)
ps2 = [float(r["ciclo_p95_ms"]) for r in EP["s2"] if es_valido(r)]
ps3 = [float(r["ciclo_p95_ms"]) for r in EP["s3"] if es_valido(r)]
chk("R7.09", "§7 = §8 s3 (réplica en paralelo) no más lenta que s2: Mann-Whitney p", "0.68",
    stats.mannwhitneyu(ps3, ps2, alternative="two-sided").pvalue)
# §2 precisión 26-09 activaciones de escape
def activaciones(ses, e):
    n = 0
    for a in range(5):
        prev_ = 0
        for f in DEC[ses][(e, a)]:
            if f[6] == 1 and prev_ == 0:
                n += 1
            prev_ = f[6]
    return n


act26 = [activaciones("26-09", e) for e in sorted(VAL["26-09"])]
act30 = [activaciones(s, e) for s in SES30 for e in sorted(VAL[s])]
chk("R7.10", "§2 activaciones de escape 30-09: media", "2.12", np.mean(act30))
chk("R7.11", "§2 activaciones de escape 26-09: desvío ('0.90 ± 1.4', un decimal menos que el resto)", "1.4", np.std(act26, ddof=1))
info(f"activaciones 26-09 = {np.mean(act26):.2f} ± {np.std(act26, ddof=1):.2f}; total 30-09 = {sum(act30)} (§4: 106)")
chk_ent("R7.12", "§4 activaciones de escape del 30-09 (total)", "106", sum(act30))

# ============================================================================= §9 — archivos
seccion("§9 — archivos crudos del paquete")
lista9 = ([f"csv/20260930_sesion-evaluacion_etapa7_episodios{SUF[s]}.csv" for s in SES30] +
          [f"csv/20260930_sesion-evaluacion_etapa7_decisiones{SUF[s]}.csv" for s in SES30] +
          [f"csv/20260930_sesion-replica_etapa7_capas-on_de-20260930{SUF[s]}.csv" for s in SES30] +
          ["csv/calibracion_medida.json", "consola/consola_20260926.txt", "consola/consola_20260930.txt",
           "consola/consola_20260930_02.txt", "consola/consola_20260930_03.txt", "consola/consola_20260930_05.txt",
           "scripts/pareo_final_0930.py", "scripts/pareo_extra_0930.py", "scripts/verificar_cifras.py",
           "figuras/a30f_congel_mapa.png", "derivados/pareo_final_0930_sha256_antes_de_correr.txt",
           "derivados/replica_0930_hashes_pila_final.txt", "derivados/replica_0930_todas_log.txt"])
falt = [p_ for p_ in lista9 if not (BASE / p_).is_file()]
chk_ent("F9.01", "§9 archivos nombrados que faltan en el paquete", "0", len(falt), nota=", ".join(falt) or "ninguno")
chk_txt("F9.02", "§9 'con sha256 en LEEME.md'", "LEEME.md", "presente" if (BASE / "LEEME.md").is_file() else "AUSENTE",
        (BASE / "LEEME.md").is_file())
chk_ent("F9.03", "§9 'No hay consola de la s4'", "0", int((CONS / "consola_20260930_04.txt").is_file()))
chk_ent("F9.04", "§9 'codigo/': diff del arreglo y de la prueba", "2", len(list((BASE / "codigo").glob("*.diff"))))
s26 = [p_.name for p_ in CSVD.glob("20260926_*")] + [p_.name for p_ in CSVD.glob("2026091[12]_*")]
chk_ent("F9.05", "§9 'csv/20260926_* y csv/20260911_*, csv/20260912_*'", "5", len(s26), nota=", ".join(sorted(s26)))
hp = (BASE / "derivados" / "replica_0930_hashes_pila_final.txt").read_text(encoding="utf-8", errors="replace")
n_juegos = len([l for l in hp.splitlines() if "replica_con_capas.py" in l])
nr("F9.06", "§3 'el sha256 de la pila es idéntico antes y después'", "antes y después",
   f"derivados/replica_0930_hashes_pila_final.txt trae {n_juegos} juego de hashes (sólo el 'final'); el de 'antes' no está en el paquete")
log_par = (BASE / "derivados" / "replica_0930_log.txt").read_text(encoding="utf-8", errors="replace")
corr = re.findall(r"^rep \d+ ep\s+\d+ .*cobertura ([\d.]+)\s+hw ([\d.]+)", log_par, flags=re.M)
ini = re.search(r"INICIO (\d\d:\d\d:\d\d)", log_par)
nr("F9.07", "§3 'había visto en el registro 4 coberturas sueltas de la rep 1 de la s1, sin parear'", "4, sin parear",
   f"lo que el autor miró no es medible; pero derivados/replica_0930_log.txt (corrida parcial de la s1, INICIO "
   f"{ini.group(1) if ini else '?'}, anterior al plan de las 13:40) trae {len(corr)} líneas 'cobertura <réplica> hw <hw>' "
   f"del mismo episodio, y el docstring del plan cita '1/23 en la corrida parcial' y '2/7 al arrancar la definitiva'")
extras = sorted(p_.name for p_ in (BASE / "scripts").glob("*.py")
                if not p_.name.startswith(("a30f_", "verificar_", "pareo_")))
info(f"scripts/ no nombrados en §9: {extras}; derivados/wf_0930_extraido.txt (afirmaciones y veredictos) tampoco se nombra")
nr("F9.08", "§9 'Los únicos archivos nuevos del proyecto son los 5 CSV de la réplica'", "5 CSV",
   "scripts/arreglo_detencion.py (shutil.copy2 → *_respaldo_20260930_preDetencion.py) y las cabeceras de codigo/*.diff "
   "muestran 2 respaldos nuevos y 2 archivos modificados del proyecto el 30-09")
nr("F9.09", "encabezado/§9 'REPORTE_2026-09-30_datos.zip'", "zip", "fuera del paquete; el paquete es una carpeta")

print("#" * 100)
print(f"RESUMEN {SECCION}: {CUENTA['ok']} ok, {CUENTA['falla']} fallas, {CUENTA['nr']} no recalculables")
