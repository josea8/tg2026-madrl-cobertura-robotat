import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): parseo propio de las consolas pegadas (s1, s2, s3, s5 del
30-09 y 26-09). La de s4 NO existe: todo lo de consola de s4 = sin dato.
Cubre A02, A03 (conexión perdida), A04, A05, A07, A09, A23, A24, A25 (menciones), A28.
SOLO LECTURA."""
import sys
sys.dont_write_bytecode = True
import os, re
from collections import Counter, defaultdict

SP = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
CONS = {"s1": "consola_20260930.txt", "s2": "consola_20260930_02.txt", "s3": "consola_20260930_03.txt",
        "s4": "consola_20260930_04.txt", "s5": "consola_20260930_05.txt", "c26": "consola_20260926.txt"}
out = []
P = out.append

tot = defaultdict(Counter)
for s, nombre in CONS.items():
    ruta = os.path.join(SP, nombre)
    P("=" * 100)
    if not os.path.exists(ruta):
        P(f"{s}: {nombre} NO EXISTE -> sin dato")
        continue
    L = open(ruta, encoding="utf-8").read().splitlines()
    P(f"{s}: {nombre} ({len(L)} líneas)")
    # bloques de episodio: desde 'EPISODIO N  (válidos' hasta el siguiente
    ini = [(i, int(m.group(1))) for i, l in enumerate(L) if (m := re.match(r"^EPISODIO (\d+)\s+\(válidos", l))]
    ini.append((len(L), None))
    for k in range(len(ini) - 1):
        i0, ep = ini[k]
        i1 = ini[k + 1][0]
        B = L[i0:i1]
        res = next((l for l in B if re.match(rf"^\s+>>> EPISODIO {ep}:", l)), "")
        valido = "VÁLIDO" in res and "INVÁLIDO" not in res
        # última línea resumen de colocación ('  colocación: ...' sin corchete)
        idx_col = [j for j, l in enumerate(B) if re.match(r"^\s+colocación: ", l)]
        idx_res = [j for j, l in enumerate(B) if re.match(rf"^\s+>>> EPISODIO {ep}:", l)]
        det = None
        if idx_col and idx_res:
            det = sum(1 for l in B[idx_col[-1]:idx_res[0]] if "detención enviada" in l)
        n_col = len(idx_col)
        nogasta = sum(1 for l in B if "no se gasta el intento" in l)
        noav = [re.search(r"robot (\d+)", l).group(1) for l in B if "queda para el operador (no avanza)" in l]
        sinp = [re.search(r"robot (\d+)", l).group(1) for l in B if "queda para el operador (sin pose)" in l]
        otros_op = [l.strip()[:90] for l in B if "queda para el operador" in l and "(no avanza)" not in l and "(sin pose)" not in l]
        vieja = [re.search(r"antigüedad=(\d+) ticks", l).group(1) for l in B if "Decisión con pose vieja" in l]
        fren = [l.strip() for l in B if "frenando por pose vencida" in l]
        e10054 = [l.strip()[:120] for l in B if "10054" in l and "fallo enviando" in l]
        noconf = sum(1 for l in B if "NO SE PUDO CONFIRMAR LA DETENCIÓN" in l)
        recon = [l.strip()[:200] for l in B if "RECONECTADO" in l]
        perd = [l.strip()[:120] for l in B if "conexión perdida" in l]
        sinpose_guia = sum(1 for l in B if re.search(r"robot \d+: SIN POSE", l))
        piv = sum(1 for l in B if "pivot" in l.lower())
        P(f"  ep{ep:>2} {'V' if valido else 'INV'} colocaciones={n_col} no_gasta={nogasta} det_entre_col_y_res={det} "
          f"noavanza={noav} sinpose={sinp} otros_op={otros_op} pose_vieja={vieja} frenando={fren} 10054={len(e10054)} "
          f"noconf={noconf} recon={recon} perdida={perd} SIN_POSE_guia={sinpose_guia} pivot={piv}")
        tot[s]["episodios"] += 1
        tot[s]["validos"] += valido
        tot[s]["colocaciones"] += n_col
        tot[s]["colocaciones_repetidas"] += max(n_col - 1, 0)
        tot[s]["no_gasta"] += nogasta
        tot[s]["noavanza"] += len(noav)
        tot[s]["sinpose"] += len(sinp)
        tot[s]["10054"] += len(e10054)
        tot[s]["noconf"] += noconf
        tot[s][f"det_validos_{det}"] += valido
        tot[s]["pivot"] += piv
        for r in noav:
            tot[s][f"noavanza_r{r}"] += 1
    resumen = [l.strip() for l in L if "rechazos del chequeo de colocación" in l]
    todos10054 = [l.strip()[:140] for l in L if "10054" in l and "fallo enviando" in l]
    todos_noconf = [i for i, l in enumerate(L) if "NO SE PUDO CONFIRMAR" in l]
    P(f"  resumen de rechazos: {resumen}")
    P(f"  10054 (todas las líneas 'fallo enviando'): {len(todos10054)} {todos10054}")
    P(f"  'NO SE PUDO CONFIRMAR' (todo el archivo): {len(todos_noconf)} ; robots: " +
      str([L[i + 1].strip() for i in todos_noconf]))
    P(f"  'conexión perdida' en todo el archivo: {sum(1 for l in L if 'conexión perdida' in l)}")
    P(f"  menciones 'pivot' (todo el archivo): {sum(1 for l in L if 'pivot' in l.lower())}")
    P(f"  TOTALES {s}: {dict(tot[s])}")

P("")
P("RESUMEN 30-09 con consola (s1, s2, s3, s5):")
for k in ["colocaciones_repetidas", "no_gasta", "noavanza", "sinpose", "10054", "noconf", "pivot"]:
    P(f"  {k}: " + " ".join(f"{s}={tot[s][k]}" for s in ["s1", "s2", "s3", "s5"]) + f" | total={sum(tot[s][k] for s in ['s1','s2','s3','s5'])} | 26-09={tot['c26'][k]}")
P("  detenciones entre fin de colocación y resultado en VÁLIDOS: " + " ".join(
    f"{s}:" + str({k: v for k, v in tot[s].items() if k.startswith('det_validos_') and v}) for s in ["s1", "s2", "s3", "s5", "c26"]))
open(os.path.join(SP, "a30f_verif_robots_3_consola_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
