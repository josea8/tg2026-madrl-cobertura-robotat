import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""4) Seguridad del hardware desde el CSV de decisiones: episodios con colisión
(par a < 0.15 / < 0.22 m) o con d_pared_min < 0.05 (lista con robot y ubicación),
eventos más cercanos a pared y entre pares, distribución de d_pared por fila
(percentiles) y fracción de filas con d_pared < 0.10. Válidos de S1..S5 (50) y
26-09 (10) como control; los inválidos se revisan aparte (no son resultado).
⚠ Sólo cubre las decisiones DENTRO del episodio: el avance a ciegas posterior al
fin de los episodios válidos (S1–S4, antes del arreglo) no está en los CSV."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import numpy as np
import pandas as pd
from a30f_metricas_comun import (SES, S30, ROBOT, PTS_CIEGOS, leer_dec, env_a_lab, arreglos,
                                 dist_pares, md_tabla, SP)

pd.set_option("display.width", 230)
T = pd.read_csv(SP + r"\a30f_metricas_tabla.csv")
PCT = [0, 0.1, 1, 5, 10, 25, 50]


def pared_mas_cercana(x, y):
    d = {"x=0": x, "x=3": 3 - x, "y=0": y, "y=3": 3 - y}
    return min(d, key=d.get)


FILAS_D = {}
eventos_pared, eventos_par, listado = [], [], []
for ses in ["26-09"] + S30:
    D = leer_dec(SES[ses][1])
    FILAS_D[ses] = D
    for r in T[T.ses == ses].itertuples():
        s = D[D.episodio == r.ep]
        P = arreglos(s)
        dd, iu = dist_pares(P)
        # colisiones y separación mínima
        k, j = np.unravel_index(np.argmin(dd), dd.shape)
        a, b = iu[0][j], iu[1][j]
        eventos_par.append(dict(ses=ses, ep=r.ep, valido=r.valido, paso=int(k), par=f"r{ROBOT[a]}–r{ROBOT[b]}",
                                d=float(dd[k, j]), x=float((P[k, a, 0] + P[k, b, 0]) / 2),
                                y=float((P[k, a, 1] + P[k, b, 1]) / 2),
                                c15=int((dd < 0.15).any(axis=0).sum()), c22=int((dd < 0.22).any(axis=0).sum())))
        # fila más cercana a pared
        i = s.d_pared.idxmin()
        f = s.loc[i]
        xl, yl = env_a_lab(f.pose_env_x, f.pose_env_y)
        dc = {n: np.hypot(f.pose_env_x - px, f.pose_env_y - py) for n, (px, py) in PTS_CIEGOS.items()}
        nc = min(dc, key=dc.get)
        eventos_pared.append(dict(ses=ses, ep=r.ep, valido=r.valido, robot=int(f.robot), paso=int(f.paso),
                                  d_pared=float(f.d_pared), pared=pared_mas_cercana(f.pose_env_x, f.pose_env_y),
                                  x_env=float(f.pose_env_x), y_env=float(f.pose_env_y), x_lab=float(xl), y_lab=float(yl),
                                  repetida=bool(f.repetida), retro=int(f.en_retroceso), escape=int(f.en_escape),
                                  cbf=int(f.cbf_intervino), pto_ciego=f"{nc} {dc[nc]:.2f} m"))
EP = pd.DataFrame(eventos_pared)
EPar = pd.DataFrame(eventos_par)

print("=== ¿EPISODIOS VÁLIDOS CON COLISIÓN (par < 0.15 o < 0.22 m) o d_pared_min < 0.05? ===")
for ses in ["26-09"] + S30:
    v = EPar[(EPar.ses == ses) & (EPar.valido == 1)]
    w = EP[(EP.ses == ses) & (EP.valido == 1)]
    print(f"   {ses}: válidos {len(v)} · con c15>0 {int((v.c15 > 0).sum())} · con c22>0 {int((v.c22 > 0).sum())} · "
          f"con d_pared_min<0.05 {int((w.d_pared < 0.05).sum())} · <0.10 {int((w.d_pared < 0.10).sum())} · "
          f"separación mín {v.d.min():.4f} m · d_pared mín {w.d_pared.min():.4f} m")
v30 = EPar[EPar.ses.isin(S30) & (EPar.valido == 1)]
w30 = EP[EP.ses.isin(S30) & (EP.valido == 1)]
print(f"   TOTAL 30-09: {len(v30)} válidos · colisión <0.15: {int((v30.c15 > 0).sum())} eps · <0.22: {int((v30.c22 > 0).sum())} eps"
      f" · d_pared_min<0.05: {int((w30.d_pared < 0.05).sum())} eps → NINGUNO; no hay nada que listar.")

print("\n=== los 10 episodios válidos del 30-09 con MENOR d_pared_min (robot, paso, ubicación) ===")
cols = ["ses", "ep", "robot", "paso", "d_pared", "pared", "x_env", "y_env", "x_lab", "y_lab", "repetida", "retro",
        "escape", "cbf", "pto_ciego"]
print(w30.nsmallest(10, "d_pared")[cols].to_string(index=False, float_format=lambda v: f"{v:.4f}"))
print("\n=== los 10 episodios válidos del 30-09 con MENOR separación entre un par ===")
print(v30.nsmallest(10, "d")[["ses", "ep", "paso", "par", "d", "x", "y"]].to_string(index=False, float_format=lambda v: f"{v:.4f}"))

print("\n=== inválidos (NO son resultado; revisión aparte) ===")
inv = EP[EP.valido == 0].merge(EPar[EPar.valido == 0][["ses", "ep", "d", "par", "c15", "c22"]], on=["ses", "ep"])
print(inv[["ses", "ep", "robot", "paso", "d_pared", "pared", "x_env", "y_env", "repetida", "d", "par", "c15", "c22"]]
      .to_string(index=False, float_format=lambda v: f"{v:.4f}"))

# ── distribución de d_pared por fila ───────────────────────────────────
print("\n=== DISTRIBUCIÓN DE d_pared POR FILA (decisión-agente), válidos ===")
fil = []
res = {}
for nom, sesiones in [(s, [s]) for s in S30] + [("Total 30-09", S30), ("26-09", ["26-09"])]:
    partes, partes_viva = [], []
    for s in sesiones:
        eps = T[(T.ses == s) & (T.valido == 1)].ep.tolist()
        q = FILAS_D[s][FILAS_D[s].episodio.isin(eps)]
        partes.append(q)
    q = pd.concat(partes)
    dp = q.d_pared.to_numpy()
    dv = q[~q.repetida].d_pared.to_numpy()
    pc = np.percentile(dp, PCT)
    res[nom] = (dp, dv)
    print(f"   {nom:12s} filas {len(dp):6d} · pctl {dict(zip(PCT, np.round(pc, 4)))} · <0.10 {np.mean(dp < 0.10):.5f} "
          f"({int((dp < 0.10).sum())}) · <0.15 {np.mean(dp < 0.15):.5f} · <0.18 {np.mean(dp < 0.18):.5f} · "
          f"<0.35 {np.mean(dp < 0.35):.4f} · sin filas repetidas: <0.18 {np.mean(dv < 0.18):.5f} (filas {len(dv)})")
    fil.append([nom, len(dp)] + [f"{v:.4f}" for v in pc] +
               [f"{np.mean(dp < 0.10):.4f} ({int((dp < 0.10).sum())})", f"{np.mean(dp < 0.15):.4f}",
                f"{np.mean(dp < 0.18):.4f}", f"{np.mean(dp < 0.35):.4f}"])
print("\n=== TABLA MARKDOWN 11 — d_pared por fila (decisión-agente, válidos) ===")
print(md_tabla(["Sesión", "filas", "mín", "p0.1", "p1", "p5", "p10", "p25", "mediana",
                "frac < 0.10 (n)", "frac < 0.15", "frac < 0.18", "frac < 0.35"], fil))

# filas bajo 0.15 m: ¿quién y dónde? (contexto: umbral CBF 0.18 en el punto de mira)
dp30 = pd.concat([FILAS_D[s][FILAS_D[s].episodio.isin(T[(T.ses == s) & (T.valido == 1)].ep)].assign(ses=s) for s in S30])
b15 = dp30[dp30.d_pared < 0.15]
print(f"\n=== filas válidas 30-09 con d_pared < 0.15: {len(b15)} ({len(b15)/len(dp30):.4f}) ===")
print("   por robot:", b15.groupby("robot").size().to_dict(), "· por sesión:", b15.groupby("ses").size().to_dict())
b15 = b15.assign(pared=[pared_mas_cercana(x, y) for x, y in zip(b15.pose_env_x, b15.pose_env_y)])
print("   por pared más cercana:", b15.groupby("pared").size().to_dict(),
      f"· con pose repetida {int(b15.repetida.sum())} · en retroceso {int(b15.en_retroceso.sum())} · en escape {int(b15.en_escape.sum())}"
      f" · CBF activo {int(b15.cbf_intervino.sum())}")
print(f"   episodios distintos con alguna fila < 0.15: {b15.groupby(['ses', 'episodio']).ngroups} de 50")

# ── ¿quién fija el d_pared_min del episodio y dónde? ───────────────────
print("\n=== robot que fija el d_pared_min de cada episodio válido ===")
for nom, ss_ in (("Total 30-09", S30), ("26-09", ["26-09"])):
    w = EP[EP.ses.isin(ss_) & (EP.valido == 1)]
    print(f"   {nom}: {w.groupby('robot').size().to_dict()} · en escape {int(w.escape.sum())}/{len(w)} · "
          f"pose repetida {int(w.repetida.sum())} · en retroceso {int(w.retro.sum())}")
caja = b15[(b15.pose_env_x > 2.6) & (b15.pose_env_x < 2.85) & (b15.pose_env_y < 0.15)]
print(f"   filas 30-09 < 0.15 en la caja x_env∈(2.60, 2.85), y_env<0.15 (pared y=0 cerca de la esquina +x−y): "
      f"{len(caja)} de {len(b15)} · robots {caja.groupby('robot').size().to_dict()} · episodios "
      f"{caja.groupby(['ses', 'episodio']).ngroups} · semillas {sorted((caja.merge(T[['ses','ep','semilla']], left_on=['ses','episodio'], right_on=['ses','ep']).semilla.unique() - 420000).tolist())} (−420000)")
w = EP[EP.ses.isin(S30) & (EP.valido == 1)]
print("\n=== TABLA MARKDOWN 12b — 8 episodios válidos con menor d_pared_min (desde decisiones) ===")
print(md_tabla(["Sesión", "ep", "robot", "paso", "d_pared [m]", "pared", "(x, y) env [m]", "(x, y) lab [m]", "escape", "pose repetida"],
               [[r.ses, r.ep, r.robot, r.paso, f"{r.d_pared:.4f}", r.pared, f"({r.x_env:.3f}, {r.y_env:.3f})",
                 f"({r.x_lab:.3f}, {r.y_lab:.3f})", r.escape, "sí" if r.repetida else "no"]
                for r in w.nsmallest(8, "d_pared").itertuples()]))
