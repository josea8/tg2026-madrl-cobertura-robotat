import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_verif_deriva_4_direccion.py — VERIFICADOR ADVERSARIAL. SOLO LECTURA.
# ¿Hacia dónde se movió cada robot entre su última pose registrada y la 2.ª impresión?
#   proy = (p2 − p_ult)·(cos θ_ult, sin θ_ult) / |p2 − p_ult|  (+1 = hacia adelante, −1 = marcha atrás)
#   rec  = misma proyección sobre la dirección de avance registrada en el último 1 s (p_ult − p_{ult−10})
# Para s1 k=1,2 además: distancia de retroceso ANUNCIADA en la consola (líneas "↩ agente a (robot r): ... X cm")
# de la última decisión del episodio, contra d2.
import csv, os, re, math
from collections import defaultdict
import numpy as np
RES = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
S = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
out = []
def P(*a):
    s = " ".join(str(x) for x in a); out.append(s); print(s)
F = lambda v: None if v in ("", "None", None) else float(v)
mio = [r for r in csv.DictReader(open(os.path.join(S, "a30f_verif_deriva_por_robot.csv"), encoding="utf-8")) if r["medible"] == "True"]
DEC = {"26-09": "20260926_sesion-evaluacion_etapa7_decisiones.csv", "s1": "20260930_sesion-evaluacion_etapa7_decisiones.csv",
       "s2": "20260930_sesion-evaluacion_etapa7_decisiones_02.csv", "s3": "20260930_sesion-evaluacion_etapa7_decisiones_03.csv",
       "s5": "20260930_sesion-evaluacion_etapa7_decisiones_05.csv"}
necesarios = defaultdict(set)
for r in mio:
    necesarios[r["sesion"]].add((int(r["k"]), int(r["agente"])))
tray = {}
for ses, f in DEC.items():
    d = defaultdict(list)
    with open(os.path.join(RES, f), encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            key = (int(r["episodio"]), int(r["agente"]))
            if key in necesarios[ses]:
                d[key].append((int(r["paso"]), float(r["pose_env_x"]), float(r["pose_env_y"]), float(r["pose_env_th"]), float(r["v_ejecutada"])))
    for key, rs in d.items():
        rs.sort(); tray[(ses,) + key] = rs
def proy(r, campo_x, campo_y):
    rs = tray[(r["sesion"], int(r["k"]), int(r["agente"]))]
    _, xu, yu, thu, vu = rs[-1]
    x2, y2 = F(r[campo_x]), F(r[campo_y])
    if x2 is None: return None
    dx, dy = x2 - xu, y2 - yu; n = math.hypot(dx, dy)
    if n < 0.015: return None          # por debajo de ~2× la resolución de impresión
    ph = (dx * math.cos(thu) + dy * math.sin(thu)) / n
    _, xa, ya, _, _ = rs[max(0, len(rs) - 11)]
    ex, ey = xu - xa, yu - ya; ne = math.hypot(ex, ey)
    pr = (dx * ex + dy * ey) / (n * ne) if ne > 0.01 else None
    return ph, pr, vu
def resumen(nombre, rows, cx="x2", cy="y2"):
    v = [proy(r, cx, cy) for r in rows]
    v = [x for x in v if x is not None]
    ph = [x[0] for x in v]; pr = [x[1] for x in v if x[1] is not None]
    P(f"  {nombre:28s} n={len(v):3d}  cos(Δ, rumbo) med {np.median(ph):+.2f}  n(<0)={sum(1 for x in ph if x < 0):3d}   "
      f"cos(Δ, avance último 1 s) med {np.median(pr):+.2f}  n(<0)={sum(1 for x in pr if x < 0):3d}  (v_ult<0 en {sum(1 for x in v if x[2] < 0)})")
P("Dirección del desplazamiento última pose → 2.ª impresión (Δ ≥ 1.5 cm)")
resumen("PRE válidos", [r for r in mio if r["arreglo"] == "False" and r["tipo"] == "V"])
resumen("PRE abortados limpio", [r for r in mio if r["arreglo"] == "False" and r["tipo"] == "A" and r["cong_fin"] == "False"])
resumen("s5 válidos", [r for r in mio if r["arreglo"] == "True" and r["tipo"] == "V"])
resumen("s1 k=1,2 (caché)", [r for r in mio if r["sesion"] == "s1" and r["k"] in ("1", "2")])
P("Misma medida hacia la 1.ª impresión:")
resumen("PRE válidos (imp1)", [r for r in mio if r["arreglo"] == "False" and r["tipo"] == "V"], "x1", "y1")
resumen("s5 válidos (imp1)", [r for r in mio if r["arreglo"] == "True" and r["tipo"] == "V"], "x1", "y1")

P("\ns1 k=1,2: retroceso anunciado en consola vs d2 y dirección")
L = open(os.path.join(S, "consola_20260930.txt"), encoding="utf-8").read().splitlines()
anun = {}
ep = None
for l in L:
    m = re.match(r"^EPISODIO (\d+)\s", l)
    if m: ep = int(m.group(1))
    m = re.search(r"↩ agente (\d) \(robot (\d)\): pose repetida .* ([\d.]+) cm, en ≤ ([\d.]+) s \(decisión (\d+)\)", l)
    if m and ep in (1, 2):
        anun[(ep, int(m.group(2)))] = (float(m.group(3)), float(m.group(4)), int(m.group(5)))
pares = []
for r in [r for r in mio if r["sesion"] == "s1" and r["k"] in ("1", "2")]:
    a = anun.get((int(r["k"]), int(r["robot"])))
    p = proy(r, "x2", "y2")
    P(f"  k={r['k']} robot {r['robot']}: retroceso anunciado {a[0] if a else None} cm (≤{a[1] if a else None} s, decisión {a[2] if a else None})  "
      f"d2 {F(r['d2']):.2f} cm  cos(Δ,rumbo) {p[0]:+.2f}  cos(Δ,avance 1 s) {p[1] if p[1] is None else round(p[1], 2)}  paso_ult {r['paso_ult']}")
    if a: pares.append((a[0], F(r["d2"])))
if pares:
    x, y = np.array(pares).T
    P(f"  correlación de Pearson (retroceso anunciado, d2): r = {np.corrcoef(x, y)[0, 1]:.3f}  (n={len(x)});  d2 − anunciado: mediana {np.median(y - x):+.2f} cm, rango [{(y-x).min():+.2f}, {(y-x).max():+.2f}]")
open(os.path.join(S, "a30f_verif_deriva_4_direccion_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
