import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Tareas 1, 2 y 5 (parte consola): parsea las consolas pegadas por Jose (s1, s2, s3, s5;
la de s4 NO existe → 'sin dato') y el control 26-09. Por episodio: colocaciones (incluye
las repetidas tras un rechazo del chequeo, que el CSV NO guarda), abandonos con su motivo y
clase (giro atascado / avance sin acercarse / sin pose), rechazos del chequeo de arranque,
eventos de ruedas (10054, reconexión, detención no confirmada), avisos de pose vieja,
frenado por pose vencida, retrocesos, ⛔, resultado del episodio, y cuántas 'detención
enviada' hay entre el fin de la colocación y el '>>> EPISODIO' (verificación del arreglo).
SOLO LECTURA. Uso: python -B a30f_robots_consola.py"""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import re
from collections import Counter, defaultdict
from a30f_robots_comun import SES, ruta_consola, AG_DE_ROBOT, ROBOT, leer_ep

RE_EP = re.compile(r"^EPISODIO (\d+)\s+\(válidos hasta ahora: (\d+)/")
RE_COL = re.compile(r"^\s+\[colocación\s+(\d+) s\] (.*)$")
RE_FIN_COL = re.compile(r"^\s+colocación: (todos listos|listos los que se podían mover|marcador congelado \(robot (\d+)\): se detuvo la colocación de todos|no se movió a nadie[^—]*) en (\d+) s — (\d)/5")
RE_FIN_COL2 = re.compile(r"^\s+⚠ colocación: no se movió a nadie")
RE_AB = re.compile(r"colocación: robot (\d+) queda para el operador \(([^)]+)\)")
RE_RECH = re.compile(r"^\s+✘ no se arranca todavía:")
RE_RECH_FIN = re.compile(r"^\s+\(no se gasta el intento: corregí y dale Enter — (\d+)/(\d+)\)")
RE_NO_ARR = re.compile(r"^\s+✘ no se arranca este episodio")
RE_ITEM = re.compile(r"^\s+· (.*)$")
RE_FALLO = re.compile(r"\[ruedas\] fallo enviando al agente (\d+) \(robot (\d+)\): (.*)$")
RE_RECON = re.compile(r"\[ruedas\] agente (\d+) → robot (\d+) RECONECTADO \(reconexión n\.º (\d+)\) a los ([\d.]+) s de la caída \(caída ([\d:]+), ([^)]*)\) · intentos fallidos: (.*)$")
RE_NOCONF = re.compile(r"NO SE PUDO CONFIRMAR LA DETENCIÓN")
RE_NOCONF_ITEM = re.compile(r"^\s+agente (\d+) → robot (\d+) @")
RE_VIEJA = re.compile(r"Decisión con pose vieja: antigüedad=(\d+) ticks \(umbral \d+\) en tick (\d+)")
RE_FRENA = re.compile(r"\[ruedas\] frenando por pose vencida: \[([\d, ]+)\]")
RE_RETRO = re.compile(r"↩ agente (\d+) \(robot (\d+)\): pose repetida en \(([\d.]+), ([\d.]+)\), a ([\d.]+) m de la pared .*\(decisión (\d+)\)")
RE_REAN = re.compile(r"▶ agente (\d+) \(robot (\d+)\): pose viva otra vez tras ([\d.]+) s")
RE_STOP = re.compile(r"^\s+⛔ (.*)$")
RE_RES = re.compile(r">>> EPISODIO (\d+): (VÁLIDO|INVÁLIDO)\s*(.*)$")
RE_DET = re.compile(r"\[ruedas\] detención enviada a los 5 robots")
RE_SINPOSE_GUIA = re.compile(r"^\s+robot (\d+): SIN POSE")
RE_RECH_TOT = re.compile(r"\[sesion\] rechazos del chequeo de colocación que NO gastaron intento: (\d+)")
RE_EVAL = re.compile(r"EVALUACIÓN — (\d+) episodios válidos de (\d+) intentos")
RE_PARTE = re.compile(r"r(\d+) (.*)")
RE_WARN_OTRO = re.compile(r"(⚠|✘|Traceback|Error|error |WARNING|Warning)")
RE_GUIA_CONG = re.compile(r"^\s+✘ robot (\d+): marcador CONGELADO")
RE_AVISO_CONG = re.compile(r"⚠ colocación: marcador congelado \(robot (\d+)\)")


def parsear(ruta):
    eps = {}
    cur = None
    col = None
    en_rech = None
    en_noconf = False
    extra = defaultdict(list)
    tot = {}
    lineas = open(ruta, encoding="utf-8").read().splitlines()
    fase = "pre"
    for n, ln in enumerate(lineas, 1):
        m = RE_EP.match(ln)
        if m:
            e = int(m.group(1))
            cur = eps.setdefault(e, dict(ep=e, cols=[], rech=[], no_arranca=[], fallos=[], recon=[], noconf=[], viejas=[],
                                         frena=[], retro=[], rean=[], stop=[], res=None, det_col_a_res=0, det_tras_res=0,
                                         sinpose_guia=Counter(), cong_guia=Counter(), linea=n))
            col, en_rech, fase = None, None, "guia"
            continue
        if cur is None:
            if RE_WARN_OTRO.search(ln) and "No hay reset" not in ln:
                extra["pre"].append((n, ln.strip()))
            continue
        m = RE_COL.match(ln)
        if m:
            t = int(m.group(1))
            if t == 0 or col is None or col.get("fin") is not None:
                col = dict(refrescos=[], abandonos=[], fin=None, linea=n)
                cur["cols"].append(col)
            est = {}
            for parte in m.group(2).split(" · "):
                pm = RE_PARTE.match(parte.strip())
                if not pm:
                    continue
                rob, txt = int(pm.group(1)), pm.group(2)
                md = re.match(r"(\d+) cm (\w+)", txt)
                if md:
                    est[rob] = (int(md.group(1)), md.group(2))
                elif txt.startswith("✔"):
                    est[rob] = (None, "listo")
                elif txt.startswith("✘"):
                    est[rob] = (None, "abandonado:" + txt[2:])
                else:
                    est[rob] = (None, txt)
            col["refrescos"].append((t, est))
            fase = "col"
            continue
        m = RE_AB.search(ln)
        if m:
            if col is None or col.get("fin") is not None:
                col = dict(refrescos=[], abandonos=[], fin=None, linea=n)
                cur["cols"].append(col)
            t_prev = col["refrescos"][-1][0] if col["refrescos"] else 0
            col["abandonos"].append((int(m.group(1)), m.group(2), t_prev, n))
            continue
        m = RE_FIN_COL.match(ln)
        if m:
            if col is None or col.get("fin") is not None:
                col = dict(refrescos=[], abandonos=[], fin=None, linea=n)
                cur["cols"].append(col)
            col["fin"] = (m.group(1), int(m.group(3)), int(m.group(4)), n)
            fase = "tras_col"
            continue
        if RE_RECH.match(ln):
            en_rech = dict(items=[], linea=n)
            cur["rech"].append(en_rech)
            continue
        if RE_NO_ARR.match(ln):
            en_rech = dict(items=[], linea=n, definitivo=True)
            cur["no_arranca"].append(en_rech)
            continue
        if en_rech is not None:
            mi = RE_ITEM.match(ln)
            if mi:
                en_rech["items"].append(mi.group(1))
                continue
            mf = RE_RECH_FIN.match(ln)
            if mf:
                en_rech["n"] = (int(mf.group(1)), int(mf.group(2)))
            en_rech = None
        m = RE_FALLO.search(ln)
        if m:
            cur["fallos"].append((int(m.group(1)), int(m.group(2)), m.group(3), fase, n))
            continue
        m = RE_RECON.search(ln)
        if m:
            cur["recon"].append((int(m.group(1)), int(m.group(2)), float(m.group(4)), m.group(5), m.group(6), m.group(7), fase, n))
            continue
        if RE_NOCONF.search(ln):
            en_noconf = True
            continue
        if en_noconf:
            mi = RE_NOCONF_ITEM.match(ln)
            if mi:
                cur["noconf"].append((int(mi.group(1)), int(mi.group(2)), fase, n))
                continue
            if ln.startswith("===="):
                en_noconf = False
            continue
        m = RE_VIEJA.search(ln)
        if m:
            cur["viejas"].append((int(m.group(1)), int(m.group(2)), n))
            continue
        m = RE_FRENA.search(ln)
        if m:
            cur["frena"].append(([int(x) for x in m.group(1).split(",")], n))
            continue
        m = RE_RETRO.search(ln)
        if m:
            cur["retro"].append((int(m.group(1)), int(m.group(2)), float(m.group(3)), float(m.group(4)), float(m.group(5)),
                                 int(m.group(6)), n))
            continue
        m = RE_REAN.search(ln)
        if m:
            cur["rean"].append((int(m.group(1)), int(m.group(2)), float(m.group(3)), n))
            continue
        m = RE_STOP.match(ln)
        if m:
            cur["stop"].append((m.group(1), n))
            continue
        m = RE_RES.search(ln)
        if m:
            cur["res"] = (m.group(2), m.group(3), n)
            fase = "tras_res"
            continue
        if RE_DET.search(ln):
            if fase in ("tras_col", "ep"):
                cur["det_col_a_res"] += 1
            elif fase == "tras_res":
                cur["det_tras_res"] += 1
            continue
        m = RE_SINPOSE_GUIA.match(ln)
        if m:
            cur["sinpose_guia"][int(m.group(1))] += 1
            continue
        m = RE_GUIA_CONG.match(ln)
        if m:
            cur["cong_guia"][int(m.group(1))] += 1
            continue
        if RE_AVISO_CONG.search(ln):
            continue
        m = RE_RECH_TOT.search(ln)
        if m:
            tot["rechazos_sin_gastar"] = int(m.group(1))
            continue
        m = RE_EVAL.search(ln)
        if m:
            tot["eval"] = (int(m.group(1)), int(m.group(2)))
            continue
        if RE_WARN_OTRO.search(ln) and "SESGADA" not in ln and "No hay reset" not in ln and "queda para el operador" not in ln \
                and not RE_COL.match(ln) and "el error de" not in ln:
            extra[cur["ep"]].append((n, ln.strip()[:160]))
    return eps, tot, extra


def clase_abandono(col, rob, motivo, t_ab):
    """Clase del abandono por la historia de refrescos (metodología de a30b_consola_colocacion)."""
    if motivo != "no avanza":
        ult = [(t, est[rob]) for t, est in col["refrescos"] if t <= t_ab and rob in est and est[rob][0] is not None]
        return f"{motivo} (venía {ult[-1][1][1] if ult else '?'})", ult[-7:]
    hist = [(t, est[rob]) for t, est in col["refrescos"] if t <= t_ab and rob in est and est[rob][0] is not None]
    if not hist:
        return "no avanza (sin historia)", []
    d_fin = hist[-1][1][0]
    ventana = []
    for t, (dcm, fase) in reversed(hist):
        if abs(dcm - d_fin) <= 3:
            ventana.append((t, dcm, fase))
        else:
            break
    fases = [f for _, _, f in ventana]
    ng = fases.count("girando")
    c = "GIRO atascado" if fases and ng / len(fases) >= 0.5 else "AVANCE sin acercarse"
    return c, hist[-7:]


def main():
    resumen_ab = Counter()
    ab_por_robot = defaultdict(Counter)
    tabla_ab = []
    for s in ["s1", "s2", "s3", "s4", "s5", "c26"]:
        ruta = ruta_consola(s)
        print("=" * 118)
        if ruta is None:
            print(f"SESIÓN {s}: consola NO disponible (no se pegó) → todo lo que depende de consola: SIN DATO")
            continue
        eps, tot, extra = parsear(ruta)
        E = {int(f["episodio"]): f for f in leer_ep(s)}
        print(f"SESIÓN {s}: {ruta.split(chr(92))[-1]} · episodios en consola {len(eps)} · en CSV {len(E)} · "
              f"resumen consola: {tot}")
        if extra.get("pre"):
            for n, t in extra["pre"]:
                print(f"   [pre] l.{n}: {t[:150]}")
        n_det_ok = Counter()
        for e in sorted(eps):
            d = eps[e]
            f = E.get(e)
            res = d["res"]
            print(f"-- ep {e:>2} (l.{d['linea']}): resultado consola={res[0] if res else '—'} {('«' + res[1][:80] + '»') if res and res[1] else ''} "
                  f"· CSV valido={f['valido'] if f else '—'}  · colocaciones en consola: {len(d['cols'])}")
            for k, c in enumerate(d["cols"], 1):
                fin = c["fin"]
                print(f"     colocación {k}: fin={fin[0] + f' en {fin[1]} s, {fin[2]}/5' if fin else '—'}"
                      + (f"  (CSV: col_t_s={f['col_t_s']} listos={f['col_listos']} motivo='{f['col_motivo']}')" if f and k == len(d['cols']) else ""))
                for rob, motivo, t_ab, n in c["abandonos"]:
                    cl, hist = clase_abandono(c, rob, motivo, t_ab)
                    seq = " → ".join(f"{t}s:{dcm}cm {fa[:3]}" for t, (dcm, fa) in hist)
                    ultima = (k == len(d["cols"]))
                    print(f"        abandono r{rob} [{motivo}] ~{t_ab} s → {cl}   (colocación {'FINAL (la del CSV)' if ultima else 'REPETIDA después, no queda en el CSV'})")
                    print(f"            refrescos: {seq}")
                    resumen_ab[(s, motivo, cl.split(' (')[0])] += 1
                    ab_por_robot[s][(rob, motivo)] += 1
                    tabla_ab.append((s, e, k, len(d["cols"]), rob, motivo, cl, f["valido"] if f else "?"))
            for r in d["rech"]:
                print(f"     RECHAZO del chequeo (no gasta intento) {r.get('n')}: " + " | ".join(r["items"]))
            for r in d["no_arranca"]:
                print(f"     NO SE ARRANCA el episodio: " + " | ".join(r["items"]))
            for a, rob, txt, fase, n in d["fallos"]:
                print(f"     ruedas: FALLO enviando a a{a}/r{rob} en fase '{fase}' (l.{n}): {txt[:90]}")
            for a, rob, n in [(x[0], x[1], x[3]) for x in d["noconf"]]:
                print(f"     ruedas: detención NO confirmada de a{a}/r{rob} (l.{n})")
            for a, rob, t, hora, err, intentos, fase, n in d["recon"]:
                print(f"     ruedas: a{a}/r{rob} RECONECTADO a los {t:.1f} s de la caída (caída {hora}, {err}), intentos fallidos: {intentos} (l.{n})")
            for ant, tick, n in d["viejas"]:
                print(f"     aviso pose vieja: antigüedad {ant} ticks en tick {tick} (l.{n})")
            for ags, n in d["frena"]:
                print(f"     frenando por pose vencida: {[f'a{a}/r{ROBOT[a]}' for a in ags]} (l.{n})")
            for a, rob, x, y, dp, dec, n in d["retro"]:
                print(f"     retroceso a{a}/r{rob} en ({x:.2f},{y:.2f}) d_pared {dp:.2f} decisión {dec}")
            for a, rob, t, n in d["rean"]:
                print(f"     reanuda a{a}/r{rob} tras {t:.1f} s")
            for txt, n in d["stop"]:
                print(f"     ⛔ {txt[:110]}")
            if d["sinpose_guia"]:
                print(f"     guía con 'SIN POSE': " + ", ".join(f"r{r} ×{k}" for r, k in sorted(d["sinpose_guia"].items())))
            if d["cong_guia"]:
                print(f"     guía con '✘ marcador CONGELADO': " + ", ".join(f"r{r} ×{k}" for r, k in sorted(d["cong_guia"].items())))
            print(f"     detenciones 'enviada a los 5' entre fin de colocación y '>>> EPISODIO': {d['det_col_a_res']}")
            n_det_ok[(res[0] if res else "—", d["det_col_a_res"])] += 1
            for n, t in extra.get(e, []):
                print(f"     [otro] l.{n}: {t}")
        print(f"   DETENCIONES por (resultado, n.º entre colocación y resultado): {dict(n_det_ok)}")
        cuenta = Counter()
        for d in eps.values():
            cuenta["colocaciones"] += len(d["cols"])
            cuenta["colocaciones repetidas (no quedan en CSV)"] += max(0, len(d["cols"]) - 1)
            cuenta["rechazos del chequeo"] += len(d["rech"])
            cuenta["fallos de envío (10054)"] += sum(1 for x in d["fallos"] if "10054" in x[2])
            cuenta["reconexiones"] += len(d["recon"])
            cuenta["detenciones no confirmadas"] += len(d["noconf"])
            cuenta["avisos de pose vieja"] += len(d["viejas"])
            cuenta["frenados por pose vencida"] += len(d["frena"])
            cuenta["retrocesos (inicio)"] += len(d["retro"])
            cuenta["líneas de guía 'SIN POSE'"] += sum(d["sinpose_guia"].values())
            for c in d["cols"]:
                for rob, motivo, t_ab, n in c["abandonos"]:
                    cuenta[f"abandonos '{motivo}'"] += 1
        print(f"   CONTEOS {s}: " + " · ".join(f"{k} {v}" for k, v in sorted(cuenta.items())))
    print()
    print("=" * 118)
    print("ABANDONOS DE COLOCACIÓN en las consolas (todas las colocaciones, incluidas las repetidas):")
    for k, v in sorted(resumen_ab.items()):
        print(f"   {k}: {v}")
    print("por sesión y robot:")
    for s, c in ab_por_robot.items():
        print(f"   {s}: " + ", ".join(f"r{r} {m}×{k}" for (r, m), k in sorted(c.items())))
    print("tabla (sesión, ep, colocación k de K, robot, motivo, clase, CSV valido):")
    for t in tabla_ab:
        print("   ", t)


if __name__ == "__main__":
    main()
