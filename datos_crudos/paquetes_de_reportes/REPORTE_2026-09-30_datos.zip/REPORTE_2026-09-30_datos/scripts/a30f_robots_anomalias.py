import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Tarea 5 (parte decisiones): anomalías por ROBOT en las 5 sesiones del 30-09 (+26-09), para
cruzar con lo que dicen las consolas:
  (a) SEGUIMIENTO: réplica del DetectorSeguimiento de la sesión (ventana 50 decisiones, recorrido /
      comandado, comandado = |v_ejecutada|·factor·0.1 s con factor 0.40 —0.10 en las 50 primeras
      decisiones del PRIMER intento de la sesión (rampa)—, 0 en retroceso, no se juzga si lo
      comandado < 0.10 m). dt nominal 0.1 s (el CSV no trae el dt real): aproximación.
  (b) PIVOTE: firma geométrica usada para el robot 6 el 26-09 — ventanas de 2 s (20 decisiones)
      con |giro medido| ≥ 90 °/s sobre un círculo de radio < 7 cm, sin retroceso.
  (c) POSE REPETIDA: inicios de racha (primera fila de un agente con (x,y,θ) EXACTAMENTE igual a
      la anterior del mismo agente en el mismo episodio), separando 'los 5 a la vez' (consulta
      fallida / caché: no es Motive) de los individuales, con la distancia al punto ciego del
      26-09 más cercano (A 2.54,2.20 · B 2.82,2.49 · C 2.52,2.79).
SOLO LECTURA. Uso: python -B a30f_robots_anomalias.py"""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import csv, math, os
from collections import Counter, defaultdict
import numpy as np
from a30f_robots_comun import SES, SES30, ROBOT, RS, leer_ep, d_pared

CIEGOS = {"A": (2.54, 2.20), "B": (2.82, 2.49), "C": (2.52, 2.79)}
VENT, UMBRAL, CMD_MIN = 50, 0.50, 0.10


def cargar(s):
    D = defaultdict(list)
    with open(os.path.join(RS, SES[s][1]), encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            D[(int(r["episodio"]), int(r["agente"]))].append(
                (int(r["paso"]), r["pose_env_x"], r["pose_env_y"], r["pose_env_th"], float(r["v_ejecutada"]),
                 int(r["en_retroceso"])))
    for k in D:
        D[k].sort()
    return D


def main():
    resumen = {}
    for s in SES30 + ["c26"]:
        E = {int(f["episodio"]): f for f in leer_ep(s)}
        primer_ep = min(E)
        D = cargar(s)
        seg = defaultdict(list)            # robot -> [(ep, valido, ratio)] de todas las ventanas juzgadas
        piv = Counter()
        piv_eps = defaultdict(set)
        rep = []                           # (ep, paso, agente, x, y, n_simultaneos)
        inicios_por_paso = defaultdict(list)
        for (ep, a), filas in D.items():
            paso = np.array([t[0] for t in filas])
            xy = np.array([[float(t[1]), float(t[2])] for t in filas])
            th = np.unwrap(np.array([float(t[3]) for t in filas]))
            v = np.array([t[4] for t in filas])
            ret = np.array([t[5] for t in filas])
            fac = np.where((ep == primer_ep) & (paso < 50), 0.10, 0.40)
            com = np.where(ret == 1, 0.0, np.abs(v) * fac * 0.1)
            av = np.r_[0.0, np.linalg.norm(np.diff(xy, axis=0), axis=1)]
            # ventanas de 50 como la cola del detector (el avance del paso k con el comandado del paso k)
            for k in range(VENT, len(filas)):
                c = com[k - VENT + 1:k + 1].sum()
                if c < CMD_MIN:
                    continue
                seg[ROBOT[a]].append((ep, E[ep]["valido"], av[k - VENT + 1:k + 1].sum() / c))
            # pivote geométrico
            for k in range(0, len(filas) - 20, 10):
                wm = math.degrees(th[k + 20] - th[k]) / 2.0
                if abs(wm) >= 90 and not ret[k:k + 21].any():
                    A = np.c_[2 * xy[k:k + 21, 0], 2 * xy[k:k + 21, 1], np.ones(21)]
                    cc, *_ = np.linalg.lstsq(A, (xy[k:k + 21] ** 2).sum(1), rcond=None)
                    r = math.sqrt(max(cc[2] + cc[0] ** 2 + cc[1] ** 2, 0))
                    if r < 0.07:
                        piv[ROBOT[a]] += 1
                        piv_eps[ROBOT[a]].add(ep)
            # repeticiones exactas
            for k in range(1, len(filas)):
                if filas[k][1:4] == filas[k - 1][1:4] and not (k >= 2 and filas[k - 1][1:4] == filas[k - 2][1:4]):
                    inicios_por_paso[(ep, filas[k][0])].append((a, float(filas[k][1]), float(filas[k][2])))
        for (ep, p), lst in inicios_por_paso.items():
            for a, x, y in lst:
                rep.append((ep, p, a, x, y, len(lst)))
        print("=" * 118)
        print(f"SESIÓN {s}")
        print("  (a) SEGUIMIENTO recorrido/comandado en ventanas de 50 decisiones (réplica del detector, dt nominal):")
        for rob in (1, 5, 8, 6, 9):
            w = seg[rob]
            wv = [r for ep, val, r in w if val == "1"]
            wi = [(ep, r) for ep, val, r in w if val != "1"]
            bajo = [(ep, round(r, 2)) for ep, val, r in w if r < UMBRAL]
            eps_bajo = sorted({ep for ep, _ in bajo})
            min_v = min(wv) if wv else float("nan")
            print(f"     r{rob}: ventanas {len(w)} (válidos {len(wv)}) · mediana válidos {np.median(wv):.3f} · p05 válidos "
                  f"{np.percentile(wv, 5):.3f} · mín válidos {min_v:.3f} · ventanas < 0.70 en válidos {sum(1 for r in wv if r < 0.70)} · "
                  f"< 0.50 (dispararía) en episodios {eps_bajo or '—'}")
        print("  (b) PIVOTE (≥ 90 °/s sobre círculo r < 7 cm, 2 s, sin retroceso): " +
              (", ".join(f"r{r} {n} ventanas en eps {sorted(piv_eps[r])}" for r, n in sorted(piv.items())) or "ninguno"))
        rep5 = [x for x in rep if x[5] >= 5]
        rep1 = [x for x in rep if x[5] < 5]
        print(f"  (c) POSE REPETIDA — inicios de racha: {len(rep)}; 'los 5 a la vez' (misma decisión): {len(rep5)//5 if rep5 else 0} decisiones "
              f"({sorted({(ep, p) for ep, p, *_ in rep5})}); individuales: {len(rep1)}")
        for ep, p, a, x, y, n in sorted(rep1):
            dc = min((math.hypot(x - cx, y - cy), k) for k, (cx, cy) in CIEGOS.items())
            print(f"       ep {ep:>2} paso {p:>3} r{ROBOT[a]} en ({x:.2f},{y:.2f}) d_pared {d_pared(x, y):.2f} · punto ciego más cercano "
                  f"{dc[1]} a {dc[0]:.2f} m · simultáneos en esa decisión: {n} · episodio {'válido' if E[ep]['valido']=='1' else 'INVÁLIDO'}")
        resumen[s] = (seg, piv, rep1, rep5)
    print()
    print("=" * 118)
    print("RESUMEN POR ROBOT (30-09, 5 sesiones): mín del seguimiento en válidos · inicios de repetición individuales · pivotes")
    for rob in (1, 5, 8, 6, 9):
        mins = {s: min([r for ep, val, r in resumen[s][0][rob] if val == "1"]) for s in SES30}
        reps = {s: sum(1 for ep, p, a, x, y, n in resumen[s][2] if ROBOT[a] == rob) for s in SES30}
        pv = {s: resumen[s][1][rob] for s in SES30}
        print(f"   r{rob}: seguimiento mín válidos " + " ".join(f"{s}={v:.2f}" for s, v in mins.items()) +
              " | repeticiones individuales " + " ".join(f"{s}={v}" for s, v in reps.items()) +
              " | pivotes " + " ".join(f"{s}={v}" for s, v in pv.items()))


if __name__ == "__main__":
    main()
