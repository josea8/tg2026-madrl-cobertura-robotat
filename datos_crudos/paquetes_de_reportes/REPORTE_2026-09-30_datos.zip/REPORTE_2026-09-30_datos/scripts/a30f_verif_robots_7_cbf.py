import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): A11/A12 — bloqueo mutuo del CBF robot-robot en la colocación.
Chequeos PROPIOS (no reuso el script del analista; sí uso la ley y el filtro REALES de
colocacion_autonoma, que son el objeto bajo prueba, importados sin bytecode y sin torch):
  (1) prueba geométrica independiente: distancia al punto de mira vecino más cercano en x0 para
      TODOS los robots de todos los intentos; ¿los 'no avanza' se agolpan en D_ROBOTS=0.25 y los
      'listo' no? (un robot trabado por la base quedaría a cualquier distancia);
  (2) comando filtrado en x0 y si cae bajo la zona muerta (|v|<V_MIN y |ω|<W_MIN);
  (3) simulación propia (uniciclo, dt=0.1, 12 s = S_SIN_PROGRESO) moviendo a los no-listo, con y
      sin zona muerta; progreso = mejora > MEJORA_MINIMA de la métrica del código;
  (4) robustez: 30 perturbaciones de x0 (σ 5 mm, 2°) por episodio: fracción que sigue trabada;
  (5) signos de ω del r9 en s2 ep5 (¿'oscila'?).
SOLO LECTURA."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import csv, os, math, warnings
from collections import defaultdict
import numpy as np
import colocacion_autonoma as ca
assert "torch" not in sys.modules
warnings.simplefilter("ignore")

D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
EPI = {"s1": "20260930_sesion-evaluacion_etapa7_episodios.csv", "s2": "20260930_sesion-evaluacion_etapa7_episodios_02.csv",
       "s3": "20260930_sesion-evaluacion_etapa7_episodios_03.csv", "s4": "20260930_sesion-evaluacion_etapa7_episodios_04.csv",
       "s5": "20260930_sesion-evaluacion_etapa7_episodios_05.csv", "c26": "20260926_sesion-evaluacion_etapa7_episodios.csv"}
ROB = [1, 5, 8, 6, 9]
FIL = ca.FiltroColocacion()
out = []
P = out.append


def mira(p):
    return np.array([p[0] + ca.ELE_A * math.cos(p[2]), p[1] + ca.ELE_A * math.sin(p[2])])


def env(a):
    return math.atan2(math.sin(a), math.cos(a))


def metrica(p, b, rumbo, llego):
    if llego:
        return 0.1 * abs(env(rumbo - p[2]))
    return math.hypot(b[0] - p[0], b[1] - p[1]) + 0.1 * abs(env(math.atan2(b[1] - p[1], b[0] - p[0]) - p[2]))


def comando(a, poses, b, rumbo, llego):
    u_nom, fase = ca.ley_nominal(poses[a], b, rumbo, llego)
    if fase == "listo":
        return np.zeros(2), fase, u_nom, None
    r = FIL.filtrar(poses[a], np.array(u_nom), FIL.barreras_robots(a, poses))
    return (r.u_seguro if r.exito_qp else np.zeros(2)), fase, u_nom, r


def sim(poses0, bl, ru, mover, zm, T=12.0, dt=0.1, traza=None):
    poses = {k: v.copy() for k, v in poses0.items()}
    llego = {k: np.hypot(*(bl[k] - poses[k][:2])) <= ca.TOL_LLEGADA_M for k in poses}
    m0 = {k: metrica(poses[k], bl[k], ru[k], llego[k]) for k in mover}
    t_prog = {k: None for k in mover}
    for n in range(int(round(T / dt))):
        u = {}
        for k in mover:
            d = np.hypot(*(bl[k] - poses[k][:2]))
            if d <= ca.TOL_LLEGADA_M:
                llego[k] = True
            elif d > ca.TOL_SALIDA_M:
                llego[k] = False
            c, fase, _, _ = comando(k, poses, bl[k], ru[k], llego[k])
            if zm and abs(c[0]) < ca.V_MIN and abs(c[1]) < ca.W_MIN:
                c = np.zeros(2)
            u[k] = c
            if traza is not None and k == traza[0]:
                traza[1].append(float(c[1]))
        for k, c in u.items():
            x, y, th = poses[k]
            poses[k] = np.array([x + c[0] * math.cos(th) * dt, y + c[0] * math.sin(th) * dt, env(th + c[1] * dt)])
            if t_prog[k] is None and metrica(poses[k], bl[k], ru[k], llego[k]) < m0[k] - ca.MEJORA_MINIMA:
                t_prog[k] = (n + 1) * dt
    dfin = {k: float(np.hypot(*(bl[k] - poses[k][:2]))) for k in mover}
    return t_prog, dfin


rng = np.random.default_rng(12345)
geo = defaultdict(list)          # estado -> distancias al punto de mira más cercano
resumen = []
porsem = defaultdict(list)
for s, a in EPI.items():
    with open(os.path.join(D, a), encoding="utf-8", newline="") as fh:
        F = list(csv.DictReader(fh))
    for r in F:
        ep = int(r["episodio"])
        poses = {i: np.array([float(r[f"x0_a{i}"]), float(r[f"y0_a{i}"]), float(r[f"th0_a{i}"])]) for i in range(5)}
        bl = {i: np.array([float(r[f"blanco_x_a{i}"]), float(r[f"blanco_y_a{i}"])]) for i in range(5)}
        ru = {i: float(r[f"blanco_th_a{i}"]) for i in range(5)}
        est = {i: r[f"col_estado_a{i}"].strip() for i in range(5)}
        pm = {i: mira(poses[i]) for i in range(5)}
        for i in range(5):
            dmin = min(np.hypot(*(pm[i] - pm[j])) for j in range(5) if j != i)
            geo[(s == "c26", est[i])].append(dmin)
        na = [i for i in range(5) if est[i] == "no avanza"]
        porsem[int(r["semilla"])].append((s, ep, [ROB[i] for i in na]))
        if not na:
            continue
        mover = [i for i in range(5) if est[i] != "listo"]
        tz, dz = sim(poses, bl, ru, mover, True)
        ts_, ds = sim(poses, bl, ru, mover, False)
        # robustez
        trab = defaultdict(int)
        for _ in range(30):
            pp = {i: poses[i] + np.array([rng.normal(0, 0.005), rng.normal(0, 0.005), rng.normal(0, math.radians(2))]) for i in range(5)}
            tp, _ = sim(pp, bl, ru, mover, True)
            for i in na:
                trab[i] += tp[i] is None
        P(f"{s} ep{ep} sem{r['semilla']} valido={r['valido']} estados={[ (ROB[i], est[i]) for i in range(5)]}")
        for i in na:
            c, fase, u_nom, res = comando(i, poses, bl[i], ru[i], False)
            vec = sorted((float(np.hypot(*(pm[i] - pm[j]))), ROB[j], est[j]) for j in range(5) if j != i)
            bajo = abs(c[0]) < ca.V_MIN and abs(c[1]) < ca.W_MIN
            hrr = 0.5 * (vec[0][0] - ca.D_ROBOTS)
            P(f"   r{ROB[i]}: d_blanco={np.hypot(*(bl[i]-poses[i][:2])):.3f} fase={fase} u_nom=({u_nom[0]:+.3f},{u_nom[1]:+.3f}) u_filt=({c[0]:+.4f},{c[1]:+.4f}) "
              f"bajo_zona_muerta={bajo} barrera={res.barrera_activa if res else '-'} h_min={res.h_minima if res else float('nan'):+.4f} h_rr_crudo={hrr:+.4f} "
              f"vecinos_mira={[(round(d,3), rb, e) for d, rb, e in vec[:2]]}")
            P(f"        sim12s ZM: progreso_a={tz[i]} d_fin={dz[i]:.3f} | sin ZM: progreso_a={ts_[i]} d_fin={ds[i]:.3f} | trabado en {trab[i]}/30 perturbaciones (ZM)")
            clase = ("BLOQUEO CBF" if (res is not None and res.barrera_activa.startswith("robot") and vec[0][0] < ca.D_ROBOTS + 0.02 and tz[i] is None)
                     else ("barrera activa pero progresa" if (res is not None and res.barrera_activa.startswith("robot") and vec[0][0] < ca.D_ROBOTS + 0.02) else "NO CBF"))
            P(f"        -> {clase}")
            resumen.append((s, ep, ROB[i], clase, trab[i]))
        if s == "s2" and ep == 5:
            tr = (4, [])
            sim(poses, bl, ru, mover, True, traza=tr)
            w = np.array(tr[1])
            P(f"   s2 ep5 r9 ω simulado (ZM, 12 s): cambios de signo={int(np.sum(np.diff(np.sign(w[np.abs(w)>1e-6]))!=0))} "
              f"ω min={w.min():+.3f} max={w.max():+.3f} primeros 20={np.round(w[:20],2).tolist()}")

P("")
P("== (1) distancia al punto de mira más cercano en x0 ==")
for k in sorted(geo):
    v = np.array(geo[k])
    P(f"  {'26-09' if k[0] else '30-09'} estado={k[1]!r}: n={len(v)} en [0.245,0.255]: {int(np.sum((v>=0.245)&(v<=0.255)))} "
      f"min={v.min():.3f} mediana={np.median(v):.3f} max={v.max():.3f}")
P("== resumen de clases ==")
from collections import Counter
P(str(Counter((s == 'c26', c) for s, ep, rb, c, t in resumen)))
for x in resumen:
    P(f"  {x}")
P("== A12: 'no avanza' por semilla ==")
for sem in sorted(porsem):
    con = [(s, ep, rb) for s, ep, rb in porsem[sem] if rb]
    if con:
        sin = [(s, ep) for s, ep, rb in porsem[sem] if not rb]
        P(f"  {sem}: con={con} | sin={sin}")
open(os.path.join(r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad", "a30f_verif_robots_7_cbf_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
