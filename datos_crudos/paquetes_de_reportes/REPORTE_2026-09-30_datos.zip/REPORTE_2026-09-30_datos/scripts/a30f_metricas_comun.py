import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Utilidades comunes (SOLO LECTURA) del análisis a30f_metricas_: métricas del
hardware de las 5 sesiones del 30-09 (50 válidos) + control 26-09.
Reutiliza a26_superv_comun (lectura de CSV, d_pared, filas repetidas) sin
modificarlo. No lee ningún archivo de réplica (cegado)."""
import sys
sys.dont_write_bytecode = True
SP = (r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis"
      r"\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
sys.path.insert(0, SP)
import numpy as np
import pandas as pd
from scipy import stats
from a26_superv_comun import leer_ep, leer_dec, env_a_lab, RS  # noqa: F401

# sesión → (episodios, decisiones, orden temporal; 0 = control 26-09)
SES = {
    "26-09": ("20260926_sesion-evaluacion_etapa7_episodios.csv",
              "20260926_sesion-evaluacion_etapa7_decisiones.csv", 0),
    "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones.csv", 1),
    "S2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_02.csv", 2),
    "S3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_03.csv", 3),
    "S4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_04.csv", 4),
    "S5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_05.csv", 5),
}
S30 = ["S1", "S2", "S3", "S4", "S5"]
VALIDOS_ESPERADOS = {
    "S1": list(range(3, 13)),
    "S2": [1] + list(range(4, 13)),
    "S3": [1, 2] + list(range(4, 12)),
    "S4": list(range(1, 7)) + list(range(8, 12)),
    "S5": list(range(1, 6)) + list(range(7, 12)),
}
ROBOT = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
PTS_CIEGOS = {"A": (2.54, 2.20), "B": (2.82, 2.49), "C": (2.52, 2.79)}


def arreglos(s):
    """(pasos, 5, 3) de la tabla de decisiones de UN episodio."""
    s = s.sort_values(["paso", "agente"])
    n = s["paso"].nunique()
    assert len(s) == 5 * n, "faltan filas"
    return s[["pose_env_x", "pose_env_y", "pose_env_th"]].to_numpy().reshape(n, 5, 3)


def dist_pares(P):
    """(pasos, 10) distancias centro a centro de los 10 pares; y los índices."""
    iu = np.triu_indices(5, 1)
    d = np.linalg.norm(P[:, :, None, :2] - P[:, None, :, :2], axis=-1)
    return d[:, iu[0], iu[1]], iu


def icc1(df, y, g="semilla"):
    """ICC(1) de una vía NO balanceada (estimador ANOVA, n0 corregido).
    IC95 aproximado con la fórmula balanceada usando n0 (declarado aprox.)."""
    gr = df.groupby(g)[y]
    k = gr.size().to_numpy().astype(float)
    a = len(k)
    N = k.sum()
    mg = gr.mean().to_numpy()
    m = df[y].mean()
    ssb = float((k * (mg - m) ** 2).sum())
    ssw = float(((df[y] - df[g].map(gr.mean())) ** 2).sum())
    msb, msw = ssb / (a - 1), ssw / (N - a)
    n0 = (N - (k ** 2).sum() / N) / (a - 1)
    s2b_raw = (msb - msw) / n0
    s2b = max(s2b_raw, 0.0)
    icc = s2b / (s2b + msw) if (s2b + msw) > 0 else np.nan
    F = msb / msw if msw > 0 else np.inf
    p = stats.f.sf(F, a - 1, N - a)
    Fl = F / stats.f.ppf(0.975, a - 1, N - a)
    Fu = F * stats.f.ppf(0.975, N - a, a - 1)
    lo, hi = (Fl - 1) / (Fl + n0 - 1), (Fu - 1) / (Fu + n0 - 1)
    return dict(a=a, N=int(N), n0=n0, msb=msb, msw=msw, sd_dentro=np.sqrt(msw),
                s2b_raw=s2b_raw, sd_entre=np.sqrt(s2b), sd_total=df[y].std(ddof=1),
                icc=icc, F=F, p=p, lo=max(lo, -1.0), hi=min(hi, 1.0))


def ols(X, y):
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    r = y - X @ b
    return float(r @ r), b


def dummies(serie, drop_first=True):
    D = pd.get_dummies(serie.astype(str))
    cols = list(D.columns)
    D = D.to_numpy(float)
    return (D[:, 1:], cols) if drop_first else (D, cols)


def md_tabla(cab, filas):
    """Tabla markdown a partir de cabecera y filas (listas de str)."""
    out = ["| " + " | ".join(cab) + " |", "|" + "|".join("---" for _ in cab) + "|"]
    out += ["| " + " | ".join(str(c) for c in f) + " |" for f in filas]
    return "\n".join(out)
