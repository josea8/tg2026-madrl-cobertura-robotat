import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_verif_deriva_3_extras.py — VERIFICADOR ADVERSARIAL. SOLO LECTURA.
# Usa MI tabla por robot (a30f_verif_deriva_por_robot.csv, salida de a30f_verif_deriva_1_consola.py) para:
#  (1) umbral 0.05 m con aritmética decimal (la impresión tiene 2 decimales: 3−2.95 en float da 0.04999…);
#  (2) s1 k=1,2: ¿la 1.ª impresión es idéntica a la última pose registrada? (cota de redondeo √2·0.5 cm = 0.71 cm);
#  (3) diferencias robot a robot contra la tabla del analista (a30f_deriva_por_robot.csv): qué d2 le faltan;
#  (4) extra: distancia mínima entre robots en la 1.ª y 2.ª impresión (seguridad durante la deriva).
import csv, os, math, itertools
from decimal import Decimal
from collections import defaultdict
import numpy as np
S = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
out = []
def P(*a):
    s = " ".join(str(x) for x in a); out.append(s); print(s)
F = lambda v: None if v in ("", "None", None) else float(v)
mio = list(csv.DictReader(open(os.path.join(S, "a30f_verif_deriva_por_robot.csv"), encoding="utf-8")))
med = [r for r in mio if r["medible"] == "True"]

P("(1) d_pared en la 2.ª impresión, válidos pre-arreglo, con aritmética DECIMAL sobre las coordenadas impresas")
pre_v = [r for r in med if r["arreglo"] == "False" and r["tipo"] == "V" and F(r["x2"]) is not None]
def dpd(x, y):
    x, y = Decimal(str(x)), Decimal(str(y)); t = Decimal("3")
    return min(x, t - x, y, t - y)
vals = [(r["sesion"], int(r["k"]), int(r["robot"]), dpd(F(r["x2"]), F(r["y2"])), F(r["dp2"])) for r in pre_v]
P(f"  n medidas = {len(vals)}")
P(f"  float:   n(dp2<0.05) = {sum(1 for v in vals if v[4] < 0.05)}   n(dp2<0) = {sum(1 for v in vals if v[4] < 0)}")
P(f"  decimal: n(dp2<0.05) = {sum(1 for v in vals if v[3] < Decimal('0.05'))}   n(dp2==0.05) = {sum(1 for v in vals if v[3] == Decimal('0.05'))}   n(dp2<0) = {sum(1 for v in vals if v[3] < 0)}")
for v in sorted(vals, key=lambda v: v[3]):
    if v[3] <= Decimal("0.05"):
        P(f"     {v[0]:5s} k={v[1]:2d} robot {v[2]}  dp2 decimal {v[3]}  float {v[4]!r}")
for ses in ("26-09", "s1", "s2", "s3"):
    vv = [v for v in vals if v[0] == ses]
    P(f"  {ses}: float n<0.05={sum(1 for v in vv if v[4] < 0.05)}  decimal n<0.05={sum(1 for v in vv if v[3] < Decimal('0.05'))}  mín {min(v[3] for v in vv)}")

P("\n(2) s1 k=1,2 (pose en caché): d1 frente a la cota de redondeo 0.71 cm")
s1 = [r for r in med if r["sesion"] == "s1" and r["k"] in ("1", "2")]
for r in s1:
    P(f"  k={r['k']} robot {r['robot']}  racha_fin={r['racha_fin']}  d1={F(r['d1']):.2f}  d2={F(r['d2']):.2f}  |p2-p1|={F(r['d12']):.2f}  v_ult={F(r['v_ult']):.3f}")
P(f"  robots con d1 > 0.71 cm: {sum(1 for r in s1 if F(r['d1']) > 0.7072)} de {len(s1)}")

P("\n(3) Contra la tabla por robot del analista (a30f_deriva_por_robot.csv)")
ana = {(r["sesion"], r["k"], r["robot"]): r for r in csv.DictReader(open(os.path.join(S, "a30f_deriva_por_robot.csv"), encoding="utf-8"))}
dif = defaultdict(list)
for r in med:
    a = ana.get((r["sesion"], r["k"], r["robot"]))
    if a is None:
        dif["sin_fila_analista"].append((r["sesion"], r["k"], r["robot"])); continue
    for c_m, c_a in (("d1", "d1_cm"), ("d2", "d2_cm"), ("d12", "d12_cm")):
        vm, va = F(r[c_m]), F(a[c_a])
        if (vm is None) != (va is None) or (vm is not None and abs(vm - va) > 1e-6):
            dif[c_m].append((r["sesion"], int(r["k"]), int(r["robot"]), r["tipo"], r["cong_fin"], None if vm is None else round(vm, 2), None if va is None else round(va, 2)))
for c, l in dif.items():
    P(f"  campo {c}: {len(l)} diferencias")
    for x in l:
        P(f"     {x}")
P("  (formato: sesión, k, robot, tipo, cong_fin, MÍO, ANALISTA)")

P("\n(4) Distancia mínima entre pares de robots en las impresiones (cm), por grupo")
pos = defaultdict(dict)
for r in med:
    pos[(r["sesion"], int(r["k"]), r["tipo"], r["arreglo"])][int(r["robot"])] = (F(r.get("x1")), F(r.get("y1")), F(r.get("x2")), F(r.get("y2")))
def dmin(dic, i):
    pts = [(v[i], v[i + 1]) for v in dic.values() if v[i] is not None]
    return min(math.hypot(a[0] - b[0], a[1] - b[1]) for a, b in itertools.combinations(pts, 2)) * 100 if len(pts) > 1 else None
for nombre, filtro in (("PRE válidos", lambda k: k[3] == "False" and k[2] == "V"),
                       ("PRE abortados", lambda k: k[3] == "False" and k[2] == "A"),
                       ("s5 válidos", lambda k: k[3] == "True" and k[2] == "V")):
    ks = [k for k in pos if filtro(k)]
    m1 = [dmin(pos[k], 0) for k in ks]; m2 = [dmin(pos[k], 2) for k in ks]
    m1 = [x for x in m1 if x is not None]; m2 = [x for x in m2 if x is not None]
    P(f"  {nombre:14s} n_ep={len(ks):2d}  mín entre robots imp1 {min(m1):6.2f} cm  imp2 {min(m2) if m2 else float('nan'):6.2f} cm  "
      f"episodios con par <15 cm en imp2: {sum(1 for x in m2 if x < 15)}")
# distancia mínima entre robots en la ÚLTIMA pose registrada (mismos episodios) para comparar
dU = defaultdict(dict)
for r in med:
    dU[(r["sesion"], int(r["k"]), r["tipo"], r["arreglo"])][int(r["robot"])] = (F(r["x"]), F(r["y"]))
for nombre, filtro in (("PRE válidos", lambda k: k[3] == "False" and k[2] == "V"), ("s5 válidos", lambda k: k[3] == "True" and k[2] == "V")):
    ks = [k for k in dU if filtro(k)]
    mm = [min(math.hypot(a[0] - b[0], a[1] - b[1]) for a, b in itertools.combinations(dU[k].values(), 2)) * 100 for k in ks]
    P(f"  {nombre:14s} mín entre robots en la ÚLTIMA pose registrada: {min(mm):.2f} cm")
open(os.path.join(S, "a30f_verif_deriva_3_extras_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
