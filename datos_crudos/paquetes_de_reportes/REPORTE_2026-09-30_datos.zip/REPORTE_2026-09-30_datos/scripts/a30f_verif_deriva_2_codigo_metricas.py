import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_verif_deriva_2_codigo_metricas.py — VERIFICADOR ADVERSARIAL (desde cero). SOLO LECTURA.
# (a) diff respaldo preDetencion vs vigente con difflib.ndiff (línea a línea) y ubicación de detener_todo en ambos;
# (b) fechas: mtime y fecha de CREACIÓN (st_birthtime) de código, respaldo, pruebas, pyc y CSV;
# (c) descriptivo de duracion_s, decisiones, ciclo_p95_ms (válidos) s5 vs s1–s4, DE ddof=1.
import os, re, csv, difflib, datetime, struct
import numpy as np

C = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
R = os.path.join(C, "resultados_sesion")
S = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
out = []
def P(*a):
    s = " ".join(str(x) for x in a); out.append(s); print(s)
def ts(t):
    return datetime.datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

P("=" * 100); P("(a) DIFF sesion_robotat_respaldo_20260930_preDetencion.py → sesion_robotat.py"); P("=" * 100)
A = open(os.path.join(C, "sesion_robotat_respaldo_20260930_preDetencion.py"), encoding="utf-8").read().splitlines()
B = open(os.path.join(C, "sesion_robotat.py"), encoding="utf-8").read().splitlines()
sm = difflib.SequenceMatcher(a=A, b=B, autojunk=False)
mas = menos = 0
for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == "equal": continue
    menos += i2 - i1; mas += j2 - j1
    P(f"  {tag}: respaldo líneas {i1+1}-{i2}  → vigente líneas {j1+1}-{j2}")
    for l in A[i1:i2]: P(f"     - {l}")
    for l in B[j1:j2]: P(f"     + {l}")
P(f"  total: +{mas} / -{menos} líneas;  respaldo {len(A)} líneas, vigente {len(B)}")
def ubic(L, nombre):
    i0 = next(i for i, l in enumerate(L) if l.startswith("def _correr_episodio"))
    i1 = next(i for i in range(i0 + 1, len(L)) if L[i].startswith("def "))
    P(f"  [{nombre}] _correr_episodio líneas {i0+1}-{i1}")
    for i in range(i0, i1):
        l = L[i]
        if re.search(r"detener_todo|gestor\.cerrar_todos|^\s+tramo = |^\s+cob = |^\s+duracion = |^\s+return \{|\"duracion_s\"|\"decisiones\":|\"ciclo_p95_ms\"|if abortado:|print\(f\"  ⛔", l):
            P(f"     {i+1:5d}: {l.rstrip()}")
ubic(A, "respaldo"); ubic(B, "vigente")

P("\n" + "=" * 100); P("(b) FECHAS (mtime = última modificación; birth = creación del archivo en este disco)"); P("=" * 100)
arch = ["sesion_robotat.py", "sesion_robotat_respaldo_20260930_preDetencion.py", "test_sesion_robotat.py",
        "test_sesion_robotat_respaldo_20260930_preDetencion.py", "adaptadores_robotat.py", "colocacion_autonoma.py",
        "lanzar_robotat.py", "coordinador_enjambre.py", "config_robotat.py", "configuracion.py",
        os.path.join("__pycache__", "sesion_robotat.cpython-313.pyc")]
for a in arch:
    p = os.path.join(C, a)
    if not os.path.exists(p):
        P(f"  {a:60s} NO EXISTE"); continue
    st = os.stat(p)
    bt = getattr(st, "st_birthtime", None)
    P(f"  {a:60s} mtime {ts(st.st_mtime)}  birth {ts(bt) if bt else '—'}  tamaño {st.st_size}")
# cabecera del pyc: magic(4) flags(4) mtime_fuente(4) tamaño_fuente(4)
pyc = os.path.join(C, "__pycache__", "sesion_robotat.cpython-313.pyc")
if os.path.exists(pyc):
    h = open(pyc, "rb").read(16)
    flags = struct.unpack("<I", h[4:8])[0]
    if flags == 0:
        mt, sz = struct.unpack("<II", h[8:16])
        P(f"  pyc compilado desde una fuente con mtime {ts(mt)} y tamaño {sz} B "
          f"(vigente {os.path.getsize(os.path.join(C, 'sesion_robotat.py'))} B, respaldo {os.path.getsize(os.path.join(C, 'sesion_robotat_respaldo_20260930_preDetencion.py'))} B)")
    else:
        P(f"  pyc con flags={flags} (hash-based), no trae mtime")
for suf in ("", "_02", "_03", "_04", "_05"):
    for tipo in ("episodios", "decisiones"):
        p = os.path.join(R, f"20260930_sesion-evaluacion_etapa7_{tipo}{suf}.csv")
        st = os.stat(p); bt = getattr(st, "st_birthtime", None)
        P(f"  {os.path.basename(p):60s} mtime {ts(st.st_mtime)}  birth {ts(bt) if bt else '—'}")
# otros .py modificados el 30-09 en la carpeta (sin tocar réplicas)
P("  .py de la carpeta del coordinador modificados el 2026-09-30:")
for f in sorted(os.listdir(C)):
    if f.endswith(".py"):
        m = os.path.getmtime(os.path.join(C, f))
        if datetime.datetime.fromtimestamp(m).date() == datetime.date(2026, 9, 30):
            P(f"     {f}  {ts(m)}")

P("\n" + "=" * 100); P("(c) DESCRIPTIVO (válidos). DE con ddof=1"); P("=" * 100)
SES = {"s1": "", "s2": "_02", "s3": "_03", "s4": "_04", "s5": "_05"}
D = {}
for k, suf in SES.items():
    with open(os.path.join(R, f"20260930_sesion-evaluacion_etapa7_episodios{suf}.csv"), encoding="utf-8", newline="") as fh:
        D[k] = [r for r in csv.DictReader(fh) if r["valido"] == "1"]
def d(v):
    v = np.array(v, dtype=float)
    return f"n={len(v):2d} mediana {np.median(v):.4f} [{v.min():.4f}, {v.max():.4f}]  media {v.mean():.4f} ± {v.std(ddof=1):.4f}"
for campo in ("duracion_s", "decisiones", "ciclo_p95_ms"):
    P(f"-- {campo}")
    for k in SES:
        P(f"   {k:6s} {d([float(r[campo]) for r in D[k]])}")
    P(f"   s1–s4  {d([float(r[campo]) for k in ('s1','s2','s3','s4') for r in D[k]])}")
P("-- duracion_s − 0.1·decisiones [ms]")
for k in SES:
    P(f"   {k:6s} {d([(float(r['duracion_s']) - 0.1*float(r['decisiones']))*1000 for r in D[k]])}")
P(f"   s1–s4  {d([(float(r['duracion_s']) - 0.1*float(r['decisiones']))*1000 for k in ('s1','s2','s3','s4') for r in D[k]])}")
open(os.path.join(S, "a30f_verif_deriva_2_codigo_metricas_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
