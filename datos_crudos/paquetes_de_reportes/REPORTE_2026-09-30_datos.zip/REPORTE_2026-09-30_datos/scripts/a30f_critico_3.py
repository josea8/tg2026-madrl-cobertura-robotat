import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico (3): ¿la diferencia 26-09 → 30-09 en pared/escape es la 'trampa' de r5 en la esquina (3, 0)?
SOLO LECTURA; sin réplica. Uso: python -B a30f_critico_3.py > a30f_critico_3_salida.txt"""
import sys
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SES = {
    "26-09": ("20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
    "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv"),
    "S2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv", "20260930_sesion-evaluacion_etapa7_decisiones_02.csv"),
    "S3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv", "20260930_sesion-evaluacion_etapa7_decisiones_03.csv"),
    "S4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv", "20260930_sesion-evaluacion_etapa7_decisiones_04.csv"),
    "S5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv", "20260930_sesion-evaluacion_etapa7_decisiones_05.csv"),
}
S30 = ["S1", "S2", "S3", "S4", "S5"]
P = np.array([2.73, 0.11])      # punto de los mínimos de r5 (a30f_critico_2_salida.txt)
RAD = 0.30
E, DV = {}, []
for s, (fe, fd) in SES.items():
    e = pd.read_csv(f"{RS}\\{fe}"); e["ses"] = s; E[s] = e
    d = pd.read_csv(f"{RS}\\{fd}"); d["ses"] = s
    d = d[d.episodio.isin(set(e[e.valido == 1].episodio))].sort_values(["episodio", "agente", "paso"])
    x, y = d.pose_env_x.to_numpy(), d.pose_env_y.to_numpy()
    d["dp"] = np.minimum.reduce([x, 3 - x, y, 3 - y])
    d["cerca"] = np.hypot(x - P[0], y - P[1]) < RAD
    DV.append(d)
DV = pd.concat(DV, ignore_index=True)
DV["dia"] = np.where(DV.ses == "26-09", "26-09", "30-09")
EP = pd.concat(E.values(), ignore_index=True)
V = EP[EP.valido == 1].copy()
V["dia"] = np.where(V.ses == "26-09", "26-09", "30-09")

# activaciones de escape (0→1) por agente, con su lugar
act = []
for (s, ep, a), g in DV.groupby(["ses", "episodio", "agente"]):
    e_ = g.en_escape.to_numpy()
    idx = np.where(np.r_[e_[0] == 1, (e_[1:] == 1) & (e_[:-1] == 0)])[0]
    for i in idx:
        act.append(dict(dia="26-09" if s == "26-09" else "30-09", ses=s, ep=int(ep), robot=int(g.robot.iloc[0]),
                        cerca=bool(g.cerca.iloc[i]), x=g.pose_env_x.iloc[i], y=g.pose_env_y.iloc[i]))
A = pd.DataFrame(act)
print("=== Activaciones de escape (0→1), válidos ===")
for dia, n_ep in (("26-09", 10), ("30-09", 50)):
    z = A[A.dia == dia]
    print(f"  {dia}: total {len(z)} ({len(z) / n_ep:.2f}/episodio) · por robot " + "  ".join(
        f"r{k} {v}" for k, v in z.robot.value_counts().sort_index().items())
          + f" · a <{RAD} m de (2.73, 0.11): {int(z.cerca.sum())} (r5 {int((z.cerca & (z.robot == 5)).sum())})")
    z5 = z[(z.robot == 5)]
    print(f"     r5: {len(z5)} activaciones, {int(z5.cerca.sum())} en ese punto")

print("\n=== Episodios en que r5 pasa por la esquina (≤0.30 m de (2.73, 0.11)) ===")
ep5 = DV[(DV.robot == 5) & DV.cerca].groupby(["ses", "episodio"]).size()
for dia, sl, n_ep in (("26-09", ["26-09"], 10), ("30-09", S30, 50)):
    k = sum(1 for (s, e) in ep5.index if s in sl)
    print(f"  {dia}: {k}/{n_ep} episodios · filas {int(sum(v for (s, e), v in ep5.items() if s in sl))}")
k30 = sum(1 for (s, e) in ep5.index if s in S30); k26 = sum(1 for (s, e) in ep5.index if s == "26-09")
print(f"  Fisher {k30}/50 vs {k26}/10: p {stats.fisher_exact([[k30, 50 - k30], [k26, 10 - k26]]).pvalue:.3f}")
v26 = V[V.dia == "26-09"]
comp = sorted(set(v26.semilla) & set(V[V.dia == "30-09"].semilla))
for s_ in comp:
    eps30 = V[(V.dia == "30-09") & (V.semilla == s_)][["ses", "episodio"]].itertuples(index=False)
    eps30 = list(eps30)
    k = sum(1 for t in eps30 if (t.ses, t.episodio) in ep5.index)
    ep26 = int(v26[v26.semilla == s_].episodio.iloc[0])
    print(f"   semilla {s_}: 30-09 {k}/{len(eps30)} episodios con r5 en la esquina · 26-09 ep{ep26}: {'sí' if ('26-09', ep26) in ep5.index else 'no'}")

print("\n=== ¿La diferencia de día en d_pared_min y escape desaparece sin r5? (por episodio, válidos) ===")
rows = []
for (s, ep), g in DV.groupby(["ses", "episodio"]):
    sem = int(V[(V.ses == s) & (V.episodio == ep)].semilla.iloc[0])
    sin5 = g[g.robot != 5]
    a_ep = A[(A.ses == s) & (A.ep == ep)]
    rows.append(dict(ses=s, ep=ep, semilla=sem, dia30=int(s != "26-09"), dpmin=g.dp.min(), dpmin_sin5=sin5.dp.min(),
                     f018=(g.dp < 0.18).mean(), f018_sin5=(sin5.dp < 0.18).mean(),
                     act=len(a_ep), act_sin5=int((a_ep.robot != 5).sum()),
                     cbf=g.cbf_intervino.mean(), cbf_sin5=sin5.cbf_intervino.mean()))
T = pd.DataFrame(rows)


def fe(df, y):
    X = np.column_stack([np.ones(len(df)), df.dia30] + list(pd.get_dummies(df.semilla.astype(str), drop_first=True).to_numpy(float).T))
    yv = df[y].to_numpy(float)
    b, *_ = np.linalg.lstsq(X, yv, rcond=None)
    r = yv - X @ b; gl = len(yv) - np.linalg.matrix_rank(X)
    se = np.sqrt(np.diag(np.linalg.pinv(X.T @ X)) * (r @ r / gl))
    q = stats.t.ppf(.975, gl)
    return b[1], b[1] - q * se[1], b[1] + q * se[1], 2 * stats.t.sf(abs(b[1] / se[1]), gl)


for y in ("dpmin", "dpmin_sin5", "f018", "f018_sin5", "act", "act_sin5", "cbf", "cbf_sin5"):
    c = T[T.dia30 == 1][y].mean() - T[T.dia30 == 0][y].mean()
    b, lo, hi, p = fe(T, y)
    difs = []
    for s_ in comp:
        difs.append(T[(T.dia30 == 1) & (T.semilla == s_)][y].mean() - float(T[(T.dia30 == 0) & (T.semilla == s_)][y].iloc[0]))
    print(f"  {y:11s} cruda {c:+.4f} · ajustada semilla {b:+.4f} [{lo:+.4f}, {hi:+.4f}] p {p:.3f} · pareada 5 semillas "
          + " ".join(f"{d_:+.3f}" for d_ in difs))

print("\n=== Cobertura de los episodios con / sin r5 en la esquina (30-09, ajustado semilla) ===")
V30 = V[V.dia == "30-09"].copy()
V30["r5esq"] = [int((r.ses, r.episodio) in ep5.index) for _, r in V30.iterrows()]
X = np.column_stack([np.ones(len(V30)), V30.r5esq] + list(pd.get_dummies(V30.semilla.astype(str), drop_first=True).to_numpy(float).T))
yv = V30.cobertura_aoi.to_numpy(float)
b, *_ = np.linalg.lstsq(X, yv, rcond=None)
r = yv - X @ b; gl = len(yv) - np.linalg.matrix_rank(X)
se = np.sqrt(np.diag(np.linalg.pinv(X.T @ X)) * (r @ r / gl))
print(f"  con {int(V30.r5esq.sum())} ({V30[V30.r5esq == 1].cobertura_aoi.mean():.4f}) · sin {int((V30.r5esq == 0).sum())} "
      f"({V30[V30.r5esq == 0].cobertura_aoi.mean():.4f}) · ajustada {b[1]:+.4f} ± {se[1]:.4f} p {2 * stats.t.sf(abs(b[1] / se[1]), gl):.3f}")
# por sesión
print("  episodios con r5 en la esquina por sesión: " + "  ".join(
    f"{s} {int(V30[V30.ses == s].r5esq.sum())}/10" for s in S30))
# tiempo de r5 en la esquina (s) y pasos del primer ingreso
z = DV[(DV.dia == "30-09") & (DV.robot == 5) & DV.cerca]
t_ep = z.groupby(["ses", "episodio"]).size() * 0.1
pr = z.groupby(["ses", "episodio"]).paso.min()
print(f"  tiempo de r5 en la esquina por episodio: mediana {t_ep.median():.1f} s · rango {t_ep.min():.1f}–{t_ep.max():.1f} s · "
      f"primer paso ahí: mediana {int(pr.median())} (rango {int(pr.min())}–{int(pr.max())})")
