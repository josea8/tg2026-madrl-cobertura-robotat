import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""2) Heterogeneidad de la cobertura del hardware entre las 5 sesiones del 30-09
(ANOVA, Kruskal-Wallis, Levene/Brown-Forsythe; modelo aditivo semilla + sesión),
efecto del orden (tendencia S1→S5, cruda y ajustada por semilla) y S3 (réplica
en paralelo) / S5 (arreglo de detención) contra el resto (descriptivo con IC).
Proxy medido de 'estado del robot' por sesión: cociente recorrido medido /
recorrido comandado (batería/temperatura = HIPÓTESIS, no se miden).
Entrada: a30f_metricas_tabla.csv (de a30f_metricas_1_tabla.py) + decisiones."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import os
import datetime
import numpy as np
import pandas as pd
from scipy import stats
from a30f_metricas_comun import SES, S30, ROBOT, leer_dec, RS, ols, dummies, md_tabla, SP

pd.set_option("display.width", 220)
T = pd.read_csv(SP + r"\a30f_metricas_tabla.csv")
V = T[(T.valido == 1) & T.ses.isin(S30)].copy()
assert len(V) == 50
f4 = lambda v: f"{v:.4f}"

print("=== horas de fin de sesión (mtime del CSV de episodios, lectura con os.stat) ===")
for s in S30:
    t = os.stat(os.path.join(RS, SES[s][0])).st_mtime
    print(f"   {s}: {datetime.datetime.fromtimestamp(t).strftime('%H:%M:%S')} (hora local del PC)")

# ── 1-vía por sesión ────────────────────────────────────────────────────
g = [V[V.ses == s].cob.to_numpy() for s in S30]
f = stats.f_oneway(*g)
kw = stats.kruskal(*g)
lv = stats.levene(*g, center="mean")
bf = stats.levene(*g, center="median")
allc = np.concatenate(g)
ssb = sum(len(x) * (x.mean() - allc.mean()) ** 2 for x in g)
sst = ((allc - allc.mean()) ** 2).sum()
msw = (sst - ssb) / (len(allc) - 5)
omega2 = (ssb - 4 * msw) / (sst + msw)
print("\n=== ANOVA de 1 vía de la cobertura por sesión (válidos; ⚠ composición de semillas distinta por sesión) ===")
print(f"   medias {[round(x.mean(), 4) for x in g]} · sd {[round(x.std(ddof=1), 4) for x in g]} · n {[len(x) for x in g]}")
print(f"   F(4,{len(allc) - 5}) = {f.statistic:.3f}  p = {f.pvalue:.4f} · η² = {ssb/sst:.4f} · ω² = {omega2:.4f}")
print(f"   Kruskal-Wallis H(4) = {kw.statistic:.3f}  p = {kw.pvalue:.4f}")
print(f"   Levene (media) p = {lv.pvalue:.4f} · Brown-Forsythe (mediana) p = {bf.pvalue:.4f}")
print(f"   rango de medias de sesión = {max(x.mean() for x in g) - min(x.mean() for x in g):.4f}")

print("\n   semillas presentes por sesión (válidos):")
for s in S30:
    ss = sorted(V[V.ses == s].semilla - 420000)
    falta = sorted(set(range(12)) - set(ss))
    print(f"   {s}: faltan semillas {[420000 + x for x in falta]}")


# ── modelo aditivo semilla + sesión ────────────────────────────────────
def aditivo(df, y, extra=None):
    """y ~ semilla + sesión (efectos fijos). SS tipo II por comparación de modelos."""
    S, _ = dummies(df.semilla)
    D, cols = dummies(df.ses)
    one = np.ones((len(df), 1))
    yy = df[y].to_numpy(float)
    ss_full, b = ols(np.hstack([one, S, D]), yy)
    ss_nos, _ = ols(np.hstack([one, D]), yy)
    ss_nod, _ = ols(np.hstack([one, S]), yy)
    gl_res = len(df) - (1 + S.shape[1] + D.shape[1])
    ms = ss_full / gl_res
    Fs = ((ss_nos - ss_full) / S.shape[1]) / ms
    Fd = ((ss_nod - ss_full) / D.shape[1]) / ms
    return dict(ss_tot=float(((yy - yy.mean()) ** 2).sum()), ss_sem=ss_nos - ss_full, gl_sem=S.shape[1],
                F_sem=Fs, p_sem=stats.f.sf(Fs, S.shape[1], gl_res), ss_ses=ss_nod - ss_full,
                gl_ses=D.shape[1], F_ses=Fd, p_ses=stats.f.sf(Fd, D.shape[1], gl_res),
                ss_res=ss_full, gl_res=gl_res, sd_res=np.sqrt(ms))


a = aditivo(V, "cob")
print("\n=== modelo aditivo cob ~ semilla + sesión (efectos fijos, SS tipo II) — 50 válidos ===")
print(f"   SS total {a['ss_tot']:.5f} · SS semilla {a['ss_sem']:.5f} (gl {a['gl_sem']}, F {a['F_sem']:.2f}, p {a['p_sem']:.4f})"
      f" · SS sesión {a['ss_ses']:.5f} (gl {a['gl_ses']}, F {a['F_ses']:.2f}, p {a['p_ses']:.4f})"
      f" · residuo {a['ss_res']:.5f} (gl {a['gl_res']}, sd {a['sd_res']:.4f})")
print(f"   fracción de la SS total: semilla {a['ss_sem']/a['ss_tot']:.3f} · sesión {a['ss_ses']/a['ss_tot']:.3f}")

# medias de sesión ajustadas por semilla (LS-means: predicción promediada sobre las 12 semillas)
S, cs = dummies(V.semilla, drop_first=False)
D, cd = dummies(V.ses, drop_first=False)
X = np.hstack([S, D[:, 1:]])
yy = V.cob.to_numpy()
ss, b = ols(X, yy)
gl = len(yy) - np.linalg.matrix_rank(X)
cov = ss / gl * np.linalg.pinv(X.T @ X)
tq = stats.t.ppf(0.975, gl)
print("\n   medias de sesión ajustadas por semilla (promedio sobre las 12 semillas) ± EE e IC95:")
L_base = np.r_[np.full(S.shape[1], 1 / S.shape[1]), np.zeros(D.shape[1] - 1)]
fil_ls = []
for j, s in enumerate(cd):
    L = L_base.copy()
    if j > 0:
        L[S.shape[1] + j - 1] = 1.0
    m = L @ b
    ee = np.sqrt(L @ cov @ L)
    cruda = V[V.ses == s].cob.mean()
    print(f"   {s}: cruda {cruda:.4f} · ajustada {m:.4f} ± {ee:.4f} IC95 [{m - tq*ee:.4f}, {m + tq*ee:.4f}]")
    fil_ls.append([s, f4(cruda), f4(m), f"[{m - tq*ee:.4f}, {m + tq*ee:.4f}]"])

# ── tendencia por orden de sesión ──────────────────────────────────────
print("\n=== TENDENCIA S1→S5 (orden = 1..5) ===")
o = V.orden.to_numpy(float)
rho = stats.spearmanr(o, yy)
lr = stats.linregress(o, yy)
tq48 = stats.t.ppf(0.975, len(yy) - 2)
print(f"   cruda: pendiente {lr.slope:+.5f}/sesión IC95 [{lr.slope - tq48*lr.stderr:+.5f}, {lr.slope + tq48*lr.stderr:+.5f}]"
      f" p {lr.pvalue:.4f} · Spearman ρ = {rho.statistic:+.3f} p {rho.pvalue:.4f}")
# Jonckheere–Terpstra (alternativa ordenada), por permutación
def jt(groups):
    s = 0.0
    for i in range(len(groups)):
        for j in range(i + 1, len(groups)):
            a_, b_ = groups[i][:, None], groups[j][None, :]
            s += (b_ > a_).sum() + 0.5 * (b_ == a_).sum()
    return s
rng = np.random.default_rng(20260930)
J0 = jt(g)
lab = V.ses.to_numpy()
cob = V.cob.to_numpy()
Jp = np.empty(20000)
for i in range(len(Jp)):
    pm = rng.permutation(cob)
    Jp[i] = jt([pm[lab == s] for s in S30])
EJ = Jp.mean()
p_jt = (np.abs(Jp - EJ) >= abs(J0 - EJ)).mean()
print(f"   Jonckheere-Terpstra J = {J0:.1f} (E[J] bajo H0 ≈ {EJ:.1f}) · p bilateral por permutación (20000) = {p_jt:.4f}")
# ajustada por semilla
S1_, _ = dummies(V.semilla)
X = np.hstack([np.ones((len(V), 1)), S1_, o[:, None]])
ss, b = ols(X, yy)
gl = len(yy) - X.shape[1]
cov = ss / gl * np.linalg.inv(X.T @ X)
ee = np.sqrt(cov[-1, -1])
tq = stats.t.ppf(0.975, gl)
p = 2 * stats.t.sf(abs(b[-1] / ee), gl)
print(f"   ajustada por semilla: pendiente {b[-1]:+.5f}/sesión ± {ee:.5f} IC95 [{b[-1]-tq*ee:+.5f}, {b[-1]+tq*ee:+.5f}] p {p:.4f} (gl {gl})")
print(f"   → cambio acumulado S1→S5 (4 pasos) ajustado: {4*b[-1]:+.4f} IC95 [{4*(b[-1]-tq*ee):+.4f}, {4*(b[-1]+tq*ee):+.4f}]")
# falta de ajuste de la recta (sesión como factor vs lineal), ajustado por semilla
ss_fac = a["ss_res"]
F_lof = ((ss - ss_fac) / 3) / (ss_fac / a["gl_res"])
print(f"   falta de ajuste lineal (sesión factor vs recta, ajustado por semilla): F(3,{a['gl_res']}) = {F_lof:.3f} p {stats.f.sf(F_lof, 3, a['gl_res']):.4f}")
print("   ⚠ dentro de una sesión el orden del episodio ES la semilla (semilla = 420000+ep−1 en todas):\n"
      "     el efecto del orden DENTRO de la sesión (descarga de batería durante la sesión) NO es identificable\n"
      "     por separado del escenario. Sólo el orden ENTRE sesiones lo es.")

# otras métricas: tendencia ajustada por semilla
print("\n   pendiente ajustada por semilla de otras métricas (por sesión):")
for k in ["dpmin", "cbf", "esc", "act", "vec", "drec_min", "dmin_par", "p95"]:
    yk = V[k].to_numpy(float)
    ssk, bk = ols(X, yk)
    covk = ssk / gl * np.linalg.inv(X.T @ X)
    eek = np.sqrt(covk[-1, -1])
    pk = 2 * stats.t.sf(abs(bk[-1] / eek), gl)
    print(f"   {k:9s} {bk[-1]:+9.5f} IC95 [{bk[-1]-tq*eek:+9.5f}, {bk[-1]+tq*eek:+9.5f}] p {pk:.4f}")

# ── S3 y S5 contra el resto ────────────────────────────────────────────
print("\n=== S3 (réplica simulada en paralelo en el mismo PC) y S5 (arreglo de detención) vs el resto ===")
fil_c = []
for s in ("S3", "S5"):
    for k, nom in (("cob", "cobertura"), ("p95", "ciclo p95 [ms]"), ("s100", "ciclos >100 ms"),
                   ("dpmin", "d_pared_min"), ("cbf", "frac_cbf"), ("esc", "n_escape"), ("drec_min", "dist_min_robot"),
                   ("col_t", "colocación t [s]"), ("col_err_med", "colocación err medio [m]"),
                   ("col_err_max", "colocación err máx [m]")):
        x = V[V.ses == s][k].to_numpy(float)
        r = V[V.ses != s][k].to_numpy(float)
        w = stats.ttest_ind(x, r, equal_var=False)
        ci = w.confidence_interval(0.95)
        # ajustada por semilla: y ~ semilla + 1{ses==s}
        ind = (V.ses == s).to_numpy(float)[:, None]
        Xs = np.hstack([np.ones((len(V), 1)), S1_, ind])
        yk = V[k].to_numpy(float)
        ssk, bk = ols(Xs, yk)
        glk = len(yk) - Xs.shape[1]
        eek = np.sqrt(ssk / glk * np.linalg.inv(Xs.T @ Xs)[-1, -1])
        tqk = stats.t.ppf(0.975, glk)
        print(f"   {s} {nom:26s} {x.mean():9.4f} vs resto {r.mean():9.4f} · dif {x.mean()-r.mean():+9.4f} "
              f"IC95 Welch [{ci.low:+.4f}, {ci.high:+.4f}] p {w.pvalue:.4f} · ajust. semilla {bk[-1]:+.4f} "
              f"[{bk[-1]-tqk*eek:+.4f}, {bk[-1]+tqk*eek:+.4f}]")
        if k in ("cob", "p95", "col_t", "col_err_med"):
            fil_c.append([s, nom, f4(x.mean()), f4(r.mean()), f"{x.mean()-r.mean():+.4f}",
                          f"[{ci.low:+.4f}, {ci.high:+.4f}]", f"{bk[-1]:+.4f} [{bk[-1]-tqk*eek:+.4f}, {bk[-1]+tqk*eek:+.4f}]"])
print("   Nota S5: el arreglo actúa DESPUÉS de cerrar las métricas; sólo puede influir en el episodio SIGUIENTE\n"
      "   (pose de partida para la colocación). Lo esperado a priori sobre la cobertura es ningún efecto.")

# colocación: robots fuera del blanco al arrancar y reintentos, por sesión (todos los intentos)
print("\n=== colocación por sesión (TODOS los intentos, válidos e inválidos) ===")
for s in S30:
    t = T[T.ses == s]
    print(f"   {s}: intentos {len(t)} · válidos {int(t.valido.sum())} · col_listos=5 en {int((t.col_listos == 5).sum())}"
          f" · t colocación med {t.col_t.median():.1f} s (máx {t.col_t.max():.1f}) · err máx med {t.col_err_max.median():.3f} m")

# ── proxy medido del estado del robot: recorrido medido / comandado ────
print("\n=== PROXY MEDIDO: cociente recorrido medido / recorrido comandado, por sesión y robot (válidos) ===")
print("   comandado = |v_ejecutada| × 0.40 × 0.1 s; se excluyen paso < 50 (arranque seguro), filas en retroceso,\n"
      "   filas con pose repetida y la fila siguiente a una repetida (salto tras congelamiento), y filas en escape.\n"
      "   ⚠ el marco env está escalado ×1.0167 respecto del lab: el nivel absoluto no importa, sí la comparación.")
FILAS = []
for s in ["26-09"] + S30:
    D = leer_dec(SES[s][1])
    eps = T[(T.ses == s) & (T.valido == 1)].ep.tolist()
    D = D[D.episodio.isin(eps)].sort_values(["episodio", "agente", "paso"]).copy()
    gr = D.groupby(["episodio", "agente"])
    D["dx"] = gr.pose_env_x.diff()
    D["dy"] = gr.pose_env_y.diff()
    D["rec"] = np.hypot(D.dx, D.dy)
    D["cmd"] = D.v_ejecutada.abs() * 0.40 * 0.1
    prev_rep = gr.repetida.shift(1).fillna(False).astype(bool)
    ok = ((D.paso >= 50) & (D.en_retroceso == 0) & ~D.repetida & ~prev_rep & (D.en_escape == 0)
          & D.rec.notna())
    Dk = D[ok]
    for ag in range(5):
        q = Dk[Dk.agente == ag]
        FILAS.append(dict(ses=s, robot=ROBOT[ag], ratio=q.rec.sum() / q.cmd.sum(), filas=len(q)))
    # por episodio (para IC por sesión)
    pe = Dk.groupby("episodio").apply(lambda q: q.rec.sum() / q.cmd.sum(), include_groups=False)
    FILAS.append(dict(ses=s, robot="todos", ratio=Dk.rec.sum() / Dk.cmd.sum(), filas=len(Dk),
                      ep_media=pe.mean(), ep_sd=pe.std(ddof=1)))
R = pd.DataFrame(FILAS)
piv = R[R.robot != "todos"].pivot(index="ses", columns="robot", values="ratio").reindex(["26-09"] + S30)
tod = R[R.robot == "todos"].set_index("ses").reindex(["26-09"] + S30)
piv["todos"] = tod.ratio
piv["ep_media±sd"] = [f"{m:.4f} ± {sdv:.4f}" for m, sdv in zip(tod.ep_media, tod.ep_sd)]
print(piv.to_string(float_format=lambda v: f"{v:.4f}"))
rr = R[(R.robot != "todos") & R.ses.isin(S30)].copy()
rr["o"] = rr.ses.str[1].astype(int)
print("   tendencia por robot S1→S5 (pendiente del cociente por sesión):")
for rb, q in rr.groupby("robot"):
    l_ = stats.linregress(q.o, q.ratio)
    print(f"   robot {rb}: {l_.slope:+.4f}/sesión (p {l_.pvalue:.3f}) · S1 {q.ratio.iloc[0]:.4f} → S5 {q.ratio.iloc[-1]:.4f}")
# correlación del cociente del episodio con la cobertura
print("   (el cociente es un proxy de seguimiento; que la batería lo explique es HIPÓTESIS)")

print("\n=== TABLA MARKDOWN 5 — heterogeneidad entre sesiones (cobertura, 50 válidos) ===")
print(md_tabla(["Prueba", "Estadístico", "p"], [
    ["ANOVA 1 vía (sesión)", f"F(4,45) = {f.statistic:.3f}; η² = {ssb/sst:.3f}", f"{f.pvalue:.3f}"],
    ["Kruskal-Wallis", f"H(4) = {kw.statistic:.3f}", f"{kw.pvalue:.3f}"],
    ["Levene / Brown-Forsythe (varianzas)", "—", f"{lv.pvalue:.3f} / {bf.pvalue:.3f}"],
    ["Aditivo semilla + sesión: término sesión", f"F({a['gl_ses']},{a['gl_res']}) = {a['F_ses']:.3f}", f"{a['p_ses']:.3f}"],
    ["Aditivo: término semilla", f"F({a['gl_sem']},{a['gl_res']}) = {a['F_sem']:.3f}", f"{a['p_sem']:.4f}"],
    ["Tendencia cruda (pendiente/sesión)", f"{lr.slope:+.4f} [{lr.slope - tq48*lr.stderr:+.4f}, {lr.slope + tq48*lr.stderr:+.4f}]", f"{lr.pvalue:.3f}"],
    ["Tendencia ajustada por semilla", f"{b[-1]:+.4f} [{b[-1]-tq*ee:+.4f}, {b[-1]+tq*ee:+.4f}]", f"{p:.3f}"],
    ["Jonckheere-Terpstra (permutación)", f"J = {J0:.1f}", f"{p_jt:.3f}"],
]))
print("\n=== TABLA MARKDOWN 6 — medias de sesión crudas y ajustadas por semilla ===")
print(md_tabla(["Sesión", "cruda", "ajustada por semilla", "IC95 ajustada"], fil_ls))
print("\n=== TABLA MARKDOWN 7 — S3 y S5 contra el resto (descriptivo) ===")
print(md_tabla(["Sesión", "Métrica", "sesión", "resto", "dif.", "IC95 Welch", "dif. ajust. semilla [IC95]"], fil_c))
