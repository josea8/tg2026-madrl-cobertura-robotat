#!/usr/bin/env python3
"""verificar_s7_robots.py — verificación INDEPENDIENTE de las cifras del §7 ("Robots, colocación y
ritmo del lazo") y de los ítems 6 y 7 del §1 (Resumen) de REPORTE_2026-09-30.md.

Autocontenido: Python 3 + numpy + scipy. Lee SÓLO csv/ y consola/ del paquete (rutas relativas a
este archivo). No importa nada del proyecto ni lee derivados/ (sólo los cita como fuente de las
cifras NO RECALCULABLES).

Salida: una línea por cifra
    id | descripción | valor en el reporte | recalculado | OK/FALLA
con tolerancia = media unidad del último decimal mostrado en el reporte. Las cifras que no salen de
csv/ ni consola/ se marcan "NO RECALCULABLE (fuente: …)". Las líneas "INFO | …" son contexto para
afirmaciones cualitativas y no se cuentan. Termina con "RESUMEN s7_robots: n ok, m fallas, k no
recalculables".

Definiciones usadas (las del encargo y las del propio reporte):
  · válido = columna 'valido' en ('1', 'True'); semilla = 420000 + ep − 1;
  · agentes 0..4 = robots 1, 5, 8, 6, 9; d_pared = min(x, 3−x, y, 3−y) en el marco env;
  · inicio de congelamiento = primera fila de un agente con (x, y, θ) idéntica a la fila anterior
    del mismo agente y episodio (comparación del texto del CSV);
  · desvíos con ddof = 1;
  · "punto de mira" de la colocación = centro + ℓa·(cos θ, sin θ), ℓa = 0.05 m (constante del
    código de colocación; el reporte compara contra D_ROBOTS = 0.25 m entre puntos de mira);
  · par mínimo = menor distancia entre centros en x0 (pose de arranque del episodio);
  · pivote = ventana de 2 s (21 decisiones, paso 10) con |Δθ|/2 s ≥ 90 °/s sobre un círculo de
    radio < 7 cm (ajuste algebraico), sin retroceso — la firma que el reporte usa para el r6 el 26-09;
  · "hipo" del lazo = dos consultas casi seguidas: en la decisión del inicio de congelamiento TODOS
    los agentes NO congelados avanzan ≤ 0.25 veces su paso mediano del episodio, y en la decisión
    anterior la mediana de los 5 agentes avanza ≥ 1.5 veces (una retención de Motive deja a los
    demás agentes avanzando ~1 vez lo normal);
  · diversidad: Monte Carlo propio del sorteo de COLOCACIÓN (uniforme en [0.45, 2.55]², separación
    > 0.45 m, 400 intentos por robot, rumbo uniforme), 1000 sesiones de referencia, generador
    numpy default_rng(0). Se valida contra los percentiles que imprimieron las consolas reales.
"""
import csv
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

try:
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
except Exception:  # pragma: no cover
    pass

BASE = Path(__file__).resolve().parent.parent
CSV = BASE / "csv"
CON = BASE / "consola"

SESIONES = ["s1", "s2", "s3", "s4", "s5"]
SUF = {"s1": "", "s2": "_02", "s3": "_03", "s4": "_04", "s5": "_05"}
CONSOLA = {"s1": "consola_20260930.txt", "s2": "consola_20260930_02.txt", "s3": "consola_20260930_03.txt",
           "s4": None, "s5": "consola_20260930_05.txt", "c26": "consola_20260926.txt"}
ROBOT = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
AG = {r: a for a, r in ROBOT.items()}
ELE_A = 0.05

# ----------------------------------------------------------------------------- conteo y formato
CUENTA = Counter()


def _tol(rep):
    r = rep.replace("−", "-").strip().lower()
    if "e" in r:
        man, ex = r.split("e")
        d = len(man.split(".")[1]) if "." in man else 0
        return 0.5 * 10 ** (-d) * 10 ** int(ex)
    d = len(r.split(".")[1]) if "." in r else 0
    return 0.5 * 10 ** (-d)


def num(i, desc, rep, val, fmt="{:.4f}"):
    """Cifra numérica: OK si |reporte − recalculado| ≤ media unidad del último decimal del reporte."""
    r = float(rep.replace("−", "-"))
    ok = abs(r - val) <= _tol(rep) * (1 + 1e-9) + 1e-15
    CUENTA["ok" if ok else "falla"] += 1
    print(f"{i} | {desc} | {rep} | {fmt.format(val)} | {'OK' if ok else 'FALLA'}")
    return ok


def cat(i, desc, rep, recal, ok):
    """Cifra/identificación categórica o afirmación con umbral (verdad booleana)."""
    CUENTA["ok" if ok else "falla"] += 1
    print(f"{i} | {desc} | {rep} | {recal} | {'OK' if ok else 'FALLA'}")
    return ok


def nr(i, desc, rep, fuente):
    CUENTA["nr"] += 1
    print(f"{i} | {desc} | {rep} | — | NO RECALCULABLE (fuente: {fuente})")


def info(txt):
    print(f"INFO | {txt}")


def cab(txt):
    print(f"== {txt}")


# ----------------------------------------------------------------------------- lectura
def leer(nombre):
    with open(CSV / nombre, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def es_valido(f):
    return str(f.get("valido", "")).strip() in ("1", "True")


def fl(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return float("nan")


EP = {s: leer(f"20260930_sesion-evaluacion_etapa7_episodios{SUF[s]}.csv") for s in SESIONES}
EP["c26"] = leer("20260926_sesion-evaluacion_etapa7_episodios.csv")
REP = {s: leer(f"20260930_sesion-replica_etapa7_capas-on_de-20260930{SUF[s]}.csv") for s in SESIONES}
REP26 = leer("20260926_sesion-replica_etapa7_capas-on_de-20260926.csv")
EP11 = leer("20260911_sesion-evaluacion_etapa7_episodios.csv")

for s, filas in EP.items():          # comprobaciones de las definiciones
    for f in filas:
        assert int(f["semilla"]) == 420000 + int(f["episodio"]) - 1, (s, f["episodio"])
        for a in range(5):
            assert int(f[f"robot_a{a}"]) == ROBOT[a], (s, f["episodio"], a)


def cargar_decisiones(nombre):
    """{(ep, agente): [(paso, x_txt, y_txt, th_txt, x, y, th, en_retroceso, en_escape)] ordenado}"""
    D = defaultdict(list)
    with open(CSV / nombre, encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            D[(int(r["episodio"]), int(r["agente"]))].append(
                (int(r["paso"]), r["pose_env_x"], r["pose_env_y"], r["pose_env_th"],
                 float(r["pose_env_x"]), float(r["pose_env_y"]), float(r["pose_env_th"]),
                 int(r["en_retroceso"]), int(r["en_escape"])))
    for k in D:
        D[k].sort()
    return D


DEC = {s: cargar_decisiones(f"20260930_sesion-evaluacion_etapa7_decisiones{SUF[s]}.csv") for s in SESIONES}
DEC["c26"] = cargar_decisiones("20260926_sesion-evaluacion_etapa7_decisiones.csv")


def x0(f, a):
    return np.array([fl(f[f"x0_a{a}"]), fl(f[f"y0_a{a}"]), fl(f[f"th0_a{a}"])])


def blanco(f, a):
    return np.array([fl(f[f"blanco_x_a{a}"]), fl(f[f"blanco_y_a{a}"]), fl(f[f"blanco_th_a{a}"])])


def d_blanco(f, a):
    return float(np.hypot(*(x0(f, a)[:2] - blanco(f, a)[:2])))


def mira(f, a):
    p = x0(f, a)
    return p[:2] + ELE_A * np.array([math.cos(p[2]), math.sin(p[2])])


def pares_centros(f):
    out = []
    for a in range(5):
        for b in range(a + 1, 5):
            out.append((float(np.hypot(*(x0(f, a)[:2] - x0(f, b)[:2]))), a, b))
    return sorted(out)


def d_pared(x, y):
    return min(x, 3.0 - x, y, 3.0 - y)


def validos(s):
    return [f for f in EP[s] if es_valido(f)]


V30 = [(s, f) for s in SESIONES for f in validos(s)]
assert len(V30) == 50

# =============================================================================== COLOCACIÓN
cab("§7 Colocación (colocación final de cada intento, columnas col_estado_a*)")
estados = Counter()
for s in SESIONES:
    for f in EP[s]:
        for a in range(5):
            estados[f[f"col_estado_a{a}"]] += 1
n_ri = sum(estados.values())
num("C01", "robot-intentos de colocación del 30-09 (57 intentos × 5)", "285", n_ri, "{:.0f}")
num("C02", "robot-intentos 'listo'", "266", estados["listo"], "{:.0f}")
num("C03", "robot-intentos 'no avanza'", "15", estados["no avanza"], "{:.0f}")
num("C04", "robot-intentos 'sin pose'", "4", estados["sin pose"], "{:.0f}")
sinpose = [(s, int(f["episodio"]), ROBOT[a]) for s in SESIONES for f in EP[s] for a in range(5)
           if f[f"col_estado_a{a}"] == "sin pose"]
eps_sp = sorted({(s, e) for s, e, _ in sinpose})
cat("C05", "los 4 'sin pose' son de s1 ep 2", "s1 ep 2", f"{eps_sp} robots {[r for *_, r in sinpose]}",
    eps_sp == [("s1", 2)] and len(sinpose) == 4)
# "los 4 a la vez": en la consola de s1, los 4 avisos "(sin pose)" van entre dos refrescos consecutivos de la guía
txt1 = (CON / CONSOLA["s1"]).read_text(encoding="utf-8").splitlines()
idx = [i for i, l in enumerate(txt1) if "queda para el operador (sin pose)" in l]
refrescos_entre = [l for l in txt1[min(idx):max(idx) + 1] if l.strip().startswith("[colocación")]
cat("C06", "los 4 'sin pose' de s1 ep 2 'a la vez' (avisos consecutivos en la consola, sin refresco entre ellos)",
    "4 a la vez", f"{len(idx)} avisos en líneas {[i + 1 for i in idx]}, refrescos intercalados {len(refrescos_entre)}",
    len(idx) == 4 and max(idx) - min(idx) == 3 and not refrescos_entre)
info("C04–C06: que el flujo de poses se cortara es hipótesis (el reporte lo dice); la consola sólo muestra los 4 avisos juntos entre 12 s y 15 s.")

# --- geometría del punto de mira
reg = []   # (s, ep, semilla, agente, estado, d_vecino, vecino, estado_vecino, valido)
for s in SESIONES:
    for f in EP[s]:
        for a in range(5):
            est = f[f"col_estado_a{a}"]
            if est not in ("listo", "no avanza"):
                continue
            ds = sorted((float(np.hypot(*(mira(f, a) - mira(f, b)))), b) for b in range(5) if b != a)
            dv, b = ds[0]
            reg.append((s, int(f["episodio"]), int(f["semilla"]), a, est, dv, b, f[f"col_estado_a{b}"], es_valido(f)))
VENT = (0.245, 0.255)
na = [r for r in reg if r[4] == "no avanza"]
li = [r for r in reg if r[4] == "listo"]
na_in = [r for r in na if VENT[0] <= r[5] <= VENT[1]]
li_in = [r for r in li if VENT[0] <= r[5] <= VENT[1]]
num("C07", "'no avanza' con el punto de mira del vecino más cercano en [0.245, 0.255] m (bloqueo CBF)", "14", len(na_in), "{:.0f}")
num("C08", "total de 'no avanza' (denominador del 14 de 15)", "15", len(na), "{:.0f}")
rng_in = (min(r[5] for r in na_in), max(r[5] for r in na_in))
cat("C09", "rango de la distancia entre puntos de mira de esos 14", "0.245–0.255",
    f"{rng_in[0]:.4f}–{rng_in[1]:.4f}", VENT[0] <= rng_in[0] and rng_in[1] <= VENT[1])
mutuos = [r for r in na_in if r[7] == "no avanza"]
quieto = [r for r in na_in if r[7] != "no avanza"]
num("C10", "de los 14: mutuos (el vecino trabado también es 'no avanza')", "13", len(mutuos), "{:.0f}")
num("C11", "de los 14: contra un robot quieto ('listo')", "1", len(quieto), "{:.0f}")
cat("C12", "el bloqueo contra robot quieto es s2 ep 5", "s2 ep 5",
    "; ".join(f"{r[0]} ep {r[1]} r{ROBOT[r[3]]} vs r{ROBOT[r[6]]} ({r[7]}) a {r[5]:.4f} m" for r in quieto),
    [(r[0], r[1]) for r in quieto] == [("s2", 5)])
num("C13", "'listo' con el punto de mira del vecino en [0.245, 0.255] m", "1", len(li_in), "{:.0f}")
num("C14", "denominador de 'listo' en esa comparación", "266", len(li), "{:.0f}")
info("C13: el único 'listo' en la ventana es " + "; ".join(
    f"{r[0]} ep {r[1]} r{ROBOT[r[3]]} (vecino r{ROBOT[r[6]]} a {r[5]:.4f} m)" for r in li_in)
     + " — es la contraparte del bloqueo de s2 ep 5, no un caso independiente.")
resto = [r for r in na if not (VENT[0] <= r[5] <= VENT[1])]
cat("C15", "el 'no avanza' restante (no CBF) es el r5 en s2 ep 3", "r5 s2 ep 3",
    "; ".join(f"{r[0]} ep {r[1]} r{ROBOT[r[3]]} (vecino a {r[5]:.3f} m)" for r in resto),
    [(r[0], r[1], ROBOT[r[3]]) for r in resto] == [("s2", 3, 5)])
nr("C16", "en la simulación con la ley y el filtro reales los 14 no progresan", "no progresan",
   "derivados/a30f_robots_bloqueo_cbf_salida.txt y a30f_verif_robots_7_cbf_salida.txt; requiere colocacion_autonoma del proyecto")
nr("C17", "para 7 de los 14 la no-progresión depende del supuesto de zona muerta", "7",
   "derivados/a30f_robots_bloqueo_cbf_salida.txt (sin zona muerta progresan s2 ep10 ×3, s2 ep12 ×2, s5 ep9 ×2)")
nr("C18", "D_ROBOTS (separación mínima entre puntos de mira del filtro de colocación)", "0.25",
   "constante de colocacion_autonoma; derivados/a30f_robots_bloqueo_cbf_salida.txt")
# --- no es propiedad de la semilla
bloq_por_sem = defaultdict(set)
for r in na_in:
    bloq_por_sem[r[2]].add(r[0])
max_ses = max(len(v) for v in bloq_por_sem.values())
cat("C19", "cada semilla con bloqueo CBF lo tuvo en una sola sesión del 30-09", "1 sesión por semilla",
    "; ".join(f"{k}: {sorted(v)}" for k, v in sorted(bloq_por_sem.items())), max_ses == 1)
otras_no55 = []
for sem, ses_b in bloq_por_sem.items():
    for s in SESIONES:
        if s in ses_b:
            continue
        for f in EP[s]:
            if int(f["semilla"]) == sem and any(f[f"col_estado_a{a}"] != "listo" for a in range(5)):
                otras_no55.append((sem, s, int(f["episodio"])))
cat("C20", "esas semillas colocaron 5/5 en las demás sesiones del 30-09", "5/5", f"excepciones: {otras_no55 or 'ninguna'}",
    not otras_no55)
c26_mismas = [(int(f["semilla"]), int(f["episodio"]), [ROBOT[a] for a in range(5) if f[f"col_estado_a{a}"] != "listo"])
              for f in EP["c26"] if int(f["semilla"]) in bloq_por_sem
              and any(f[f"col_estado_a{a}"] != "listo" for a in range(5))]
info(f"C20: el 26-09, con la misma semilla, no colocaron 5/5: {c26_mismas} (r6 'no avanza', que el reporte no "
     f"clasifica como CBF). 'En las demás' vale sólo para las sesiones del 30-09.")
na_s3 = sum(1 for r in na if r[0] == "s3")
na_s4 = sum(1 for r in na if r[0] == "s4")
num("C21", "'no avanza' en la s3", "0", na_s3, "{:.0f}")
num("C22", "'no avanza' en la s4", "0", na_s4, "{:.0f}")
# 'no avanza' en colocaciones repetidas que el CSV no guarda (consola)
rep_na = []
for s in ("s1", "s2", "s3", "s5"):
    t = (CON / CONSOLA[s]).read_text(encoding="utf-8").splitlines()
    ep, n_na = None, 0
    for l in t:
        m = re.match(r"^EPISODIO (\d+)", l)
        if m:
            ep = int(m.group(1))
        if "queda para el operador (no avanza)" in l:
            rep_na.append((s, ep, re.search(r"robot (\d+)", l).group(1)))
info(f"Consola: avisos 'no avanza' en todas las colocaciones (incluidas las repetidas): {len(rep_na)} "
     f"(s4 sin consola) contra 15 del CSV; el extra es {sorted(set(rep_na) - {(r[0], r[1], str(ROBOT[r[3]])) for r in na})} "
     f"(s2 ep 4, colocación repetida: el r5 averiado, no CBF).")

# =============================================================================== ARRANQUES
cab("§7 Arranques fuera del soporte")
fuera = []
for s, f in V30:
    nl = [a for a in range(5) if f[f"col_estado_a{a}"] != "listo"]
    pm = pares_centros(f)[0][0]
    if nl or pm < 0.31:
        fuera.append((s, f, nl, pm))
num("A01", "válidos con algún robot no 'listo' (arranques fuera del soporte)", "5", len(fuera), "{:.0f}")
n_rob = sum(len(x[2]) for x in fuera)
num("A02", "robots no 'listo' en esos 5", "11", n_rob, "{:.0f}")
dd = [d_blanco(f, a) for _, f, nl, _ in fuera for a in nl]
num("A03", "distancia mínima al blanco de esos 11 [m]", "0.44", min(dd))
num("A04", "distancia máxima al blanco de esos 11 [m]", "1.49", max(dd))
par_lt = sorted((s, int(f["episodio"])) for s, f in V30 if pares_centros(f)[0][0] < 0.31)
nl_set = sorted((s, int(f["episodio"])) for s, f, nl, _ in fuera if nl)
cat("A05", "son los únicos válidos con un par a < 0.31 m (mismo conjunto)", "los mismos 5",
    f"par<0.31: {par_lt}", par_lt == nl_set and len(par_lt) == 5)
otros_min = min(pares_centros(f)[0][0] for s, f in V30 if (s, int(f["episodio"])) not in par_lt)
info(f"A05: par mínimo de los otros 45 válidos = {otros_min:.3f} m.")
nr("A06", "0.31 m = mínimo del sorteo de entrenamiento (2·D_SAFE + 0.01)", "0.31",
   "código del entorno de entrenamiento; derivados/a30f_robots_colocacion_salida.txt")
TABLA = [("s1", 8, "420007", [("5", "0.89"), ("8", "0.44"), ("6", "0.83")], "0.233"),
         ("s2", 5, "420004", [("9", "0.80")], "0.286"),
         ("s2", 10, "420009", [("1", "0.94"), ("5", "1.18"), ("6", "0.61")], "0.237"),
         ("s2", 12, "420011", [("1", "0.56"), ("9", "1.19")], "0.278"),
         ("s5", 9, "420008", [("1", "0.55"), ("5", "1.49")], "0.275")]
for s, ep, sem, robs, par in TABLA:
    f = next(f for f in EP[s] if int(f["episodio"]) == ep)
    tag = f"{s} ep {ep}"
    num(f"A07.{tag}", f"{tag}: semilla", sem, int(f["semilla"]), "{:.0f}")
    nl_r = sorted(ROBOT[a] for a in range(5) if f[f"col_estado_a{a}"] != "listo")
    cat(f"A08.{tag}", f"{tag}: robots no 'listo'", ",".join(f"r{r}" for r, _ in robs),
        ",".join(f"r{r}" for r in nl_r), sorted(int(r) for r, _ in robs) == nl_r)
    for r, dist in robs:
        num(f"A09.{tag}.r{r}", f"{tag}: distancia al blanco del r{r} [m]", dist, d_blanco(f, AG[int(r)]))
    num(f"A10.{tag}", f"{tag}: par mínimo entre centros en x0 [m]", par, pares_centros(f)[0][0])
# chequeo de arranque de la sesión
pasa = []
for s, f, nl, pm in fuera:
    dpm = min(d_pared(*x0(f, a)[:2]) for a in range(5))
    pasa.append((s, int(f["episodio"]), round(pm, 3), round(dpm, 3), pm >= 0.15 and dpm >= 0.20))
cat("A11", "el chequeo de arranque (≥ 0.15 m entre robots, ≥ 0.20 m a la pared) deja pasar a los 5", "los deja pasar",
    "; ".join(f"{a} ep{b}: par {c}, pared {d}" for a, b, c, d, _ in pasa), all(p[4] for p in pasa))
nr("A12", "umbrales del chequeo de arranque de la sesión", "0.15 m / 0.20 m",
   "constantes de sesion_robotat.py; derivados/a30f_robots_colocacion_salida.txt")
err_rep = []
for s, f, nl, pm in fuera:
    ep = f["episodio"]
    err_rep += [fl(r["error_pose_inicial_m"]) for r in REP[s] if r["episodio"] == ep]
cat("A13", "la réplica de esos 5 arranca de la misma pose medida (error_pose_inicial_m)", "misma pose",
    f"máx {max(err_rep):.1e} m en {len(err_rep)} corridas", max(err_rep) < 1e-6)
cob_f = [fl(f["cobertura_aoi"]) for s, f, nl, pm in fuera]
cob_r = [fl(f["cobertura_aoi"]) for s, f in V30 if (s, int(f["episodio"])) not in set(nl_set)]
cbf_f = [fl(f["frac_cbf"]) for s, f, nl, pm in fuera]
cbf_r = [fl(f["frac_cbf"]) for s, f in V30 if (s, int(f["episodio"])) not in set(nl_set)]
num("A14", "cobertura hw media de los 5 fuera del soporte", "0.370", float(np.mean(cob_f)), "{:.5f}")
num("A15", "cobertura hw media de los otros 45", "0.342", float(np.mean(cob_r)), "{:.5f}")
num("A16", "frac_cbf media de los 5", "0.370", float(np.mean(cbf_f)), "{:.5f}")
num("A17", "frac_cbf media de los otros 45", "0.262", float(np.mean(cbf_r)), "{:.5f}")
info(f"A14–A17: Mann-Whitney cobertura p = {stats.mannwhitneyu(cob_f, cob_r, alternative='two-sided').pvalue:.2f}, "
     f"frac_cbf p = {stats.mannwhitneyu(cbf_f, cbf_r, alternative='two-sided').pvalue:.3f} (n = 5 contra 45; descriptivo).")

# =============================================================================== DIVERSIDAD
cab("§7 Diversidad (Monte Carlo propio del sorteo de colocación, validado contra las consolas)")
LO, HI, GR = 0.45, 2.55, 4
EST = [("celdas_cubiertas", "baja"), ("disp_centroide", "baja"), ("vecino_medio", "ambas"),
       ("resultante_rumbo", "alta"), ("ks_x", "alta"), ("ks_y", "alta")]


def sorteo(n, rng, sep=0.45, margen=0.45, arena=3.0):
    pts = []
    for _ in range(n):
        for _t in range(400):
            c = (rng.uniform(margen, arena - margen), rng.uniform(margen, arena - margen))
            if all(math.hypot(c[0] - p[0], c[1] - p[1]) > sep for p in pts):
                pts.append(c)
                break
        else:
            raise RuntimeError("sorteo imposible")
    return pts


def sesion_sorteada(n_ep, n_ag, rng, sep):
    out = []
    for _ in range(n_ep):
        p = sorteo(n_ag, rng, sep)
        th = rng.uniform(-math.pi, math.pi, size=n_ag)
        out.append(np.array([[p[i][0], p[i][1], th[i]] for i in range(n_ag)]))
    return out


def ks2(a, b):
    a, b = np.sort(a), np.sort(b)
    t = np.concatenate([a, b])
    return float(np.max(np.abs(np.searchsorted(a, t, "right") / len(a) - np.searchsorted(b, t, "right") / len(b))))


def estadisticos(eps, rx, ry):
    T = np.concatenate(eps)
    x, y, th = T[:, 0], T[:, 1], T[:, 2]
    cx = np.clip(((x - LO) / (HI - LO) * GR).astype(int), 0, GR - 1)
    cy = np.clip(((y - LO) / (HI - LO) * GR).astype(int), 0, GR - 1)
    cen = np.array([e[:, :2].mean(0) for e in eps])
    vec = []
    for e in eps:
        d = np.linalg.norm(e[:, None, :2] - e[None, :, :2], axis=2)
        np.fill_diagonal(d, np.inf)
        vec.extend(d.min(1))
    return {"celdas_cubiertas": len(set(zip(cx.tolist(), cy.tolist()))) / GR ** 2,
            "disp_centroide": float(cen.std(0).mean()), "vecino_medio": float(np.mean(vec)),
            "resultante_rumbo": float(abs(np.mean(np.exp(1j * th)))), "ks_x": ks2(x, rx), "ks_y": ks2(y, ry)}


def diversidad(eps, sep=0.45, semilla=0, nref=1000):
    rng = np.random.default_rng(semilla)
    g = np.concatenate(sesion_sorteada(400, eps[0].shape[0], rng, sep))
    v = estadisticos(eps, g[:, 0], g[:, 1])
    sims = [estadisticos(sesion_sorteada(len(eps), eps[0].shape[0], rng, sep), g[:, 0], g[:, 1]) for _ in range(nref)]
    pct, band = {}, []
    for k, cola in EST:
        d = np.array([sm[k] for sm in sims])
        p = 100 * (np.mean(d < v[k]) + 0.5 * np.mean(d == v[k]))
        pct[k] = p
        if (cola == "baja" and p < 5) or (cola == "alta" and p > 95) or (cola == "ambas" and (p < 2.5 or p > 97.5)):
            band.append(k)
    extremo = [k for k in band if pct[k] < 0.5 or pct[k] > 99.5]
    ver = "compatible" if not band else ("aviso" if len(band) == 1 and not extremo else "⚠ poco representativos")
    return v, pct, band, ver


def mat_x0(f):
    return np.array([x0(f, a) for a in range(5)])


def mat_bl(f):
    return np.array([blanco(f, a) for a in range(5)])


# (1) el sorteo de colocación (sep 0.45) reproduce los blancos del CSV desde la semilla
err_bl = 0.0
for s in SESIONES:
    for f in EP[s]:
        p = sorteo(5, np.random.default_rng(int(f["semilla"])))
        for a in range(5):
            err_bl = max(err_bl, abs(p[a][0] - fl(f[f"blanco_x_a{a}"])), abs(p[a][1] - fl(f[f"blanco_y_a{a}"])))
cat("D01", "el chequeo compara contra el sorteo de COLOCACIÓN, separación 0.45 m (reproduce los blancos del CSV desde la semilla)",
    "0.45", f"error máx {err_bl:.1e} m en 57 × 5 blancos", err_bl < 1e-4)


# (2) validación contra las consolas: percentiles impresos por el código real
def leer_div_consola(nombre):
    t = (CON / nombre).read_text(encoding="utf-8").splitlines()
    i = next(k for k, l in enumerate(t) if l.startswith("DIVERSIDAD DE LOS ARRANQUES"))
    pct, ver = {}, None
    for l in t[i:i + 12]:
        m = re.match(r"^\s+(\w+)\s+([\d.]+)\s*m?\s+percentil\s+([\d.]+)", l)
        if m:
            pct[m.group(1)] = (float(m.group(2)), float(m.group(3)))
        if "→" in l:
            ver = l.split("→")[1].strip()
    return pct, ver


ver_ses = {}
max_dif_pct = 0.0
for s in ("s1", "s2", "s3", "s5", "c26"):
    pc, verc = leer_div_consola(CONSOLA[s])
    eps = [mat_x0(f) for f in EP[s] if es_valido(f)]
    v, p, band, ver = diversidad(eps)
    dif = max(abs(p[k] - pc[k][1]) for k, _ in EST)
    max_dif_pct = max(max_dif_pct, dif)
    ver_ses[s] = (verc, ver)
info(f"Validación del Monte Carlo propio contra las 5 consolas (s1, s2, s3, s5, 26-09; 30 percentiles): "
     f"diferencia máxima {max_dif_pct:.2f} puntos de percentil.")
v_alt = diversidad([mat_x0(f) for f in EP['s2'] if es_valido(f)], sep=0.31)
info(f"Control: con separación 0.31 m (entrenamiento) el percentil de vecino_medio de s2 sería "
     f"{v_alt[1]['vecino_medio']:.1f} (consola: 4.2) → la consola NO usa 0.31 m.")
eps_s4 = [mat_x0(f) for f in EP["s4"] if es_valido(f)]
v4 = diversidad(eps_s4)
ver_ses["s4"] = ("(sin consola)", v4[3])
todas_compat = all(("compatible" in (vc or "")) and vm == "compatible" for s, (vc, vm) in ver_ses.items() if s != "s4") \
    and v4[3] == "compatible"
cat("D02", "diversidad de cada sesión del 30-09: compatible", "compatible (×5)",
    "; ".join(f"{s}: consola «{vc}» / propio «{vm}»" for s, (vc, vm) in ver_ses.items() if s != "c26"), todas_compat)
eps50 = [mat_x0(f) for s, f in V30]
v50, p50, b50, ver50 = diversidad(eps50)
num("D03", "los 50 válidos: percentil de vecino_medio", "1.1", p50["vecino_medio"], "{:.1f}")
cat("D04", "los 50 válidos: aviso (1 estadístico en la cola: vecino_medio)", "aviso por vecino medio",
    f"{ver50} {b50} (vecino_medio = {v50['vecino_medio']:.3f} m)", ver50 == "aviso" and b50 == ["vecino_medio"])
eps45 = [mat_x0(f) for s, f in V30 if (s, int(f["episodio"])) not in set(nl_set)]
v45, p45, b45, ver45 = diversidad(eps45)
cat("D05", "sin esos 5 (n = 45) el aviso desaparece", "desaparece",
    f"{ver45} (vecino_medio p{p45['vecino_medio']:.1f})", ver45 == "compatible")
eps57 = [mat_bl(f) for s in SESIONES for f in EP[s]]
v57, p57, b57, ver57 = diversidad(eps57)
cat("D06", "blancos de los 57 intentos: '⚠ poco representativos'", "⚠ poco representativos",
    f"{ver57} {b57} (celdas p{p57['celdas_cubiertas']:.1f}, ks_y p{p57['ks_y']:.1f})", ver57.startswith("⚠"))
uno = {}
for s in SESIONES:
    for f in EP[s]:
        uno.setdefault(int(f["semilla"]), f)
v12, p12, b12, ver12 = diversidad([mat_bl(f) for f in uno.values()])
num("D07", "configuraciones distintas (semillas) en los 57 intentos", "12", len(uno), "{:.0f}")
cat("D08", "las 12 configuraciones por sí solas: compatibles", "compatibles", f"{ver12} {b12}", ver12 == "compatible")
info("D06–D08: que el ⚠ sea 'un artefacto de repetir 12 configuraciones' es una interpretación (el Monte Carlo supone "
     "sorteos independientes); los datos sólo muestran que las 12 distintas son compatibles.")
nr("D09", "separación del sorteo de ENTRENAMIENTO (contra la que el chequeo NO compara)", "0.31",
   "código de entrenamiento; derivados/a30f_robots_diversidad_salida.txt")
nr("D10", "el docstring de diversidad_arranques induce a confusión ('sorteo de entrenamiento')", "—",
   "código del proyecto; derivados/wf_0930_extraido.txt (omisión 2)")

# =============================================================================== ROBOTS
cab("§7 Robots")
mot = {(s, int(f["episodio"])): f["motivo"] for s in SESIONES for f in EP[s] if not es_valido(f)}
ns = sorted(k for k, m in mot.items() if "NO SIGUE" in m)
cat("B01", "robot 5 (agente 1): NO SIGUE en s2 ep 2 y 3", "s2 ep 2 y 3",
    "; ".join(f"{k[0]} ep {k[1]}: «{mot[k][:40]}»" for k in ns),
    ns == [("s2", 2), ("s2", 3)] and all("agente 1 NO SIGUE" in mot[k] for k in ns))
r5_2 = DEC["s2"][(2, 1)]
r5_3 = DEC["s2"][(3, 1)]
fx, fy = r5_2[-1][4], r5_2[-1][5]
num("B02", "posición env x del r5 inmóvil (fin del ep 2)", "2.36", fx)
num("B03", "posición env y del r5 inmóvil (fin del ep 2)", "1.22", fy)
xs3 = np.array([[t[4], t[5]] for t in r5_3])
info(f"B02–B03: en el ep 3 el r5 queda en x∈[{xs3[:, 0].min():.4f}, {xs3[:, 0].max():.4f}], "
     f"y∈[{xs3[:, 1].min():.4f}, {xs3[:, 1].max():.4f}] ({len(xs3)} decisiones).")
ult_lejos = max(t[0] for t in r5_2 if math.hypot(t[4] - fx, t[5] - fy) > 0.001)
num("B04", "decisión del ep 2 desde la que el r5 queda inmóvil (última a > 1 mm de su pose final)", "236", ult_lejos, "{:.0f}")
camino = sum(math.hypot(b[4] - a[4], b[5] - a[5]) for a, b in zip(r5_2, r5_2[1:]))
info(f"B04: antes de la decisión ~236 el r5 recorrió {camino:.2f} m en el ep 2 (ep 2 tiene {len(r5_2)} decisiones; "
     f"aborta en la {r5_2[-1][0]}): 'inmóvil' vale desde ~236, no para todo el ep 2.")
t2 = (CON / CONSOLA["s2"]).read_text(encoding="utf-8").splitlines()
i10054 = next(i for i, l in enumerate(t2) if "fallo enviando" in l and "10054" in l)
iep3 = next(i for i, l in enumerate(t2) if l.startswith("EPISODIO 3"))
pos_r5 = {re.search(r"robot 5: está \(([\d.]+), ([\d.]+)\)", l).groups() for l in t2[iep3:i10054]
          if re.search(r"robot 5: está \(", l)}
info(f"B02–B05: la guía de la consola s2 entre el ep 3 y el 10054 muestra al r5 siempre en {sorted(pos_r5)}.")
rec = [re.search(r"a los ([\d.]+) s de la caída \(caída (\d\d:\d\d:\d\d)", l) for l in t2 if "RECONECTADO" in l]
rec = [m for m in rec if m]
cat("B05", "hora del 10054 del r5 (s2)", "12:17:16", rec[0].group(2) if rec else "—", bool(rec) and rec[0].group(2) == "12:17:16")
num("B06", "reconexión del r5 tras el 10054 [s]", "117", float(rec[0].group(1)), "{:.1f}")
caidos = {}
for s in ("s1", "s2", "s3", "s5", "c26"):
    t = (CON / CONSOLA[s]).read_text(encoding="utf-8").splitlines()
    caidos[s] = sum(1 for l in t if "fallo enviando" in l and "10054" in l)
num("B07", "enlaces caídos (fallos de envío 10054) el 30-09 (s1, s2, s3, s5)", "1",
    sum(caidos[s] for s in ("s1", "s2", "s3", "s5")), "{:.0f}")
num("B08", "enlaces caídos (10054) el 26-09", "5", caidos["c26"], "{:.0f}")
cat("B09", "la s4 no tiene consola (sin dato de 10054)", "s4 sin dato",
    "no hay consola de s4 en consola/", not any(CON.glob("consola_20260930_04*")))


def pivotes(D):
    out = []
    for (ep, a), filas in D.items():
        xy = np.array([[t[4], t[5]] for t in filas])
        th = np.unwrap(np.array([t[6] for t in filas]))
        ret = np.array([t[7] for t in filas])
        for k in range(0, len(filas) - 20, 10):
            w = math.degrees(th[k + 20] - th[k]) / 2.0
            if abs(w) < 90 or ret[k:k + 21].any():
                continue
            seg = xy[k:k + 21]
            A = np.c_[2 * seg[:, 0], 2 * seg[:, 1], np.ones(21)]
            c, *_ = np.linalg.lstsq(A, (seg ** 2).sum(1), rcond=None)
            r = math.sqrt(max(c[2] + c[0] ** 2 + c[1] ** 2, 0.0))
            if r < 0.07:
                out.append((ep, ROBOT[a]))
    return out


piv30 = [(s,) + p for s in SESIONES for p in pivotes(DEC[s])]
piv26 = pivotes(DEC["c26"])
num("B10", "ventanas de pivote en todo el 30-09", "1", len(piv30), "{:.0f}")
cat("B11", "esa ventana es del r6 en s4 ep 3", "r6, s4 ep 3", str(piv30), piv30 == [("s4", 3, 6)])
num("B12", "ventanas de pivote del r6 el 26-09", "28", sum(1 for e, r in piv26 if r == 6), "{:.0f}")
info(f"B12: las ventanas del 26-09 están en los episodios {sorted({e for e, r in piv26})} (ambos inválidos); "
     f"otros robots el 26-09: {sum(1 for e, r in piv26 if r != 6)}.")
info("B01–B06: la causa física del fallo del r5 (base, batería o placa) es hipótesis, como dice el reporte.")

# =============================================================================== RITMO DEL LAZO
cab("§7 Ritmo del lazo (ciclo_p95_ms)")
p95 = {s: [fl(f["ciclo_p95_ms"]) for f in validos(s)] for s in SESIONES + ["c26"]}
s100 = {s: sum(int(fl(f["ciclos_sobre_100ms"])) for f in validos(s)) for s in SESIONES + ["c26"]}
num("T01", "hw 26-09: p95 medio de los válidos [ms]", "15.5", float(np.mean(p95["c26"])))
num("T02", "hw 26-09: desvío del p95 (ddof 1) [ms]", "1.0", float(np.std(p95["c26"], ddof=1)))
num("T03", "hw 26-09: ciclos > 100 ms en válidos", "0", s100["c26"], "{:.0f}")
for s, rep in zip(SESIONES, ["59.4", "50.0", "49.1", "37.6", "36.9"]):
    num(f"T04.{s}", f"hw 30-09 {s}: p95 medio de los válidos [ms]", rep, float(np.mean(p95[s])))
for s, rep in zip(SESIONES, ["6", "6", "3", "18", "5"]):
    num(f"T05.{s}", f"hw 30-09 {s}: ciclos > 100 ms en válidos", rep, s100[s], "{:.0f}")
todos100 = {s: sum(int(fl(f["ciclos_sobre_100ms"])) for f in EP[s]) for s in SESIONES}
info(f"T05: en TODOS los intentos serían {[todos100[s] for s in SESIONES]} (el reporte usa bien los válidos).")
rep26 = [fl(r["ciclo_p95_ms"]) for r in REP26 if es_valido(r)]
rep30 = [fl(r["ciclo_p95_ms"]) for s in SESIONES for r in REP[s] if es_valido(r)]
num("T06", f"réplica 26-09: mediana del p95 (n = {len(rep26)} corridas válidas) [ms]", "20.9", float(np.median(rep26)))
num("T07", f"réplica 30-09: mediana del p95 (n = {len(rep30)} corridas válidas) [ms]", "16.3", float(np.median(rep30)))
info(f"T06–T07: Mann-Whitney réplica 30-09 vs 26-09 p = {stats.mannwhitneyu(rep30, rep26, alternative='two-sided').pvalue:.1e}; "
     f"medianas por sesión de réplica: " + ", ".join(
         f"{s} {np.median([fl(r['ciclo_p95_ms']) for r in REP[s] if es_valido(r)]):.1f}" for s in SESIONES)
     + ". La réplica del 30-09 corrió DESPUÉS de las sesiones (13:39–15:46, §3), no durante: no mide la carga del PC "
       "mientras corría el hw.")
nr("T08", "adaptador {af7051bf} el 26-09 y {58c68cd4} el 30-09, conectado a las 11:54:30, sin eventos WLAN",
   "{af7051bf} / {58c68cd4} / 11:54:30", "registro de Windows; derivados/a30f_robots_wlan_salida.txt y a30f_verif_robots_5_wlan_salida.txt")
kw = stats.kruskal(*[p95[s] for s in SESIONES])
num("T09", "Kruskal-Wallis del p95 de los válidos entre s1..s5 (p)", "7.6e-6", float(kw.pvalue), "{:.3e}")
orden = [i for i, s in enumerate(SESIONES) for _ in p95[s]]
rho = stats.spearmanr(orden, [x for s in SESIONES for x in p95[s]])
info(f"T09: H = {kw.statistic:.2f}. Kruskal-Wallis prueba heterogeneidad, no tendencia; la caída a lo largo del día la "
     f"sostiene mejor Spearman contra el orden de sesión: ρ = {rho.correlation:+.3f}, p = {rho.pvalue:.1e}.")
p26_todos = [fl(f["ciclo_p95_ms"]) for f in EP["c26"]]
s4_todos = [(int(f["episodio"]), fl(f["ciclo_p95_ms"]), es_valido(f)) for f in EP["s4"]]
s4_nivel = [t for t in s4_todos if t[1] <= max(p26_todos)]
num("T10", "intentos de la s4 al nivel del 26-09 (p95 ≤ máx de los 19 intentos del 26-09)", "3", len(s4_nivel), "{:.0f}")
num("T11", "p95 mínimo de esos intentos de la s4 [ms]", "12", min(t[1] for t in s4_nivel), "{:.1f}")
num("T12", "p95 máximo de esos intentos de la s4 [ms]", "18", max(t[1] for t in s4_nivel), "{:.1f}")
info(f"T10–T12: {[(e, round(p, 1), 'válido' if v else 'inválido') for e, p, v in s4_nivel]}; el 26-09 va de "
     f"{min(p26_todos):.1f} a {max(p26_todos):.1f} ms. El de 12.2 ms es un intento inválido (ep 7).")
p11 = [fl(f["ciclo_p95_ms"]) for f in EP11 if f["ciclo_p95_ms"].strip()]
nr("T13", "con el MU-MIMO, p95 ≥ 25 ms en 27 de 33 episodios de fechas anteriores", "27 de 33",
   "faltan en csv/ los episodios del 22-09 y 24-09; derivados/a30f_robots_ritmo_salida.txt y "
   f"a30f_verif_robots_6_codigo_ritmo_salida.txt. Parte verificable (11-09): {sum(1 for x in p11 if x >= 25)} de {len(p11)}")
info("T13: según derivados, 17 de esos 33 son del 24-09, con el robot 5 fuera de la red (p95 de ~450 ms en 5 intentos), "
     "y sólo 6 de los 33 son válidos; el reporte omite esa salvedad.")


# --- asociación latencia ↔ cobertura/seguridad con efectos fijos de semilla
def ols_fe(y, x, grupos):
    g = sorted(set(grupos))
    X = np.column_stack([np.ones(len(y)), x] + [np.array([1.0 if gi == k else 0.0 for gi in grupos]) for k in g[1:]])
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    res = y - X @ b
    rk = np.linalg.matrix_rank(X)
    gl = len(y) - rk
    se = math.sqrt(np.linalg.pinv(X.T @ X)[1, 1] * (res @ res) / gl)
    t = b[1] / se
    return b[1], se, 2 * stats.t.sf(abs(t), gl), gl


def f018_actesc(s, ep):
    filas_ep = [(a, DEC[s][(ep, a)]) for a in range(5)]
    n = bajo = act = 0
    for a, fil in filas_ep:
        n += len(fil)
        bajo += sum(1 for t in fil if d_pared(t[4], t[5]) < 0.18)
        e = [t[8] for t in fil]
        act += int(e[0] == 1) + sum(1 for i in range(1, len(e)) if e[i] == 1 and e[i - 1] == 0)
    return bajo / n, act


sem = [int(f["semilla"]) for s, f in V30]
x10 = np.array([fl(f["ciclo_p95_ms"]) / 10 for s, f in V30])
metr = {k: np.array([fl(f[k]) for s, f in V30]) for k in ("cobertura_aoi", "d_pared_min", "viola_018", "frac_cbf", "n_escape")}
fa = [f018_actesc(s, int(f["episodio"])) for s, f in V30]
metr["f018 (filas < 0.18 m)"] = np.array([a for a, b in fa])
metr["act_esc (activaciones de escape)"] = np.array([b for a, b in fa], dtype=float)
pvals = {}
for k, y in metr.items():
    b, se, p, gl = ols_fe(y, x10, sem)
    pvals[k] = p
    info(f"T14: {k}: pendiente por +10 ms de p95 = {b:+.4f} (EE {se:.4f}), p = {p:.3f}, gl {gl}")
pmin_k = min(pvals, key=pvals.get)
cat("T14", "latencia vs cobertura y seguridad con efectos fijos de semilla: ninguna p < 0.05; la menor 0.24", "ninguna p < 0.05; mín 0.24",
    f"mín p = {pvals[pmin_k]:.3f} ({pmin_k}); ninguna < 0.05",
    all(p >= 0.05 for p in pvals.values()) and abs(pvals[pmin_k] - 0.24) < 0.005)


# --- brecha hw − réplica vs latencia (§3) y sensibilidad sin los 5 (§1 ítem 6) — sólo INFO
def pares():
    out = []
    for s, f in V30:
        reps = [fl(r["cobertura_aoi"]) for r in REP[s] if r["episodio"] == f["episodio"] and es_valido(r)]
        out.append((s, int(f["episodio"]), int(f["semilla"]), fl(f["cobertura_aoi"]) - float(np.mean(reps)),
                    fl(f["ciclo_p95_ms"])))
    return out


PAR = pares()


def por_escenario(filas):
    d = defaultdict(list)
    for s, ep, sm, dif, _ in filas:
        d[sm].append(dif)
    m = np.array([np.mean(v) for v in d.values()])
    h = stats.t.ppf(0.975, len(m) - 1) * m.std(ddof=1) / math.sqrt(len(m))
    return m.mean(), m.mean() - h, m.mean() + h, len(m)


pe = por_escenario(PAR)
pa = por_escenario([t for t in PAR if (t[0], t[1]) not in set(nl_set)])
info(f"§1 ítem 6 ('la sensibilidad sin ellos no cambia nada'): principal por escenario {pe[0]:+.4f} [{pe[1]:+.4f}, {pe[2]:+.4f}] "
     f"vs sin los 5 {pa[0]:+.4f} [{pa[1]:+.4f}, {pa[2]:+.4f}] ({pa[3]} semillas). La conclusión no cambia, pero la cota "
     f"inferior baja de {pe[1]:+.4f} a {pa[1]:+.4f}, algo más allá del '~0.01' del ítem 2.")
bb, se_b, pb, glb = ols_fe(np.array([t[3] for t in PAR]), np.array([t[4] / 10 for t in PAR]), [t[2] for t in PAR])
info(f"§7 'no mueve la brecha (§3)' y §1 ítem 7 'no predice la brecha': pendiente hw − réplica por +10 ms = {bb:+.4f}, "
     f"IC95 [{bb - stats.t.ppf(0.975, glb) * se_b:+.4f}, {bb + stats.t.ppf(0.975, glb) * se_b:+.4f}], p = {pb:.2f}.")

mw = stats.mannwhitneyu(p95["s3"], p95["s2"], alternative="two-sided")
num("T15", "s3 (réplica en paralelo) vs s2: Mann-Whitney del p95 de los válidos (p)", "0.68", float(mw.pvalue), "{:.4f}")
info(f"T15: medianas s3 {np.median(p95['s3']):.1f} ms vs s2 {np.median(p95['s2']):.1f} ms. Que la réplica corriera "
     f"en paralelo con la s3 sale del registro de la réplica (derivados/replica_0930_log.txt), no de csv/.")


# --- hipos: retrocesos de los válidos disparados por el "hipo" del lazo
def inicios(D, ep):
    out = []
    for a in range(5):
        fil = D[(ep, a)]
        for k in range(1, len(fil)):
            if fil[k][1:4] == fil[k - 1][1:4] and not (k >= 2 and fil[k - 1][1:4] == fil[k - 2][1:4]):
                out.append((fil[k][0], a))
    return out


hipos, n_ini, no_hipo = [], 0, []
for s, f in V30:
    ep = int(f["episodio"])
    D = DEC[s]
    ini = inicios(D, ep)
    n_ini += len(ini)
    pasos = {a: {t[0]: (t[4], t[5]) for t in D[(ep, a)]} for a in range(5)}
    med = {}
    for a in range(5):
        fil = D[(ep, a)]
        med[a] = float(np.median([math.hypot(b[4] - c[4], b[5] - c[5]) for c, b in zip(fil, fil[1:])]))

    def paso_de(a, k):
        if k in pasos[a] and k - 1 in pasos[a]:
            return math.hypot(pasos[a][k][0] - pasos[a][k - 1][0], pasos[a][k][1] - pasos[a][k - 1][1]) / med[a]
        return float("nan")

    por_paso = defaultdict(list)
    for k, a in ini:
        por_paso[k].append(a)
    for k, ags in por_paso.items():
        prev = [paso_de(a, k - 1) for a in range(5)]
        ahora = [paso_de(a, k) for a in range(5) if a not in ags]
        if float(np.median(prev)) >= 1.5 and ahora and max(ahora) <= 0.25:
            for a in ags:
                hipos.append((s, ep, k, ROBOT[a], round(min(prev), 2), round(max(prev), 2), round(max(ahora), 2)))
        else:
            no_hipo.append((float(np.median(prev)), max(ahora) if ahora else float("nan")))
num("T16", "retrocesos de los válidos (inicios de pose repetida en válidos)", "16", n_ini, "{:.0f}")
num("T17", "retrocesos falsos de los válidos disparados por un 'hipo' del lazo", "5", len(hipos), "{:.0f}")
info("T17: hipos = " + "; ".join(f"{s} ep{e} dec {k} r{r} (decisión anterior ×{a}–{b}, no congelados ≤ ×{c})"
                                  for s, e, k, r, a, b, c in hipos)
     + f". En las otras {len(no_hipo)} decisiones con inicio de los válidos, el no congelado más rápido avanza "
       f"{min(m for _, m in no_hipo):.2f}–{max(m for _, m in no_hipo):.2f} veces lo normal y la mediana de la decisión "
       f"anterior es {min(p for p, _ in no_hipo):.2f}–{max(p for p, _ in no_hipo):.2f} (retención, no hipo). "
       "En s5 ep 9 el r9 avanzó sólo ~0.6 veces en la decisión anterior: 'todos los agentes' (§6) no vale con esta "
       "normalización, pero sí la mediana. Que sea 'el único efecto documentado' de la latencia es una afirmación "
       "de alcance (ver T14).")
nr("T18", "'con otro código' (el MU-MIMO de fechas anteriores corrió código distinto)", "otro código",
   "fechas de modificación del código; derivados/a30f_robots_ritmo_salida.txt")

# =============================================================================== §1 ÍTEMS 6 y 7
cab("§1 Resumen, ítems 6 y 7 (repetición de cifras del §7)")
num("R6.1", "ítem 6: arranques fuera del soporte", "5", len(fuera), "{:.0f}")
nr("R6.2", "ítem 6: umbral 'par < 0.31 m' (mínimo del sorteo de entrenamiento)", "0.31", "código de entrenamiento (= A06)")
num("R6.3", "ítem 6: 'no avanza' que son bloqueo del CBF robot-robot", "14", len(na_in), "{:.0f}")
num("R6.4", "ítem 6: total de 'no avanza'", "15", len(na), "{:.0f}")
v50p95 = [fl(f["ciclo_p95_ms"]) for s, f in V30]
num("R7.1", "ítem 7: p95 del ciclo del hw 30-09 (media de los 50 válidos) [ms]", "46.6", float(np.mean(v50p95)))
num("R7.2", "ítem 7: p95 del ciclo del hw 26-09 [ms]", "15.5", float(np.mean(p95["c26"])))
num("R7.3", "ítem 7: réplica 30-09, mediana del p95 [ms]", "16.3", float(np.median(rep30)))
num("R7.4", "ítem 7: réplica 26-09, mediana del p95 [ms]", "20.9", float(np.median(rep26)))
nr("R7.5", "ítem 7: 'el adaptador USB cambió'", "cambió", "registro de Windows (= T08)")
info("R7: 'La latencia está del lado de la red, el servidor o los robots' es una inferencia por descarte (la réplica sin "
     "WiFi no es más lenta); no hay medición directa de la red, del servidor ni de los robots.")

print(f"RESUMEN s7_robots: {CUENTA['ok']} ok, {CUENTA['falla']} fallas, {CUENTA['nr']} no recalculables")
