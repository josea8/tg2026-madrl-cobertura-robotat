"""
Arreglo de seguridad (aprobado por Jose el 2026-09-30): detener los robots al final de
TODO episodio, no sólo de los abortados. Edición por bytes que preserva el fin de línea
de cada archivo (ambos CRLF), con respaldo previo y reemplazos que deben aparecer
exactamente una vez.

  python arreglo_detencion.py prueba    → sólo agrega la prueba (control negativo)
  python arreglo_detencion.py arreglo   → aplica el cambio en sesion_robotat.py
"""
import shutil, sys
from pathlib import Path

COORD = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")


def editar(archivo: Path, viejo: str, nuevo: str, respaldo: str) -> None:
    b = archivo.read_bytes()
    crlf = b.count(b"\r\n") == b.count(b"\n") and b.count(b"\n") > 0
    t = b.decode("utf-8").replace("\r\n", "\n")
    n = t.count(viejo)
    if n != 1:
        sys.exit(f"{archivo.name}: el fragmento aparece {n} veces (se esperaba 1); no toco nada")
    dest = archivo.with_name(archivo.stem + respaldo + archivo.suffix)
    if dest.exists():
        sys.exit(f"ya existe el respaldo {dest.name}; no lo piso")
    shutil.copy2(archivo, dest)
    t = t.replace(viejo, nuevo)
    if crlf:
        t = t.replace("\n", "\r\n")
    archivo.write_bytes(t.encode("utf-8"))
    print(f"ok {archivo.name} (respaldo {dest.name}, {'CRLF' if crlf else 'LF'})")


VIEJO_SESION = """    if abortado:
        canal.detener_todo()
        print(f"  ⛔ {motivo}")
"""
NUEVO_SESION = """    # Detención al final de TODO episodio, no sólo de los abortados.
    # ⚠ HALLAZGO (2026-09-30): al terminar un episodio VÁLIDO no se mandaba
    # nada; cada robot seguía con su última orden mientras la sesión calculaba
    # la réplica simulada, hasta que la guía siguiente latía (0,0). Se midieron
    # 25–56 cm de avance a ciegas, sin CBF ni escape, con robots a 2 cm de la
    # pared. No cambia nada dentro del episodio: las métricas ya están cerradas.
    canal.detener_todo()
    if abortado:
        print(f"  ⛔ {motivo}")
"""

ANCLA_TEST = """    def test_produce_las_metricas_que_faltaban(self) -> None:
"""
NUEVO_TEST = """    def test_al_terminar_un_episodio_valido_los_robots_quedan_frenados(self) -> None:
        \"\"\"
        ⚠ REGRESIÓN (2026-09-30). Al terminar un episodio VÁLIDO no se mandaba
        la detención: los robots seguían con la última orden mientras la
        sesión calculaba la réplica simulada (25–56 cm a ciegas, sin CBF, en
        el laboratorio). Cuando se llama a la réplica, el canal ya tiene que
        haber frenado a todos.
        \"\"\"
        estados = []
        original = ses._replica_simulada

        def replica_que_mira_las_ruedas(*args, **kwargs):
            t0 = time.perf_counter()
            while (not self.sim.todos_detenidos()
                   and time.perf_counter() - t0 < 0.5):
                time.sleep(0.01)          # el (0,0) viaja por TCP
            estados.append(self.sim.todos_detenidos())
            return None                   # la réplica en sí no importa acá

        ses._replica_simulada = replica_que_mira_las_ruedas
        try:
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                ses.sesion_evaluacion(
                    self.ctx, n_agentes=len(self.ROBOTS), factor=0.40,
                    episodios_objetivo=1, episodios_minimo=1,
                    decisiones=25, intentos_max=2, rpm_aborto=400.0)
        finally:
            ses._replica_simulada = original
        self.assertTrue(estados, "no hubo ningún episodio válido: la prueba "
                                 "no ejercitó el camino que importa\\n"
                        + buf.getvalue())
        self.assertTrue(all(estados),
                        "al pedir la réplica, algún robot seguía con orden "
                        "no nula tras un episodio válido")

""" + ANCLA_TEST

if __name__ == "__main__":
    modo = sys.argv[1] if len(sys.argv) > 1 else ""
    if modo == "prueba":
        editar(COORD / "test_sesion_robotat.py", ANCLA_TEST, NUEVO_TEST, "_respaldo_20260930_preDetencion")
    elif modo == "arreglo":
        editar(COORD / "sesion_robotat.py", VIEJO_SESION, NUEVO_SESION, "_respaldo_20260930_preDetencion")
    else:
        sys.exit(__doc__)
