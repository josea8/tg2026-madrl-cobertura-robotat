import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Utilidades comunes (SOLO LECTURA) del análisis a30f_robots_: robots, colocación,
validez y arranques de las 5 sesiones de evaluación del 30-09 (+ control 26-09).
No lee ningún archivo de réplica del 30-09 (cegado)."""
import csv
import math
import os
import sys

sys.dont_write_bytecode = True

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SP = (r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis"
      r"\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")

# sesión -> (episodios, decisiones, consola o None)
SES = {
    "s1": ("20260930_sesion-evaluacion_etapa7_episodios.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones.csv", "consola_20260930.txt"),
    "s2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_02.csv", "consola_20260930_02.txt"),
    "s3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_03.csv", "consola_20260930_03.txt"),
    "s4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_04.csv", None),   # consola NO pegada
    "s5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv",
           "20260930_sesion-evaluacion_etapa7_decisiones_05.csv", "consola_20260930_05.txt"),
    "c26": ("20260926_sesion-evaluacion_etapa7_episodios.csv",
            "20260926_sesion-evaluacion_etapa7_decisiones.csv", "consola_20260926.txt"),
}
SES30 = ["s1", "s2", "s3", "s4", "s5"]

# Válidos declarados por el orquestador (se verifican contra la columna 'valido').
VALIDOS = {
    "s1": [3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    "s2": [1, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    "s3": [1, 2, 4, 5, 6, 7, 8, 9, 10, 11],
    "s4": [1, 2, 3, 4, 5, 6, 8, 9, 10, 11],
    "s5": [1, 2, 3, 4, 5, 7, 8, 9, 10, 11],
}
ROBOT = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
AG_DE_ROBOT = {r: a for a, r in ROBOT.items()}
TOL_BLANCO = 0.12          # tolerancia de colocación de la sesión
SEP_ENTRENAMIENTO = 0.31   # 2·D_SAFE+0.01: separación mínima del sorteo de entrenamiento
MARGEN_ENTRENAMIENTO = 0.45  # 0.15·arena: margen a la pared del sorteo de entrenamiento
SEP_CHEQUEO = 0.15         # D_SEPARACION_MIN_ARRANQUE_M (chequeo de arranque de la sesión)
MARGEN_CHEQUEO = 0.20      # MARGEN_PARED_ARRANQUE_M


def leer_ep(s):
    with open(os.path.join(RS, SES[s][0]), encoding="utf-8", newline="") as fh:
        filas = list(csv.DictReader(fh))
    for f in filas:
        for a in range(5):
            assert int(f[f"robot_a{a}"]) == ROBOT[a], (s, f["episodio"], a)
    return filas


def ruta_consola(s):
    c = SES[s][2]
    return None if c is None else os.path.join(SP, c)


def fl(x, d=float("nan")):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


def x0(f, a):
    return (fl(f[f"x0_a{a}"]), fl(f[f"y0_a{a}"]), fl(f[f"th0_a{a}"]))


def blanco(f, a):
    return (fl(f[f"blanco_x_a{a}"]), fl(f[f"blanco_y_a{a}"]), fl(f[f"blanco_th_a{a}"]))


def d_blanco(f, a):
    p, b = x0(f, a), blanco(f, a)
    return math.hypot(p[0] - b[0], p[1] - b[1])


def d_pared(x, y):
    return min(x, 3.0 - x, y, 3.0 - y)


def pares_x0(f):
    """[(d, a, b)] de todos los pares de centros en x0, ordenado."""
    out = []
    for a in range(5):
        for b in range(a + 1, 5):
            pa, pb = x0(f, a), x0(f, b)
            out.append((math.hypot(pa[0] - pb[0], pa[1] - pb[1]), a, b))
    return sorted(out)


def media_de(v, ddof=1):
    n = len(v)
    if n == 0:
        return float("nan"), float("nan")
    m = sum(v) / n
    if n - ddof <= 0:
        return m, float("nan")
    return m, math.sqrt(sum((x - m) ** 2 for x in v) / (n - ddof))


def mediana(v):
    v = sorted(v)
    n = len(v)
    if n == 0:
        return float("nan")
    return v[n // 2] if n % 2 else 0.5 * (v[n // 2 - 1] + v[n // 2])
