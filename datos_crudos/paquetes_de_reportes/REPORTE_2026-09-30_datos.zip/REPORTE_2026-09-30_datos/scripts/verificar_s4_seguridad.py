#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verificar_s4_seguridad.py — verificación INDEPENDIENTE del §4 (Seguridad: sin colisiones, con
menos margen de pared) y del ítem 3 del §1 de REPORTE_2026-09-30.md, más la repetición de la
seguridad en el §8 ("Citable").

Todo sale de los CSV crudos del paquete (csv/). No importa ni lee los scripts del análisis
(a30f_*, pareo_*), ni sus salidas, ni nada fuera del paquete. Python 3 + numpy + scipy.

Uso (desde cualquier carpeta):
    python verificar_s4_seguridad.py > ../derivados/verificar_s4_seguridad_salida.txt

Formato: una línea por cifra
    id | descripción | valor en el reporte | recalculado | OK/FALLA
tolerancia = media unidad del último decimal mostrado en el reporte. Las afirmaciones
cualitativas verificables llevan id "A…" y el criterio va en la descripción. Las cifras que no
salen de csv/ ni consola/ van como NO RECALCULABLE (fuente: …).

Definiciones (fijadas por el pedido de verificación):
  válidos      = columna 'valido' en ('1', 'True')
  semilla      = 420000 + ep − 1 (se comprueba)
  agentes 0..4 = robots 1, 5, 8, 6, 9
  d_pared      = min(x, 3 − x, y, 3 − y) en el marco env (pose_env_x, pose_env_y)
  pose congelada = fila con (x, y, θ) idéntica a la fila anterior del mismo agente y episodio
  calibración  env = R(rot)·(escala·lab) + tras  →  lab = R(−rot)·(env − tras)/escala
  desvíos con ddof = 1; IC95 con t de Student.
  réplica      = media de las repeticiones VÁLIDAS de cada episodio (regla del pareo).
"""
import csv
import json
import math
import re
import sys
from pathlib import Path

import numpy as np
from scipy import stats

try:  # salida en UTF-8 con fin de línea LF, también en Windows con redirección
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
except Exception:
    pass

PAQ = Path(__file__).resolve().parent.parent
DIR_CSV = PAQ / "csv"
DIR_CONSOLA = PAQ / "consola"  # ninguna cifra del §4 sale de la consola (se deja declarado)

SECCION = "s4_seguridad"
ROBOT = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
DT, FACTOR, RAMPA = 0.1, 0.40, 50
SES30 = [("s1", ""), ("s2", "_02"), ("s3", "_03"), ("s4", "_04"), ("s5", "_05")]
ESQ_R5 = np.array([2.73, 0.11])   # punto de la "esquina env (3, 0)" donde el r5 fija el mínimo
RADIO_ESQ = 0.30                  # radio para contar activaciones "en esa esquina"

N_OK = N_FALLA = N_NOREC = 0


# ───────────────────────────── utilidades de salida ─────────────────────────────
def _nums(s):
    """Números de una cadena del reporte (acepta el signo menos tipográfico)."""
    s = s.replace("−", "-")
    return [(float(m), len(m.split(".")[1]) if "." in m else 0)
            for m in re.findall(r"[-+]?\d+(?:\.\d+)?", s)]


def cifra(id_, desc, reportado, valores, recalc_txt):
    """Compara cada número de `reportado` con el valor recalculado correspondiente."""
    global N_OK, N_FALLA
    ns = _nums(reportado)
    if len(ns) != len(valores):
        raise ValueError(f"{id_}: {len(ns)} números en el reporte y {len(valores)} recalculados")
    ok = all(abs(v - r) <= 0.5 * 10 ** (-d) + 1e-12 for (r, d), v in zip(ns, valores))
    N_OK += ok
    N_FALLA += (not ok)
    print(f"{id_} | {desc} | {reportado} | {recalc_txt} | {'OK' if ok else 'FALLA'}")


def cifra_alguno(id_, desc, reportado, candidatos, recalc_txt):
    """Una sola cifra que el reporte puede estar tomando de cualquiera de dos estimadores que él mismo
    publica (p. ej. 'por pares' y 'por escenario'): OK si coincide con alguno."""
    global N_OK, N_FALLA
    (r, d), = _nums(reportado)
    ok = any(abs(v - r) <= 0.5 * 10 ** (-d) + 1e-12 for v in candidatos)
    N_OK += ok
    N_FALLA += (not ok)
    print(f"{id_} | {desc} | {reportado} | {recalc_txt} | {'OK' if ok else 'FALLA'}")


def afirm(id_, desc, reportado, evidencia, ok):
    global N_OK, N_FALLA
    N_OK += bool(ok)
    N_FALLA += (not ok)
    print(f"{id_} | {desc} | {reportado} | {evidencia} | {'OK' if ok else 'FALLA'}")


def norec(id_, desc, reportado, fuente):
    global N_NOREC
    N_NOREC += 1
    print(f"{id_} | {desc} | {reportado} | — | NO RECALCULABLE (fuente: {fuente})")


def control(txt):
    print(f"# control: {txt}")


def sep(t):
    print(f"\n# ── {t} " + "─" * max(0, 90 - len(t)))


# ───────────────────────────── lectura ─────────────────────────────
def leer(nombre):
    with open(DIR_CSV / nombre, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def es_valido(r):
    return (r.get("valido") or "").strip() in ("1", "True")


def leer_dec(nombre):
    """episodio → agente → dict de arreglos ordenados por paso."""
    tmp = {}
    with open(DIR_CSV / nombre, encoding="utf-8", newline="") as f:
        rd = csv.reader(f)
        cab = next(rd)
        ix = {c: i for i, c in enumerate(cab)}
        for row in rd:
            ep, ag = int(row[ix["episodio"]]), int(row[ix["agente"]])
            tmp.setdefault(ep, {}).setdefault(ag, []).append((
                int(row[ix["paso"]]), int(row[ix["robot"]]),
                float(row[ix["pose_env_x"]]), float(row[ix["pose_env_y"]]), float(row[ix["pose_env_th"]]),
                float(row[ix["v_ejecutada"]]), int(float(row[ix["en_escape"]])),
                int(float(row[ix["cbf_intervino"]])), int(float(row[ix["en_retroceso"]]))))
    out = {}
    for ep, ags in tmp.items():
        out[ep] = {}
        for ag, filas in ags.items():
            filas.sort(key=lambda t: t[0])
            a = np.array(filas, dtype=float)
            x, y, th = a[:, 2], a[:, 3], a[:, 4]
            rep = np.r_[False, (x[1:] == x[:-1]) & (y[1:] == y[:-1]) & (th[1:] == th[:-1])]
            out[ep][ag] = dict(paso=a[:, 0].astype(int), robot=int(a[0, 1]), x=x, y=y, th=th, v=a[:, 5],
                               esc=a[:, 6].astype(int), cbf=a[:, 7].astype(int), ret=a[:, 8].astype(int),
                               d=np.minimum.reduce([x, 3 - x, y, 3 - y]), rep=rep)
    return out


def activaciones(esc):
    """Activaciones de escape 0→1 de un agente (una fila inicial en escape cuenta como activación)."""
    return np.where(np.r_[esc[0] == 1, (esc[1:] == 1) & (esc[:-1] == 0)])[0]


def rachas(b):
    """(inicio, fin) de los tramos contiguos True de un arreglo booleano."""
    dif = np.diff(np.r_[0, b.astype(int), 0])
    return list(zip(np.where(dif == 1)[0], np.where(dif == -1)[0]))


def t_ic(v):
    v = np.asarray(v, float)
    n, m, sd = len(v), float(np.mean(v)), float(np.std(v, ddof=1))
    w = stats.t.ppf(0.975, n - 1) * sd / math.sqrt(n)
    return m, m - w, m + w, float(stats.ttest_1samp(v, 0).pvalue)


def ols_fe(y, x, grupos):
    """y ~ 1 + x + efectos fijos de grupo. Devuelve (b, lo, hi, p, gl) del coeficiente de x."""
    y = np.asarray(y, float)
    cats = sorted(set(grupos))
    cols = [np.ones(len(y)), np.asarray(x, float)]
    cols += [np.array([1.0 if g == c else 0.0 for g in grupos]) for c in cats[1:]]
    X = np.column_stack(cols)
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    res = y - X @ b
    gl = len(y) - np.linalg.matrix_rank(X)
    se = math.sqrt(np.linalg.pinv(X.T @ X)[1, 1] * (res @ res) / gl)
    q = stats.t.ppf(0.975, gl)
    return float(b[1]), float(b[1] - q * se), float(b[1] + q * se), float(2 * stats.t.sf(abs(b[1] / se), gl)), gl


def holm(ps):
    ps = np.asarray(ps, float)
    k, orden, out, acc = len(ps), np.argsort(ps), np.empty(len(ps)), 0.0
    for j, i in enumerate(orden):
        acc = max(acc, min(1.0, (k - j) * ps[i]))
        out[i] = acc
    return out


# calibración env ↔ lab
try:
    _cal = json.load(open(DIR_CSV / "calibracion_medida.json", encoding="utf-8"))
    ESCALA, ROT = float(_cal["escala_posicion"]), float(_cal["rotacion_marco_rad"])
    TRAS = np.array([float(_cal["traslacion_x_m"]), float(_cal["traslacion_y_m"])])
except Exception:  # valores de respaldo indicados en el pedido
    ESCALA, ROT, TRAS = 1.0166876, 0.0084726, np.array([1.5061547, 1.2563353])


def env_a_lab(x, y):
    c, s = math.cos(-ROT), math.sin(-ROT)
    dx, dy = np.asarray(x) - TRAS[0], np.asarray(y) - TRAS[1]
    return (c * dx - s * dy) / ESCALA, (s * dx + c * dy) / ESCALA


# ───────────────────────────── carga de datos ─────────────────────────────
EP30, DEC30, REP30 = {}, {}, {}
for ses, suf in SES30:
    EP30[ses] = leer(f"20260930_sesion-evaluacion_etapa7_episodios{suf}.csv")
    DEC30[ses] = leer_dec(f"20260930_sesion-evaluacion_etapa7_decisiones{suf}.csv")
    REP30[ses] = leer(f"20260930_sesion-replica_etapa7_capas-on_de-20260930{suf}.csv")
EP26 = leer("20260926_sesion-evaluacion_etapa7_episodios.csv")
DEC26 = leer_dec("20260926_sesion-evaluacion_etapa7_decisiones.csv")
REP26 = leer("20260926_sesion-replica_etapa7_capas-on_de-20260926.csv")
EP11 = leer("20260911_sesion-evaluacion_etapa7_episodios.csv")
REP11 = leer("20260912_sesion-replica_etapa7_capas-on.csv")

# episodios válidos: (día, sesión, ep) → fila del CSV de episodios
VAL = []
for ses, _ in SES30:
    for r in EP30[ses]:
        if es_valido(r):
            VAL.append(("30-09", ses, int(r["episodio"]), r))
for r in EP26:
    if es_valido(r):
        VAL.append(("26-09", "26-09", int(r["episodio"]), r))
V30 = [v for v in VAL if v[0] == "30-09"]
V26 = [v for v in VAL if v[0] == "26-09"]


def dec_de(ses, ep):
    return (DEC26 if ses == "26-09" else DEC30[ses])[ep]


sep("controles de integridad (no se cuentan como cifras)")
control(f"válidos 30-09 = {len(V30)} (por sesión " +
        ", ".join(f"{s} {sum(1 for v in V30 if v[1] == s)}" for s, _ in SES30) + f") · válidos 26-09 = {len(V26)}")
mal_sem = [(v[1], v[2]) for v in VAL if int(v[3]["semilla"]) != 420000 + v[2] - 1]
control(f"semilla = 420000 + ep − 1 en los {len(VAL)} válidos: {'sí' if not mal_sem else 'NO ' + str(mal_sem)}")
mal_rob = [(v[1], v[2], a) for v in VAL for a, g in dec_de(v[1], v[2]).items() if g["robot"] != ROBOT[a]]
control(f"agente→robot = {ROBOT} en todas las filas válidas: {'sí' if not mal_rob else 'NO ' + str(mal_rob[:5])}")
completos = all(len(dec_de(v[1], v[2])) == 5 and all(np.array_equal(g["paso"], np.arange(500))
                                                      for g in dec_de(v[1], v[2]).values()) for v in VAL)
control(f"cada válido tiene 5 agentes × pasos 0..499: {'sí' if completos else 'NO'}")
dif_dp = max(abs(float(v[3]["d_pared_min"]) - min(g["d"].min() for g in dec_de(v[1], v[2]).values())) for v in VAL)
control(f"d_pared_min del CSV de episodios = mínimo por filas de min(x,3−x,y,3−y): máx |dif| {dif_dp:.2e} m")
dif_vi = max(abs(int(float(v[3]["viola_018"])) - sum(int(g["d"].min() < 0.18) for g in dec_de(v[1], v[2]).values()))
             for v in VAL)
dif_ne = max(abs(int(float(v[3]["n_escape"])) - sum(int(g["esc"].sum()) for g in dec_de(v[1], v[2]).values()))
             for v in VAL)
dif_fc = max(abs(float(v[3]["frac_cbf"]) - np.mean(np.concatenate([g["cbf"] for g in dec_de(v[1], v[2]).values()])))
             for v in VAL)
control(f"viola_018 = n.º de agentes con alguna fila < 0.18 (máx |dif| {dif_vi}); n_escape = Σ filas en escape "
        f"(máx |dif| {dif_ne}); frac_cbf = fracción de filas con CBF (máx |dif| {dif_fc:.1e})")

# ───────────────────────────── pareo hw − réplica (30-09) ─────────────────────────────
SEG = ("d_pared_min", "viola_018", "n_escape", "frac_cbf")
PARES = []
for ses, _ in SES30:
    reps = {}
    for x in REP30[ses]:
        if es_valido(x):
            reps.setdefault(int(x["episodio"]), []).append(x)
    for r in EP30[ses]:
        if not es_valido(r):
            continue
        e = int(r["episodio"])
        xs = reps[e]
        PARES.append(dict(ses=ses, ep=e, sem=int(r["semilla"]), nrep=len(xs),
                          hw={k: float(r[k]) for k in SEG},
                          rep={k: float(np.mean([float(x[k]) for x in xs])) for k in SEG}))
SEMS = sorted({p["sem"] for p in PARES})
control(f"pares hw–réplica: {len(PARES)} · semillas {len(SEMS)} · reps válidas usadas "
        f"{sum(p['nrep'] for p in PARES)} de {sum(len(REP30[s]) for s, _ in SES30)}")
RES = {}
for k in SEG:
    d = np.array([p["hw"][k] - p["rep"][k] for p in PARES])
    m1, lo1, hi1, p1 = t_ic(d)
    ms = [float(np.mean([d[i] for i in range(len(PARES)) if PARES[i]["sem"] == s])) for s in SEMS]
    m2, lo2, hi2, p2 = t_ic(ms)
    RES[k] = dict(d=d, m1=m1, lo1=lo1, hi1=hi1, p1=p1, m2=m2, lo2=lo2, hi2=hi2, p2=p2,
                  neg=int((d < 0).sum()), pos=int((d > 0).sum()), emp=int((d == 0).sum()))

sep("§4 — tabla 'Pareada hw − réplica, 50 episodios'")
cifra("4.01", "episodios pareados hw − réplica (30-09)", "50", [len(PARES)], f"{len(PARES)}")
ETQ = {"d_pared_min": "d_pared mín (m)", "viola_018": "violaciones de 0.18 m",
       "n_escape": "decisiones-agente en escape", "frac_cbf": "fracción con CBF"}
REP_TXT = {
    "d_pared_min": ("−0.0355", "[−0.0404, −0.0306]", "−0.0353", "[−0.0426, −0.0281]", "49/50"),
    "viola_018": ("+0.43", "[+0.23, +0.62]", "+0.45", "[+0.17, +0.74]", "3/50"),
    "n_escape": ("+11.4", "[+4.7, +18.1]", "+11.0", "[+3.8, +18.2]", "12/50"),
    "frac_cbf": ("+0.003", "[−0.013, +0.019]", "+0.002", "[−0.013, +0.017]", "26/50"),
}
i = 2
for k in ("d_pared_min", "viola_018", "n_escape", "frac_cbf"):
    R, T = RES[k], REP_TXT[k]
    cifra(f"4.{i:02d}", f"{ETQ[k]}: media por pares", T[0], [R["m1"]], f"{R['m1']:+.5f} (t p {R['p1']:.2g})"); i += 1
    cifra(f"4.{i:02d}", f"{ETQ[k]}: IC95 por pares", T[1], [R["lo1"], R["hi1"]],
          f"[{R['lo1']:+.5f}, {R['hi1']:+.5f}]"); i += 1
    cifra(f"4.{i:02d}", f"{ETQ[k]}: media por escenario (12 semillas)", T[2], [R["m2"]],
          f"{R['m2']:+.5f} (t p {R['p2']:.2g})"); i += 1
    cifra(f"4.{i:02d}", f"{ETQ[k]}: IC95 por escenario (t, 11 gl)", T[3], [R["lo2"], R["hi2"]],
          f"[{R['lo2']:+.5f}, {R['hi2']:+.5f}]"); i += 1
    cifra(f"4.{i:02d}", f"{ETQ[k]}: episodios con hw < réplica", T[4], [R["neg"], len(PARES)],
          f"{R['neg']}/{len(PARES)} (hw > réplica {R['pos']}, empates {R['emp']})"); i += 1
norec("4.22", "'post hoc; el plan sólo pedía medias'", "post hoc",
      "texto de scripts/pareo_final_0930.py, no los CSV; leído: su bloque SEGURIDAD sólo imprime medias hw y réplica")

# ───────────────────────────── control 26-09 y 11-09 ─────────────────────────────
def dif_pared(ep_rows, rep_rows):
    hw = {int(r["episodio"]): float(r["d_pared_min"]) for r in ep_rows if es_valido(r)}
    rp = {}
    for x in rep_rows:
        if es_valido(x):
            rp.setdefault(int(x["episodio"]), []).append(float(x["d_pared_min"]))
    d = np.array([hw[e] - np.mean(rp[e]) for e in sorted(hw)])
    d_rep1 = np.array([hw[e] - rp[e][0] for e in sorted(hw)])
    return d, d_rep1, np.mean(list(hw.values())), np.mean([np.mean(rp[e]) for e in hw])


D26, D26r1, HW26, RP26 = dif_pared(EP26, REP26)
D11, D11r1, HW11, RP11 = dif_pared(EP11, REP11)
m26, lo26, hi26, p26 = t_ic(D26)
m11, lo11, hi11, p11 = t_ic(D11)
mp = RES["d_pared_min"]

sep("§4 — viñeta 'hallazgo más consistente de los tres días'")
cifra_alguno("4.23", "hw se mete ~3.5 cm más hacia la pared (cm; OK si coincide con el estimador por pares "
             "o por escenario de la tabla)", "3.5", [-100 * mp["m1"], -100 * mp["m2"]],
             f"{-100 * mp['m2']:.3f} cm por escenario (→ 3.5); {-100 * mp['m1']:.3f} cm por pares (→ 3.6)")
cifra("4.24", "26-09: hw − réplica con capas en d_pared mín (cm, n=10)", "2.6", [-100 * m26],
      f"{-100 * m26:.3f} cm (hw {HW26:.4f} vs réplica {RP26:.4f}; IC95 [{100 * lo26:+.2f}, {100 * hi26:+.2f}] cm; "
      f"{int((D26 < 0).sum())}/{len(D26)} negativas)")
cifra("4.25", "11-09: hw − réplica con capas en d_pared mín (cm, n=5)", "4.5", [-100 * m11],
      f"{-100 * m11:.3f} cm (hw {HW11:.4f} vs réplica {RP11:.4f}; IC95 [{100 * lo11:+.2f}, {100 * hi11:+.2f}] cm; "
      f"{int((D11 < 0).sum())}/{len(D11)} negativas; sólo con la rep 1: {-100 * D11r1.mean():.3f} cm)")
afirm("A4.26", "'hallazgo más consistente de los tres días' (criterio: mismo signo en los 3 días y mayoría de "
      "episodios negativos en cada uno)", "consistente",
      f"30-09 {mp['neg']}/50, 26-09 {int((D26 < 0).sum())}/10, 11-09 {int((D11 < 0).sum())}/5 negativas; "
      f"IC95 de cada día excluye 0: 30-09 {mp['hi1'] < 0}, 26-09 {hi26 < 0}, 11-09 {hi11 < 0}",
      mp["neg"] > 25 and (D26 < 0).sum() > 5 and (D11 < 0).sum() > 2.5 and mp["hi1"] < 0 and hi26 < 0 and hi11 < 0)
afirm("A4.27", "'El CBF actúa igual de seguido' (criterio: IC95 de frac_cbf hw − réplica incluye 0)", "igual de seguido",
      f"por pares [{RES['frac_cbf']['lo1']:+.4f}, {RES['frac_cbf']['hi1']:+.4f}], por escenario "
      f"[{RES['frac_cbf']['lo2']:+.4f}, {RES['frac_cbf']['hi2']:+.4f}]",
      RES["frac_cbf"]["lo1"] < 0 < RES["frac_cbf"]["hi1"] and RES["frac_cbf"]["lo2"] < 0 < RES["frac_cbf"]["hi2"])
norec("4.28", "hipótesis: el 3pi responde en ~450 ms", "~450 ms",
      "medición de actuación del 29-08 fuera del paquete; el único dato del paquete, calibracion_medida.json "
      f"(latencia_actuacion_media_s), dice {1000 * float(_cal.get('latencia_actuacion_media_s', float('nan'))):.1f} ms"
      if "_cal" in globals() else "medición de actuación del 29-08 fuera del paquete")
norec("4.29", "'la réplica no modela ese retardo con esa magnitud'", "(sin cifra)",
      "código de SimuladorRobotat/replica_con_capas.py, no incluido en el paquete")

# ───────────────────────────── filas bajo 0.18 / 0.15 / 0.10 ─────────────────────────────
def filas(vlist):
    d, esc, cbf, rep, ret = [], [], [], [], []
    for _, ses, ep, _ in vlist:
        for g in dec_de(ses, ep).values():
            d.append(g["d"]); esc.append(g["esc"]); cbf.append(g["cbf"]); rep.append(g["rep"]); ret.append(g["ret"])
    return tuple(np.concatenate(z) for z in (d, esc, cbf, rep, ret))


d30, esc30, cbf30, rep30, ret30 = filas(V30)
d26, esc26, cbf26, rep26, ret26 = filas(V26)
b18 = d30 < 0.18

sep("§4 — viñeta 'Dónde pasa'")
cifra("4.30", "filas válidas 30-09 con d_pared < 0.18 m (%)", "13.6 %", [100 * b18.mean()],
      f"{100 * b18.mean():.3f} % ({int(b18.sum())}/{len(d30)})")
cifra("4.31", "ídem 26-09 (%)", "10.7 %", [100 * (d26 < 0.18).mean()],
      f"{100 * (d26 < 0.18).mean():.3f} % ({int((d26 < 0.18).sum())}/{len(d26)})")
cifra("4.32", "en esas filas (30-09) el CBF interviene (%)", "89.5 %", [100 * cbf30[b18].mean()],
      f"{100 * cbf30[b18].mean():.3f} %")
cifra("4.33", "en esas filas (30-09) el escape está activo (%)", "9.4 %", [100 * esc30[b18].mean()],
      f"{100 * esc30[b18].mean():.3f} % (ni CBF ni escape: {100 * ((cbf30[b18] == 0) & (esc30[b18] == 0)).mean():.2f} %)")

# rachas contiguas bajo 0.18 m por agente-episodio (30-09 válidos)
RACH = []
for _, ses, ep, _ in V30:
    for a, g in dec_de(ses, ep).items():
        for i0, i1 in rachas(g["d"] < 0.18):
            n = i1 - i0
            xy = np.c_[g["x"][i0:i1], g["y"][i0:i1]]
            rec = float(np.linalg.norm(np.diff(xy, axis=0), axis=1).sum()) if n > 1 else 0.0
            RACH.append(dict(ses=ses, ep=ep, robot=g["robot"], n=n, dmed=float(np.median(g["d"][i0:i1])),
                             filas_d=g["d"][i0:i1], rec=rec, neto=float(np.linalg.norm(xy[-1] - xy[0]))))
L10 = [r for r in RACH if r["n"] * DT >= 10 - 1e-9]
dmed_racha = float(np.median([r["dmed"] for r in L10]))
dmed_pool = float(np.median(np.concatenate([r["filas_d"] for r in L10])))
vel_neta = np.array([r["neto"] / (r["n"] * DT) for r in L10])
cifra("4.34", "rachas de ≥ 10 s (≥ 100 decisiones seguidas) bajo 0.18 m, 30-09", "51", [len(L10)],
      f"{len(L10)} (de {len(RACH)} rachas; máx {max(r['n'] for r in RACH) * DT:.1f} s)")
cifra("4.35", "distancia mediana a la pared en esas rachas (m)", "~0.17", [dmed_racha],
      f"mediana de las medianas {dmed_racha:.4f}; mediana de sus filas {dmed_pool:.4f}")
afirm("A4.36", "'avanzando a lo largo de la pared' (criterio: desplazamiento neto/duración > 0.05 m/s en la mayoría)",
      "avanzando", f"velocidad neta mediana {np.median(vel_neta):.3f} m/s; {int((vel_neta > 0.05).sum())}/{len(L10)} "
      f"rachas > 0.05 m/s; neto/recorrido mediano {np.median([r['neto'] / r['rec'] for r in L10]):.3f}",
      (vel_neta > 0.05).mean() > 0.5)
cifra("4.37", "filas válidas 30-09 bajo 0.15 m (%)", "0.38 %", [100 * (d30 < 0.15).mean()],
      f"{100 * (d30 < 0.15).mean():.4f} %")
cifra("4.38", "filas válidas 30-09 bajo 0.15 m (n)", "479", [int((d30 < 0.15).sum())],
      f"{int((d30 < 0.15).sum())} (en escape {int(esc30[d30 < 0.15].sum())}, con CBF {int(cbf30[d30 < 0.15].sum())})")
cifra("4.39", "filas válidas 30-09 bajo 0.10 m ('ninguna')", "0", [int((d30 < 0.10).sum())], f"{int((d30 < 0.10).sum())}")
cifra("4.40", "d_pared mínima de las filas válidas 30-09 (m)", "0.1120", [float(d30.min())], f"{d30.min():.5f}")

# ───────────────────────────── robot 5 en la esquina ─────────────────────────────
def minimo_episodio(ses, ep, excluir_robot=None):
    best = None
    for a, g in dec_de(ses, ep).items():
        if g["robot"] == excluir_robot:
            continue
        i = int(np.argmin(g["d"]))
        if best is None or g["d"][i] < best["d"]:
            best = dict(robot=g["robot"], paso=int(g["paso"][i]), x=float(g["x"][i]), y=float(g["y"][i]),
                        d=float(g["d"][i]), esc=int(g["esc"][i]))
    return best


MIN30 = [(ses, ep, int(r["semilla"]), minimo_episodio(ses, ep)) for _, ses, ep, r in V30]
MIN26 = [(ses, ep, int(r["semilla"]), minimo_episodio(ses, ep)) for _, ses, ep, r in V26]
R5 = [t for t in MIN30 if t[3]["robot"] == 5]
R5_26 = [t for t in MIN26 if t[3]["robot"] == 5]
ESQ = [t for t in R5 if t[3]["y"] < 0.15 and 2.6 < t[3]["x"] < 2.85]   # pared y = 0 junto a (3, 0)
xs_e, ys_e = np.array([t[3]["x"] for t in ESQ]), np.array([t[3]["y"] for t in ESQ])
lx, ly = env_a_lab(xs_e, ys_e)
lcx, lcy = env_a_lab(np.array([2.73]), np.array([0.12]))

sep("§4 — viñeta 'Robot 5 en la esquina env (3, 0)'")
cifra("4.41", "válidos 30-09 en que el r5 fija el mínimo de pared", "26 de 50", [len(R5), len(MIN30)],
      f"{len(R5)} de {len(MIN30)} (por robot: " + ", ".join(
          f"r{rb} {sum(1 for t in MIN30 if t[3]['robot'] == rb)}" for rb in (1, 5, 8, 6, 9)) + ")")
cifra("4.42", "ídem 26-09", "3 de 10", [len(R5_26), len(MIN26)], f"{len(R5_26)} de {len(MIN26)}")
cifra("4.43", "de esos 26, los que caen en el mismo punto (pared y=0, x∈(2.60, 2.85))", "20 de esos 26",
      [len(ESQ), len(R5)], f"{len(ESQ)} de {len(R5)} (los otros: " + ", ".join(
          f"{t[0]} ep{t[1]} ({t[3]['x']:.2f}, {t[3]['y']:.2f})" for t in R5 if t not in ESQ) + ")")
cifra("4.44", "rango env del punto: x", "2.72–2.74", [xs_e.min(), xs_e.max()], f"{xs_e.min():.4f}–{xs_e.max():.4f}")
cifra("4.45", "rango env del punto: y", "0.11–0.13", [ys_e.min(), ys_e.max()], f"{ys_e.min():.4f}–{ys_e.max():.4f}")
cifra("4.46", "punto en el marco lab (centroide de los 20)", "(+1.19, −1.13)", [float(lx.mean()), float(ly.mean())],
      f"centroide ({lx.mean():+.4f}, {ly.mean():+.4f}); rango x {lx.min():+.3f}…{lx.max():+.3f}, "
      f"y {ly.min():+.3f}…{ly.max():+.3f}; centro del rango env (2.73, 0.12) → ({lcx[0]:+.3f}, {lcy[0]:+.3f})")
cifra("4.47", "'Los 26 son en escape' (mínimos del r5 con escape activo)", "26", [sum(t[3]["esc"] for t in R5)],
      f"{sum(t[3]['esc'] for t in R5)}/{len(R5)}")
por_ses = {s: sum(1 for t in ESQ if t[0] == s) for s, _ in SES30}
por_ses_r5 = {s: sum(1 for t in R5 if t[0] == s) for s, _ in SES30}
sem_rep = {s: sorted({t[0] for t in ESQ if t[2] == s}) for s in SEMS}
sem_rep2 = {s: v for s, v in sem_rep.items() if len(v) >= 2}
afirm("A4.48", "'Pasa en todas las sesiones' (criterio: ≥1 mínimo del r5 en ese punto en cada sesión)",
      "todas las sesiones", "en el punto: " + ", ".join(f"{s} {n}" for s, n in por_ses.items()) +
      " · r5 como mínimo (cualquier lugar): " + ", ".join(f"{s} {n}" for s, n in por_ses_r5.items()),
      all(n >= 1 for n in por_ses.values()))
afirm("A4.49", "'se repite por semilla' (criterio: alguna semilla con el mínimo del r5 en ese punto en ≥2 sesiones)",
      "se repite", f"{len(sem_rep2)} semillas con ≥2 sesiones: " + "; ".join(
          f"{s} en {len(v)}/{sum(1 for p in PARES if p['sem'] == s)} ({','.join(v)})" for s, v in sem_rep2.items()),
      len(sem_rep2) >= 1)

ACT = []
for _, ses, ep, _ in V30:
    for a, g in dec_de(ses, ep).items():
        for i in activaciones(g["esc"]):
            ACT.append(dict(robot=g["robot"], cerca=bool(np.hypot(g["x"][i] - ESQ_R5[0], g["y"][i] - ESQ_R5[1]) < RADIO_ESQ)))
n_act = len(ACT)
n_act5 = sum(1 for a in ACT if a["robot"] == 5)
n_act5c = sum(1 for a in ACT if a["robot"] == 5 and a["cerca"])
sens = []
for rr in (0.20, 0.25, 0.35):
    c = 0
    for _, ses, ep, _ in V30:
        g = dec_de(ses, ep)[1]
        c += sum(1 for i in activaciones(g["esc"]) if np.hypot(g["x"][i] - ESQ_R5[0], g["y"][i] - ESQ_R5[1]) < rr)
    sens.append(f"{rr:.2f} m → {c}")
cifra("4.50", "activaciones de escape (0→1) del 30-09, válidos", "106", [n_act], f"{n_act} ({n_act / 50:.2f}/episodio)")
cifra("4.51", "de ellas, del r5", "44", [n_act5], f"{n_act5}")
cifra("4.52", f"del r5 en esa esquina (a < {RADIO_ESQ:.2f} m de env (2.73, 0.11))", "24", [n_act5c],
      f"{n_act5c} (todos los robots en ese radio: {sum(1 for a in ACT if a['cerca'])}; según radio: {'; '.join(sens)})")

# ───────────────────────────── 30-09 vs 26-09 ajustado por semilla, Holm ─────────────────────────────
def por_episodio(ses, ep, r):
    G = dec_de(ses, ep)
    dd = np.concatenate([g["d"] for g in G.values()])
    sin5 = np.concatenate([g["d"] for g in G.values() if g["robot"] != 5])
    act = sum(len(activaciones(g["esc"])) for g in G.values())
    return dict(cobertura_aoi=float(r["cobertura_aoi"]), d_pared_min=float(r["d_pared_min"]),
                viola_018=float(r["viola_018"]), f018=float((dd < 0.18).mean()), frac_cbf=float(r["frac_cbf"]),
                act_esc=float(act), n_escape=float(r["n_escape"]), frac_vecino=float(r["frac_vecino"]),
                dist_min_robot=float(r["dist_min_robot"]), dpmin_sin5=float(sin5.min()))


PE = [(dia, int(r["semilla"]), por_episodio(ses, ep, r)) for dia, ses, ep, r in VAL]
dia30 = [1.0 if t[0] == "30-09" else 0.0 for t in PE]
semg = [t[1] for t in PE]
METS = ["cobertura_aoi", "d_pared_min", "viola_018", "f018", "frac_cbf", "act_esc", "n_escape", "frac_vecino",
        "dist_min_robot"]
FE = {m: ols_fe([t[2][m] for t in PE], dia30, semg) for m in METS + ["dpmin_sin5"]}
PH = holm([FE[m][3] for m in METS])
compartidas = sorted({t[1] for t in PE if t[0] == "26-09"} & {t[1] for t in PE if t[0] == "30-09"})

sep("§4 — viñetas 'Sin el r5…' y '30-09 contra 26-09'")
b, lo, hi, p, gl = FE["d_pared_min"]
b5, lo5, hi5, p5, _ = FE["dpmin_sin5"]
afirm("A4.53", "'Sin el r5, la diferencia de pared con el 26-09 pierde significación' (criterio: p > 0.05 sin r5)",
      "pierde significación", f"con r5 {b:+.4f} [{lo:+.4f}, {hi:+.4f}] p {p:.2g}; sin r5 {b5:+.4f} "
      f"[{lo5:+.4f}, {hi5:+.4f}] p {p5:.3f}", p5 > 0.05)
cifra("4.54", "30-09 − 26-09 en d_pared mín, ajustado por semilla (OLS con efectos fijos)", "−0.033", [b],
      f"{b:+.5f} (p {p:.1e}, {gl} gl)")
cifra("4.55", "ídem, IC95", "[−0.047, −0.019]", [lo, hi], f"[{lo:+.5f}, {hi:+.5f}]")
cifra("4.56", "'sólo 5 episodios de control' (26-09 con semilla compartida con el 30-09)", "5", [len(compartidas)],
      f"{len(compartidas)}: {compartidas}")
sobreviven = [m for m, ph in zip(METS, PH) if ph < 0.05]
cifra("4.57", "'Con Holm sobre 9 métricas'", "9", [len(METS)], f"{len(METS)}: {', '.join(METS)}")
afirm("A4.58", "'es la única que sobrevive' a Holm (α = 0.05)", "sólo d_pared mín",
      "Holm: " + ", ".join(f"{m} {ph:.3g}" for m, ph in zip(METS, PH)) + f" → sobreviven {sobreviven}",
      sobreviven == ["d_pared_min"])
frac_r5 = 1 - b5 / b
afirm("A4.59", "'el r5 aporta ~40 %' de la diferencia de día (criterio: |aporte − 0.40| < 0.05)", "~40 %",
      f"sin r5 la estimación pasa de {b:+.4f} a {b5:+.4f}: el r5 aporta {100 * frac_r5:.0f} %; "
      f"el {100 * (1 - frac_r5):.0f} % restante sigue (IC [{lo5:+.4f}, {hi5:+.4f}])", abs(frac_r5 - 0.40) < 0.05)

# "Probé la latencia, la actuación del r5 y la selección de los válidos del 26-09: ninguna la explica."
p95 = [float(r["ciclo_p95_ms"]) for _, _, _, r in V30]
bl, lol, hil, pl, _ = ols_fe([float(r["d_pared_min"]) for _, _, _, r in V30], p95, [int(r["semilla"]) for _, _, _, r in V30])
dp95 = np.mean(p95) - np.mean([float(r["ciclo_p95_ms"]) for _, _, _, r in V26])


def ganancia_r5(vlist):
    num = den = 0.0
    for _, ses, ep, r in vlist:
        g = dec_de(ses, ep)[1]
        # rampa: primeras 50 decisiones de la SESIÓN (sólo afecta al ep 1 si es el primero de la sesión)
        rampa = RAMPA if ep == 1 else 0
        for k in range(1, len(g["x"])):
            if g["rep"][k] or g["rep"][k - 1] or (k - 1) < rampa:
                continue
            num += math.hypot(g["x"][k] - g["x"][k - 1], g["y"][k] - g["y"][k - 1])
            den += abs(g["v"][k - 1]) * FACTOR * DT
    return num / den


g26, g30 = ganancia_r5(V26), ganancia_r5(V30)
# selección del 26-09: abortados con ≥ 400 decisiones (episodios largos) agregados al control
ABL = [r for r in EP26 if not es_valido(r) and r.get("decisiones") and int(float(r["decisiones"])) >= 400]
PE_sel = PE + [("26-09", int(r["semilla"]), dict(d_pared_min=float(r["d_pared_min"]))) for r in ABL]
bs, los, his, ps_, _ = ols_fe([t[2]["d_pared_min"] for t in PE_sel], [1.0 if t[0] == "30-09" else 0.0 for t in PE_sel],
                              [t[1] for t in PE_sel])
f018_ab = []
for r in EP26:
    if not es_valido(r) and int(float(r["episodio"])) in DEC26:
        G = DEC26[int(float(r["episodio"]))]
        f018_ab.append(np.concatenate([g["d"][~g["rep"]] for g in G.values()]))
f018_ab = np.concatenate(f018_ab)
afirm("A4.60", "'Probé la latencia … ninguna la explica': latencia (pendiente de d_pared mín por +10 ms de p95 "
      "dentro del 30-09, efectos fijos de semilla)", "no la explica",
      f"{10 * bl:+.4f} m por +10 ms [{10 * lol:+.4f}, {10 * hil:+.4f}] p {pl:.2f}; × Δp95 entre días "
      f"({dp95:.1f} ms) = {bl * dp95:+.4f} m frente a {b:+.4f} (cota del IC: {lol * dp95:+.4f})", pl > 0.05)
afirm("A4.61", "ídem: actuación del r5 (Σ|Δp| / Σ|v|·factor·dt, sin filas repetidas ni rampa)", "no la explica",
      f"26-09 {g26:.3f} → 30-09 {g30:.3f} (Δ {100 * (g30 / g26 - 1):+.1f} %)", abs(g30 / g26 - 1) < 0.02)
afirm("A4.62", "ídem: selección de los válidos del 26-09 (filas < 0.18 en abortados vs válidos; y d_pared ajustada "
      "agregando los abortados con ≥ 400 decisiones)", "no la explica",
      f"f018 abortados {(f018_ab < 0.18).mean():.4f} vs válidos {(d26[~rep26] < 0.18).mean():.4f}; con "
      f"{len(ABL)} abortados largos (ep {', '.join(r['episodio'] for r in ABL)}) la diferencia ajustada es "
      f"{bs:+.4f} [{los:+.4f}, {his:+.4f}]", (f018_ab < 0.18).mean() <= (d26[~rep26] < 0.18).mean() + 0.01 and his < 0)

# ───────────────────────────── colisiones ─────────────────────────────
sep("§4 — viñeta 'Colisiones'")
c15 = sum(int(float(r["colisiones_015"])) for _, _, _, r in V30)
c22 = sum(int(float(r["colisiones_022"])) for _, _, _, r in V30)
best = (9.0, None)
n15 = n22 = 0
for _, ses, ep, _ in V30:
    G = dec_de(ses, ep)
    P = np.stack([np.c_[G[a]["x"], G[a]["y"]] for a in range(5)], axis=1)       # paso × agente × 2
    for i in range(5):
        for j in range(i + 1, 5):
            dist = np.linalg.norm(P[:, i] - P[:, j], axis=1)
            n15 += int((dist < 0.15).sum()); n22 += int((dist < 0.22).sum())
            k = int(np.argmin(dist))
            if dist[k] < best[0]:
                best = (float(dist[k]), (ses, ep, int(G[i]["paso"][k]), ROBOT[i], ROBOT[j]))
cifra("4.63", "hw: colisiones < 0.15 m (CSV de episodios; pasos-par en filas)", "0", [c15],
      f"{c15} en el CSV; {n15} pasos-par < 0.15 m en las filas")
cifra("4.64", "hw: colisiones < 0.22 m", "0", [c22], f"{c22} en el CSV; {n22} pasos-par < 0.22 m en las filas")
cifra("4.65", "separación mínima entre robots en los válidos (m)", "0.2329", [best[0]],
      f"{best[0]:.5f} en {best[1][0]} ep {best[1][1]} paso {best[1][2]} (r{best[1][3]}–r{best[1][4]})")
cifra("4.66", "…en el paso 0 de s1 ep 8", "paso 0, s1 ep 8", [best[1][2], int(best[1][0][1]), best[1][1]],
      f"paso {best[1][2]}, {best[1][0]} ep {best[1][1]}")
r8 = [r for r in EP30["s1"] if int(r["episodio"]) == 8][0]
pts = [(float(r8[f"x0_a{i}"]), float(r8[f"y0_a{i}"])) for i in range(5)]
par0 = min(math.dist(pts[i], pts[j]) for i in range(5) for j in range(i + 1, 5))
nolisto = [f"r{ROBOT[i]}" for i in range(5) if (r8.get(f"col_estado_a{i}") or "").strip() != "listo"]
afirm("A4.67", "'un arranque fuera del soporte' (criterio: par inicial < 0.31 m o robots no 'listo')", "fuera del soporte",
      f"par inicial mínimo {par0:.4f} m; no 'listo': {', '.join(nolisto) or 'ninguno'}", par0 < 0.31 or bool(nolisto))
col_rep = []
c15_rep = 0
for ses, _ in SES30:
    for x in REP30[ses]:
        c15_rep += int(float(x["colisiones_015"] or 0))
        if float(x["colisiones_022"] or 0) > 0:
            col_rep.append((ses, int(x["episodio"]), int(x["semilla"]), int(x["rep"]), es_valido(x),
                            int(float(x["colisiones_022"]))))
eps_rep = sorted({(c[0], c[1], c[2]) for c in col_rep})
cifra("4.68", "réplica: episodios con pares a < 0.22 m ('en dos episodios')", "2 (dos)", [len(eps_rep)],
      f"{len(eps_rep)}: " + "; ".join(f"{s} ep {e} (semilla {sm})" for s, e, sm in eps_rep) +
      " · corridas: " + "; ".join(f"{c[0]} ep{c[1]} rep{c[3]} {'válida' if c[4] else 'INVÁLIDA'} n={c[5]}" for c in col_rep) +
      f" · < 0.15 m en la réplica: {c15_rep}")
cifra("4.69", "réplica: semilla de esos episodios", "420009", [eps_rep[0][2] if len({e[2] for e in eps_rep}) == 1 else -1],
      f"{sorted({e[2] for e in eps_rep})}")
cifra("4.70", "réplica: episodios (s1 ep 10 y s5 ep 10)", "s1 ep 10 y s5 ep 10",
      [1, 10, 5, 10] if [(e[0], e[1]) for e in eps_rep] == [("s1", 10), ("s5", 10)] else [0, 0, 0, 0],
      ", ".join(f"{e[0]} ep {e[1]}" for e in eps_rep))

sep("§4 — viñeta 'Alcance'")
cifra("4.71", "filas con pose congelada (repetida) en los válidos del 30-09", "64", [int(rep30.sum())],
      f"{int(rep30.sum())} (filas en_retroceso: {int(ret30.sum())})")

# ───────────────────────────── §1 ítem 3 ─────────────────────────────
sep("§1 ítem 3 (Resumen)")
cifra_alguno("1.3a", "'el hardware anda 3.5 cm más cerca de la pared que su réplica' (cm; va con el IC por semilla "
             "→ estimador por escenario)", "3.5", [-100 * mp["m2"], -100 * mp["m1"]],
             f"{-100 * mp['m2']:.3f} cm por escenario (→ 3.5); {-100 * mp['m1']:.3f} por pares (→ 3.6)")
cifra("1.3b", "'Pasa en 49 de 50 episodios'", "49 de 50", [mp["neg"], len(PARES)], f"{mp['neg']} de {len(PARES)}")
cifra("1.3c", "IC95 por semilla (cm)", "[−4.3, −2.8]", [100 * mp["lo2"], 100 * mp["hi2"]],
      f"[{100 * mp['lo2']:+.3f}, {100 * mp['hi2']:+.3f}]")
cifra("1.3d", "más violaciones de 0.18 m por episodio", "+0.43", [RES["viola_018"]["m1"]], f"{RES['viola_018']['m1']:+.4f}")
cifra("1.3e", "más escape (decisiones-agente)", "+11", [RES["n_escape"]["m1"]],
      f"{RES['n_escape']['m1']:+.3f} por pares; {RES['n_escape']['m2']:+.3f} por escenario")
afirm("A1.3f", "'la fracción con CBF no cambia' (IC95 incluye 0)", "no cambia",
      f"{RES['frac_cbf']['m1']:+.4f} [{RES['frac_cbf']['lo1']:+.4f}, {RES['frac_cbf']['hi1']:+.4f}]",
      RES["frac_cbf"]["lo1"] < 0 < RES["frac_cbf"]["hi1"])
cifra("1.3g", "11-09 (cm)", "4.5", [-100 * m11], f"{-100 * m11:.3f} cm")
cifra("1.3h", "26-09 (cm)", "2.6", [-100 * m26], f"{-100 * m26:.3f} cm")
cifra("1.3i", "'sin colisiones' (hw, < 0.15 y < 0.22 m)", "0", [c15 + c22], f"{c15 + c22}")
# "Una parte la pone el robot 5": la réplica no trae filas por agente; cota con el mínimo hw SIN r5 contra el
# mínimo de la réplica CON los 5 (rép_sin5 ≥ rép_todos, así que esta diferencia es una cota SUPERIOR de la
# diferencia sin r5: la verdadera es igual o más negativa).
mapa_sin5 = {(s, e): por_episodio(s, e, r)["dpmin_sin5"] for _, s, e, r in V30}
d_sin5 = np.array([mapa_sin5[(p["ses"], p["ep"])] - p["rep"]["d_pared_min"] for p in PARES])
m_s5, lo_s5, hi_s5, _ = t_ic(d_sin5)
afirm("A1.3j", "'Una parte la pone el robot 5' (brecha hw − réplica sin el r5 en el hw: cota)", "una parte",
      f"hw sin r5 − réplica (5 agentes) = {m_s5:+.4f} [{lo_s5:+.4f}, {hi_s5:+.4f}] frente a {mp['m1']:+.4f}: "
      f"el r5 aporta a lo sumo {100 * (1 - m_s5 / mp['m1']):.0f} %", 0 < 1 - m_s5 / mp["m1"] < 1)

# ───────────────────────────── §8 (repetición) ─────────────────────────────
sep("§8 'Citable' — repetición de la seguridad")
cifra_alguno("8.s1", "'el hw anda 3.5 cm más cerca de la pared que su simulación' (cm; por escenario o por pares)",
             "3.5", [-100 * mp["m2"], -100 * mp["m1"]],
             f"{-100 * mp['m2']:.3f} cm por escenario (→ 3.5); {-100 * mp['m1']:.3f} por pares (→ 3.6)")
cifra("8.s2", "(49/50)", "49/50", [mp["neg"], len(PARES)], f"{mp['neg']}/{len(PARES)}")
afirm("A8.s3", "'consistente en los tres días' (mismo signo los 3 días)", "consistente",
      f"30-09 {mp['m1']:+.4f}, 26-09 {m26:+.4f}, 11-09 {m11:+.4f}", mp["m1"] < 0 and m26 < 0 and m11 < 0)

# ───────────────────────────── contexto (no se cuenta) ─────────────────────────────
sep("contexto para las observaciones (no se cuenta)")
rp_all = np.array([float(x["d_pared_min"]) for s, _ in SES30 for x in REP30[s] if es_valido(x)])
hw_all = np.array([float(v[3]["d_pared_min"]) for v in V30])
control(f"d_pared_min de la réplica (148 corridas válidas): mediana {np.median(rp_all):.4f}, mín {rp_all.min():.4f}, "
        f"corridas < 0.15 m: {int((rp_all < 0.15).sum())}, en [0.16, 0.17): {int(((rp_all >= 0.16) & (rp_all < 0.17)).sum())}")
control(f"d_pared_min del hw (50 válidos): mediana {np.median(hw_all):.4f}; episodios < 0.15 m: {int((hw_all < 0.15).sum())}/50 "
        f"(la brecha de 3.5 cm la dan las incursiones < 0.15 m; el seguimiento a ~0.17 m también está en la réplica)")
s5v = np.array(list(mapa_sin5.values()))
control(f"hw SIN el r5 (mínimo de los otros 4 robots): mediana {np.median(s5v):.4f}, media {s5v.mean():.4f}; episodios < 0.15 m: "
        f"{int((s5v < 0.15).sum())}/50 (réplica con los 5: {int((rp_all < 0.15).sum())}/{len(rp_all)} corridas)")
vmax = max(abs(g["v"]).max() for _, s, e, _ in V30 for g in dec_de(s, e).values())
control(f"velocidad máxima ejecutada × factor = {vmax * FACTOR:.3f} m/s → 0.45 s equivalen a {0.45 * vmax * FACTOR * 100:.1f} cm "
        f"({100 * 0.45 * vmax * FACTOR / 0.18:.0f} % del margen de 0.18 m)")
control(f"otras métricas 30-09 − 26-09 ajustadas por semilla (sin Holm): f018 {FE['f018'][0]:+.4f} p {FE['f018'][3]:.3f}; "
        f"act_esc {FE['act_esc'][0]:+.3f} p {FE['act_esc'][3]:.3f}; frac_cbf {FE['frac_cbf'][0]:+.4f} p {FE['frac_cbf'][3]:.3f}")
control("consola/: no se usa; ninguna cifra del §4 sale de la consola")

print(f"\nRESUMEN {SECCION}: {N_OK} ok, {N_FALLA} fallas, {N_NOREC} no recalculables")
