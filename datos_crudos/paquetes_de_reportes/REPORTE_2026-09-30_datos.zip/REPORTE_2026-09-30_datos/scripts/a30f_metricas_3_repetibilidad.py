import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""3) Repetibilidad por semilla (mismo escenario = mismos blancos y focos del AoI
en varias sesiones). Tabla semilla × sesión, media por semilla, desvío dentro de
semilla, desvío entre semillas, ICC(1) con n0 corregido por grupos desiguales.
Principal: las 5 sesiones del 30-09 (50 válidos, 12 semillas).
Variante declarada: + 26-09 como 6.ª sesión (a) sólo semillas compartidas y
(b) también las 5 semillas del 26-09 que sólo aparecen una vez.
Entrada: a30f_metricas_tabla.csv."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import numpy as np
import pandas as pd
from scipy import stats
from a30f_metricas_comun import S30, icc1, ols, dummies, md_tabla, SP

pd.set_option("display.width", 230)
T = pd.read_csv(SP + r"\a30f_metricas_tabla.csv")
V = T[T.valido == 1].copy()
V30 = V[V.ses.isin(S30)].copy()
V30["fuera_bl"] = V30.fuera != "-"
f4 = lambda v: f"{v:.4f}"

print("=== TABLA SEMILLA × SESIÓN — cobertura del hardware (válidos) ===")
piv = V.pivot_table(index="semilla", columns="ses", values="cob")[["26-09"] + S30]
q = piv[S30]
piv["n_30"] = q.notna().sum(axis=1)
piv["media_30"] = q.mean(axis=1)
piv["sd_dentro_30"] = q.std(axis=1, ddof=1)
piv["rango_30"] = q.max(axis=1) - q.min(axis=1)
print(piv.to_string(float_format=lambda v: f"{v:.4f}", na_rep="·"))
print(f"   semillas con ≥1 válido el 30-09: {int((piv.n_30 > 0).sum())} · n por semilla: "
      f"{piv.n_30[piv.n_30 > 0].astype(int).value_counts().sort_index().to_dict()}")

fil = []
for sem, r in piv.iterrows():
    fil.append([sem] + [("·" if np.isnan(r[s]) else f4(r[s])) for s in ["26-09"] + S30]
               + [int(r.n_30), "·" if r.n_30 == 0 else f4(r.media_30),
                  "·" if r.n_30 < 2 else f4(r.sd_dentro_30), "·" if r.n_30 == 0 else f4(r.rango_30)])
print("\n=== TABLA MARKDOWN 8 — semilla × sesión (cobertura hw; '·' = no válido o no corrido) ===")
print(md_tabla(["Semilla", "26-09", "S1", "S2", "S3", "S4", "S5", "n (30-09)", "media 30-09",
                "sd dentro (ddof 1)", "rango"], fil))


def informe(df, nombre, y="cob"):
    r = icc1(df, y)
    ms = df.groupby("semilla")[y].mean()
    print(f"--- {nombre} [{y}] ---")
    print(f"   semillas a={r['a']} · N={r['N']} · n0={r['n0']:.3f} · n por semilla {df.groupby('semilla').size().value_counts().sort_index().to_dict()}")
    print(f"   sd DENTRO de semilla (√MSw, entre sesiones) = {r['sd_dentro']:.4f} · sd ENTRE semillas (componente "
          f"√((MSb−MSw)/n0)) = {r['sd_entre']:.4f}{' (estimador negativo truncado a 0)' if r['s2b_raw'] < 0 else ''}"
          f" · sd de las medias por semilla (ddof1) = {ms.std(ddof=1):.4f} · sd total (ddof1) = {r['sd_total']:.4f}")
    print(f"   MSb {r['msb']:.6f} · MSw {r['msw']:.6f} · F({r['a']-1},{r['N']-r['a']}) = {r['F']:.3f} p = {r['p']:.4g}")
    print(f"   ICC(1) = {r['icc']:.3f}  IC95 aprox. (F con n0) [{r['lo']:.3f}, {r['hi']:.3f}]")
    return r


print("\n=== ICC(1) de la cobertura, semilla como grupo ===")
R = {}
R["principal"] = informe(V30, "PRINCIPAL: 5 sesiones del 30-09 (50 válidos)")
# variante con 26-09
v26 = V[V.ses == "26-09"]
comp = v26[v26.semilla.isin(V30.semilla.unique())]
R["con26_comp"] = informe(pd.concat([V30, comp]), "VARIANTE A: + 26-09 (sólo semillas compartidas, 5 episodios)")
R["con26_todo"] = informe(pd.concat([V30, v26]), "VARIANTE B: + 26-09 completo (5 semillas 420014–18 con n=1)")
print(f"   (26-09: semillas compartidas {sorted(comp.semilla.tolist())}; exclusivas {sorted(set(v26.semilla) - set(comp.semilla))})")
# sensibilidad: sin episodios con robots fuera de su blanco al arrancar
sf = V30[~V30.fuera_bl]
R["sin_fuera"] = informe(sf, "SENSIBILIDAD: 30-09 sin episodios con robots fuera del blanco")
# sensibilidad: restando la media de sesión (quita efecto de sesión)
Vc = V30.copy()
Vc["cob_c"] = Vc.cob - Vc.groupby("ses").cob.transform("mean") + Vc.cob.mean()
R["centrado"] = informe(Vc, "SENSIBILIDAD: 30-09 centrado por sesión", "cob_c")

# episodios con robots fuera del blanco: desvío respecto de la media de SU semilla sin él
print("\n=== episodios con robots fuera de su blanco al arrancar: desvío vs la media del resto de su semilla ===")
res_f, res_n = [], []
for r_ in V30.itertuples():
    otros = V30[(V30.semilla == r_.semilla) & ~((V30.ses == r_.ses) & (V30.ep == r_.ep))].cob
    d = r_.cob - otros.mean()
    (res_f if r_.fuera_bl else res_n).append(abs(d))
    if r_.fuera_bl:
        print(f"   {r_.ses} ep {r_.ep} sem {r_.semilla} fuera {r_.fuera}: cob {r_.cob:.4f} · resto de la semilla "
              f"{otros.mean():.4f} (n={len(otros)}) · desvío {d:+.4f}")
print(f"   |desvío| medio: con robots fuera {np.mean(res_f):.4f} (n={len(res_f)}) · sin robots fuera {np.mean(res_n):.4f} "
      f"(n={len(res_n)}) · Mann-Whitney p {stats.mannwhitneyu(res_f, res_n, alternative='two-sided').pvalue:.4f}")

# bootstrap por semilla del ICC (percentil) — principal
rng = np.random.default_rng(20260930)
sems = V30.semilla.unique()
grp = {s: V30[V30.semilla == s].cob.to_numpy() for s in sems}
bs = []
for _ in range(10000):
    pick = rng.choice(sems, size=len(sems), replace=True)
    df = pd.DataFrame({"semilla": np.repeat(np.arange(len(pick)), [len(grp[s]) for s in pick]),
                       "cob": np.concatenate([grp[s] for s in pick])})
    bs.append(icc1(df, "cob")["icc"])
bs = np.array(bs)
print(f"\n   ICC(1) principal: bootstrap por semilla (10000, percentil) IC95 [{np.percentile(bs, 2.5):.3f}, "
      f"{np.percentile(bs, 97.5):.3f}] · fracción de réplicas con ICC = 0 (truncado) {np.mean(bs == 0):.3f}")

# ── modelo aditivo semilla + sesión ─────────────────────────────────────
print("\n=== descomposición semilla + sesión (efectos fijos) — 30-09 ===")
S, _ = dummies(V30.semilla)
D, _ = dummies(V30.ses)
one = np.ones((len(V30), 1))
y = V30.cob.to_numpy()
ss_full, _ = ols(np.hstack([one, S, D]), y)
ss_sem_only, _ = ols(np.hstack([one, S]), y)
gl_full = len(y) - (1 + S.shape[1] + D.shape[1])
gl_sem = len(y) - (1 + S.shape[1])
print(f"   sd residual con semilla sola = {np.sqrt(ss_sem_only/gl_sem):.4f} (gl {gl_sem}) · con semilla + sesión = "
      f"{np.sqrt(ss_full/gl_full):.4f} (gl {gl_full}) → la sesión casi no reduce el desvío dentro de semilla")

# ── otras métricas ──────────────────────────────────────────────────────
print("\n=== ICC(1) de otras métricas (principal, 30-09) ===")
fil2 = []
for k, nom in (("cob", "cobertura_aoi"), ("dpmin", "d_pared_min"), ("viola", "viola_018"), ("cbf", "frac_cbf"),
               ("esc", "n_escape"), ("act", "activaciones escape"), ("vec", "frac_vecino"),
               ("drec_min", "dist_min_robot"), ("dmin_par", "separación mín. par")):
    r = icc1(V30, k)
    print(f"   {nom:22s} ICC {r['icc']:.3f} [{r['lo']:.3f}, {r['hi']:.3f}] · sd dentro {r['sd_dentro']:.4f} · "
          f"sd entre {r['sd_entre']:.4f} · F p {r['p']:.4g}")
    fil2.append([nom, f"{r['icc']:.3f}", f"[{r['lo']:.3f}, {r['hi']:.3f}]", f"{r['sd_dentro']:.4f}",
                 f"{r['sd_entre']:.4f}", f"{r['p']:.3g}"])

print("\n=== TABLA MARKDOWN 9 — repetibilidad de la cobertura por semilla ===")
fil = []
for key, nom in (("principal", "Principal: 30-09 (5 sesiones)"),
                 ("con26_comp", "Variante A: + 26-09, semillas compartidas"),
                 ("con26_todo", "Variante B: + 26-09 completo"),
                 ("sin_fuera", "Sens.: sin robots fuera del blanco"),
                 ("centrado", "Sens.: centrado por sesión")):
    r = R[key]
    fil.append([nom, r["a"], r["N"], f"{r['n0']:.3f}", f"{r['sd_dentro']:.4f}", f"{r['sd_entre']:.4f}",
                f"{r['sd_total']:.4f}", f"{r['icc']:.3f}", f"[{r['lo']:.3f}, {r['hi']:.3f}]",
                f"F({r['a']-1},{r['N']-r['a']}) = {r['F']:.2f}, p = {r['p']:.3g}"])
print(md_tabla(["Conjunto", "semillas", "N", "n0", "sd dentro", "sd entre (comp.)", "sd total",
                "ICC(1)", "IC95 aprox.", "F"], fil))
print("\n=== TABLA MARKDOWN 10 — ICC(1) de otras métricas (30-09, 50 válidos, 12 semillas) ===")
print(md_tabla(["Métrica", "ICC(1)", "IC95 aprox.", "sd dentro", "sd entre", "p (F)"], fil2))
