import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR: control de SOLO LECTURA propio al terminar (tras importar colocacion_autonoma con -B):
foto de coordinador_enjambre ahora vs la foto 'después' del analista (que coincidió con la mía en
a30f_verif_robots_6). Sólo os.stat."""
import sys
sys.dont_write_bytecode = True
import os, datetime
RAIZ = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
SP = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
ahora = {}
for d, _, fs in os.walk(RAIZ):
    for f in fs:
        p = os.path.join(d, f)
        st = os.stat(p)
        ahora[os.path.relpath(p, RAIZ)] = (st.st_size, st.st_mtime_ns)
ref = {}
for l in open(os.path.join(SP, "a30f_robots_mtimes_despues.txt"), encoding="utf-8").read().splitlines():
    if l.strip():
        k, a, b = l.split("\t")
        ref[k] = (int(a), int(b))
nuevos = sorted(set(ahora) - set(ref)); borr = sorted(set(ref) - set(ahora)); cam = sorted(k for k in set(ref) & set(ahora) if ref[k] != ahora[k])
txt = (f"ahora={len(ahora)} ref={len(ref)} nuevos={[(k, datetime.datetime.fromtimestamp(ahora[k][1]/1e9).strftime('%H:%M:%S')) for k in nuevos]} "
       f"borrados={borr} cambiados={cam}")
open(os.path.join(SP, "a30f_verif_robots_10_solo_lectura_salida.txt"), "w", encoding="utf-8").write(txt + "\n")
print(txt)
