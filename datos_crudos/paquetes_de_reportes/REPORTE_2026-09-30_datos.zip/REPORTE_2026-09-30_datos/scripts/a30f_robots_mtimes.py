import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# Foto de (ruta, tamaño, mtime) de TODO lo que hay bajo coordinador_enjambre, para
# verificar al final que el análisis a30f_robots_ no escribió nada ahí (SOLO LECTURA).
# Uso: python -B a30f_robots_mtimes.py antes|despues
import os, sys
sys.dont_write_bytecode = True
RAIZ = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
SP = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
etiqueta = sys.argv[1]
filas = []
for d, _, fs in os.walk(RAIZ):
    for f in fs:
        p = os.path.join(d, f)
        st = os.stat(p)
        filas.append(f"{os.path.relpath(p, RAIZ)}\t{st.st_size}\t{st.st_mtime_ns}")
filas.sort()
with open(os.path.join(SP, f"a30f_robots_mtimes_{etiqueta}.txt"), "w", encoding="utf-8") as fh:
    fh.write("\n".join(filas) + "\n")
print(f"{etiqueta}: {len(filas)} archivos")
