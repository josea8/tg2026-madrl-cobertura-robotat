import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_congel_comun.py — carga común para el análisis de congelamientos y
retrocesos de las 5 sesiones del 30-09 (+ control 26-09). SÓLO LECTURA de la
carpeta de la tesis; no escribe nada (lo importan los otros a30f_congel_*.py).

Definiciones (heredadas de a30_congel_analisis.py / a26_congel_*.py):
* Secuencia = filas de un (sesión, episodio, agente), ordenadas por paso.
* Fila REPETIDA = (pose_env_x, pose_env_y, pose_env_th) EXACTAMENTE igual a la
  fila anterior de la secuencia. INICIO de evento = primera fila repetida de
  una racha. La pose del inicio es la última viva (idéntica a la anterior).
* Racha = n.º de filas repetidas consecutivas desde el inicio.
* Fila VIVA = fila no repetida.
* d_pared = min(x, 3-x, y, 3-y) en el marco del entorno.
* Calibración: env = R(rot)·(esc·lab) + tras ; lab = R^-1(env - tras)/esc.
"""
import csv, math, os, re, sys
from collections import defaultdict, Counter

D = r'C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_sesion'
SP = r'C:/Users/velas/AppData/Local/Temp/claude/C--Users-velas-OneDrive-Documents-tesis/bd144444-ab27-4353-9d36-c6c2c73e1595/scratchpad'

ESC, ROT, TX, TY = 1.0166876, 0.0084726, 1.5061547, 1.2563353
L = 3.0
PUNTOS = {'A': (2.54, 2.20), 'B': (2.82, 2.49), 'C': (2.52, 2.79)}
ROBOTS = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}

# (etiqueta, prefijo, sufijo, consola)
SESIONES = [
    ('26-09', '20260926_sesion-evaluacion_etapa7', '', 'consola_20260926.txt'),
    ('s1', '20260930_sesion-evaluacion_etapa7', '', 'consola_20260930.txt'),
    ('s2', '20260930_sesion-evaluacion_etapa7', '_02', 'consola_20260930_02.txt'),
    ('s3', '20260930_sesion-evaluacion_etapa7', '_03', 'consola_20260930_03.txt'),
    ('s4', '20260930_sesion-evaluacion_etapa7', '_04', None),          # consola NO pegada
    ('s5', '20260930_sesion-evaluacion_etapa7', '_05', 'consola_20260930_05.txt'),
]
SES30 = ['s1', 's2', 's3', 's4', 's5']
VALIDOS_ESPERADOS = {
    's1': set(range(3, 13)), 's2': {1} | set(range(4, 13)), 's3': {1, 2} | set(range(4, 12)),
    's4': set(range(1, 7)) | set(range(8, 12)), 's5': set(range(1, 6)) | set(range(7, 12)),
}


def env2lab(x, y):
    dx, dy = x - TX, y - TY
    c, s = math.cos(ROT), math.sin(ROT)
    return (c * dx + s * dy) / ESC, (-s * dx + c * dy) / ESC


def lab2env(xl, yl):
    c, s = math.cos(ROT), math.sin(ROT)
    return c * ESC * xl - s * ESC * yl + TX, s * ESC * xl + c * ESC * yl + TY


def pared(x, y):
    ds = [('x=0', x), ('x=3', L - x), ('y=0', y), ('y=3', L - y)]
    return min(ds, key=lambda t: t[1])


def cargar_decisiones(ses, pref, suf):
    g = defaultdict(list)
    with open(os.path.join(D, f'{pref}_decisiones{suf}.csv'), newline='', encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            g[(int(r['episodio']), int(r['agente']))].append(r)
    seqs = {}
    for (ep, ag), filas in sorted(g.items()):
        filas.sort(key=lambda r: int(r['paso']))
        prev = None; prev_rep = False; recs = []
        for r in filas:
            pf = (float(r['pose_env_x']), float(r['pose_env_y']), float(r['pose_env_th']))
            rep = prev is not None and pf == prev
            pw, d = pared(pf[0], pf[1])
            recs.append(dict(paso=int(r['paso']), x=pf[0], y=pf[1], th=pf[2], rep=rep,
                             ini=rep and not prev_rep, pared=pw, d=d,
                             retro=int(r.get('en_retroceso', '0') or 0),
                             v=float(r['v_ejecutada']), w=float(r['w_ejecutada']),
                             esc=int(r['en_escape']), cbf=int(r['cbf_intervino']),
                             robot=int(r['robot'])))
            prev, prev_rep = pf, rep
        seqs[(ep, ag)] = dict(ses=ses, ep=ep, ag=ag, robot=int(filas[0]['robot']), f=recs)
    return seqs


def cargar_episodios(pref, suf):
    with open(os.path.join(D, f'{pref}_episodios{suf}.csv'), newline='', encoding='utf-8-sig') as fh:
        return {int(r['episodio']): r for r in csv.DictReader(fh)}


RX_DET = re.compile(r'a(\d+):(\d+)-(\d+)\(([\d.]+)s,([\d.]+)cm,([a-z_]+)\)')


def detalle(ep_row):
    """retrocesos_detalle -> lista de dict(ag, p_ini, p_fin, dur, cm, res)"""
    out = []
    for m in RX_DET.finditer(ep_row.get('retrocesos_detalle', '') or ''):
        out.append(dict(ag=int(m.group(1)), p_ini=int(m.group(2)), p_fin=int(m.group(3)),
                        dur=float(m.group(4)), cm=float(m.group(5)), res=m.group(6)))
    return out


RX_HDR = re.compile(r'^EPISODIO (\d+)\s+\(')
RX_SYNC = re.compile(r'\[sync\] Decisi.n con pose vieja: antig.edad=(\d+) ticks .* en tick (\d+)')
RX_RET = re.compile(r'↩ agente (\d+) \(robot (\d+)\): pose repetida en \(([\d.]+), ([\d.]+)\), a ([\d.]+) m de la pared'
                    r'.*deshace ([\d.]+) s de .rdenes y sigue ([\d.]+) s m.s, ([\d.]+) cm, en ≤ ([\d.]+) s \(decisi.n (\d+)\)')
RX_VIVA = re.compile(r'▶ agente (\d+) \(robot (\d+)\): pose viva otra vez tras ([\d.]+) s')
RX_VENC = re.compile(r'frenando por pose vencida: \[([\d, ]*)\]')
RX_CIERRE = re.compile(r'>>> EPISODIO (\d+): (V.LIDO|INV.LIDO)\s*(.*)$')


def leer_consola(nombre):
    """Eventos de consola por episodio. [sync] -> paso estimado anclando el tick al
    '↩' siguiente del mismo episodio (tick = base + 10·paso)."""
    if nombre is None:
        return None
    lin = open(os.path.join(SP, nombre), encoding='utf-8', errors='replace').read().splitlines()
    ep = None
    syncs, rets, vivas, venc, cierres, perdidas = [], [], [], [], {}, []
    for k, l in enumerate(lin):
        m = RX_HDR.match(l)
        if m:
            ep = int(m.group(1)); continue
        m = RX_SYNC.search(l)
        if m:
            syncs.append(dict(ep=ep, antig=int(m.group(1)), tick=int(m.group(2)), linea=k + 1, paso=None)); continue
        m = RX_RET.search(l)
        if m:
            rets.append(dict(ep=ep, ag=int(m.group(1)), robot=int(m.group(2)), x=float(m.group(3)), y=float(m.group(4)),
                             d=float(m.group(5)), ventana=float(m.group(6)), margen=float(m.group(7)),
                             cm=float(m.group(8)), tope=float(m.group(9)), paso=int(m.group(10)), linea=k + 1)); continue
        m = RX_VIVA.search(l)
        if m:
            vivas.append(dict(ep=ep, ag=int(m.group(1)), tras=float(m.group(3)), linea=k + 1)); continue
        m = RX_VENC.search(l)
        if m:
            venc.append(dict(ep=ep, ags=[int(t) for t in m.group(1).split(',') if t.strip()], linea=k + 1)); continue
        m = RX_CIERRE.search(l)
        if m:
            cierres[int(m.group(1))] = (m.group(2), m.group(3).strip(), k + 1); continue
        if 'conexión perdida' in l:
            perdidas.append(dict(ep=ep, linea=k + 1, txt=l.strip()))
    # anclar ticks de [sync] a pasos
    base = {}
    for s in syncs:
        sig = [r for r in rets if r['ep'] == s['ep'] and r['linea'] > s['linea']]
        otro = [t for t in syncs if t['ep'] == s['ep'] and t['linea'] > s['linea']]
        if sig and (not otro or sig[0]['linea'] < otro[0]['linea']):
            s['paso'] = sig[0]['paso']
            base.setdefault(s['ep'], s['tick'] - 10 * sig[0]['paso'])
    for s in syncs:
        if s['paso'] is None and s['ep'] in base:
            s['paso'] = (s['tick'] - base[s['ep']]) // 10
    return dict(syncs=syncs, rets=rets, vivas=vivas, venc=venc, cierres=cierres, perdidas=perdidas, n_lineas=len(lin))


def entrada(f, i, k=5):
    """Desplazamiento de las últimas k filas vivas antes del índice i."""
    viv = [r for r in f[:i] if not r['rep']]
    if len(viv) < 2:
        return 0.0, 0.0, 0.0, 0
    a = viv[max(0, len(viv) - 1 - k)]
    b = viv[-1]
    dx, dy = b['x'] - a['x'], b['y'] - a['y']
    return dx, dy, math.hypot(dx, dy), b['paso'] - a['paso']


# ---------------------------------------------------------------- carga
S, E, C = {}, {}, {}
for ses, pref, suf, cons in SESIONES:
    S[ses] = cargar_decisiones(ses, pref, suf)
    E[ses] = cargar_episodios(pref, suf)
    C[ses] = leer_consola(cons)


def eventos(ses):
    res = []
    for (ep, ag), s in S[ses].items():
        f = s['f']
        for i, r in enumerate(f):
            if r['ini']:
                j = i
                while j < len(f) and f[j]['rep']:
                    j += 1
                res.append(dict(ses=ses, ep=ep, ag=ag, robot=s['robot'], s=s, i=i, j=j, r=r, racha=j - i,
                                hasta_fin=(j == len(f))))
    ini_paso = Counter((it['ep'], it['r']['paso']) for it in res)
    rep_paso = Counter()
    for (ep, ag), s in S[ses].items():
        for r in s['f']:
            if r['rep']:
                rep_paso[(ep, r['paso'])] += 1
    nag = Counter(ep for (ep, ag) in S[ses])
    for it in res:
        it['n_ini_paso'] = ini_paso[(it['ep'], it['r']['paso'])]
        it['n_rep_paso'] = rep_paso[(it['ep'], it['r']['paso'])]
        it['n_ag'] = nag[it['ep']]
    return sorted(res, key=lambda it: (it['ep'], it['r']['paso'], it['ag']))


I = {ses: eventos(ses) for ses in S}


def sync_en(ses, ep, paso):
    c = C[ses]
    if c is None:
        return 'sin consola'
    m = [s for s in c['syncs'] if s['ep'] == ep and s['paso'] == paso]
    return max(s['antig'] for s in m) if m else 0


def clasificar(it):
    """(a) Motive: un solo robot, sin evidencia de caché; (b) simultáneo ≥2 robots en la misma
    decisión; (c) otro (un solo robot con caché por pose rechazada)."""
    ses, ep, paso = it['ses'], it['ep'], it['r']['paso']
    e = E[ses][ep]
    pf, pr = int(e['poses_fallidas'] or 0), int(e['poses_rechazadas'] or 0)
    sy = sync_en(ses, ep, paso)
    if it['n_ini_paso'] >= 2:
        sub = 'flujo entero' if it['n_ini_paso'] >= it['n_ag'] else 'parcial'
        if sy == 'sin consola':
            cache = 'caché (inferido: fallidas>0)' if pf > 0 else ('¿caché? rechazos en el ep.' if pr > 0 else 'NO caché (fallidas=0, rechazadas=0 en el ep.; sin consola)')
        elif sy and sy >= 10:
            cache = 'caché: [sync] ' + str(sy) + ' ticks' + (', consulta fallida' if pf > 0 else '') + (', rechazo' if pr > 0 else '')
        else:
            cache = 'NO caché (sin [sync]; fallidas=%d, rechazadas=%d en el ep.)' % (pf, pr)
        return 'b', sub, cache
    if sy == 'sin consola':
        if pr > 0 or pf > 0:
            return 'c', 'rechazo/fallo (inferido)', f'sin consola; ep. con rechazadas={pr} ({e["poses_rechazos_motivo"]}), fallidas={pf}'
        return 'a', 'Motive', 'sin consola; ep. con fallidas=0 y rechazadas=0 → pose aceptada fresca'
    if sy and sy >= 10:
        return 'c', 'caché por rechazo' if pr > 0 else 'caché (¿?)', f'[sync] {sy} ticks; ep. rechazadas={pr} ({e["poses_rechazos_motivo"]}), fallidas={pf}'
    return 'a', 'Motive', f'sin [sync]; ep. fallidas={pf}, rechazadas={pr}'


for ses in I:
    for it in I[ses]:
        it['tipo'], it['sub'], it['evid'] = clasificar(it)
        e = E[ses][it['ep']]
        it['valido'] = int(e['valido'])
        it['dt'] = float(e['duracion_s']) / max(1, int(e['decisiones']))
        it['xl'], it['yl'] = env2lab(it['r']['x'], it['r']['y'])
        det = [d for d in detalle(e) if d['ag'] == it['ag'] and d['p_ini'] == it['r']['paso']]
        it['det'] = det[0] if det else None
        c = C[ses]
        if c is not None:
            rr = [q for q in c['rets'] if q['ep'] == it['ep'] and q['ag'] == it['ag'] and q['paso'] == it['r']['paso']]
            it['cons_ret'] = rr[0] if rr else None
        else:
            it['cons_ret'] = 'sin consola'
