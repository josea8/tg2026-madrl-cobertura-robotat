import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_deriva_explora.py — SOLO LECTURA. Vista rápida de los CSV de episodios (30-09 s1..s5 y 26-09).
import csv, os
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
F = {"26-09": "20260926_sesion-evaluacion_etapa7_episodios.csv",
     "s1": "20260930_sesion-evaluacion_etapa7_episodios.csv"}
for s in (2, 3, 4, 5):
    F[f"s{s}"] = f"20260930_sesion-evaluacion_etapa7_episodios_0{s}.csv"
for k, f in F.items():
    rows = list(csv.DictReader(open(os.path.join(R, f), encoding="utf-8")))
    print(f"== {k}  {f}  filas={len(rows)}")
    for i, r in enumerate(rows, 1):
        print(f"  fila {i:2d} ep={r['episodio']:>3} valido={r['valido']} motivo={r['motivo'][:60]!r:62} dec={r['decisiones']:>4} dur={r['duracion_s']:>8} p95={r['ciclo_p95_ms']:>7} col={r['colocacion'][:20]!r} col_motivo={r['col_motivo'][:30]!r} semilla={r['semilla']}")
# decisiones: episodios presentes y máximo paso
DF = {"26-09": "20260926_sesion-evaluacion_etapa7_decisiones.csv",
      "s1": "20260930_sesion-evaluacion_etapa7_decisiones.csv"}
for s in (2, 3, 4, 5):
    DF[f"s{s}"] = f"20260930_sesion-evaluacion_etapa7_decisiones_0{s}.csv"
for k, f in DF.items():
    mx = {}; n = {}
    for r in csv.DictReader(open(os.path.join(R, f), encoding="utf-8")):
        e = int(r["episodio"]); p = int(r["paso"])
        mx[e] = max(mx.get(e, -1), p); n[e] = n.get(e, 0) + 1
    print(f"== {k} decisiones: " + " ".join(f"{e}:{mx[e]}/{n[e]}" for e in sorted(mx)))
