import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico (4): ganancia de GIRO por robot y día (¿cambió r5 entre 26-09 y 30-09?).
Regresión de la tasa de giro medida (Δθ/dt, envuelta) sobre ω_ejecutada·factor con retardo k decisiones.
SOLO LECTURA; sin réplica. Uso: python -B a30f_critico_4.py > a30f_critico_4_salida.txt"""
import sys
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SES = {
    "26-09": ("20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
    "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv"),
    "S2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv", "20260930_sesion-evaluacion_etapa7_decisiones_02.csv"),
    "S3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv", "20260930_sesion-evaluacion_etapa7_decisiones_03.csv"),
    "S4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv", "20260930_sesion-evaluacion_etapa7_decisiones_04.csv"),
    "S5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv", "20260930_sesion-evaluacion_etapa7_decisiones_05.csv"),
}
DT, FACTOR = 0.1, 0.40
acc = {}
for s, (fe, fd) in SES.items():
    e = pd.read_csv(f"{RS}\\{fe}")
    d = pd.read_csv(f"{RS}\\{fd}")
    d = d[d.episodio.isin(set(e[e.valido == 1].episodio))].sort_values(["episodio", "agente", "paso"])
    dia = "26-09" if s == "26-09" else "30-09"
    for (ep, a), g in d.groupby(["episodio", "agente"]):
        th = g.pose_env_th.to_numpy(); w = g.w_ejecutada.to_numpy() * FACTOR; v = g.v_ejecutada.to_numpy() * FACTOR
        x, y = g.pose_env_x.to_numpy(), g.pose_env_y.to_numpy()
        rep = np.r_[False, (np.diff(x) == 0) & (np.diff(y) == 0) & (np.diff(th) == 0)]
        dth = np.angle(np.exp(1j * np.diff(th))) / DT          # tasa medida entre decisiones i→i+1
        ok = ~(rep[1:] | rep[:-1])
        ok[:60] = False                                         # fuera la rampa y el arranque
        for k in range(0, 8):
            m = ok[k:].copy()
            key = (dia, int(g.robot.iloc[0]), k)
            yy, xx = dth[k:][m], w[:len(dth) - k][m]
            a0 = acc.setdefault(key, [0.0, 0.0, 0.0, 0])
            a0[0] += float(xx @ yy); a0[1] += float(xx @ xx); a0[2] += float(yy @ yy); a0[3] += int(m.sum())
print("Ganancia de giro g = Σ(ω_cmd·ω_med)/Σ(ω_cmd²) y correlación r, por robot y día, según retardo k (decisiones de 0.1 s)")
for dia in ("26-09", "30-09"):
    print(f"  {dia}:")
    for rb in (1, 5, 8, 6, 9):
        best = max(range(8), key=lambda k: acc[(dia, rb, k)][0] / np.sqrt(acc[(dia, rb, k)][1] * acc[(dia, rb, k)][2]))
        xs = acc[(dia, rb, best)]
        g_ = xs[0] / xs[1]; r_ = xs[0] / np.sqrt(xs[1] * xs[2])
        linea = "  ".join(f"k{k}:{acc[(dia, rb, k)][0] / acc[(dia, rb, k)][1]:.2f}" for k in range(8))
        print(f"    r{rb}: mejor k={best} ({best * 100} ms) g {g_:.3f} r {r_:.3f} n {xs[3]} · {linea}")
