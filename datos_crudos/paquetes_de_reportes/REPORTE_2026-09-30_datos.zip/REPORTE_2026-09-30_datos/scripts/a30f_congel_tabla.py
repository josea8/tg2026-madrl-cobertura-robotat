import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""a30f_congel_tabla.py — tablas markdown (eventos 30-09, resumen por sesión, retrocesos por mecanismo)
a partir de a30f_congel_clase.py. SÓLO LECTURA."""
import math, sys
from collections import Counter
sys.stdout.reconfigure(encoding='utf-8')
import a30f_congel_clase as CL
K = CL.K
S, E, C, I = K.S, K.E, K.C, K.I
ORDEN = ['26-09', 's1', 's2', 's3', 's4', 's5']
MEC = {'Motive': 'retención Motive', 'caché-fallida': 'caché: consulta fallida', 'caché-rechazo': 'caché: rechazo (inclinación)', 'hipo': 'hipo de ritmo'}
GRUPO = {}
for it in [x for s in ORDEN for x in I[s]]:
    r = it['r']
    if it['mec'] not in ('Motive', 'caché-rechazo'):
        GRUPO[id(it)] = '—'; continue
    g = 'aislado'
    for nom, (cx, cy) in [('A', (2.544, 2.198)), ('B', (2.817, 2.490)), ('C', (2.531, 2.797)), ('D', (1.471, 1.269)), ('E', (2.826, 2.741))]:
        if math.hypot(r['x'] - cx, r['y'] - cy) <= 0.08:
            g = nom
    GRUPO[id(it)] = g


def neto(it):
    f = it['s']['f']; i, j = it['i'], it['j']
    if j >= len(f):
        return 'no reaparece'
    dx, dy, n, _ = K.entrada(f, i)
    ux, uy = (dx / n, dy / n) if n > 1e-6 else (math.cos(it['r']['th']), math.sin(it['r']['th']))
    al = (f[j]['x'] - it['r']['x']) * ux + (f[j]['y'] - it['r']['y']) * uy
    return f'{-100*al:+.1f}'


print('TABLA 1 — inicios de congelamiento del 30-09 (los de "flujo entero" agrupados por decisión)')
print('| ses | ep | robot(s) | paso | racha filas (≈ s) | env (x, y) | lab (x, y) | d_pared | tipo | mecanismo | evidencia | grupo | retroceso | neto retrocedido cm |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|')
for s in K.SES30:
    hechos = set()
    for it in I[s]:
        r = it['r']; d = it['det']
        if it['mec'] == 'caché-fallida':
            clave = (it['ep'], r['paso'])
            if clave in hechos:
                continue
            hechos.add(clave)
            grp = [x for x in I[s] if x['ep'] == it['ep'] and x['r']['paso'] == r['paso']]
            rob = ', '.join(str(x['robot']) for x in grp)
            print(f"| {s} | {it['ep']} ({'V' if it['valido'] else 'A'}) | {rob} | {r['paso']} | 1 (≈ {it['dt']:.2f}) | 5 poses | — | "
                  f"{min(x['r']['d'] for x in grp):.3f}–{max(x['r']['d'] for x in grp):.3f} | b | {MEC[it['mec']]} | [sync] 10 ticks, poses_fallidas 1 | — | "
                  f"5 × {d['res']} {d['dur']} s | no reaparece |")
            continue
        sy = K.sync_en(s, it['ep'], r['paso'])
        e = E[s][it['ep']]
        ev = ('sin consola; ' if sy == 'sin consola' else (f'[sync] {sy} ticks; ' if sy else 'sin [sync]; ')) + \
             f"fallidas {e['poses_fallidas']}, rechazadas {e['poses_rechazadas']}" + (f", r_prev {it['rprev_otros']:.2f} r {it['r_otros']:.2f}" if it['mec'] == 'hipo' else '')
        print(f"| {s} | {it['ep']} ({'V' if it['valido'] else 'A'}) | {it['robot']} | {r['paso']} | {it['racha']} (≈ {it['racha']*it['dt']:.2f}) | ({r['x']:.3f}, {r['y']:.3f}) | "
              f"({it['xl']:+.3f}, {it['yl']:+.3f}) | {r['d']:.3f} | {it['tipo_f']} | {MEC[it['mec']]}{' (inferido)' if it['inferido'] and it['mec'] != 'Motive' else ''} | {ev} | {GRUPO[id(it)]} | "
              f"{d['res']} {d['dur']} s, plan {d['cm']} cm | {neto(it)} |")

print()
print('TABLA 2 — resumen por sesión (inicios por tipo y mecanismo; retrocesos)')
print('| sesión | válidos/eps | filas (vivas) | inicios | (a) | (b) | (c) | Motive | caché fallida | caché rechazo | hipo | retrocesos | recuperados | sigue_congelada | ep. abortado | filas en_retroceso |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|')
for s in ORDEN:
    filas = sum(len(sq['f']) for sq in S[s].values())
    viv = sum(1 for sq in S[s].values() for r in sq['f'] if not r['rep'])
    t = Counter(it['tipo_f'] for it in I[s]); m = Counter(it['mec'] for it in I[s])
    dets = [d for e in E[s].values() for d in K.detalle(e)]
    res = Counter(d['res'] for d in dets)
    fr = sum(r['retro'] for sq in S[s].values() for r in sq['f'])
    nv = sum(1 for e in E[s].values() if e['valido'] == '1')
    print(f"| {s} | {nv}/{len(E[s])} | {filas} ({viv}) | {len(I[s])} | {t['a']} | {t['b']} | {t['c']} | {m['Motive']} | {m['caché-fallida']} | {m['caché-rechazo']} | {m['hipo']} |"
          f" {len(dets)} | {res['recuperada']} | {res['sigue_congelada']} | {res['episodio_abortado']} (+{res['fin_del_episodio']} fin_ep) | {fr} |")
