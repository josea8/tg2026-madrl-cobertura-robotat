import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Verificador a30f_verif_metricas_ (parte 3): tablas 6, 8 y 12 (f1/f2) del analista,
conversión env→lab de las distancias citadas, ubicación en marco lab de las rachas
de pose congelada del 30-09 y control 26-09 'fuera' en las semillas compartidas.
Desde cero; SOLO LECTURA; sin réplica. Salida: a30f_verif_metricas_3_salida.txt"""
import sys
sys.dont_write_bytecode = True
import os
import csv
import math
import numpy as np
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SP = (r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis"
      r"\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
OUT = open(os.path.join(SP, "a30f_verif_metricas_3_salida.txt"), "w", encoding="utf-8", newline="\n")


def P(*a):
    print(*a, file=OUT)


S30 = ["S1", "S2", "S3", "S4", "S5"]
ARCH = {"C26": "20260926_sesion-evaluacion_etapa7_episodios.csv", "S1": "20260930_sesion-evaluacion_etapa7_episodios.csv"}
for k in range(2, 6):
    ARCH[f"S{k}"] = f"20260930_sesion-evaluacion_etapa7_episodios_0{k}.csv"
ESC, ROT, TX, TY = 1.0166876, 0.0084726, 1.5061547, 1.2563353


def env_a_lab(xe, ye):
    vx, vy = xe - TX, ye - TY
    c, s = math.cos(ROT), math.sin(ROT)
    return (c * vx + s * vy) / ESC, (-s * vx + c * vy) / ESC


E = {}
for s, fn in ARCH.items():
    with open(os.path.join(RS, fn), encoding="utf-8-sig", newline="") as fh:
        E[s] = [r for r in csv.DictReader(fh) if r["valido"] == "1"]
y = np.array([float(r["cobertura_aoi"]) for s in S30 for r in E[s]])
sem = np.array([int(r["semilla"]) for s in S30 for r in E[s]])
ses = np.array([s for s in S30 for r in E[s]])
useeds = np.unique(sem)

# Tabla 8: por semilla
P("=== Tabla 8 (semilla × sesión) recalculada ===")
for k in useeds:
    fila = {s: [float(r["cobertura_aoi"]) for r in E[s] if int(r["semilla"]) == k] for s in ["C26"] + S30}
    v = y[sem == k]
    P(f"  {k}: " + " ".join(f"{s}={fila[s][0]:.4f}" if fila[s] else f"{s}=·" for s in ["C26"] + S30)
      + f" · n {len(v)} · media {v.mean():.4f} · sd {v.std(ddof=1) if len(v) > 1 else float('nan'):.4f} · rango {v.max()-v.min():.4f}")

# Tabla 6: medias de sesión ajustadas (promedio sobre las 12 semillas)
Xs = np.array([[1.0 if a == k else 0.0 for k in useeds] for a in sem])
Xd = np.array([[1.0 if a == s else 0.0 for s in S30[1:]] for a in ses])
X = np.hstack([Xs, Xd])
b = np.linalg.lstsq(X, y, rcond=None)[0]
r = y - X @ b
df = len(y) - X.shape[1]
cov = (r @ r) / df * np.linalg.inv(X.T @ X)
q = stats.t.ppf(0.975, df)
P("\n=== Tabla 6: medias de sesión ajustadas por semilla ===")
for j, s in enumerate(S30):
    L = np.r_[np.full(len(useeds), 1 / len(useeds)), np.zeros(4)]
    if j > 0:
        L[len(useeds) + j - 1] = 1.0
    m, se = L @ b, math.sqrt(L @ cov @ L)
    P(f"  {s}: cruda {y[ses == s].mean():.4f} · ajustada {m:.4f} [{m - q*se:.4f}, {m + q*se:.4f}] (gl {df})")


# Tabla 12 f1/f2
def cr1(yv, g):
    u = yv - yv.mean()
    gs = np.array([u[g == k].sum() for k in np.unique(g)])
    G = len(gs)
    return math.sqrt(G / (G - 1) * (gs ** 2).sum()) / len(yv), G


m = y.mean()
se_ses, Gs = cr1(y, ses)
se_sem, Gm = cr1(y, sem)
se_int, _ = cr1(y, np.array([f"{a}_{b_}" for a, b_ in zip(ses, sem)]))
q4 = stats.t.ppf(0.975, 4)
se_cgm = math.sqrt(max(se_sem ** 2 + se_ses ** 2 - se_int ** 2, 0))
P("\n=== Tabla 12 (f1)/(f2) ===")
P(f"  (f1) CR1 sesión: EE {se_ses:.4f} · [{m - q4*se_ses:.4f}, {m + q4*se_ses:.4f}] semiancho {q4*se_ses:.4f}")
P(f"  (f2) CGM: EE {se_cgm:.4f} · [{m - q4*se_cgm:.4f}, {m + q4*se_cgm:.4f}] semiancho {q4*se_cgm:.4f}")

# conversión env -> lab de distancias citadas (la rotación conserva distancias; sólo divide la escala)
P("\n=== distancias citadas: marco env -> lab (÷ 1.0166876) ===")
for nom, d in (("d_pared mín 30-09", 0.1120), ("d_pared mín 26-09", 0.1098), ("separación mín 30-09", 0.2329),
               ("umbral colisión 0.15", 0.15), ("umbral colisión 0.22", 0.22), ("umbral pared 0.18", 0.18)):
    P(f"  {nom}: env {d:.4f} m -> lab {d / ESC:.4f} m")

# rachas de pose congelada del 30-09 en marco lab (posiciones tomadas de a30f_verif_metricas_2_salida.txt)
P("\n=== rachas de congelamiento 30-09 (env -> lab) ===")
RACHAS = [("S1", 8, 6, 1.409, 1.244), ("S1", 9, 6, 1.545, 1.197), ("S2", 10, 8, 0.699, 1.660), ("S2", 10, 6, 1.454, 1.320),
          ("S3", 1, 8, 2.570, 2.802), ("S3", 1, 8, 2.538, 2.806), ("S3", 5, 8, 2.778, 2.768), ("S4", 1, 8, 2.868, 2.718),
          ("S4", 1, 8, 2.828, 2.713), ("S4", 6, 6, 1.487, 1.257), ("S4", 6, 6, 1.472, 1.260), ("S4", 6, 6, 1.459, 1.253),
          ("S4", 9, 5, 2.420, 0.177), ("S4", 9, 6, 1.805, 0.894), ("S5", 9, 1, 1.817, 0.853), ("S5", 9, 8, 0.967, 2.714)]
for s, ep, rb, xe, ye in RACHAS:
    xl, yl = env_a_lab(xe, ye)
    P(f"  {s} ep{ep} r{rb}: env ({xe:.3f}, {ye:.3f}) -> lab ({xl:+.3f}, {yl:+.3f}) · |lab| {math.hypot(xl, yl):.3f} m")
r6 = [(xe, ye) for s, ep, rb, xe, ye in RACHAS if rb == 6 and abs(xe - 1.5) < 0.2]
P(f"  rachas del robot 6 a < 0.2 m en x de 1.5: {len(r6)} de {sum(1 for t in RACHAS if t[2] == 6)} del robot 6 · "
  f"de {len(RACHAS)} rachas en total")

# 26-09: episodios de semillas compartidas con robots fuera
comp = {420000, 420003, 420007, 420008, 420011}
P("\n=== 26-09: episodios de semillas compartidas con robots fuera del blanco ===")
for r in E["C26"]:
    if int(r["semilla"]) in comp:
        f = [i for i in range(5) if r[f"col_estado_a{i}"] != "listo"]
        P(f"  ep{r['episodio']} sem {r['semilla']} fuera {f} estados {[r[f'col_estado_a{i}'] for i in f]} "
          f"err {[r[f'col_err_m_a{i}'] for i in f]}")
P("\nFIN")
OUT.close()
print("listo")
