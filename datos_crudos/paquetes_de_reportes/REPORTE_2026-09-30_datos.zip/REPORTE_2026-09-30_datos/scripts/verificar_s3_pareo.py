#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verificar_s3_pareo.py — verificación INDEPENDIENTE de las cifras de la comparación pareada
sim/real del REPORTE_2026-09-30.md:

  * §3 completo: validez de la réplica (148/150, reps inválidas, ruido entre reps), tabla del
    resultado preespecificado (principal y sensibilidades A y B), tabla por sesión,
    heterogeneidad, combinados declarados con 26-09 y 11-09, tabla por escenario/semilla,
    CR1, latencia y relativo +2.3 %;
  * §1, ítem 2 (incluida "la cota pasó de ±0.031 … a un semiancho de ~0.017–0.020");
  * §8, lo citable sobre la brecha.

Cálculo propio (no importa ni copia pareo_final_0930.py / pareo_extra_0930.py): medias, IC t,
Wilcoxon por aproximación normal, CR1, ANOVA, Kruskal-Wallis y regresión con efectos fijos
escritos acá. Sens. B se recalcula desde el CSV de DECISIONES con la definición del enunciado
(inicio de congelamiento = fila con (x, y, θ) idéntica a la anterior del mismo agente y
episodio), no desde la columna retrocesos_detalle.

Sólo lee csv/ del paquete (ninguna cifra de esta sección sale de consola/). Solo lectura.
Python 3 + numpy + scipy. Uso:  python verificar_s3_pareo.py

Formato:  id | descripción | valor en el reporte | recalculado | OK/FALLA
Tolerancia: media unidad del último decimal mostrado en el reporte.
"""
import csv
import math
import sys
from pathlib import Path

import numpy as np
from scipy import stats

BASE = Path(__file__).resolve().parent.parent
CSV = BASE / "csv"
CONSOLA = BASE / "consola"          # no se usa: ninguna cifra del §3 sale de la consola
SECCION = "s3_pareo"
SUF = ["", "_02", "_03", "_04", "_05"]   # s1..s5

try:  # salida en UTF-8 y fin de línea LF también al redirigir a un archivo en Windows
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
except (AttributeError, ValueError):
    pass

RES = {"ok": 0, "falla": 0, "norec": 0}
FALLAS = []


# ----------------------------------------------------------------------------- utilidades
def leer(nombre):
    with open(CSV / nombre, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def es_valido(v):
    return str(v).strip() in ("1", "True")


def _a_float(s):
    return float(s.replace("−", "-").replace("+", "").replace("%", "").replace("~", "")
                 .replace("±", "").strip())


def _decimales(s):
    t = s.replace("−", "-").replace("+", "").replace("%", "").replace("~", "").replace("±", "").strip()
    return len(t.split(".")[1]) if "." in t else 0


def num(id_, desc, reporte, valor, unidad=""):
    """Compara una cifra numérica con tolerancia = media unidad del último decimal del reporte."""
    dec = _decimales(reporte)
    tol = 0.5 * 10 ** (-dec)
    ok = abs(valor - _a_float(reporte)) <= tol * (1 + 1e-9)
    signo = "+" if reporte.strip().startswith(("+", "−", "-")) else ""
    if dec == 0 and abs(valor - round(valor)) < 1e-9:
        rec = f"{int(round(valor)):{signo}d}"
    else:
        rec = f"{valor:{signo}.{dec + 2}f}"
    rec = rec.replace("-", "−")
    est = "OK" if ok else "FALLA"
    RES["ok" if ok else "falla"] += 1
    if not ok:
        FALLAS.append(id_)
    print(f"{id_} | {desc} | {reporte}{unidad} | {rec}{unidad} | {est}")


def cat(id_, desc, reporte, valor):
    """Compara un dato categórico (texto, conjunto, signo)."""
    ok = str(reporte) == str(valor)
    RES["ok" if ok else "falla"] += 1
    if not ok:
        FALLAS.append(id_)
    print(f"{id_} | {desc} | {reporte} | {valor} | {'OK' if ok else 'FALLA'}")


def norec(id_, desc, reporte, fuente):
    RES["norec"] += 1
    print(f"{id_} | {desc} | {reporte} | — | NO RECALCULABLE (fuente: {fuente})")


def nota(txt):
    print(f"#   {txt}")


def ic_t(v):
    """media, sd(ddof=1), IC95 t, p bilateral de la t de una muestra."""
    v = np.asarray(v, float)
    n = len(v)
    m = float(v.mean())
    sd = float(math.sqrt(((v - m) ** 2).sum() / (n - 1)))
    se = sd / math.sqrt(n)
    tc = float(stats.t.ppf(0.975, n - 1))
    p = float(2 * stats.t.sf(abs(m / se), n - 1))
    return dict(n=n, m=m, sd=sd, lo=m - tc * se, hi=m + tc * se, w=tc * se, p=p)


def wilcoxon_normal(d):
    """Rango con signo, aproximación normal sin corrección de continuidad, con corrección por empates."""
    d = np.asarray(d, float)
    d = d[d != 0]
    n = len(d)
    r = stats.rankdata(np.abs(d))
    wp = r[d > 0].sum()
    mu = n * (n + 1) / 4
    _, cuenta = np.unique(np.abs(d), return_counts=True)
    var = n * (n + 1) * (2 * n + 1) / 24 - ((cuenta ** 3 - cuenta).sum()) / 48
    z = (wp - mu) / math.sqrt(var)
    return float(2 * stats.norm.sf(abs(z)))


def cr1(y, g):
    """Media con error estándar robusto por conglomerado (CR1, sólo intercepto), t con G−1 gl."""
    y = np.asarray(y, float)
    g = np.asarray(g)
    n = len(y)
    m = float(y.mean())
    e = y - m
    grupos = sorted(set(g.tolist()))
    G = len(grupos)
    sumas = np.array([e[g == k].sum() for k in grupos])
    var = (G / (G - 1)) * (sumas ** 2).sum() / n ** 2
    se = math.sqrt(var)
    tc = float(stats.t.ppf(0.975, G - 1))
    return dict(m=m, se=se, lo=m - tc * se, hi=m + tc * se, w=tc * se,
                p=float(2 * stats.t.sf(abs(m / se), G - 1)), G=G)


def anova_1via(grupos):
    todos = np.concatenate([np.asarray(x, float) for x in grupos])
    N, k = len(todos), len(grupos)
    gm = todos.mean()
    ssb = sum(len(x) * (np.mean(x) - gm) ** 2 for x in grupos)
    ssw = sum(((np.asarray(x) - np.mean(x)) ** 2).sum() for x in grupos)
    F = (ssb / (k - 1)) / (ssw / (N - k))
    return float(stats.f.sf(F, k - 1, N - k)), float(ssb / (ssb + ssw))


def kruskal(grupos):
    todos = np.concatenate([np.asarray(x, float) for x in grupos])
    N = len(todos)
    r = stats.rankdata(todos)
    H, i = 0.0, 0
    for x in grupos:
        ri = r[i:i + len(x)]
        H += ri.sum() ** 2 / len(x)
        i += len(x)
    H = 12 / (N * (N + 1)) * H - 3 * (N + 1)
    _, t = np.unique(todos, return_counts=True)
    C = 1 - (t ** 3 - t).sum() / (N ** 3 - N)
    return float(stats.chi2.sf(H / C, len(grupos) - 1))


def rss(y, cols):
    X = np.column_stack([np.ones(len(y))] + cols)
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    r = y - X @ b
    return float(r @ r), X.shape[1]


def dummies(v):
    v = np.asarray(v)
    niveles = sorted(set(v.tolist()))
    return [(v == k).astype(float) for k in niveles[1:]]


def rango_txt(ses):
    """{1,2,3,5} -> '1–3, 5' (formato del reporte)."""
    tramos = []
    for s in sorted(ses):
        if tramos and s == tramos[-1][1] + 1:
            tramos[-1][1] = s
        else:
            tramos.append([s, s])
    # el reporte escribe dos consecutivos como "1, 2" y tres o más como "1–3"
    out = []
    for a, b in tramos:
        out.append(str(a) if a == b else (f"{a}, {b}" if b == a + 1 else f"{a}–{b}"))
    return ", ".join(out)


# ----------------------------------------------------------------------------- carga 30-09
P = []           # un dict por episodio válido del hw
REP_TODAS = []   # (sesión, fila de la réplica)
INTEGRIDAD = []
for i, s in enumerate(SUF, 1):
    eps = leer(f"20260930_sesion-evaluacion_etapa7_episodios{s}.csv")
    rep = leer(f"20260930_sesion-replica_etapa7_capas-on_de-20260930{s}.csv")
    hw = {int(r["episodio"]): r for r in eps if es_valido(r["valido"])}
    for x in rep:
        REP_TODAS.append((i, x))
    filas_por_ep = {}
    for x in rep:
        filas_por_ep.setdefault(int(x["episodio"]), []).append(x)
    # integridad del pareo
    if set(filas_por_ep) != set(hw):
        INTEGRIDAD.append(f"s{i}: episodios de la réplica {sorted(filas_por_ep)} ≠ válidos {sorted(hw)}")
    for e, r in sorted(hw.items()):
        filas = filas_por_ep.get(e, [])
        for x in filas:
            if int(x["semilla"]) != int(r["semilla"]) or int(r["semilla"]) != 420000 + e - 1:
                INTEGRIDAD.append(f"s{i} ep {e}: semilla distinta")
            if abs(float(x["cobertura_hw"]) - float(r["cobertura_aoi"])) > 1e-9:
                INTEGRIDAD.append(f"s{i} ep {e}: cobertura_hw de la réplica ≠ cobertura del hw")
            if abs(float(x["error_pose_inicial_m"])) > 1e-9:
                INTEGRIDAD.append(f"s{i} ep {e}: error de pose inicial {x['error_pose_inicial_m']}")
        val = [float(x["cobertura_aoi"]) for x in filas if es_valido(x["valido"])]
        P.append(dict(
            ses=i, ep=e, sem=int(r["semilla"]), hw=float(r["cobertura_aoi"]),
            rep=float(np.mean(val)) if val else float("nan"), nval=len(val), nfilas=len(filas),
            sdrep=float(np.std(val, ddof=1)) if len(val) > 1 else float("nan"),
            p95=float(r["ciclo_p95_ms"]), fila=r))
for p in P:
    p["d"] = p["hw"] - p["rep"]

D = np.array([p["d"] for p in P])
G = np.array([p["sem"] for p in P])
SES = np.array([p["ses"] for p in P])


def por_semilla(pares):
    sem = sorted(set(p["sem"] for p in pares))
    return np.array([np.mean([p["d"] for p in pares if p["sem"] == s]) for s in sem]), sem


# ------------------------------------------------- Sens. A: arranques fuera del soporte
def par_min(r):
    pts = [(float(r[f"x0_a{k}"]), float(r[f"y0_a{k}"])) for k in range(5)]
    return min(math.dist(a, b) for j, a in enumerate(pts) for b in pts[j + 1:])


FUERA_PAR = {(p["ses"], p["ep"]) for p in P if par_min(p["fila"]) < 0.31}
FUERA_EST = {(p["ses"], p["ep"]) for p in P
             if any((p["fila"].get(f"col_estado_a{k}") or "").strip() not in ("", "listo") for k in range(5))}
FUERA_BLANCO = {(p["ses"], p["ep"]) for p in P
                if any(math.hypot(float(p["fila"][f"x0_a{k}"]) - float(p["fila"][f"blanco_x_a{k}"]),
                                  float(p["fila"][f"y0_a{k}"]) - float(p["fila"][f"blanco_y_a{k}"])) > 0.12
                       for k in range(5))}
FUERA = FUERA_PAR | FUERA_EST | FUERA_BLANCO

# ------------------------------------------- Sens. B: episodios con pose repetida (DECISIONES)
POSE_REP = set()
N_INICIOS = 0
for i, s in enumerate(SUF, 1):
    validos = {p["ep"] for p in P if p["ses"] == i}
    ult = {}
    racha = {}
    with open(CSV / f"20260930_sesion-evaluacion_etapa7_decisiones{s}.csv", encoding="utf-8", newline="") as f:
        filas = sorted(((int(r["episodio"]), int(r["agente"]), int(r["paso"]),
                         (r["pose_env_x"], r["pose_env_y"], r["pose_env_th"])) for r in csv.DictReader(f)))
    for ep, ag, paso, pose in filas:
        if ep not in validos:
            continue
        clave = (ep, ag)
        if clave in ult and ult[clave] == pose:
            if not racha.get(clave, False):
                N_INICIOS += 1
                POSE_REP.add((i, ep))
            racha[clave] = True
        else:
            racha[clave] = False
        ult[clave] = pose
RETRO_DET = {(p["ses"], p["ep"]) for p in P if (p["fila"].get("retrocesos_detalle") or "").strip()}

# ------------------------------------------------------------------- 26-09 y 11-09
def pares_otra(f_eps, f_rep, etiqueta):
    hw = {int(r["episodio"]): r for r in leer(f_eps) if es_valido(r["valido"])}
    rp = {}
    for x in leer(f_rep):
        if es_valido(x.get("valido", "1")):
            rp.setdefault(int(x["episodio"]), []).append(float(x["cobertura_aoi"]))
    out = []
    for e, r in sorted(hw.items()):
        out.append(dict(ses=etiqueta, ep=e, sem=int(r["semilla"]), hw=float(r["cobertura_aoi"]),
                        rep=float(np.mean(rp[e])), d=float(r["cobertura_aoi"]) - float(np.mean(rp[e]))))
    return out


P26 = pares_otra("20260926_sesion-evaluacion_etapa7_episodios.csv",
                 "20260926_sesion-replica_etapa7_capas-on_de-20260926.csv", "26-09")
P11 = pares_otra("20260911_sesion-evaluacion_etapa7_episodios.csv",
                 "20260912_sesion-replica_etapa7_capas-on.csv", "11-09")

# ======================================================================= SALIDA
print(f"# verificar_s3_pareo.py — §3, §1 ítem 2 y §8 (brecha) de REPORTE_2026-09-30.md")
print(f"# paquete: {BASE.name}  ·  numpy {np.__version__}  ·  scipy {__import__('scipy').__version__}")
print("# id | descripción | valor en el reporte | recalculado | OK/FALLA")
nota("integridad del pareo (semilla = 420000+ep−1, cobertura_hw de la réplica = hw, pose inicial "
     "replicada, réplica sólo de válidos): " + ("sin problemas" if not INTEGRIDAD else "; ".join(INTEGRIDAD)))

# ---------------------------------------------------------------- §3 réplica y condiciones
print("\n# §3 · Réplica y condiciones")
nfilas = sorted(set(p["nfilas"] for p in P))
cat("3a-01", "corridas de réplica por episodio válido (--reps 3)", "3", "3" if nfilas == [3] else str(nfilas))
dur = [float(x["duracion_s"]) for _, x in REP_TODAS if es_valido(x["valido"])]
dec_ep = sorted(set(int(x["decisiones_episodio"]) for _, x in REP_TODAS))
num("3a-02", f"frecuencia de decisión de la réplica = {dec_ep[0]} decisiones / mediana de duracion_s", "10",
    dec_ep[0] / float(np.median(dur)), " Hz")
norec("3a-03", "la réplica corrió de 13:39 a 15:46", "13:39 a 15:46",
      "derivados/replica_0930_todas_log.txt, INICIO 13:39:50 y FIN 15:46:50; no está en csv/")
norec("3a-04", "sha256 de la pila idéntico antes y después", "idéntico",
      "derivados/replica_0930_hashes_pila_final.txt; el paquete trae un solo juego de hashes")

# ---------------------------------------------------------------- §3 validez
print("\n# §3 · Validez de la réplica")
tot = len(REP_TODAS)
val = sum(es_valido(x["valido"]) for _, x in REP_TODAS)
inv = [(i, x) for i, x in REP_TODAS if not es_valido(x["valido"])]
num("3b-01", "corridas de réplica en total", "150", tot)
num("3b-02", "corridas de réplica válidas", "148", val)
cat("3b-03", "inválidas: rep 1 de s1 ep 4 y ep 5", "s1 rep 1 ep 4, ep 5",
    "s{} rep {} ep {}".format(inv[0][0], inv[0][1]["rep"], ", ep ".join(x["episodio"] for _, x in inv))
    if len({(i, x["rep"]) for i, x in inv}) == 1 else str([(i, x["rep"], x["episodio"]) for i, x in inv]))
cat("3b-04", "motivo de las 2 inválidas", "antigüedad de pose",
    "antigüedad de pose" if all("antigüedad de pose" in x["motivo"] for _, x in inv) else str([x["motivo"] for _, x in inv]))
dinv = {int(x["episodio"]): float(x["duracion_s"]) for _, x in inv}
num("3b-05", "s1 ep 4 rep 1 abortó a los … s", "48.6", dinv.get(4, float("nan")), " s")
num("3b-06", "s1 ep 5 rep 1 abortó a los … s", "0.26", dinv.get(5, float("nan")), " s")
num("3b-07", "episodios válidos sin ninguna rep válida ('ningún episodio quedó sin réplica')", "0",
    sum(p["nval"] == 0 for p in P))
sds = [p["sdrep"] for p in P if p["sdrep"] == p["sdrep"]]
num("3b-08", "ruido entre reps (sd ddof=1 de la cobertura): mediana", "0.0013", float(np.median(sds)))
num("3b-09", "ruido entre reps: máximo", "0.0314", max(sds))
pm = max((p for p in P if p["sdrep"] == p["sdrep"]), key=lambda p: p["sdrep"])
cat("3b-10", "episodio del ruido máximo", "s2 ep 11", f"s{pm['ses']} ep {pm['ep']}")
norec("3b-11", "pareo_final_0930.py se escribió a las 13:40", "13:40",
      "afirmación del autor; el mtime del script en scripts/ es 13:45:12")
norec("3b-12", "la regla de reps inválidas se agregó a las 13:45", "13:45",
      "docstring y mtime de scripts/pareo_final_0930.py")
norec("3b-13", "coberturas sueltas de la rep 1 de la s1 vistas antes de correr el pareo", "4",
      "lo que el autor vio en el registro en vivo; no está en csv/")
norec("3b-14", "se corrió sin cambios; sha256 en derivados/", "sha256",
      "derivados/pareo_final_0930_sha256_antes_de_correr.txt contra scripts/pareo_final_0930.py")
nota(f"ciclos > 100 ms en la réplica: " + ", ".join(
    f"s{i} rep {x['rep']} ep {x['episodio']} ({x['ciclos_sobre_100ms']})"
    for i, x in REP_TODAS if x["ciclos_sobre_100ms"] not in ("", "0")) + " — todos en la réplica de la s1")

# ---------------------------------------------------------------- §3 resultado preespecificado
print("\n# §3 · Resultado preespecificado: principal (50 válidos)")
a = ic_t(D)
num("3c-01", "principal: pares", "50", a["n"])
num("3c-02", "principal por pares: media hw − réplica", "+0.0077", a["m"])
num("3c-03", "principal por pares: sd (ddof=1)", "0.0432", a["sd"])
num("3c-04", "principal por pares: IC95 inferior", "−0.0046", a["lo"])
num("3c-05", "principal por pares: IC95 superior", "+0.0200", a["hi"])
num("3c-06", "principal por pares: t p", "0.22", a["p"])
num("3c-07", "principal por pares: Wilcoxon p (aprox. normal)", "0.43", wilcoxon_normal(D))
num("3c-08", "principal por pares: diferencias positivas (de 50)", "29", int((D > 0).sum()))
ms, sems = por_semilla(P)
b = ic_t(ms)
num("3c-09", "principal por escenario: semillas", "12", b["n"])
num("3c-10", "principal por escenario: media de las medias por semilla", "+0.0123", b["m"])
num("3c-11", "principal por escenario: sd entre semillas", "0.0308", b["sd"])
num("3c-12", "principal por escenario: IC95 inferior", "−0.0073", b["lo"])
num("3c-13", "principal por escenario: IC95 superior", "+0.0318", b["hi"])
num("3c-14", "principal por escenario: t p", "0.20", b["p"])

print("\n# §3 · Sensibilidad A: sin arranques fuera del soporte")
nota(f"criterios: par < 0.31 m → {len(FUERA_PAR)}; algún col_estado ≠ listo → {len(FUERA_EST)}; "
     f"|x0 − blanco| > 0.12 m → {len(FUERA_BLANCO)}; unión {len(FUERA)}; coinciden: {FUERA_PAR == FUERA_EST == FUERA_BLANCO}; "
     f"par mínimo del resto = {min(par_min(p['fila']) for p in P if (p['ses'], p['ep']) not in FUERA):.3f} m")
PA = [p for p in P if (p["ses"], p["ep"]) not in FUERA]
num("3c-15", "A: arranques fuera del soporte excluidos", "5", len(FUERA))
a = ic_t([p["d"] for p in PA]); b = ic_t(por_semilla(PA)[0])
num("3c-16", "A: pares", "45", a["n"])
num("3c-17", "A por pares: media", "+0.0053", a["m"])
num("3c-18", "A por pares: IC95 inferior", "−0.0078", a["lo"])
num("3c-19", "A por pares: IC95 superior", "+0.0185", a["hi"])
num("3c-20", "A por escenario: media", "+0.0101", b["m"])
num("3c-21", "A por escenario: IC95 inferior", "−0.0110", b["lo"])
num("3c-22", "A por escenario: IC95 superior", "+0.0312", b["hi"])

print("\n# §3 · Sensibilidad B: sin episodios con pose repetida (desde DECISIONES)")
nota(f"episodios válidos con algún inicio de congelamiento (decisiones): {len(POSE_REP)}, "
     f"{N_INICIOS} inicios; con retrocesos_detalle no vacío: {len(RETRO_DET)}; mismos episodios: {POSE_REP == RETRO_DET}")
PB = [p for p in P if (p["ses"], p["ep"]) not in POSE_REP]
num("3c-23", "B: episodios con pose repetida excluidos", "9", len(POSE_REP))
a = ic_t([p["d"] for p in PB]); b = ic_t(por_semilla(PB)[0])
num("3c-24", "B: pares", "41", a["n"])
num("3c-25", "B por pares: media", "+0.0092", a["m"])
num("3c-26", "B por pares: IC95 inferior", "−0.0048", a["lo"])
num("3c-27", "B por pares: IC95 superior", "+0.0232", a["hi"])
num("3c-28", "B por escenario: media", "+0.0114", b["m"])
num("3c-29", "B por escenario: IC95 inferior", "−0.0086", b["lo"])
num("3c-30", "B por escenario: IC95 superior", "+0.0314", b["hi"])

# ---------------------------------------------------------------- §3 por sesión
print("\n# §3 · Tabla por sesión")
TABLA_SES = {1: ("10", "+0.0173", "−0.0117", "+0.0462"), 2: ("10", "−0.0093", "−0.0377", "+0.0192"),
             3: ("10", "+0.0118", "−0.0275", "+0.0510"), 4: ("10", "+0.0071", "−0.0190", "+0.0332"),
             5: ("10", "+0.0115", "−0.0218", "+0.0448")}
ses_con_cero = 0
for i in range(1, 6):
    a = ic_t(D[SES == i])
    n_, m_, lo_, hi_ = TABLA_SES[i]
    num(f"3d-s{i}a", f"s{i}: n", n_, a["n"])
    num(f"3d-s{i}b", f"s{i}: hw − réplica", m_, a["m"])
    num(f"3d-s{i}c", f"s{i}: IC95 inferior", lo_, a["lo"])
    num(f"3d-s{i}d", f"s{i}: IC95 superior", hi_, a["hi"])
    ses_con_cero += a["lo"] <= 0 <= a["hi"]
grupos = [D[SES == i] for i in range(1, 6)]
num("3d-21", "heterogeneidad entre sesiones: ANOVA p", "0.72", anova_1via(grupos)[0])
num("3d-22", "heterogeneidad entre sesiones: Kruskal p", "0.83", kruskal(grupos))
r_g, _ = rss(D, dummies(G)); r_f, k_f = rss(D, dummies(G) + dummies(SES))
F = ((r_g - r_f) / 4) / (r_f / (len(D) - k_f))
nota(f"sesión ajustada por semilla (no está en el reporte): p = {stats.f.sf(F, 4, len(D) - k_f):.3f}")

# ---------------------------------------------------------------- §3 combinados declarados
print("\n# §3 · Combinados declarados")
for etq, extra, vals in (("30-09 + 26-09", P26, ("60", "+0.0085", "−0.0031", "+0.0202", "+0.0105", "17", "−0.0105", "+0.0315")),
                         ("30-09 + 26-09 + 11-09", P26 + P11, ("65", "+0.0061", "−0.0054", "+0.0175", "+0.0069", "17", "−0.0116", "+0.0253"))):
    todos = P + extra
    a = ic_t([p["d"] for p in todos]); msx, semx = por_semilla(todos); b = ic_t(msx)
    pre = "3e-1" if len(extra) == len(P26) else "3e-2"
    num(f"{pre}a", f"{etq}: pares", vals[0], a["n"])
    num(f"{pre}b", f"{etq} por pares: media", vals[1], a["m"])
    num(f"{pre}c", f"{etq} por pares: IC95 inferior", vals[2], a["lo"])
    num(f"{pre}d", f"{etq} por pares: IC95 superior", vals[3], a["hi"])
    num(f"{pre}e", f"{etq} por escenario: media", vals[4], b["m"])
    num(f"{pre}f", f"{etq} por escenario: semillas", vals[5], b["n"])
    num(f"{pre}g", f"{etq} por escenario: IC95 inferior", vals[6], b["lo"])
    num(f"{pre}h", f"{etq} por escenario: IC95 superior", vals[7], b["hi"])
nota("semillas válidas del 11-09: " + ", ".join(str(p["sem"]) for p in P11) +
     " (todas ya presentes el 30-09: el 11-09 no agrega escenarios, se suma a esos conglomerados)")

# ---------------------------------------------------------------- §3 por escenario
print("\n# §3 · Tabla por escenario (semilla)")
TABLA_SEM = {
    420000: ("2–5", "4", "0.3286", "0.3366", "−0.0081"), 420001: ("3–5", "3", "0.3231", "0.2839", "+0.0392"),
    420002: ("1, 4, 5", "3", "0.4101", "0.3198", "+0.0903"), 420003: ("1–5", "5", "0.3496", "0.3325", "+0.0171"),
    420004: ("1–5", "5", "0.3336", "0.3530", "−0.0194"), 420005: ("1–4", "4", "0.3464", "0.3320", "+0.0144"),
    420006: ("1–3, 5", "4", "0.3310", "0.3224", "+0.0086"), 420007: ("1–5", "5", "0.3738", "0.3646", "+0.0092"),
    420008: ("1–5", "5", "0.3264", "0.3246", "+0.0018"), 420009: ("1–5", "5", "0.2913", "0.2957", "−0.0044"),
    420010: ("1–5", "5", "0.3738", "0.4014", "−0.0276"), 420011: ("1, 2", "2", "0.3968", "0.3710", "+0.0258")}
cat("3f-sem", "semillas de la tabla = semillas de los 50 válidos", "420000–420011",
    f"{min(G)}–{max(G)}" if sorted(set(G.tolist())) == sorted(TABLA_SEM) else str(sorted(set(G.tolist()))))
for s, (ses_txt, n_, hw_, rp_, d_) in TABLA_SEM.items():
    q = [p for p in P if p["sem"] == s]
    cat(f"3f-{s % 100:02d}a", f"{s}: sesiones con la semilla válida", ses_txt, rango_txt({p['ses'] for p in q}))
    num(f"3f-{s % 100:02d}b", f"{s}: n", n_, len(q))
    num(f"3f-{s % 100:02d}c", f"{s}: hw (media)", hw_, float(np.mean([p["hw"] for p in q])))
    num(f"3f-{s % 100:02d}d", f"{s}: réplica (media)", rp_, float(np.mean([p["rep"] for p in q])))
    num(f"3f-{s % 100:02d}e", f"{s}: hw − réplica (media)", d_, float(np.mean([p["d"] for p in q])))
d2 = sorted(p["d"] for p in P if p["sem"] == 420002)
num("3f-90", "420002: diferencia mínima de sus 3 sesiones ('+0.087 a …')", "+0.087", d2[0])
num("3f-91", "420002: diferencia máxima de sus 3 sesiones ('… a +0.095')", "+0.095", d2[-1])
grandes = [s for s in sorted(set(G.tolist())) if len(G[G == s]) >= 2 and all(p["d"] > 0.05 for p in P if p["sem"] == s)]
cat("3f-92", "único escenario con diferencia grande (> 0.05) en todas sus repeticiones", "420002", ",".join(map(str, grandes)))
pmax = max(P, key=lambda p: abs(p["d"]))
nota(f"mayor |dif| individual: s{pmax['ses']} ep {pmax['ep']} (semilla {pmax['sem']}) {pmax['d']:+.4f}, no repetida en esa semilla")

# ---------------------------------------------------------------- §3 notas del estimador
print("\n# §3 · Notas sobre el estimador (post hoc)")
c = cr1(D, G)
num("3g-01", "CR1 por semilla: media de los 50", "+0.0077", c["m"])
num("3g-02", "CR1 por semilla: IC95 inferior", "−0.0091", c["lo"])
num("3g-03", "CR1 por semilla: IC95 superior", "+0.0244", c["hi"])
X = np.column_stack([np.array([p["p95"] for p in P])] + [(G == s).astype(float) for s in sorted(set(G.tolist()))])
beta, *_ = np.linalg.lstsq(X, D, rcond=None)
res = D - X @ beta
gl = len(D) - X.shape[1]
cov = (res @ res) / gl * np.linalg.inv(X.T @ X)
pend, se_p = beta[0], math.sqrt(cov[0, 0])
tc = stats.t.ppf(0.975, gl)
num("3g-04", "latencia: pendiente por +10 ms de p95 (efectos fijos de semilla)", "+0.0021", 10 * pend)
num("3g-05", "latencia: IC95 inferior", "−0.0076", 10 * (pend - tc * se_p))
num("3g-06", "latencia: IC95 superior", "+0.0118", 10 * (pend + tc * se_p))
num("3g-07", f"latencia: p ({gl} gl)", "0.67", float(2 * stats.t.sf(abs(pend / se_p), gl)))
rel50 = 100 * D.mean() / np.mean([p["rep"] for p in P])
num("3g-08", "brecha relativa = media de los 50 d / media de la réplica", "+2.3", rel50, " %")
ms_rep = np.array([np.mean([p["rep"] for p in P if p["sem"] == s]) for s in sems])
nota(f"con el estimador principal (por escenario) el relativo sería {100 * ms.mean() / ms_rep.mean():+.1f} %")

# ---------------------------------------------------------------- §3 lo que se puede / no se puede afirmar
print("\n# §3 · Lo que se puede afirmar / no se puede afirmar")
b = ic_t(ms)
num("3h-01", "cota inferior IC95 por escenario", "−0.0073", b["lo"])
num("3h-02", "cota inferior IC95 CR1", "−0.0091", c["lo"])
num("3h-03", "'el hw no pierde más de ~0.01' = −(peor cota inferior, por escenario y CR1)", "~0.01", -min(b["lo"], c["lo"]))
num("3h-04", "'ni en ninguna sesión': sesiones cuyo IC95 contiene 0 (de 5)", "5", ses_con_cero)
d26 = ic_t([p["d"] for p in P26])
num("3h-05", "26-09 solo: hw − réplica con capas (10 pares, 10 semillas)", "+0.013", d26["m"])
signos = {"+" if v > 0 else "−" for v in (ic_t(D)["m"], b["m"], d26["m"],
                                           ic_t([p["d"] for p in P + P26])["m"], ic_t([p["d"] for p in P + P26 + P11])["m"])}
cat("3h-06", "mismo signo que el 26-09 y los combinados", "+", "".join(sorted(signos)))
n_int = sum(1 for s in SUF for r in leer(f"20260930_sesion-evaluacion_etapa7_episodios{s}.csv") if not es_valido(r["valido"]))
num("3h-07", "intentos inválidos sin par", "7", n_int)
r0 = float(((D - D.mean()) ** 2).sum())
eta_d = 1 - r_g / r0
p_d = anova_1via([D[G == s] for s in sorted(set(G.tolist()))])[0]
HW = np.array([p["hw"] for p in P])
r0h = float(((HW - HW.mean()) ** 2).sum())
r_s_h, _ = rss(HW, dummies(SES)); r_f_h, _ = rss(HW, dummies(G) + dummies(SES))
eta_hw = (r_s_h - r_f_h) / r0h
r_s_d, _ = rss(D, dummies(SES))
eta_d2 = (r_s_d - r_f) / r0
num("3h-08", "'la semilla explica ~40 % de la varianza de la brecha' — η² de la DIFERENCIA hw − réplica (una vía)", "0.40", eta_d)
nota(f"semilla sobre la diferencia: una vía {eta_d:.3f} (p = {p_d:.3f}); en semilla + sesión {eta_d2:.3f}. "
     f"Sobre la cobertura hw (semilla + sesión, la cifra del §2): {eta_hw:.3f}")

# ---------------------------------------------------------------- §1 ítem 2
print("\n# §1 · ítem 2 (Resumen)")
a = ic_t(D)
num("1-01", "principal por escenario: escenarios", "12", b["n"])
num("1-02", "principal por escenario: pares", "50", len(D))
num("1-03", "principal por escenario: hw − réplica", "+0.0123", b["m"])
num("1-04", "principal por escenario: IC95 inferior", "−0.0073", b["lo"])
num("1-05", "principal por escenario: IC95 superior", "+0.0318", b["hi"])
num("1-06", "referencia 50 pares: n", "50", a["n"])
num("1-07", "referencia 50 pares: media", "+0.0077", a["m"])
num("1-08", "referencia 50 pares: IC95 inferior", "−0.0046", a["lo"])
num("1-09", "referencia 50 pares: IC95 superior", "+0.0200", a["hi"])
cat("1-10", "CR1: n / conglomerados", "50 / 12", f"{len(D)} / {c['G']}")
num("1-11", "CR1: media", "+0.0077", c["m"])
num("1-12", "CR1: IC95 inferior", "−0.0091", c["lo"])
num("1-13", "CR1: IC95 superior", "+0.0244", c["hi"])
num("1-14", "'−0.007 a …' (cota inferior por escenario)", "−0.007", b["lo"])
num("1-15", "'… a −0.009' (cota inferior CR1)", "−0.009", c["lo"])
num("1-16", "'no pierde más de ~0.01'", "~0.01", -min(b["lo"], c["lo"]))
sens_lo = [ic_t([p["d"] for p in PA])["lo"], ic_t(por_semilla(PA)[0])["lo"],
           ic_t([p["d"] for p in PB])["lo"], ic_t(por_semilla(PB)[0])["lo"]]
sens_hi = [ic_t([p["d"] for p in PA])["hi"], ic_t(por_semilla(PA)[0])["hi"],
           ic_t([p["d"] for p in PB])["hi"], ic_t(por_semilla(PB)[0])["hi"]]
num("1-17", "'Ninguna sensibilidad cambia esto': peor cota inferior en A y B", "~0.01", -min(sens_lo))
num("1-18", "'Ninguna sensibilidad cambia esto': IC de A y B que contienen 0 (de 4)", "4",
    sum(lo <= 0 <= hi for lo, hi in zip(sens_lo, sens_hi)))
num("1-19", "las 5 sesiones no difieren: ANOVA p", "0.72", anova_1via(grupos)[0])
v15 = ic_t([p["d"] for p in P26 + P11])
num("1-20", "cota previa (11-09 + 26-09): n", "15", v15["n"])
num("1-21", "cota previa (11-09 + 26-09): semiancho del IC95 por pares", "±0.031", v15["w"])
nota(f"11-09 + 26-09: media {v15['m']:+.4f}, IC95 [{v15['lo']:+.4f}, {v15['hi']:+.4f}]")
num("1-22", "semiancho actual, CR1 ('~0.017')", "0.017", c["w"])
num("1-23", "semiancho actual, por escenario ('… 0.020')", "0.020", ic_t(ms)["w"])
nota(f"semiancho actual por pares (ignora el agrupamiento, no citado): {ic_t(D)['w']:.4f}")

# ---------------------------------------------------------------- §8
print("\n# §8 · Citable: brecha sim-real en cobertura")
num("8-01", "brecha por escenario", "+0.012", b["m"])
num("8-02", "IC95 por escenario: inferior", "−0.007", b["lo"])
num("8-03", "IC95 por escenario: superior", "+0.032", b["hi"])
num("8-04", "media de 50 pares", "+0.008", a["m"])
num("8-05", "'no pierde más de ~0.01'", "~0.01", -min(b["lo"], c["lo"]))

print()
if FALLAS:
    print("# fallas: " + ", ".join(FALLAS))
print(f"RESUMEN {SECCION}: {RES['ok']} ok, {RES['falla']} fallas, {RES['norec']} no recalculables")
