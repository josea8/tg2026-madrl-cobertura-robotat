import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): recálculo independiente, desde cero, de las cifras
del CSV de EPISODIOS (A01, A03, A05-exceso, A08, A10, A13, A14, A17, A18, A19, A21).
SOLO LECTURA. No lee réplicas del 30-09. No usa cobertura_replica."""
import sys
sys.dont_write_bytecode = True
import csv, os, math
from collections import Counter, defaultdict
import numpy as np
from scipy import stats

D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
ARCH = {
    1: "20260930_sesion-evaluacion_etapa7_episodios.csv",
    2: "20260930_sesion-evaluacion_etapa7_episodios_02.csv",
    3: "20260930_sesion-evaluacion_etapa7_episodios_03.csv",
    4: "20260930_sesion-evaluacion_etapa7_episodios_04.csv",
    5: "20260930_sesion-evaluacion_etapa7_episodios_05.csv",
    26: "20260926_sesion-evaluacion_etapa7_episodios.csv",
}
FIJOS = {1: [3,4,5,6,7,8,9,10,11,12], 2: [1]+list(range(4,13)), 3: [1,2]+list(range(4,12)),
         4: [1,2,3,4,5,6,8,9,10,11], 5: [1,2,3,4,5,7,8,9,10,11]}
ROB = [1, 5, 8, 6, 9]


def leer(s):
    with open(os.path.join(D, ARCH[s]), encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def f(x):
    try:
        return float(x)
    except Exception:
        return float("nan")


def ms(v, ddof=1):
    v = np.asarray(v, float)
    return v.mean(), v.std(ddof=ddof), np.median(v), v.min(), v.max(), len(v)


E = {s: leer(s) for s in ARCH}
out = []
P = out.append

# ---------------- A01 validez -------------------------------------------------------------
P("== A01 validez ==")
It = Vt = 0
for s in [1, 2, 3, 4, 5, 26]:
    filas = E[s]
    val = [int(r["episodio"]) for r in filas if r["valido"].strip() == "1"]
    eps = [int(r["episodio"]) for r in filas]
    sem_ok = all(int(r["semilla"]) == 420000 + int(r["episodio"]) - 1 for r in filas)
    ok_lista = (val == FIJOS[s]) if s in FIJOS else None
    P(f"s{s}: filas={len(filas)} episodios={eps} validos={len(val)} {val} lista_fijada_ok={ok_lista} semilla_ok={sem_ok} tasa={len(val)/len(filas):.3f}")
    for r in filas:
        if r["valido"].strip() != "1":
            P(f"     inválido ep{r['episodio']}: {r['motivo']!r}  dec={r['decisiones']} dur={f(r['duracion_s']):.3f} exceso={f(r['duracion_s'])-0.1*int(r['decisiones']):+.3f} "
              f"fall={r['poses_fallidas']} rech={r['poses_rechazadas']} mot={r['poses_rechazos_motivo']!r}")
    if s != 26:
        It += len(filas); Vt += len(val)
P(f"30-09 total: intentos={It} validos={Vt} invalidos={It-Vt} tasa={Vt/It:.4f}")

# exceso de duración en válidos por sesión (A05)
P("== A03/A05 exceso duracion - 0.1*decisiones ==")
for s in [1, 2, 3, 4, 5, 26]:
    ex_v = [f(r["duracion_s"]) - 0.1 * int(r["decisiones"]) for r in E[s] if r["valido"].strip() == "1"]
    ex_i = [(r["episodio"], round(f(r["duracion_s"]) - 0.1 * int(r["decisiones"]), 3)) for r in E[s] if r["valido"].strip() != "1"]
    P(f"s{s}: válidos exceso min={min(ex_v):+.3f} max={max(ex_v):+.3f} ; inválidos {ex_i}")

# ---------------- A08 colocación -----------------------------------------------------------
P("== A08 colocación (col_estado_a{i}) ==")
tot = Counter(); por_s = defaultdict(Counter); por_r = defaultdict(Counter)
det = defaultdict(list)
for s in [1, 2, 3, 4, 5]:
    for r in E[s]:
        for a in range(5):
            e = r[f"col_estado_a{a}"].strip()
            tot[e] += 1; por_s[s][e] += 1; por_r[ROB[a]][e] += 1
            if e != "listo":
                det[s].append((int(r["episodio"]), ROB[a], e))
P(f"total robot-intentos={sum(tot.values())} {dict(tot)}")
for s in [1, 2, 3, 4, 5]:
    P(f"  s{s}: {dict(por_s[s])}  detalle={det[s]}")
for rb in ROB:
    P(f"  r{rb}: {dict(por_r[rb])}")
c26 = Counter(); d26 = []
for r in E[26]:
    for a in range(5):
        e = r[f"col_estado_a{a}"].strip(); c26[e] += 1
        if e != "listo":
            d26.append((int(r["episodio"]), ROB[a], e))
P(f"  26-09: {dict(c26)} {d26}")
P("  col_motivo por sesión: " + "; ".join(f"s{s}:{dict(Counter(r['col_motivo'] for r in E[s]))}" for s in [1,2,3,4,5,26]))

# ---------------- A10 col_t_s --------------------------------------------------------------
P("== A10 col_t_s ==")
todo = []
for s in [1, 2, 3, 4, 5, 26]:
    v = [f(r["col_t_s"]) for r in E[s]]
    m, sd, med, mn, mx, n = ms(v)
    P(f"s{s}: {m:.2f} ± {sd:.2f} (ddof1) mediana {med:.2f} n={n} [{mn:.1f},{mx:.1f}]")
    if s != 26:
        todo += v
m, sd, med, mn, mx, n = ms(todo)
P(f"30-09: {m:.2f} ± {sd:.2f} mediana {med:.2f} n={n}")
v = [f(r["col_t_s"]) for s in [1,2,3,4,5] for r in E[s] if r["valido"].strip()=="1"]
m, sd, med, mn, mx, n = ms(v)
P(f"30-09 solo válidos: {m:.2f} ± {sd:.2f} mediana {med:.2f} n={n}")

# ---------------- A13/A14 arranques ---------------------------------------------------------
P("== A13/A14 arranques en válidos ==")
listo_d = []; nolisto = []; fuera_sop = []; otros_min = []
viol_listo_fuera = 0; viol_nolisto_dentro = 0
min_pared_val = 9; cheq_viol = 0
cob_fuera = []; cob_otros = []
for s in [1, 2, 3, 4, 5]:
    for r in E[s]:
        if r["valido"].strip() != "1":
            continue
        ep = int(r["episodio"])
        pos = np.array([[f(r[f"x0_a{a}"]), f(r[f"y0_a{a}"])] for a in range(5)])
        bl = np.array([[f(r[f"blanco_x_a{a}"]), f(r[f"blanco_y_a{a}"])] for a in range(5)])
        dbl = np.hypot(*(pos - bl).T)
        est = [r[f"col_estado_a{a}"].strip() for a in range(5)]
        nl = []
        for a in range(5):
            if est[a] == "listo":
                listo_d.append(dbl[a])
                if dbl[a] > 0.12: viol_listo_fuera += 1
            else:
                nolisto.append((s, ep, ROB[a], est[a], round(dbl[a], 3)))
                nl.append(a)
                if dbl[a] <= 0.12: viol_nolisto_dentro += 1
        pares = []
        for a in range(5):
            for b in range(a + 1, 5):
                pares.append((np.hypot(*(pos[a] - pos[b])), ROB[a], ROB[b]))
        pares.sort()
        dp = np.minimum.reduce([pos[:, 0], 3 - pos[:, 0], pos[:, 1], 3 - pos[:, 1]])
        min_pared_val = min(min_pared_val, dp.min())
        if pares[0][0] < 0.15 or dp.min() < 0.20:
            cheq_viol += 1
        cob = f(r["cobertura_aoi"])
        if pares[0][0] < 0.31:
            fuera_sop.append((s, ep, int(r["semilla"]), [(round(d, 3), a, b) for d, a, b in pares if d < 0.315], nl))
            cob_fuera.append(cob)
        else:
            otros_min.append(pares[0][0]); cob_otros.append(cob)
        if nl and pares[0][0] >= 0.31:
            P(f"  !! válido con no-listo pero sin par <0.31: s{s} ep{ep}")
listo_d = np.array(listo_d)
P(f"robots listo en válidos: n={len(listo_d)} max={listo_d.max()*100:.2f} cm mediana={np.median(listo_d)*100:.2f} cm")
P(f"listo con d>0.12: {viol_listo_fuera}; no-listo con d<=0.12: {viol_nolisto_dentro}")
P(f"no-listo en válidos: n={len(nolisto)}  rango d=[{min(x[4] for x in nolisto)}, {max(x[4] for x in nolisto)}]")
for x in nolisto:
    P(f"   {x}")
P(f"válidos con par <0.31: {len(fuera_sop)}")
for x in fuera_sop:
    P(f"   s{x[0]} ep{x[1]} sem{x[2]} pares<0.315={x[3]} agentes_no_listo={x[4]}")
P(f"par mínimo de los otros {len(otros_min)}: min={min(otros_min):.4f}")
P(f"d_pared mínimo en x0 de los 50 válidos: {min_pared_val:.4f}; violaciones chequeo 0.15/0.20: {cheq_viol}")

# ---------------- A17 cobertura descriptiva -------------------------------------------------
P("== A17 cobertura_aoi (hw, descriptiva) ==")
a = ms(cob_fuera); b = ms(cob_otros); c = ms(cob_fuera + cob_otros)
P(f"fuera soporte n={a[5]}: {a[0]:.4f} ± {a[1]:.4f}; otros n={b[5]}: {b[0]:.4f} ± {b[1]:.4f}; todos n={c[5]}: {c[0]:.4f} ± {c[1]:.4f}")
u = stats.mannwhitneyu(cob_fuera, cob_otros, alternative="two-sided")
P(f"Mann-Whitney U={u.statistic:.1f} p={u.pvalue:.3f}")

# ---------------- A18 poses -----------------------------------------------------------------
P("== A18 consultas de pose ==")
for s in [1, 2, 3, 4, 5, 26]:
    cons = sum(int(f(r["poses_consultas"])) for r in E[s])
    fal = sum(int(f(r["poses_fallidas"])) for r in E[s])
    rec = sum(int(f(r["poses_rechazadas"])) for r in E[s])
    mot = Counter(r["poses_rechazos_motivo"] for r in E[s] if r["poses_rechazos_motivo"])
    by = sum(int(f(r["poses_bytes_descartados"])) for r in E[s])
    cdes = sum(int(f(r["poses_consultas_con_descarte"])) for r in E[s])
    fal_ep = [(r["episodio"], r["poses_fallidas"]) for r in E[s] if f(r["poses_fallidas"]) > 0]
    rec_ep = [(r["episodio"], r["poses_rechazadas"], r["poses_rechazos_motivo"]) for r in E[s] if f(r["poses_rechazadas"]) > 0]
    P(f"s{s}: consultas={cons} fallidas={fal} {fal_ep} rechazadas={rec} {rec_ep} bytes_desc={by} consultas_con_descarte={cdes}")

# ---------------- A19 / A21 ritmo -----------------------------------------------------------
P("== A19 p95 del ciclo ==")
p95v = {}
for s in [1, 2, 3, 4, 5, 26]:
    v = [f(r["ciclo_p95_ms"]) for r in E[s] if r["valido"].strip() == "1"]
    vt = [f(r["ciclo_p95_ms"]) for r in E[s]]
    p95v[s] = v
    m, sd, med, mn, mx, n = ms(v)
    s100_t = sum(int(f(r["ciclos_sobre_100ms"])) for r in E[s])
    s100_v = sum(int(f(r["ciclos_sobre_100ms"])) for r in E[s] if r["valido"].strip() == "1")
    dt = sum(int(r["decisiones"]) for r in E[s])
    dv = sum(int(r["decisiones"]) for r in E[s] if r["valido"].strip() == "1")
    lt25_t = sum(1 for x in vt if x < 25); lt25_v = sum(1 for x in v if x < 25)
    P(f"s{s}: válidos {m:.1f} ± {sd:.1f} (ddof1) mediana {med:.1f} [{mn:.1f}–{mx:.1f}] n={n}; "
      f">100ms TODOS={s100_t}/{dt} dec ({1000*s100_t/dt:.2f} por mil) VÁLIDOS={s100_v}/{dv} ({1000*s100_v/dv:.2f} por mil); "
      f"p95<25: todos {lt25_t}/{len(vt)} válidos {lt25_v}/{n}")
    P(f"     p95 por ep: " + " ".join(f"{r['episodio']}{'' if r['valido'].strip()=='1' else '*'}:{f(r['ciclo_p95_ms']):.1f}" for r in E[s]))
t = sum((p95v[s] for s in [1, 2, 3, 4, 5]), [])
m, sd, med, mn, mx, n = ms(t)
P(f"30-09 50 válidos: {m:.1f} ± {sd:.1f} mediana {med:.1f} [{mn:.1f}–{mx:.1f}] n={n}")
H, pk = stats.kruskal(*[p95v[s] for s in [1, 2, 3, 4, 5]])
orden = [s for s in [1, 2, 3, 4, 5] for _ in p95v[s]]
rho, pr = stats.spearmanr(orden, t)
P(f"Kruskal-Wallis H={H:.2f} p={pk:.2g}; Spearman rho={rho:+.3f} p={pr:.2g}")
u = stats.mannwhitneyu(p95v[3], p95v[2], alternative="two-sided")
P(f"MW s3 vs s2: U={u.statistic} p={u.pvalue:.3f} medianas {np.median(p95v[3]):.1f} vs {np.median(p95v[2]):.1f}")
# todos los intentos de s4 con p95 < 25
P("s4 p95<25 (todos los intentos): " + str([(r["episodio"], r["valido"], round(f(r["ciclo_p95_ms"]), 1)) for r in E[4] if f(r["ciclo_p95_ms"]) < 25]))
# Spearman sólo con todos los intentos, como control
tt = [f(r["ciclo_p95_ms"]) for s in [1,2,3,4,5] for r in E[s]]
oo = [s for s in [1,2,3,4,5] for r in E[s]]
rho2, pr2 = stats.spearmanr(oo, tt)
P(f"(control) Spearman con los 57 intentos rho={rho2:+.3f} p={pr2:.2g}")

open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "a30f_verif_robots_1_episodios_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
