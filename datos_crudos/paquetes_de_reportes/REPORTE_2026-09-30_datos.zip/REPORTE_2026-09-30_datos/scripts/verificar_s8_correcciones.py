"""
Cifras que se agregaron a REPORTE_2026-09-30.md al aplicar la verificación independiente
(1-oct): seguridad (incursiones, escape, robot 5, 11-09), pareo (η² de la semilla en la
brecha, relativo por escenario, mayor diferencia), §2 (rampa, separación en la s5), §6
(exposición del 26-09 en E y en el centro) y §7 (Spearman del p95).
Lee sólo ../csv. Uso: python -B verificar_s8_correcciones.py
"""
import csv, json, math
from pathlib import Path
import numpy as np
from scipy import stats

BASE = Path(__file__).resolve().parent.parent
CSV = BASE / "csv"
SUF = {"s1": "", "s2": "_02", "s3": "_03", "s4": "_04", "s5": "_05"}
res = {"ok": 0, "falla": 0, "nr": 0}


def leer(n):
    return list(csv.DictReader(open(CSV / n, encoding="utf-8")))


def valido(r):
    return r["valido"] in ("1", "True", "true")


def chk(i, desc, rep, val, dec=None):
    """rep = texto del reporte; tolerancia = media unidad del último decimal."""
    s = rep.replace("−", "-").replace("+", "").replace(",", ".")
    num = float(s)
    d = len(s.split(".")[1]) if "." in s else 0
    ok = abs(val - num) <= 0.5 * 10 ** (-d) + 1e-12
    res["ok" if ok else "falla"] += 1
    print(f"{i} | {desc} | {rep} | {val:.6g} | {'OK' if ok else 'FALLA'}")


def chk_ent(i, desc, rep, val):
    ok = int(rep) == int(val)
    res["ok" if ok else "falla"] += 1
    print(f"{i} | {desc} | {rep} | {val} | {'OK' if ok else 'FALLA'}")


def dpared(x, y):
    return min(x, 3 - x, y, 3 - y)


# ── carga ────────────────────────────────────────────────────────────────────
EP, DEC, REP = {}, {}, {}
for s, suf in SUF.items():
    EP[s] = leer(f"20260930_sesion-evaluacion_etapa7_episodios{suf}.csv")
    DEC[s] = leer(f"20260930_sesion-evaluacion_etapa7_decisiones{suf}.csv")
    REP[s] = leer(f"20260930_sesion-replica_etapa7_capas-on_de-20260930{suf}.csv")
EP["26"] = leer("20260926_sesion-evaluacion_etapa7_episodios.csv")
DEC["26"] = leer("20260926_sesion-evaluacion_etapa7_decisiones.csv")
REP["26"] = leer("20260926_sesion-replica_etapa7_capas-on_de-20260926.csv")


def filas_por_ep(dec):
    out = {}
    for r in dec:
        out.setdefault(int(r["episodio"]), []).append(r)
    return out


FILAS = {s: filas_por_ep(DEC[s]) for s in DEC}
P = []          # pares del 30-09
for s in SUF:
    rep_ok = {}
    for x in REP[s]:
        if valido(x):
            rep_ok.setdefault(int(x["episodio"]), []).append(x)
    for r in EP[s]:
        if not valido(r):
            continue
        e = int(r["episodio"]); xs = rep_ok[e]
        P.append(dict(ses=s, ep=e, sem=int(r["semilla"]), hw=float(r["cobertura_aoi"]),
                      sim=float(np.mean([float(x["cobertura_aoi"]) for x in xs])),
                      dp_hw=float(r["d_pared_min"]), dp_sim=float(np.mean([float(x["d_pared_min"]) for x in xs])),
                      p95=float(r["ciclo_p95_ms"]), filas=FILAS[s][e], reps=xs, row=r))

# ── §4 seguridad ─────────────────────────────────────────────────────────────
chk_ent("8.01", "§4 episodios hw con d_pared mín < 0.15 m (de 50)", "43", sum(p["dp_hw"] < 0.15 for p in P))
corridas = [x for p in P for x in p["reps"]]
chk_ent("8.02", "§4 corridas de réplica con d_pared mín < 0.15 m (de 148)", "5", sum(float(x["d_pared_min"]) < 0.15 for x in corridas))
chk_ent("8.03", "§4 corridas válidas de réplica", "148", len(corridas))
chk("8.04", "§4 mediana de d_pared mín de la réplica, por corrida (m)", "0.167", float(np.median([float(x["d_pared_min"]) for x in corridas])))
bajo = [f for p in P for f in p["filas"] if dpared(float(f["pose_env_x"]), float(f["pose_env_y"])) < 0.15]
chk_ent("8.05", "§4 filas hw < 0.15 m", "479", len(bajo))
chk_ent("8.06", "§4 de ellas con escape activo", "478", sum(int(f["en_escape"]) for f in bajo))
chk_ent("8.07", "§4 de ellas con CBF interviniendo", "5", sum(int(f["cbf_intervino"]) for f in bajo))


def agente_del_minimo(filas):
    f = min(filas, key=lambda f: dpared(float(f["pose_env_x"]), float(f["pose_env_y"])))
    return int(f["agente"])


r5 = [p for p in P if agente_del_minimo(p["filas"]) == 1]
otros = [p for p in P if agente_del_minimo(p["filas"]) != 1]
chk_ent("8.08", "§4 episodios en que el r5 (agente 1) fija el mínimo", "26", len(r5))
chk("8.09", "§4 hw − réplica en d_pared mín, episodios del r5 (cm)", "−4.6", 100 * np.mean([p["dp_hw"] - p["dp_sim"] for p in r5]))
chk("8.10", "§4 hw − réplica en d_pared mín, resto (cm)", "−2.4", 100 * np.mean([p["dp_hw"] - p["dp_sim"] for p in otros]))

# 11-09
e11 = [r for r in leer("20260911_sesion-evaluacion_etapa7_episodios.csv") if valido(r)]
r11 = {}
for x in leer("20260912_sesion-replica_etapa7_capas-on.csv"):
    if valido(x):
        r11.setdefault(int(x["episodio"]), []).append(float(x["d_pared_min"]))
d11 = [float(r["d_pared_min"]) - np.mean(r11[int(r["episodio"])]) for r in e11]
chk("8.11", "§1/§4/§8 11-09: hw − réplica en d_pared mín (cm, valor absoluto)", "4.5", -100 * np.mean(d11))
# 26-09
r26 = {}
for x in REP["26"]:
    if valido(x):
        r26.setdefault(int(x["episodio"]), []).append(float(x["d_pared_min"]))
d26 = [float(r["d_pared_min"]) - np.mean(r26[int(r["episodio"])]) for r in EP["26"] if valido(r)]
chk("8.12", "§4/§8 26-09: hw − réplica en d_pared mín (cm, valor absoluto)", "2.6", -100 * np.mean(d26))

# conteos hw<réplica / hw>réplica / empates
for i, k, rep in (("8.13", "d_pared_min", (49, 1, 0)), ("8.14", "viola_018", (3, 24, 23)),
                  ("8.15", "n_escape", (12, 36, 2)), ("8.16", "frac_cbf", (26, 24, 0))):
    h = np.array([float(p["row"][k]) for p in P]); s_ = np.array([np.mean([float(x[k]) for x in p["reps"]]) for p in P])
    got = (int((h < s_).sum()), int((h > s_).sum()), int((h == s_).sum()))
    ok = got == rep
    res["ok" if ok else "falla"] += 1
    print(f"{i} | §4 {k}: episodios hw<réplica / hw>réplica / empates | {rep} | {got} | {'OK' if ok else 'FALLA'}")

# Sin el r5: 30-09 − 26-09 en d_pared mín, efectos fijos de semilla
def ols_dia(sin_agente=None):
    y, dia, sem = [], [], []
    for s in list(SUF) + ["26"]:
        for r in EP[s]:
            if not valido(r):
                continue
            filas = FILAS[s][int(r["episodio"])]
            if sin_agente is not None:
                filas = [f for f in filas if int(f["agente"]) != sin_agente]
            y.append(min(dpared(float(f["pose_env_x"]), float(f["pose_env_y"])) for f in filas))
            dia.append(0.0 if s == "26" else 1.0); sem.append(int(r["semilla"]))
    y, dia, sem = np.array(y), np.array(dia), np.array(sem)
    us = sorted(set(sem))
    X = np.column_stack([dia] + [(sem == u).astype(float) for u in us])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta; gl = len(y) - np.linalg.matrix_rank(X)
    cov = (resid @ resid / gl) * np.linalg.pinv(X.T @ X)
    se = math.sqrt(cov[0, 0]); t = stats.t.ppf(0.975, gl)
    return beta[0], beta[0] - t * se, beta[0] + t * se, 2 * stats.t.sf(abs(beta[0] / se), gl)

b_all = ols_dia(); b_sin = ols_dia(sin_agente=1)
chk("8.17", "§4 30-09 − 26-09 en d_pared mín, ajustado por semilla (m)", "−0.033", b_all[0])
chk("8.18", "§4 idem sin el r5 (m)", "−0.020", b_sin[0])
chk("8.19", "§4 idem sin el r5, IC inferior", "−0.043", b_sin[1])
chk("8.20", "§4 idem sin el r5, IC superior", "+0.004", b_sin[2])
chk("8.21", "§4 idem sin el r5, p", "0.10", b_sin[3])
chk("8.22", "§4 aporte del r5 a la diferencia de día (fracción)", "0.40", 1 - b_sin[0] / b_all[0])
cal = json.load(open(CSV / "calibracion_medida.json", encoding="utf-8"))


def buscar(o, clave):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == clave:
                return v
            r = buscar(v, clave)
            if r is not None:
                return r
    return None


lat = cal.get("latencia_actuacion_media_s")   # el nivel superior; "_medido_en" guarda la fecha
if lat is None:
    res["nr"] += 1
    print("8.23 | §4 latencia de actuación medida el 29-08 (ms) | 603 | NO RECALCULABLE (clave ausente) |")
else:
    chk("8.23", "§4 latencia de actuación medida el 29-08 (ms)", "603", 1000 * float(lat))

# ── §3 pareo ─────────────────────────────────────────────────────────────────
d = np.array([p["hw"] - p["sim"] for p in P]); g = np.array([p["sem"] for p in P])
grupos = [d[g == u] for u in sorted(set(g))]
gm = d.mean()
eta = sum(len(x) * (x.mean() - gm) ** 2 for x in grupos) / ((d - gm) ** 2).sum()
chk("8.24", "§3 η² de la semilla en la brecha hw − réplica", "0.40", eta)
chk("8.25", "§3 ANOVA de la brecha por semilla, p", "0.028", stats.f_oneway(*grupos).pvalue)
ms_d = np.array([x.mean() for x in grupos])
ms_s = np.array([np.mean([p["sim"] for p in P if p["sem"] == u]) for u in sorted(set(g))])
chk("8.26", "§3 brecha relativa con el estimador por escenario (%)", "3.6", 100 * ms_d.mean() / ms_s.mean())
chk("8.27", "§3 brecha relativa, media de 50 pares (%)", "2.3", 100 * d.mean() / np.mean([p["sim"] for p in P]))
imax = int(np.argmax(d))
chk("8.28", "§3 mayor diferencia individual (s3 ep 2)", "+0.138", d[imax])
ok = (P[imax]["ses"], P[imax]["ep"], P[imax]["sem"]) == ("s3", 2, 420001)
res["ok" if ok else "falla"] += 1
print(f"8.29 | §3 la mayor diferencia es s3 ep 2, semilla 420001 | s3 ep2 420001 | {P[imax]['ses']} ep{P[imax]['ep']} {P[imax]['sem']} | {'OK' if ok else 'FALLA'}")

# ── §2 rampa y separación en la s5 ───────────────────────────────────────────
rampa = [p for p in P if p["ep"] == 1]
chk_ent("8.30", "§2 válidos con rampa (ep 1)", "4", len(rampa))
ok = sorted(p["ses"] for p in rampa) == ["s2", "s3", "s4", "s5"] and {p["sem"] for p in rampa} == {420000}
res["ok" if ok else "falla"] += 1
print(f"8.31 | §2 son el ep 1 de s2–s5, todos de la semilla 420000 | sí | {sorted(p['ses'] for p in rampa)} {sorted({p['sem'] for p in rampa})} | {'OK' if ok else 'FALLA'}")
chk("8.32", "§2 cobertura hw sin los 4 con rampa", "0.3466", np.mean([p["hw"] for p in P if p["ep"] != 1]))


def sep_min(filas):
    por_paso = {}
    for f in filas:
        por_paso.setdefault(int(f["paso"]), []).append((float(f["pose_env_x"]), float(f["pose_env_y"])))
    return min(math.dist(a, b) for pts in por_paso.values() for k, a in enumerate(pts) for b in pts[k + 1:])


def fe_sesion(y, ses_obj):
    y = np.array(y); x = np.array([1.0 if p["ses"] == ses_obj else 0.0 for p in P])
    us = sorted(set(g))
    X = np.column_stack([x] + [(g == u).astype(float) for u in us])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta; gl = len(y) - np.linalg.matrix_rank(X)
    se = math.sqrt((resid @ resid / gl) * np.linalg.pinv(X.T @ X)[0, 0])
    return beta[0], 2 * stats.t.sf(abs(beta[0] / se), gl)


def act_escape(filas):
    n = 0
    por_ag = {}
    for f in sorted(filas, key=lambda f: (int(f["agente"]), int(f["paso"]))):
        por_ag.setdefault(int(f["agente"]), []).append(int(f["en_escape"]))
    for v in por_ag.values():
        n += sum(1 for a, b in zip([0] + v[:-1], v) if a == 0 and b == 1)
    return n


METS = {"cobertura": [p["hw"] for p in P], "d_pared": [p["dp_hw"] for p in P],
        "viola": [float(p["row"]["viola_018"]) for p in P], "frac_cbf": [float(p["row"]["frac_cbf"]) for p in P],
        "n_escape": [float(p["row"]["n_escape"]) for p in P], "activaciones": [act_escape(p["filas"]) for p in P],
        "separacion": [sep_min(p["filas"]) for p in P]}
fe5 = {k: fe_sesion(v, "s5") for k, v in METS.items()}
pv = sorted(fe5.items(), key=lambda kv: kv[1][1])
holm = {k: min(1.0, max((len(pv) - j) * pv[j][1][1] for j in range(i + 1))) for i, (k, _) in enumerate(pv)}
chk("8.33", "§2 s5 vs resto, separación mínima entre pares (m)", "−0.071", fe5["separacion"][0])
chk("8.34", "§2 idem, p cruda", "0.034", fe5["separacion"][1])
chk("8.35", "§2 idem, p Holm sobre 7 métricas", "0.24", holm["separacion"])
otras_p = [v[1] for k, v in fe5.items() if k != "separacion"]
ok = min(otras_p) >= 0.05
res["ok" if ok else "falla"] += 1
print(f"8.36 | §2 en la s5 la única p cruda < 0.05 es la separación | sí | mín de las demás {min(otras_p):.3f} | {'OK' if ok else 'FALLA'}")
fe3 = {k: fe_sesion(v, "s3")[1] for k, v in METS.items()}
ok = min(fe3.values()) >= 0.05
res["ok" if ok else "falla"] += 1
print(f"8.37 | §2 en la s3 ninguna p cruda < 0.05 | sí | mín {min(fe3.values()):.3f} | {'OK' if ok else 'FALLA'}")

# ── §6 exposición del 26-09 en E y en el centro ──────────────────────────────
E = (2.8256, 2.7412)
pasadas_E, robots_E = 0, []
for e, filas in FILAS["26"].items():
    por_ag = {}
    for f in sorted(filas, key=lambda f: (int(f["agente"]), int(f["paso"]))):
        por_ag.setdefault(int(f["agente"]), []).append(math.dist((float(f["pose_env_x"]), float(f["pose_env_y"])), E) <= 0.08)
    for ag, v in por_ag.items():
        n = sum(1 for a, b in zip([False] + v[:-1], v) if b and not a)
        pasadas_E += n; robots_E += [ag] * n
chk_ent("8.38", "§6 pasadas del 26-09 por E (disco de 8 cm)", "7", pasadas_E)
ok = 2 not in robots_E
res["ok" if ok else "falla"] += 1
print(f"8.39 | §6 ninguna del r8 (agente 2) | sí | agentes {sorted(robots_E)} | {'OK' if ok else 'FALLA'}")
O = (1.5061547, 1.2563353)   # origen del lab en env
eps_r6 = sum(1 for e, filas in FILAS["26"].items()
             if any(int(f["agente"]) == 3 and math.dist((float(f["pose_env_x"]), float(f["pose_env_y"])), O) <= 0.10 for f in filas))
chk_ent("8.40", "§6 episodios del 26-09 en que el r6 pasó a ≤ 10 cm del origen del lab", "2", eps_r6)

# ── §7 Spearman del p95 contra el orden de sesión ────────────────────────────
orden = [int(p["ses"][1]) for p in P]
rho, prho = stats.spearmanr(orden, [p["p95"] for p in P])
chk("8.41", "§7 Spearman p95 vs orden de sesión, ρ", "−0.753", rho)
chk("8.42", "§7 idem, p (×1e-10)", "2.9", prho * 1e10)

print(f"RESUMEN s8_correcciones: {res['ok']} ok, {res['falla']} fallas, {res['nr']} no recalculables")
