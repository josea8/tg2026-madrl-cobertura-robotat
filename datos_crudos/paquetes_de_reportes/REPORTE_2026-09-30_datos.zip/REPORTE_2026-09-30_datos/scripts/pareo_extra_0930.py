"""
COMPLEMENTOS POST HOC del pareo del 30-09 (escritos DESPUÉS de ver la salida de
pareo_final_0930.py; no forman parte del análisis preespecificado y se rotulan así).

  1. Tabla por episodio (sesión, ep, semilla, hw, réplica, reps válidas, dif, banderas).
  2. IC de la dif. de cobertura con CR1 por semilla (mismo método que la tabla del hw).
  3. Seguridad PAREADA hw − réplica por episodio: d_pared_min, viola_018, frac_cbf,
     n_escape; IC por pares y por semilla (media de medias, t con k−1 gl).
  4. Ruido entre reps de la réplica: episodios con sd > 0.01.
  5. Ritmo del lazo en la RÉPLICA (sin WiFi): ciclo_p95_ms por archivo vs la réplica del
     26-09 → separa PC de red como causa del lazo lento del hw del 30-09.
  6. ¿La brecha depende de la latencia del hw? d vs ciclo_p95 del hw con efectos fijos de
     semilla (Frisch–Waugh).
Uso: python pareo_extra_0930.py [carpeta_csv]
"""
import csv, math, sys
from pathlib import Path
import numpy as np
from scipy import stats

_PAQUETE = Path(__file__).resolve().parent.parent / "csv"
RS = (Path(sys.argv[1]) if len(sys.argv) > 1 else
      _PAQUETE if _PAQUETE.is_dir() else
      Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"))
SES = [(f"s{i}", f"20260930_sesion-evaluacion_etapa7_episodios{s}.csv",
        f"20260930_sesion-replica_etapa7_capas-on_de-20260930{s}.csv")
       for i, s in ((1, ""), (2, "_02"), (3, "_03"), (4, "_04"), (5, "_05"))]
SEG = ("d_pared_min", "viola_018", "frac_cbf", "n_escape")


def leer(n):
    return list(csv.DictReader(open(RS / n, encoding="utf-8")))


def fuera(r, n=5):
    pts, mal = [], False
    for i in range(n):
        x0, y0 = float(r[f"x0_a{i}"]), float(r[f"y0_a{i}"])
        pts.append((x0, y0))
        if (r.get(f"col_estado_a{i}") or "listo").strip() != "listo":
            mal = True
    dmin = min(math.dist(p, q) for k, p in enumerate(pts) for q in pts[k + 1:])
    return mal or dmin < 0.31


def t_ic(v):
    v = np.asarray(v, float); n = len(v); m = v.mean(); sd = v.std(ddof=1)
    w = stats.t.ppf(0.975, n - 1) * sd / math.sqrt(n)
    return m, sd, m - w, m + w, stats.ttest_1samp(v, 0).pvalue


def cr1(y, g):
    """Media con EE robusto por conglomerado (CR1), t con G−1 gl."""
    y = np.asarray(y, float); g = np.asarray(g); m = y.mean(); n = len(y)
    grupos = np.unique(g); G = len(grupos)
    s = np.array([np.sum(y[g == k] - m) for k in grupos])
    var = (G / (G - 1)) * ((n - 1) / (n - 1)) * np.sum(s ** 2) / n ** 2
    ee = math.sqrt(var); w = stats.t.ppf(0.975, G - 1) * ee
    return m, ee, m - w, m + w, 2 * stats.t.sf(abs(m / ee), G - 1)


P, ciclos_rep = [], {}
for et, fe, fr in SES:
    hw = {int(r["episodio"]): r for r in leer(fe) if r["valido"] in ("1", "True")}
    rep = leer(fr)
    ciclos_rep[et] = [float(x["ciclo_p95_ms"]) for x in rep if x.get("ciclo_p95_ms") and x["valido"] in ("1", "True")]
    por = {}
    for x in rep:
        if x["valido"] in ("1", "True"):
            por.setdefault(int(x["episodio"]), []).append(x)
    for e, r in sorted(hw.items()):
        xs = por[e]
        P.append(dict(ses=et, ep=e, sem=int(r["semilla"]), hw=float(r["cobertura_aoi"]),
                      rep=np.mean([float(x["cobertura_aoi"]) for x in xs]),
                      sdrep=np.std([float(x["cobertura_aoi"]) for x in xs], ddof=1) if len(xs) > 1 else float("nan"),
                      nrep=len(xs), fuera=fuera(r), retro=bool((r.get("retrocesos_detalle") or "").strip()),
                      p95=float(r["ciclo_p95_ms"]),
                      seg_hw={k: float(r[k]) for k in SEG},
                      seg_rep={k: np.mean([float(x[k]) for x in xs]) for k in SEG},
                      col022_rep=sum(float(x["colisiones_022"]) for x in xs)))

print("1. TABLA POR EPISODIO")
print("ses ep  semilla   hw      réplica  reps  sd_reps  dif      banderas")
for p in P:
    b = ",".join(k for k, v in (("fuera", p["fuera"]), ("pose_rep", p["retro"])) if v)
    print(f"{p['ses']}  {p['ep']:2d}  {p['sem']}  {p['hw']:.4f}  {p['rep']:.4f}   {p['nrep']}    {p['sdrep']:.4f}  {p['hw']-p['rep']:+.4f}  {b}")

d = np.array([p["hw"] - p["rep"] for p in P]); g = np.array([p["sem"] for p in P])
m, ee, lo, hi, pv = cr1(d, g)
print(f"\n2. dif. cobertura, CR1 por semilla (12 gl−1=11): {m:+.4f}  EE {ee:.4f}  IC95 [{lo:+.4f}, {hi:+.4f}]  p {pv:.4f}")
print(f"   relativo a la réplica: {100 * d.mean() / np.mean([p['rep'] for p in P]):+.1f} %")

print("\n3. SEGURIDAD PAREADA hw − réplica (50 episodios)")
for k in SEG:
    dk = np.array([p["seg_hw"][k] - p["seg_rep"][k] for p in P])
    m1, sd1, lo1, hi1, p1 = t_ic(dk)
    ms = [np.mean([dk[i] for i in range(len(P)) if P[i]["sem"] == s]) for s in sorted(set(g))]
    m2, sd2, lo2, hi2, p2 = t_ic(ms)
    neg = int((dk < 0).sum())
    print(f"   {k:12s} pares {m1:+.4f} [{lo1:+.4f}, {hi1:+.4f}] p {p1:.2g} (negativas {neg}/50) · por semilla {m2:+.4f} [{lo2:+.4f}, {hi2:+.4f}] p {p2:.2g}")
print(f"   colisiones_022 en la réplica: {[(p['ses'], p['ep'], p['col022_rep']) for p in P if p['col022_rep'] > 0]}")

print("\n4. RUIDO ENTRE REPS > 0.01:", [(p["ses"], p["ep"], p["sem"], round(p["sdrep"], 4)) for p in P if p["sdrep"] == p["sdrep"] and p["sdrep"] > 0.01])

print("\n5. CICLO p95 DE LA RÉPLICA (ms, corridas válidas)")
r26 = [float(x["ciclo_p95_ms"]) for x in leer("20260926_sesion-replica_etapa7_capas-on_de-20260926.csv") if x["valido"] in ("1", "True")]
print(f"   réplica 26-09: mediana {np.median(r26):.1f} [{min(r26):.1f}, {max(r26):.1f}] n={len(r26)}")
todos = []
for et, v in ciclos_rep.items():
    todos += v
    print(f"   réplica {et}: mediana {np.median(v):.1f} [{min(v):.1f}, {max(v):.1f}] n={len(v)}")
print(f"   réplica 30-09 total: mediana {np.median(todos):.1f}  · Mann-Whitney vs 26-09 p {stats.mannwhitneyu(todos, r26).pvalue:.3g}")
hw26 = [float(x["ciclo_p95_ms"]) for x in leer("20260926_sesion-evaluacion_etapa7_episodios.csv") if x["valido"] in ("1", "True")]
print(f"   hw 26-09 mediana {np.median(hw26):.1f} · hw 30-09 mediana {np.median([p['p95'] for p in P]):.1f}")

print("\n6. ¿BRECHA vs LATENCIA DEL HW? (efectos fijos de semilla)")
x = np.array([p["p95"] for p in P])
def dem(v):
    out = v.astype(float).copy()
    for s in set(g):
        out[g == s] -= v[g == s].mean()
    return out
xd, yd = dem(x), dem(d)
b = (xd @ yd) / (xd @ xd)
res = yd - b * xd
gl = len(d) - len(set(g)) - 1
se = math.sqrt((res @ res) / gl / (xd @ xd))
print(f"   pendiente {10 * b:+.4f} por +10 ms  IC95 [{10 * (b - stats.t.ppf(0.975, gl) * se):+.4f}, {10 * (b + stats.t.ppf(0.975, gl) * se):+.4f}]  p {2 * stats.t.sf(abs(b / se), gl):.3f}")

print("\n7. POR SEMILLA (escenario): n, hw, réplica, dif")
for s in sorted(set(g)):
    q = [p for p in P if p["sem"] == s]
    print(f"   {s}  n={len(q)}  hw {np.mean([p['hw'] for p in q]):.4f}  réplica {np.mean([p['rep'] for p in q]):.4f}  "
          f"dif {np.mean([p['hw'] - p['rep'] for p in q]):+.4f}  sesiones {','.join(p['ses'][1] for p in q)}")
