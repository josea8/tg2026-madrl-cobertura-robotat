"""Verificación independiente de las cifras del §2 ("Las corridas") de REPORTE_2026-09-30.md,
del ítem 1 del §1 (Resumen) y de la línea "Evaluación física" del "Citable" del §8.

Autocontenido: Python 3 + numpy + scipy. Lee SÓLO csv/ y consola/ del paquete (rutas relativas
a este archivo). No importa ni reutiliza ningún otro script del paquete. Sólo lectura.

Salida: una línea por cifra
    id | descripción | valor en el reporte | recalculado | OK/FALLA
y al final exactamente:
    RESUMEN s2_corridas: <n> ok, <m> fallas, <k> no recalculables

Tolerancia: media unidad del último decimal mostrado en el reporte.
Definiciones (del encargo): válidos = 'valido' en ('1', 'True'); semilla = 420000 + ep − 1;
agentes 0..4 = robots 1, 5, 8, 6, 9; d_pared = min(x, 3−x, y, 3−y) en el marco env;
pose repetida = (x, y, θ) idéntica a la fila anterior del mismo agente y episodio;
desvíos con ddof = 1 salvo aviso; env = R(rot)·(escala·lab) + tras.
"""
import csv
import json
import re
import sys
from pathlib import Path

import numpy as np
from scipy import stats

try:
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
except Exception:  # pragma: no cover
    pass

BASE = Path(__file__).resolve().parent.parent
CSV = BASE / "csv"
CON = BASE / "consola"
SEC = "s2_corridas"
ROBOT = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
SES30 = ["s1", "s2", "s3", "s4", "s5"]
SUF = {"s1": "", "s2": "_02", "s3": "_03", "s4": "_04", "s5": "_05"}
ORDEN = {"s1": 1, "s2": 2, "s3": 3, "s4": 4, "s5": 5}
CONSOLA = {"c26": "consola_20260926.txt", "s1": "consola_20260930.txt", "s2": "consola_20260930_02.txt",
           "s3": "consola_20260930_03.txt", "s5": "consola_20260930_05.txt"}
PUNTO_C = (2.52, 2.79)  # punto C del 26-09 (marco env), §6 del reporte

# ───────────────────────────── registro de resultados ─────────────────────────────
CONT = {"ok": 0, "falla": 0, "nr": 0}
FALLAS = []


def _f(s):
    return float(s.replace("−", "-").replace("+", "").replace(" ", "").replace("%", "").replace("≈", ""))


def _dec(s):
    s = s.replace("−", "-").replace("+", "").replace("%", "").strip()
    return len(s.split(".")[1]) if "." in s else 0


def _linea(i, desc, rep, calc, estado):
    print(f"{i} | {desc} | {rep} | {calc} | {estado}")


def num(i, desc, rep, val, escala=1.0):
    """Cifra numérica: |val·escala − rep| ≤ 0.5·10^−dec(rep)."""
    r = _f(rep)
    d = _dec(rep)
    v = val * escala
    tol = 0.5 * 10 ** (-d) + 1e-12
    ok = abs(v - r) <= tol
    calc = f"{v:+.{d + 2}f}" if rep.strip()[:1] in "+−-" else f"{v:.{d + 2}f}"
    _reg(i, desc, rep, calc, ok)


def txt(i, desc, rep, calc, ok):
    _reg(i, desc, rep, calc, bool(ok))


def _reg(i, desc, rep, calc, ok):
    CONT["ok" if ok else "falla"] += 1
    if not ok:
        FALLAS.append(i)
    _linea(i, desc, rep, calc, "OK" if ok else "FALLA")


def nr(i, desc, rep, fuente):
    CONT["nr"] += 1
    _linea(i, desc, rep, f"NO RECALCULABLE (fuente: {fuente})", "NO RECALCULABLE")


# ───────────────────────────── lectura ─────────────────────────────
def leer(nombre):
    with open(CSV / nombre, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def es_valido(r):
    return str(r["valido"]).strip() in ("1", "True")


def leer_dec(nombre):
    """ep → dict con arreglos (pasos, 5): x, y, th, esc, cbf; y pasos."""
    tmp = {}
    with open(CSV / nombre, encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            ep, ag, p = int(r["episodio"]), int(r["agente"]), int(r["paso"])
            tmp.setdefault(ep, []).append((p, ag, float(r["pose_env_x"]), float(r["pose_env_y"]),
                                           float(r["pose_env_th"]), int(float(r["en_escape"])),
                                           int(float(r["cbf_intervino"])), int(r["robot"])))
    out = {}
    for ep, filas in tmp.items():
        filas.sort()
        pasos = sorted({f[0] for f in filas})
        n = len(pasos)
        assert len(filas) == 5 * n, f"faltan filas en ep {ep}"
        A = np.array([f[2:] for f in filas], float).reshape(n, 5, 6)
        assert pasos == list(range(pasos[0], pasos[0] + n)), "pasos no consecutivos"
        rob = np.array([f[7] for f in filas]).reshape(n, 5)
        assert (rob == np.array([ROBOT[a] for a in range(5)])[None, :]).all(), "mapeo agente-robot"
        out[ep] = dict(x=A[:, :, 0], y=A[:, :, 1], th=A[:, :, 2], esc=A[:, :, 3], cbf=A[:, :, 4],
                       pasos=np.array(pasos), filas=len(filas))
    return out


EP = {s: leer(f"20260930_sesion-evaluacion_etapa7_episodios{SUF[s]}.csv") for s in SES30}
EP["c26"] = leer("20260926_sesion-evaluacion_etapa7_episodios.csv")
DEC = {s: leer_dec(f"20260930_sesion-evaluacion_etapa7_decisiones{SUF[s]}.csv") for s in SES30}
DEC["c26"] = leer_dec("20260926_sesion-evaluacion_etapa7_decisiones.csv")
REP = {s: leer(f"20260930_sesion-replica_etapa7_capas-on_de-20260930{SUF[s]}.csv") for s in SES30}

try:
    _cal = json.load(open(CSV / "calibracion_medida.json", encoding="utf-8"))
    ESC, ROT = float(_cal["escala_posicion"]), float(_cal["rotacion_marco_rad"])
    TRAS = np.array([float(_cal["traslacion_x_m"]), float(_cal["traslacion_y_m"])])
except Exception:
    ESC, ROT, TRAS = 1.0166876, 0.0084726, np.array([1.5061547, 1.2563353])


def env_a_lab(x, y):
    c, s = np.cos(-ROT), np.sin(-ROT)
    dx, dy = x - TRAS[0], y - TRAS[1]
    return (c * dx - s * dy) / ESC, (s * dx + c * dy) / ESC


def repetidas(d):
    """(pasos, 5) bool: fila idéntica en (x, y, θ) a la anterior del mismo agente."""
    r = np.zeros_like(d["x"], bool)
    r[1:] = (d["x"][1:] == d["x"][:-1]) & (d["y"][1:] == d["y"][:-1]) & (d["th"][1:] == d["th"][:-1])
    return r


def metricas_dec(d):
    """Métricas de un episodio recalculadas desde el CSV de decisiones."""
    dp = np.minimum.reduce([d["x"], 3 - d["x"], d["y"], 3 - d["y"]])
    dp_ag = dp.min(axis=0)
    P = np.stack([d["x"], d["y"]], axis=-1)
    i, j = np.triu_indices(5, 1)
    dist = np.linalg.norm(P[:, i, :] - P[:, j, :], axis=-1)  # (pasos, 10)
    esc = d["esc"]
    prev = np.vstack([np.zeros((1, 5)), esc[:-1]])
    act = int(((esc == 1) & (prev == 0)).sum())
    rec = np.linalg.norm(np.diff(P, axis=0), axis=-1).sum(axis=0)
    return dict(dpmin=float(dp.min()), viola=int((dp_ag < 0.18).sum()), cbf=float(d["cbf"].mean()),
                f018=float((dp < 0.18).mean()),
                esc=int(esc.sum()), act=act, sep=float(dist.min()),
                c15=int((dist < 0.15).any(axis=0).sum()), c22=int((dist < 0.22).any(axis=0).sum()),
                rec_min=float(rec.min()), filas=d["filas"], dp=dp)


# tabla de válidos (hw)
V = []          # 30-09
V26 = []        # 26-09
for s in SES30 + ["c26"]:
    for r in EP[s]:
        if not es_valido(r):
            continue
        ep = int(r["episodio"])
        m = metricas_dec(DEC[s][ep])
        fila = dict(ses=s, ep=ep, sem=int(r["semilla"]), cob=float(r["cobertura_aoi"]),
                    p95=float(r["ciclo_p95_ms"]), dec=int(r["decisiones"]),
                    csv_dp=float(r["d_pared_min"]), csv_vi=int(r["viola_018"]), csv_cbf=float(r["frac_cbf"]),
                    csv_esc=int(r["n_escape"]), csv_c15=int(r["colisiones_015"]),
                    csv_c22=int(r["colisiones_022"]), csv_dmin=float(r["dist_min_robot"]),
                    no_listo=any((r.get(f"col_estado_a{a}") or "").strip() != "listo" for a in range(5)),
                    par0=min(np.hypot(float(r[f"x0_a{a}"]) - float(r[f"x0_a{b}"]),
                                      float(r[f"y0_a{a}"]) - float(r[f"y0_a{b}"]))
                             for a in range(5) for b in range(a + 1, 5)),
                    **{k: v for k, v in m.items() if k != "dp"})
        (V26 if s == "c26" else V).append(fila)


def col(L, k):
    return np.array([f[k] for f in L], float)


def ms(a):
    a = np.asarray(a, float)
    return a.mean(), a.std(ddof=1)


# ───────────────────────────── utilidades estadísticas (propias) ─────────────────────────────
def t_ic(a, conf=0.95):
    a = np.asarray(a, float)
    n = len(a)
    se = a.std(ddof=1) / np.sqrt(n)
    w = stats.t.ppf(0.5 + conf / 2, n - 1) * se
    return a.mean(), a.mean() - w, a.mean() + w, w


def cr1_ic(y, g):
    y = np.asarray(y, float)
    g = np.asarray(g)
    u = y - y.mean()
    grupos = np.unique(g)
    G = len(grupos)
    sumas = np.array([u[g == k].sum() for k in grupos])
    se = np.sqrt(G / (G - 1) * (sumas ** 2).sum()) / len(y)
    w = stats.t.ppf(0.975, G - 1) * se
    return y.mean(), y.mean() - w, y.mean() + w, w, G - 1, se


def demean(v, g):
    v = np.asarray(v, float).copy()
    g = np.asarray(g)
    for k in np.unique(g):
        v[g == k] -= v[g == k].mean()
    return v


def fwl(y, x, g):
    """Pendiente de x en y ~ efectos fijos de g + x (Frisch–Waugh–Lovell), IC95 y p."""
    yd, xd = demean(y, g), demean(x, g)
    b = (xd @ yd) / (xd @ xd)
    res = yd - b * xd
    gl = len(y) - len(np.unique(g)) - 1
    se = np.sqrt((res @ res) / gl / (xd @ xd))
    tq = stats.t.ppf(0.975, gl)
    return b, b - tq * se, b + tq * se, 2 * stats.t.sf(abs(b / se), gl), gl


def rss(X, y):
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    r = y - X @ b
    return float(r @ r), np.linalg.matrix_rank(X)


def dummies(v):
    v = np.asarray(v)
    niv = sorted(set(v.tolist()))
    return np.column_stack([(v == k).astype(float) for k in niv])


def icc1(y, g):
    y = np.asarray(y, float)
    g = np.asarray(g)
    niv = np.unique(g)
    n = np.array([(g == k).sum() for k in niv], float)
    m = np.array([y[g == k].mean() for k in niv])
    N, a = n.sum(), len(niv)
    msb = (n * (m - y.mean()) ** 2).sum() / (a - 1)
    msw = sum(((y[g == k] - y[g == k].mean()) ** 2).sum() for k in niv) / (N - a)
    n0 = (N - (n ** 2).sum() / N) / (a - 1)
    s2b = max((msb - msw) / n0, 0.0)
    icc = s2b / (s2b + msw)
    F = msb / msw
    FL = F / stats.f.ppf(0.975, a - 1, N - a)
    FU = F * stats.f.ppf(0.975, N - a, a - 1)
    lo, hi = (FL - 1) / (FL + n0 - 1), (FU - 1) / (FU + n0 - 1)
    return dict(icc=icc, lo=lo, hi=hi, sd_w=np.sqrt(msw), sd_b=np.sqrt(s2b), n=n, N=N, a=a)


# ═════════════════════════════ A. §1 ítem 1 y §8 "Citable" ═════════════════════════════
todos30 = [r for s in SES30 for r in EP[s]]
n_int30, n_val30 = len(todos30), sum(es_valido(r) for r in todos30)
n_int26, n_val26 = len(EP["c26"]), sum(es_valido(r) for r in EP["c26"])
cob = col(V, "cob")
sem = np.array([f["sem"] for f in V])
m_cob, sd_cob = ms(cob)
_, cr_lo, cr_hi, cr_w, cr_gl, cr_se = cr1_ic(cob, sem)
c15_tot = int(col(V, "csv_c15").sum()) + int(col(V, "c15").sum())
c22_tot = int(col(V, "csv_c22").sum()) + int(col(V, "c22").sum())
filas_val = int(col(V, "filas").sum())
sep_min_global = col(V, "sep").min()

num("R1.01", "§1.1 intentos del 30-09", "57", n_int30)
num("R1.02", "§1.1 válidos del 30-09", "50", n_val30)
num("R1.03", "§1.1 tasa de validez 50/57", "0.877", n_val30 / n_int30)
num("R1.04", "§1.1 válidos del 26-09", "10", n_val26)
num("R1.05", "§1.1 intentos del 26-09", "19", n_int26)
num("R1.06", "§1.1 cobertura hw media (50 válidos)", "0.3452", m_cob)
num("R1.07", "§1.1 cobertura hw desvío (ddof 1)", "0.0428", sd_cob)
num("R1.08", "§1.1 IC95 respetando semillas (CR1) cota inferior", "0.3253", cr_lo)
num("R1.09", "§1.1 IC95 respetando semillas (CR1) cota superior", "0.3651", cr_hi)
txt("R1.10", "§1.1 colisiones < 0.15 m (CSV + recálculo desde decisiones)", "0",
    f"{c15_tot} (separación mínima recalculada {sep_min_global:.4f} m)", c15_tot == 0)
txt("R1.11", "§1.1 colisiones < 0.22 m (CSV + recálculo desde decisiones)", "0",
    f"{c22_tot} (separación mínima recalculada {sep_min_global:.4f} m)", c22_tot == 0 and sep_min_global >= 0.22)
num("R1.12", "§1.1 decisiones-agente de los válidos (filas del CSV de decisiones)", "125000", filas_val)

reps_por_sem = {k: int((sem == k).sum()) for k in np.unique(sem)}
num("S8.01", "§8 Citable: válidos", "50", n_val30)
num("S8.02", "§8 Citable: escenarios (semillas distintas)", "12", len(reps_por_sem))
num("S8.03", "§8 Citable: cobertura media", "0.3452", m_cob)
num("S8.04", "§8 Citable: cobertura desvío", "0.0428", sd_cob)
num("S8.05", "§8 Citable: IC95 por semilla inferior", "0.3253", cr_lo)
num("S8.06", "§8 Citable: IC95 por semilla superior", "0.3651", cr_hi)
txt("S8.07", "§8 Citable: colisiones", "0", f"{c15_tot + c22_tot}", c15_tot + c22_tot == 0)
num("S8.08", "Encabezado: repeticiones mínimas por escenario", "2", min(reps_por_sem.values()))
num("S8.09", "Encabezado: repeticiones máximas por escenario", "5", max(reps_por_sem.values()))

# ═════════════════════════════ B. tabla de corridas ═════════════════════════════
CIERRE = {"s1": "12:11", "s2": "12:31", "s3": "12:48", "s4": "13:12", "s5": "13:38"}
VAL_TXT = {"s1": "3–12", "s2": "1, 4–12", "s3": "1, 2, 4–11", "s4": "1–6, 8–11", "s5": "1–5, 7–11"}
VAL_LISTA = {"s1": list(range(3, 13)), "s2": [1] + list(range(4, 13)), "s3": [1, 2] + list(range(4, 12)),
             "s4": list(range(1, 7)) + list(range(8, 12)), "s5": list(range(1, 6)) + list(range(7, 12))}
COB_REP = {"s1": ("0.3546", "0.0376"), "s2": ("0.3389", "0.0372"), "s3": ("0.3378", "0.0444"),
           "s4": ("0.3424", "0.0480"), "s5": ("0.3524", "0.0515")}
P95_REP = {"s1": ("59.4", "5.8"), "s2": ("50.0", "7.4"), "s3": ("49.1", "4.5"), "s4": ("37.6", "15.5"),
           "s5": ("36.9", "5.7")}
INT_REP = {"s1": "12", "s2": "12", "s3": "11", "s4": "11", "s5": "11"}
INV_REP = {"s1": [1, 2], "s2": [2, 3], "s3": [3], "s4": [7], "s5": [6]}


def inval(s):
    return [r for r in EP[s] if not es_valido(r)]


for s in SES30:
    S = s.upper()
    nr(f"{S}.01", f"tabla §2 {s}: hora de cierre", CIERRE[s], "mtime del CSV de episodios; no está en csv/ ni consola/")
    num(f"{S}.02", f"tabla §2 {s}: intentos", INT_REP[s], len(EP[s]))
    vl = [int(r["episodio"]) for r in EP[s] if es_valido(r)]
    num(f"{S}.03", f"tabla §2 {s}: válidos", "10", len(vl))
    txt(f"{S}.04", f"tabla §2 {s}: episodios válidos", VAL_TXT[s], str(vl), vl == VAL_LISTA[s])
    il = [int(r["episodio"]) for r in inval(s)]
    txt(f"{S}.05", f"tabla §2 {s}: episodios inválidos", ", ".join(map(str, INV_REP[s])), str(il), il == INV_REP[s])
    vs = [f for f in V if f["ses"] == s]
    m, sd = ms(col(vs, "cob"))
    num(f"{S}.06", f"tabla §2 {s}: cobertura hw media", COB_REP[s][0], m)
    num(f"{S}.07", f"tabla §2 {s}: cobertura hw desvío", COB_REP[s][1], sd)
    m, sd = ms(col(vs, "p95"))
    num(f"{S}.08", f"tabla §2 {s}: ciclo p95 válidos media (ms)", P95_REP[s][0], m)
    num(f"{S}.09", f"tabla §2 {s}: ciclo p95 válidos desvío (ms)", P95_REP[s][1], sd)
    # semilla = 420000 + ep − 1
    okse = all(int(r["semilla"]) == 420000 + int(r["episodio"]) - 1 for r in EP[s])
    txt(f"{S}.10", f"{s}: semilla = 420000 + ep − 1 en todos los intentos", "sí", str(okse), okse)


def ultima_rep(s, ep):
    d = DEC[s][ep]
    R = repetidas(d)
    return [a for a in range(5) if R[-1, a]], R, d


# s1 ep 1 y 2
for ep in (1, 2):
    r = next(x for x in EP["s1"] if int(x["episodio"]) == ep)
    txt(f"S1.1{ep}a", f"s1 ep {ep}: causa", "antigüedad de pose", r["motivo"], "antigüedad de pose" in r["motivo"])
    num(f"S1.1{ep}b", f"s1 ep {ep}: consultas fallidas", "1", int(r["poses_fallidas"]))
    ags, _, _ = ultima_rep("s1", ep)
    txt(f"S1.1{ep}c", f"s1 ep {ep}: agentes que repiten pose en la última decisión", "los 5",
        f"{len(ags)} (robots {[ROBOT[a] for a in ags]})", len(ags) == 5)
    exc = float(r["duracion_s"]) - 0.1 * int(r["decisiones"])
    nr(f"S1.1{ep}d", f"s1 ep {ep}: timeout de la consulta", "1 s",
       f"código de adaptadores; exceso duración − 0.1·decisiones = {exc:+.3f} s, compatible")

# s2 ep 2 y 3
for ep, pct in ((2, "48"), (3, "0")):
    r = next(x for x in EP["s2"] if int(x["episodio"]) == ep)
    mm = re.search(r"agente (\d) NO SIGUE.*?recorrió el (\d+) %", r["motivo"])
    ag = int(mm.group(1)) if mm else -1
    rob = int(r[f"robot_a{ag}"]) if ag >= 0 else -1
    txt(f"S2.1{ep}a", f"s2 ep {ep}: NO SIGUE de qué robot", "robot 5", f"agente {ag} → robot {rob}",
        rob == 5 and "NO SIGUE" in r["motivo"])
    num(f"S2.1{ep}b", f"s2 ep {ep}: % recorrido de lo comandado", pct, int(mm.group(2)) if mm else -1)
txt_c2 = (CON / CONSOLA["s2"]).read_text(encoding="utf-8", errors="replace")
l10054 = [l for l in txt_c2.splitlines() if "10054" in l]
txt("S2.14", "s2 nota: 10054 del r5 (consola s2)", "10054 del r5", f"{len(l10054)} líneas con 10054, todas robot 5: "
    f"{all('robot 5' in l for l in l10054)}", len(l10054) > 0 and all("robot 5" in l for l in l10054))

# s3 ep 3
r = next(x for x in EP["s3"] if int(x["episodio"]) == 3)
_, R3, _ = ultima_rep("s3", 3)
txt("S3.11", "s3 ep 3: causa", "antigüedad", r["motivo"], "antigüedad de pose" in r["motivo"])
num("S3.12", "s3 ep 3: consultas fallidas", "0", int(r["poses_fallidas"]))
num("S3.13", "s3 ep 3: poses rechazadas", "0", int(r["poses_rechazadas"]))
num("S3.14", "s3 ep 3: filas con pose repetida en todo el episodio", "0", int(R3.sum()))
nr("S3.15", "s3 nota: réplica en paralelo", "réplica en paralelo", "relato del operador y registro de la réplica, fuera de csv/ y consola/")
nr("S3.16", "s3 ep 3: el lazo se trabó (causa)", "hipótesis",
   f"declarada hipótesis; exceso duración − 0.1·dec = {float(r['duracion_s']) - 0.1 * int(r['decisiones']):+.3f} s")

# s4 ep 7
r = next(x for x in EP["s4"] if int(x["episodio"]) == 7)
ags, R4, d4 = ultima_rep("s4", 7)
rep_ag = [a for a in range(5) if R4[:, a].any()]
txt("S4.11", "s4 ep 7: causa", "antigüedad", r["motivo"], "antigüedad de pose" in r["motivo"])
num("S4.12", "s4 ep 7: poses rechazadas", "2", int(r["poses_rechazadas"]))
txt("S4.13", "s4 ep 7: motivo de rechazo", "inclinación", r["poses_rechazos_motivo"],
    r["poses_rechazos_motivo"].startswith("inclinación"))
xr, yr = d4["x"][-1, ags[0]], d4["y"][-1, ags[0]]
txt("S4.14", "s4 ep 7: robot con pose repetida y lugar", "r9, esquina (3,3)",
    f"robots {[ROBOT[a] for a in rep_ag]} en env ({xr:.2f}, {yr:.2f}), a {np.hypot(3 - xr, 3 - yr):.2f} m de (3,3)",
    [ROBOT[a] for a in rep_ag] == [9] and xr > 2.5 and yr > 2.5)
falta_s4 = not any(p.name.startswith("consola_20260930_04") for p in CON.iterdir())
txt("S4.15", "s4 nota: sin consola", "sin consola", f"consola_20260930_04 ausente en consola/: {falta_s4}", falta_s4)
nr("S4.16", "s4 nota: sin arreglo", "sin arreglo", "mtime de sesion_robotat.py vs cierre del CSV")

# s5 ep 6
r = next(x for x in EP["s5"] if int(x["episodio"]) == 6)
_, R5, d5 = ultima_rep("s5", 6)
txt("S5.11", "s5 ep 6: causa", "antigüedad", r["motivo"], "antigüedad de pose" in r["motivo"])
num("S5.12", "s5 ep 6: poses rechazadas", "3", int(r["poses_rechazadas"]))
txt("S5.13", "s5 ep 6: motivo de rechazo", "inclinación", r["poses_rechazos_motivo"],
    r["poses_rechazos_motivo"].startswith("inclinación"))
lugares = []
ok_lug = True
for a in range(5):
    idx = np.where(R5[:, a])[0]
    if len(idx) == 0:
        continue
    x, y = d5["x"][idx[0], a], d5["y"][idx[0], a]
    lx, ly = env_a_lab(x, y)
    lugares.append((ROBOT[a], len(idx), round(float(np.hypot(lx, ly)), 3),
                    round(float(np.hypot(x - PUNTO_C[0], y - PUNTO_C[1])), 3)))
rob5 = {l[0]: l for l in lugares}
ok_lug = (set(rob5) == {6, 8} and rob5[6][2] <= 0.10 and rob5[8][3] <= 0.15
          and sum(l[1] for l in lugares) == int(r["poses_rechazadas"]))
txt("S5.14", "s5 ep 6: robots con pose repetida (robot, filas, dist. al origen lab, dist. a C)",
    "r6 en el centro, r8 cerca de C", str(lugares), ok_lug)
nr("S5.15", "s5 nota: con arreglo", "con arreglo", "codigo/ (diff) y mtime; la evidencia en consola es del §5")

# fila total 30-09 y 26-09
num("T30.01", "tabla §2 total 30-09: intentos", "57", n_int30)
num("T30.02", "tabla §2 total 30-09: válidos", "50", n_val30)
mot30 = [r["motivo"] for r in todos30 if not es_valido(r)]
num("T30.03", "tabla §2 total 30-09: inválidos por antigüedad", "5", sum("antigüedad" in m for m in mot30))
num("T30.04", "tabla §2 total 30-09: inválidos por NO SIGUE", "2", sum("NO SIGUE" in m for m in mot30))
num("T30.05", "tabla §2 total 30-09: cobertura media", "0.3452", m_cob)
num("T30.06", "tabla §2 total 30-09: cobertura desvío", "0.0428", sd_cob)
m, sd = ms(col(V, "p95"))
num("T30.07", "tabla §2 total 30-09: ciclo p95 media (ms)", "46.6", m)
num("T30.08", "tabla §2 total 30-09: ciclo p95 desvío (ms)", "12.0", sd)
num("T26.01", "tabla §2 26-09: intentos", "19", n_int26)
num("T26.02", "tabla §2 26-09: válidos", "10", n_val26)
mot26 = [r["motivo"] for r in EP["c26"] if not es_valido(r)]
num("T26.03", "tabla §2 26-09: inválidos por marcador congelado", "6", sum("CONGELADO" in m for m in mot26))
num("T26.04", "tabla §2 26-09: inválidos por NO SIGUE", "3", sum("NO SIGUE" in m for m in mot26))
m26, sd26 = ms(col(V26, "cob"))
num("T26.05", "tabla §2 26-09: cobertura media", "0.3478", m26)
num("T26.06", "tabla §2 26-09: cobertura desvío", "0.0427", sd26)
m, sd = ms(col(V26, "p95"))
num("T26.07", "tabla §2 26-09: ciclo p95 media (ms)", "15.5", m)
num("T26.08", "tabla §2 26-09: ciclo p95 desvío (ms)", "1.0", sd)

# ═════════════════════════════ C. viñetas bajo la tabla ═════════════════════════════
nr("B.01", "abortos que incluye la validez (antigüedad, NO SIGUE, congelado, rpm, fuera de la arena, ritmo)",
   "6 tipos", "código de sesion_robotat.py")
v4 = [f for f in V if f["ses"] == "s4"]
ok4 = len(v4) == 10 and all(f["dec"] == 500 and f["filas"] == 2500 for f in v4)
txt("B.02", "s4: válidos con 500 decisiones de los 5 agentes", "10 × 500 × 5",
    f"{len(v4)} válidos; decisiones {sorted({f['dec'] for f in v4})}; filas {sorted({f['filas'] for f in v4})}", ok4)
reg = set()
for s in ["c26"] + SES30:
    for r in EP[s]:
        reg.add((r["factor"], r["rpm_aborto"], r["colocacion"], tuple(r[f"robot_a{a}"] for a in range(5)),
                 tuple(r[f"offset_deg_a{a}"] for a in range(5)), tuple(r[f"offset_origen_a{a}"] for a in range(5))))
num("B.03", "régimen: sesiones comparadas (26-09 y s1–s5)", "6", len(["c26"] + SES30))
reg1 = next(iter(reg))
txt("B.04", "régimen idéntico: una sola combinación de parámetros en los 76 intentos", "idéntico",
    f"{len(reg)} combinación(es)", len(reg) == 1)
num("B.05", "régimen: factor", "0.40", float(reg1[0]))
num("B.06", "régimen: aborto (rpm)", "200", float(reg1[1]))
txt("B.07", "régimen: colocación autónoma", "autónoma", reg1[2], reg1[2] == "auto")
txt("B.08", "régimen: robots", "[1, 5, 8, 6, 9]", str(list(reg1[3])), list(reg1[3]) == ["1", "5", "8", "6", "9"])
org = reg1[5]
txt("B.09", "offsets de r6 y r9: tabla del laboratorio, nunca medidos", "tabla, sin medir",
    f"r6: '{org[3]}' · r9: '{org[4]}'", "tabla" in org[3] and "tabla" in org[4]
    and "MEDIDO" not in org[3] and "MEDIDO" not in org[4])
txt("B.10", "offset de r8 medido en una sola corrida", "una sola corrida", f"r8: '{org[2]}'",
    "UNA sola corrida" in org[2])
nr("B.11", "hora de cambio de sesion_robotat.py", "13:13:50", "mtime del archivo de código")
nr("B.12", "hora de cierre de la s4", "13:12:14", "mtime del CSV de la s4")
nr("B.17", "26-09 y s1–s4 corrieron el mismo código (por fecha de modificación)", "mismo código",
   "mtimes de los módulos (derivados/a30f_*_mtimes_*.txt) y cabecera del diff en codigo/")
cache = [(s, int(r["episodio"])) for s in SES30 for r in EP[s]
         if not es_valido(r) and int(r["poses_fallidas"]) + int(r["poses_rechazadas"]) > 0]
num("B.13", "abortos con consulta fallida o pose rechazada", "4", len(cache))
num("B.14", "abortos totales del 30-09", "7", len(mot30))
txt("B.15", "abortos atribuidos a la caché", "s1 ep 1 y 2, s4 ep 7 y s5 ep 6", str(cache),
    cache == [("s1", 1), ("s1", 2), ("s4", 7), ("s5", 6)])
# en esos 4, ¿el aborto llega con pose repetida y nº de filas repetidas = fallidas + rechazadas?
coh = []
for s, ep in cache:
    r = next(x for x in EP[s] if int(x["episodio"]) == ep)
    ags, R, _ = ultima_rep(s, ep)
    nfr = int(R.sum())
    nev = int(r["poses_fallidas"]) * 5 + int(r["poses_rechazadas"])
    coh.append((s, ep, len(ags) > 0, nfr, nev))
txt("B.16", "en esos 4 abortos la última decisión trae pose repetida y filas repetidas = 5·fallidas + rechazadas",
    "defecto de caché", str(coh), all(c[2] and c[3] == c[4] for c in coh))

# ═════════════════════════════ D. métricas de los válidos ═════════════════════════════
# chequeo interno: las métricas del CSV coinciden con el recálculo desde decisiones
cons = all(abs(f["csv_dp"] - f["dpmin"]) < 1e-9 and f["csv_vi"] == f["viola"] and abs(f["csv_cbf"] - f["cbf"]) < 1e-9
           and f["csv_esc"] == f["esc"] and f["csv_c15"] == f["c15"] and f["csv_c22"] == f["c22"]
           for f in V + V26)
txt("D.00", "métricas del CSV de episodios = recálculo desde decisiones (60 válidos)", "coinciden", str(cons), cons)


def par(i, desc, rep_m, rep_s, a):
    m, sd = ms(a)
    num(i + "m", desc + " (media)", rep_m, m)
    num(i + "s", desc + " (desvío)", rep_s, sd)


# 30-09
par("D.01", "30-09 cobertura AoI", "0.3452", "0.0428", cob)
num("D.02a", "30-09 colisiones < 0.15 m (suma)", "0", col(V, "c15").sum())
num("D.02b", "30-09 colisiones < 0.22 m (suma)", "0", col(V, "c22").sum())
par("D.03", "30-09 d_pared mín (media de mínimos)", "0.1317", "0.0169", col(V, "dpmin"))
num("D.03n", "30-09 d_pared mín (mínimo)", "0.1120", col(V, "dpmin").min())
par("D.04", "30-09 violaciones de 0.18 m", "2.00", "0.83", col(V, "viola"))
par("D.05", "30-09 fracción con CBF", "0.273", "0.121", col(V, "cbf"))
par("D.06", "30-09 decisiones-agente en escape", "40.2", "31.8", col(V, "esc"))
par("D.07", "30-09 activaciones de escape (0→1)", "2.12", "1.78", col(V, "act"))
par("D.08", "30-09 separación mínima entre pares (m)", "0.432", "0.127", col(V, "sep"))
# 26-09
par("D.11", "26-09 cobertura AoI", "0.3478", "0.0427", col(V26, "cob"))
num("D.12a", "26-09 colisiones < 0.15 m (suma)", "0", col(V26, "c15").sum())
num("D.12b", "26-09 colisiones < 0.22 m (suma)", "0", col(V26, "c22").sum())
par("D.13", "26-09 d_pared mín (media de mínimos)", "0.1478", "0.0250", col(V26, "dpmin"))
num("D.13n", "26-09 d_pared mín (mínimo)", "0.1098", col(V26, "dpmin").min())
par("D.14", "26-09 violaciones de 0.18 m", "1.90", "1.10", col(V26, "viola"))
par("D.15", "26-09 fracción con CBF", "0.229", "0.102", col(V26, "cbf"))
par("D.16", "26-09 decisiones-agente en escape", "18.1", "30.5", col(V26, "esc"))
par("D.17", "26-09 activaciones de escape (0→1)", "0.90", "1.45", col(V26, "act"))
par("D.18", "26-09 separación mínima entre pares (m)", "0.480", "0.132", col(V26, "sep"))
# réplica con capas 30-09: por episodio válido del hw, media de sus reps válidas
RP = []
inval_rep = 0
for s in SES30:
    hwv = {int(r["episodio"]) for r in EP[s] if es_valido(r)}
    for ep in sorted(hwv):
        xs = [x for x in REP[s] if int(x["episodio"]) == ep and es_valido(x)]
        assert xs, f"episodio sin réplica válida {s} {ep}"
        RP.append({k: np.mean([float(x[k]) for x in xs])
                   for k in ("cobertura_aoi", "colisiones_015", "colisiones_022", "d_pared_min", "viola_018",
                             "frac_cbf", "n_escape")})
    inval_rep += sum(not es_valido(x) for x in REP[s])
par("D.21", "réplica cobertura AoI (media de reps válidas por episodio, 50)", "0.3375", "0.0403",
    [p["cobertura_aoi"] for p in RP])
num("D.22a", "réplica colisiones < 0.15 m por episodio", "0", np.mean([p["colisiones_015"] for p in RP]))
num("D.22b", "réplica colisiones < 0.22 m por episodio", "0.033", np.mean([p["colisiones_022"] for p in RP]))
par("D.23", "réplica d_pared mín", "0.1672", "0.0090", [p["d_pared_min"] for p in RP])
par("D.24", "réplica violaciones de 0.18 m", "1.57", "0.78", [p["viola_018"] for p in RP])
par("D.25", "réplica fracción con CBF", "0.270", "0.122", [p["frac_cbf"] for p in RP])
par("D.26", "réplica decisiones-agente en escape", "28.8", "18.0", [p["n_escape"] for p in RP])

# ═════════════════════════════ E. nota de nombres ═════════════════════════════
okesc = all(f["csv_esc"] == f["esc"] for f in V + V26)
txt("E.01", "n_escape = suma de en_escape (decisiones-agente), no activaciones", "decisiones-agente",
    f"n_escape = Σ en_escape en 60/60: {okesc}; activaciones 30-09 suman {int(col(V, 'act').sum())} vs "
    f"n_escape {int(col(V, 'esc').sum())}", okesc)
rot = []
for s, fn in CONSOLA.items():
    lineas = (CON / fn).read_text(encoding="utf-8", errors="replace").splitlines()
    l = [x for x in lineas if x.startswith("activaciones de escape")][-1]
    vcon = float(re.findall(r"\d+\.\d+", l)[0])
    L = V26 if s == "c26" else [f for f in V if f["ses"] == s]
    rot.append((s, vcon, round(float(col(L, "esc").mean()), 1), round(float(col(L, "act").mean()), 1)))
okrot = all(abs(a[1] - a[2]) < 0.051 for a in rot)
txt("E.02", "la consola rotula 'activaciones de escape' a la media de n_escape (sesión, consola, n_escape, act.)",
    "rotula mal", str(rot), okrot)
okrec = all(abs(f["csv_dmin"] - f["rec_min"]) < 1e-6 for f in V)
txt("E.03", "dist_min_robot = recorrido del robot que menos anduvo (recálculo desde decisiones, 50 válidos)",
    "recorrido", f"coinciden: {okrec}", okrec)
num("E.04", "dist_min_robot media 30-09 (m)", "5.56", col(V, "csv_dmin").mean())

# ═════════════════════════════ F. 30-09 contra 26-09 ═════════════════════════════
a, b = cob, col(V26, "cob")
va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
glw = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
dif = a.mean() - b.mean()
w = stats.t.ppf(0.975, glw) * np.sqrt(va + vb)
num("F.01", "30-09 − 26-09 cobertura", "−0.0026", dif)
num("F.02", "30-09 − 26-09 IC95 (Welch) inferior", "−0.0346", dif - w)
num("F.03", "30-09 − 26-09 IC95 (Welch) superior", "+0.0295", dif + w)
yy = np.r_[a, b]
gg = np.r_[sem, [f["sem"] for f in V26]]
xx = np.r_[np.ones(len(a)), np.zeros(len(b))]
bb, lo, hi, pp, gl = fwl(yy, xx, gg)
num("F.04", "30-09 − 26-09 ajustada por semilla", "+0.0210", bb)
num("F.05", "ajustada por semilla IC95 inferior", "−0.0151", lo)
num("F.06", "ajustada por semilla IC95 superior", "+0.0570", hi)
comp = sum(f["sem"] in set(sem.tolist()) for f in V26)
num("F.07", "episodios del 26-09 con semilla compartida (los que aportan al ajuste)", "5", comp)

# ═════════════════════════════ G. heterogeneidad entre sesiones ═════════════════════════════
ses = np.array([f["ses"] for f in V])
grupos = [cob[ses == s] for s in SES30]
N, k = len(cob), len(grupos)
ssb = sum(len(g) * (g.mean() - cob.mean()) ** 2 for g in grupos)
ssw = sum(((g - g.mean()) ** 2).sum() for g in grupos)
F1 = (ssb / (k - 1)) / (ssw / (N - k))
num("G.01", "ANOVA 1 vía cobertura por sesión, p", "0.870", stats.f.sf(F1, k - 1, N - k))
rk = stats.rankdata(cob)
H = 12 / (N * (N + 1)) * sum(rk[ses == s].sum() ** 2 / (ses == s).sum() for s in SES30) - 3 * (N + 1)
_, cnt = np.unique(cob, return_counts=True)
H /= 1 - (cnt ** 3 - cnt).sum() / (N ** 3 - N)
num("G.02", "Kruskal-Wallis cobertura por sesión, p", "0.763", stats.chi2.sf(H, k - 1))
one = np.ones((N, 1))
Ds, Dg = dummies(sem)[:, 1:], dummies(ses)[:, 1:]
rss_full, rk_full = rss(np.hstack([one, Ds, Dg]), cob)
rss_sem, _ = rss(np.hstack([one, Ds]), cob)
rss_ses, _ = rss(np.hstack([one, Dg]), cob)
sst = ((cob - cob.mean()) ** 2).sum()
glr = N - rk_full
ss_ses, ss_sem = rss_sem - rss_full, rss_ses - rss_full
p_ses = stats.f.sf((ss_ses / Dg.shape[1]) / (rss_full / glr), Dg.shape[1], glr)
p_sem = stats.f.sf((ss_sem / Ds.shape[1]) / (rss_full / glr), Ds.shape[1], glr)
num("G.03", "modelo semilla + sesión: % de la SS que explica la sesión (tipo II)", "1.4", 100 * ss_ses / sst)
num("G.04", "modelo semilla + sesión: p de la sesión", "0.906", p_ses)
num("G.05", "modelo semilla + sesión: % de la SS que explica la semilla (tipo II)", "50.5", 100 * ss_sem / sst)
num("G.06", "modelo semilla + sesión: p de la semilla", "0.0034", p_sem)
orden = np.array([ORDEN[s] for s in ses], float)
bb, lo, hi, pp, gl = fwl(cob, orden, sem)
num("G.07", "tendencia s1→s5 ajustada por semilla (por sesión)", "+0.0019", bb)
num("G.08", "tendencia IC inferior", "−0.0054", lo)
num("G.09", "tendencia IC superior", "+0.0092", hi)

# ═════════════════════════════ H. repetibilidad (ICC) ═════════════════════════════
I = icc1(cob, sem)
num("H.01", "ICC(1) por semilla", "0.395", I["icc"])
num("H.02", "ICC(1) IC95 aprox. inferior", "0.122", I["lo"])
num("H.03", "ICC(1) IC95 aprox. superior", "0.715", I["hi"])
num("H.04", "desvío dentro de semilla", "0.0338", I["sd_w"])
num("H.05", "desvío entre semillas (componente)", "0.0273", I["sd_b"])
fuera = np.array([f["no_listo"] or f["par0"] < 0.31 for f in V])
lista_fuera = [(f["ses"], f["ep"]) for f, z in zip(V, fuera) if z]
coinc = all(f["no_listo"] == (f["par0"] < 0.31) for f in V)
txt("H.06", "arranques fuera del soporte (robot no 'listo' o par inicial < 0.31 m)", "5",
    f"{int(fuera.sum())} {lista_fuera}; ambos criterios coinciden: {coinc}", int(fuera.sum()) == 5)
I2 = icc1(cob[~fuera], sem[~fuera])
num("H.07", "ICC(1) sin los 5 fuera del soporte", "0.681", I2["icc"])
num("H.08", "desvío dentro sin los 5", "0.0250", I2["sd_w"])

# ═════════════════════════════ I. IC de la media del hw ═════════════════════════════
m, lo_a, hi_a, w_a = t_ic(cob)
num("I.01", "IC95 episodios independientes inferior", "0.3330", lo_a)
num("I.02", "IC95 episodios independientes superior", "0.3574", hi_a)
num("I.03", "CR1 por semilla: grados de libertad", "11", cr_gl)
num("I.04", "CR1 por semilla IC95 inferior", "0.3253", cr_lo)
num("I.05", "CR1 por semilla IC95 superior", "0.3651", cr_hi)
num("I.06", "CR1: veces más ancho que el ingenuo (cociente de semianchos)", "1.63", cr_w / w_a)
msem = np.array([cob[sem == s_].mean() for s_ in np.unique(sem)])
mm, lo_c, hi_c, _ = t_ic(msem)
num("I.07", "media de las medias por semilla", "0.3487", mm)
num("I.08", "media de medias IC95 inferior", "0.3271", lo_c)
num("I.09", "media de medias IC95 superior", "0.3703", hi_c)
num("I.10", "número de medias por semilla", "12", len(msem))
nbar = (I["n"] ** 2).sum() / I["n"].sum()
deff = 1 + (nbar - 1) * I["icc"]
num("I.11", "n efectivo de Kish", "21", N / deff)

# ═════════════════════════════ J. s3 y s5 contra el resto ═════════════════════════════
dp = col(V, "dpmin")
for s, idc, rep in (("s3", "J.0", ("+0.0001", "−0.0249", "+0.0251")),
                    ("s5", "J.1", ("+0.0108", "−0.0141", "+0.0356"))):
    bb, lo, hi, pp, gl = fwl(cob, (ses == s).astype(float), sem)
    num(idc + "1", f"{s} − resto, cobertura ajustada por semilla", rep[0], bb)
    num(idc + "2", f"{s} − resto, IC95 inferior", rep[1], lo)
    num(idc + "3", f"{s} − resto, IC95 superior", rep[2], hi)
bb, lo, hi, pp, gl = fwl(dp, (ses == "s5").astype(float), sem)
num("J.21", "s5 − resto, d_pared mín ajustada por semilla", "+0.0084", bb)
num("J.22", "s5 − resto, d_pared IC95 inferior", "−0.0007", lo)
num("J.23", "s5 − resto, d_pared IC95 superior", "+0.0175", hi)
bb, lo, hi, pp, gl = fwl(col(V, "p95"), orden, sem)
num("J.24", "pendiente del ciclo p95 por sesión, ajustada por semilla (ms)", "−5.8", bb)
pv = []
for kk in ("cob", "dpmin", "viola", "f018", "cbf", "esc", "act", "sep"):
    pv.append((kk, round(float(fwl(col(V, kk), col(V, "p95"), sem)[3]), 3)))
pmin = min(pv, key=lambda t: t[1])
txt("J.25", "§2: el p95 no se asocia a ninguna métrica (efectos fijos de semilla; ninguna p < 0.05)", "no se asocia",
    str(pv), all(p_ >= 0.05 for _, p_ in pv))
txt("J.26", "§7 citado en §2: 'con efectos fijos de semilla, ninguna p < 0.05; la menor 0.24'", "ninguna p < 0.05; mín 0.24",
    f"p mínima {pmin[1]:.3f} ({pmin[0]}); viola_018 p {dict(pv)['viola']:.3f}",
    all(p_ >= 0.05 for _, p_ in pv) and abs(pmin[1] - 0.24) < 0.005)

# "Sin efecto de la s3 ni de la s5 en las métricas": todas las métricas de la tabla, Holm sobre 7
holm = []
for s_ in ("s3", "s5"):
    ps = []
    for kk in ("cob", "dpmin", "viola", "cbf", "esc", "act", "sep"):
        b_, lo_, hi_, p_, _ = fwl(col(V, kk), (ses == s_).astype(float), sem)
        ps.append((kk, b_, lo_, hi_, p_))
    orden_p = sorted(ps, key=lambda t: t[4])
    adj, acum = {}, 0.0
    for r_, t in enumerate(orden_p):
        acum = max(acum, min(1.0, (len(ps) - r_) * t[4]))
        adj[t[0]] = acum
    mn = orden_p[0]
    holm.append((s_, mn[0], round(float(mn[1]), 4), round(float(mn[2]), 4), round(float(mn[3]), 4),
                 round(float(mn[4]), 3), round(float(adj[mn[0]]), 3)))
txt("J.27", "§2: sin efecto de s3 ni s5 en las 7 métricas de la tabla (efectos fijos de semilla; Holm); "
    "(sesión, métrica de menor p, dif., IC95, p cruda, p Holm)", "sin efecto",
    str(holm), all(h[6] >= 0.05 for h in holm))

print(f"RESUMEN {SEC}: {CONT['ok']} ok, {CONT['falla']} fallas, {CONT['nr']} no recalculables")
