import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_congel_extra.py — verificaciones complementarias. SÓLO LECTURA.
 E1 distancias límite (s5 ep6 r8 a C; s1 ep9 r6 a D) y a los miembros más cercanos.
 E2 pareo por SEMILLA de los inicios "de lugar" del 30-09: el mismo agente, misma semilla, otras sesiones.
 E3 rechazos por inclinación: distancia al robot más cercano y a la pared en esa decisión.
 E4 filas "casi quietas" no contadas: (x,y) iguales con θ distinto; pasos < 0.1 mm.
 E5 robot 6 alrededor del centro D con radio 8 y 15 cm, por día.
"""
import math, sys
from collections import Counter
from scipy import stats
sys.stdout.reconfigure(encoding='utf-8')
import a30f_congel_clase as CL
K = CL.K
S, E, I = K.S, K.E, K.I
ORDEN = ['26-09', 's1', 's2', 's3', 's4', 's5']
todos = [it for s in ORDEN for it in I[s]]
lugar = [it for it in todos if it['mec'] in ('Motive', 'caché-rechazo')]


def dist(a, b):
    return math.hypot(a['r']['x'] - b['r']['x'], a['r']['y'] - b['r']['y'])


print('=' * 110)
print('E1) DISTANCIAS LÍMITE')
for ses, ep, paso, grupo in [('s5', 6, 475, 'C'), ('s1', 9, 368, 'D')]:
    it = [x for x in I[ses] if x['ep'] == ep and x['r']['paso'] == paso][0]
    otros = sorted(((dist(it, q), q) for q in lugar if q is not it), key=lambda t: t[0])[:3]
    print(f"  {ses} ep{ep} r{it['robot']} paso {paso} ({it['r']['x']:.4f}, {it['r']['y']:.4f}) [{it['mec']}] — más cercanos: " +
          '; '.join(f"{100*d:.2f} cm a {q['ses']} ep{q['ep']} r{q['robot']} ({q['r']['x']:.3f}, {q['r']['y']:.3f}) [{q['mec']}]" for d, q in otros))
    for P, (cx, cy) in K.PUNTOS.items():
        print(f"      a {P}: {100*math.hypot(it['r']['x']-cx, it['r']['y']-cy):.2f} cm", end='')
    print()

print('=' * 110)
print('E2) PAREO POR SEMILLA: para cada inicio "de lugar" del 30-09, el mismo agente con la misma semilla en los otros días')
SEM = {s: {int(e['semilla']): ep for ep, e in E[s].items()} for s in ORDEN}
print('   semillas 26-09: ' + ', '.join(f"ep{ep}:{e['semilla']}" for ep, e in sorted(E['26-09'].items())))
for it in [x for x in lugar if x['ses'] in K.SES30]:
    sem = int(E[it['ses']][it['ep']]['semilla'])
    r0 = it['r']
    print(f"  {it['ses']} ep{it['ep']} (semilla {sem}) a{it['ag']}/r{it['robot']} paso {r0['paso']} ({r0['x']:.3f}, {r0['y']:.3f}) [{it['mec']}] racha {it['racha']}")
    for s in ORDEN:
        if s == it['ses']:
            continue
        ep2 = SEM[s].get(sem)
        if ep2 is None:
            print(f"      {s:6s}: semilla no corrida"); continue
        sq = S[s].get((ep2, it['ag']))
        if sq is None:
            print(f"      {s:6s}: ep{ep2} sin filas del agente"); continue
        viv = [q for q in sq['f'] if not q['rep']]
        q = min(viv, key=lambda q: math.hypot(q['x'] - r0['x'], q['y'] - r0['y']))
        dmin = math.hypot(q['x'] - r0['x'], q['y'] - r0['y'])
        cong = [x for x in I[s] if x['ep'] == ep2 and x['ag'] == it['ag'] and math.hypot(x['r']['x'] - r0['x'], x['r']['y'] - r0['y']) < 0.08]
        print(f"      {s:6s}: ep{ep2} (V={E[s][ep2]['valido']}, {len(sq['f'])} filas) pasa a {100*dmin:5.1f} cm (paso {q['paso']}); inicios a <8 cm: "
              f"{[(x['r']['paso'], x['racha'], x['mec']) for x in cong] or 'ninguno'}")

print('=' * 110)
print('E3) RECHAZOS POR INCLINACIÓN (caché-rechazo): vecino más cercano y pared en la decisión del inicio y la anterior')
for it in [x for x in todos if x['mec'] == 'caché-rechazo']:
    s, ep, p = it['ses'], it['ep'], it['r']['paso']
    for pp in (p - 1, p):
        mine = [q for q in it['s']['f'] if q['paso'] == pp][0]
        ds = []
        for ag2 in range(5):
            if ag2 == it['ag'] or (ep, ag2) not in S[s]:
                continue
            q = [q for q in S[s][(ep, ag2)]['f'] if q['paso'] == pp]
            if q:
                ds.append((math.hypot(q[0]['x'] - mine['x'], q[0]['y'] - mine['y']), S[s][(ep, ag2)]['robot']))
        dmin = min(ds)
        print(f"  {s:6s} ep{ep} r{it['robot']} paso {pp}: vecino más cercano r{dmin[1]} a {100*dmin[0]:.1f} cm; d_pared {mine['d']:.3f} [{mine['pared']}];"
              f" v_ejec {mine['v']:+.3f} w_ejec {mine['w']:+.3f} cbf {mine['cbf']} escape {mine['esc']}")

print('=' * 110)
print('E4) FILAS "CASI QUIETAS" no contadas como repetidas (vivas)')
for s in ORDEN:
    xy_th = 0; sub01 = Counter(); tot = 0
    for (ep, ag), sq in S[s].items():
        f = sq['f']
        for k in range(1, len(f)):
            a, b = f[k - 1], f[k]
            if b['rep']:
                continue
            tot += 1
            if (a['x'], a['y']) == (b['x'], b['y']):
                xy_th += 1
            if 1000 * math.hypot(b['x'] - a['x'], b['y'] - a['y']) < 0.1:
                sub01[sq['robot']] += 1
    print(f"  {s:6s} filas vivas {tot}; (x,y) idéntica con θ distinto: {xy_th}; pasos < 0.1 mm (sin ser repetidas) por robot: {dict(sorted(sub01.items()))}")

print('=' * 110)
print('E5) ROBOT 6 alrededor del centro D (1.471, 1.269): filas vivas y pasadas por día, radios 8 y 15 cm')
cx, cy = 1.471, 1.269
for rad in (0.08, 0.15):
    for s in ORDEN:
        lin = []
        for rob in [1, 5, 8, 6, 9]:
            viv = sum(1 for sq in S[s].values() if sq['robot'] == rob for r in sq['f'] if not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < rad)
            k = sum(1 for it in lugar if it['ses'] == s and it['robot'] == rob and math.hypot(it['r']['x'] - cx, it['r']['y'] - cy) < rad)
            lin.append(f"r{rob} {k}/{viv}")
        print(f"  radio {int(100*rad)} cm {s:6s} inicios/vivas: " + '  '.join(lin))

print('=' * 110)
print('E6) RESUMEN DEL PAREO POR SEMILLA: pasadas del mismo agente (misma semilla, otro día) a ≤ 3 cm / ≤ 8 cm del inicio')
for grupo_nom, filtro in [('esquina +x+y (C, E y rechazos de borde)', lambda it: it['r']['x'] > 2.3 and it['r']['y'] > 2.5),
                          ('centro (D)', lambda it: abs(it['r']['x'] - 1.47) < 0.15 and abs(it['r']['y'] - 1.27) < 0.15)]:
    n3 = c3 = n8 = c8 = 0
    for it in [x for x in lugar if x['ses'] in K.SES30 and filtro(x)]:
        sem = int(E[it['ses']][it['ep']]['semilla']); r0 = it['r']
        for s in ORDEN:
            if s == it['ses'] or sem not in SEM[s] or (SEM[s][sem], it['ag']) not in S[s]:
                continue
            ep2 = SEM[s][sem]
            viv = [q for q in S[s][(ep2, it['ag'])]['f'] if not q['rep']]
            dmin = min(math.hypot(q['x'] - r0['x'], q['y'] - r0['y']) for q in viv)
            cong = any(x['ep'] == ep2 and x['ag'] == it['ag'] and math.hypot(x['r']['x'] - r0['x'], x['r']['y'] - r0['y']) < 0.08 for x in I[s]
                       if x['mec'] in ('Motive', 'caché-rechazo'))
            if dmin <= 0.03:
                n3 += 1; c3 += cong
            if dmin <= 0.08:
                n8 += 1; c8 += cong
    print(f"  {grupo_nom}: pares (inicio, otro día) con pasada a ≤ 3 cm: {n3}, con congelamiento ahí: {c3};  a ≤ 8 cm: {n8}, con congelamiento: {c8}")

print('=' * 110)
print('E7) RECUENTO FINAL con la clasificación definitiva (a30f_congel_clase.py): inicios / filas y / filas vivas')
for s in ORDEN:
    for grupo, cond in [('válidos', 1), ('abortados', 0)]:
        filas = sum(len(sq['f']) for (ep, ag), sq in S[s].items() if int(E[s][ep]['valido']) == cond)
        viv = sum(1 for (ep, ag), sq in S[s].items() if int(E[s][ep]['valido']) == cond for r in sq['f'] if not r['rep'])
        ev = [it for it in I[s] if it['valido'] == cond]
        t = Counter(it['tipo_f'] for it in ev); m = Counter(it['mec'] for it in ev)
        print(f"  {s:6s} {grupo:9s} filas {filas:6d} vivas {viv:6d} inicios {len(ev):2d}  tipo {dict(sorted(t.items()))}  mecanismo {dict(sorted(m.items()))}")
for grupo, cond in [('válidos', 1), ('abortados', 0), ('todos', None)]:
    for dia, lista in [('26-09', ['26-09']), ('30-09', K.SES30)]:
        filas = sum(len(sq['f']) for s in lista for (ep, ag), sq in S[s].items() if cond is None or int(E[s][ep]['valido']) == cond)
        viv = sum(1 for s in lista for (ep, ag), sq in S[s].items() if cond is None or int(E[s][ep]['valido']) == cond for r in sq['f'] if not r['rep'])
        ev = [it for s in lista for it in I[s] if cond is None or it['valido'] == cond]
        t = Counter(it['tipo_f'] for it in ev); m = Counter(it['mec'] for it in ev)
        ka = t['a']
        print(f"  {dia} {grupo:9s} filas {filas} vivas {viv} inicios {len(ev)} tipo {dict(sorted(t.items()))} mecanismo {dict(sorted(m.items()))};"
              f"  (a): {1000*ka/filas:.3f} ‰ de filas, {1000*ka/viv:.3f} ‰ de vivas; todos: {1000*len(ev)/filas:.3f} ‰ de filas")
for grupo, cond in [('válidos', 1), ('todos', None)]:
    def cuenta(lista):
        f_ = sum(len(sq['f']) for s in lista for (ep, ag), sq in S[s].items() if cond is None or int(E[s][ep]['valido']) == cond)
        k_ = sum(1 for s in lista for it in I[s] if it['mec'] == 'Motive' and (cond is None or it['valido'] == cond))
        return k_, f_
    k1, n1 = cuenta(['26-09']); k2, n2 = cuenta(K.SES30)
    _, p = stats.fisher_exact([[k1, n1 - k1], [k2, n2 - k2]])
    print(f"  Motive (a) 26-09 vs 30-09, {grupo}: {k1}/{n1} ({1000*k1/n1:.3f} ‰) vs {k2}/{n2} ({1000*k2/n2:.3f} ‰), cociente {(k2/n2)/(k1/n1):.2f}; Fisher p {p:.3g} (filas no independientes: orientativo)")
# racha de los Motive
for dia, lista in [('26-09', ['26-09']), ('30-09', K.SES30)]:
    ra = sorted(it['racha'] for s in lista for it in I[s] if it['mec'] == 'Motive')
    print(f"  rachas Motive {dia}: {ra}  (≥ 10 filas: {sum(1 for r in ra if r >= 10)}/{len(ra)})")
k1 = sum(1 for it in I['26-09'] if it['mec'] == 'Motive' and it['racha'] >= 10); n1 = sum(1 for it in I['26-09'] if it['mec'] == 'Motive')
k2 = sum(1 for s in K.SES30 for it in I[s] if it['mec'] == 'Motive' and it['racha'] >= 10); n2 = sum(1 for s in K.SES30 for it in I[s] if it['mec'] == 'Motive')
_, p = stats.fisher_exact([[k1, n1 - k1], [k2, n2 - k2]])
print(f"  Motive con racha ≥ 10: 26-09 {k1}/{n1} vs 30-09 {k2}/{n2}  Fisher p {p:.3g}")

print('=' * 110)
print('E8) ROBOT 6 en D (radio 15 cm), 26-09 vs 30-09: inicios / filas vivas (filas autocorrelacionadas: orientativo)')
cx, cy = 1.471, 1.269
def r6(lista, rob_in=True):
    viv = sum(1 for s in lista for sq in S[s].values() if (sq['robot'] == 6) == rob_in for r in sq['f'] if not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < 0.15)
    k = sum(1 for s in lista for it in lugar if it['ses'] == s and (it['robot'] == 6) == rob_in and math.hypot(it['r']['x'] - cx, it['r']['y'] - cy) < 0.15)
    return k, viv
a = r6(['26-09']); b = r6(K.SES30); o = r6(ORDEN, False)
_, p = stats.fisher_exact([[a[0], a[1] - a[0]], [b[0], b[1] - b[0]]])
_, p2 = stats.fisher_exact([[b[0], b[1] - b[0]], [o[0], o[1] - o[0]]])
print(f"  r6 26-09 {a[0]}/{a[1]} vs r6 30-09 {b[0]}/{b[1]}  Fisher p {p:.3g};  r6 30-09 vs otros robots (6 días) {o[0]}/{o[1]}  Fisher p {p2:.3g}")
