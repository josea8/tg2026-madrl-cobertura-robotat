import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): A21 (p95 de sesiones previas con MU-MIMO), A23 (mtimes y diff
respaldo -> actual de sesion_robotat.py), A29 (foto de coordinador_enjambre ahora vs la del analista).
SOLO LECTURA (os.stat, lectura de texto; no se abre ningún archivo de réplica: sólo se lista su nombre)."""
import sys
sys.dont_write_bytecode = True
import os, csv, difflib, datetime
import numpy as np

RAIZ = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
RS = os.path.join(RAIZ, "resultados_sesion")
SP = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
out = []
P = out.append


def ts(p):
    return datetime.datetime.fromtimestamp(os.stat(p).st_mtime).strftime("%Y-%m-%d %H:%M:%S.%f")


# ---- A21: p95 de sesiones previas ----
P("== A21 p95 por episodio en sesiones previas ==")
prev = ["20260911_sesion-evaluacion_etapa7_episodios.csv", "20260922_sesion-evaluacion_etapa7_episodios.csv",
        "20260922_sesion-evaluacion_etapa7_episodios_02.csv", "20260922_sesion-evaluacion_etapa7_episodios_03.csv",
        "20260924_sesion-evaluacion_etapa7_episodios.csv"]
tot = ge = 0
for a in prev:
    with open(os.path.join(RS, a), encoding="utf-8", newline="") as fh:
        F = list(csv.DictReader(fh))
    v = []
    for r in F:
        try:
            v.append(float(r.get("ciclo_p95_ms", "")))
        except ValueError:
            pass
    n25 = sum(1 for x in v if x >= 25)
    tot += len(v); ge += n25
    mot = {}
    for r in F:
        m = (r.get("motivo") or "")[:40]
        mot[m] = mot.get(m, 0) + 1
    P(f"{a}: filas={len(F)} con p95={len(v)} p95>=25: {n25} mediana={np.median(v) if v else float('nan'):.1f} [{min(v) if v else 0:.1f}-{max(v) if v else 0:.1f}] mtime={ts(os.path.join(RS, a))}")
    P(f"     motivos: {mot}")
P(f"TOTAL previas: {ge} de {tot} con p95 >= 25 ms")

# ---- A23: mtimes y diff ----
P("== A23 mtimes ==")
for a in ["20260930_sesion-evaluacion_etapa7_episodios_03.csv", "20260930_sesion-evaluacion_etapa7_episodios_04.csv",
          "20260930_sesion-evaluacion_etapa7_decisiones_04.csv", "20260930_sesion-evaluacion_etapa7_episodios_05.csv"]:
    P(f"  {a}: {ts(os.path.join(RS, a))}")
for a in ["sesion_robotat.py", "sesion_robotat_respaldo_20260930_preDetencion.py", "test_sesion_robotat.py",
          "test_sesion_robotat_respaldo_20260930_preDetencion.py"]:
    P(f"  {a}: {ts(os.path.join(RAIZ, a))}")
viejo = open(os.path.join(RAIZ, "sesion_robotat_respaldo_20260930_preDetencion.py"), encoding="utf-8").read().splitlines()
nuevo = open(os.path.join(RAIZ, "sesion_robotat.py"), encoding="utf-8").read().splitlines()
d = list(difflib.unified_diff(viejo, nuevo, "respaldo_preDetencion", "actual", n=1, lineterm=""))
P(f"  diff respaldo->actual: {len(d)} líneas")
for l in d:
    P("    " + l)
cod = lambda L: [l for l in L if l.strip() and not l.strip().startswith("#")]
dc = [l for l in difflib.unified_diff(cod(viejo), cod(nuevo), lineterm="", n=0) if l[:1] in "+-" and l[:3] not in ("+++", "---")]
P(f"  líneas de CÓDIGO (sin comentarios) que cambian: {dc}")

# ---- A29: foto actual vs foto del analista ----
P("== A29 foto de coordinador_enjambre ==")
ahora = {}
for dd, _, fs in os.walk(RAIZ):
    for f in fs:
        p = os.path.join(dd, f)
        st = os.stat(p)
        ahora[os.path.relpath(p, RAIZ)] = (st.st_size, st.st_mtime_ns)


def leer(nombre):
    r = {}
    for l in open(os.path.join(SP, nombre), encoding="utf-8").read().splitlines():
        if l.strip():
            k, sz, mt = l.split("\t")
            r[k] = (int(sz), int(mt))
    return r


antes = leer("a30f_robots_mtimes_antes.txt")
desp = leer("a30f_robots_mtimes_despues.txt")
P(f"  analista antes={len(antes)} después={len(desp)} ; ahora={len(ahora)}")
for nom, ref in (("antes(analista)->después(analista)", (antes, desp)), ("antes(analista)->ahora", (antes, ahora)), ("después(analista)->ahora", (desp, ahora))):
    a, b = ref
    nuevos = sorted(set(b) - set(a)); borr = sorted(set(a) - set(b)); cam = sorted(k for k in set(a) & set(b) if a[k] != b[k])
    P(f"  {nom}: nuevos={[(k, datetime.datetime.fromtimestamp(b[k][1]/1e9).strftime('%H:%M:%S')) for k in nuevos]} borrados={borr} cambiados={cam}")
pyc_nuevos = [k for k in ahora if "__pycache__" in k and (k not in antes)]
P(f"  __pycache__ nuevos respecto de 'antes' del analista: {pyc_nuevos}")
open(os.path.join(SP, "a30f_verif_robots_6_codigo_ritmo_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
