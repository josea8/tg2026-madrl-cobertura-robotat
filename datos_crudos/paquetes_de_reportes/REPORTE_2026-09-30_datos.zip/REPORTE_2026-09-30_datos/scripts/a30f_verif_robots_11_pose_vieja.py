import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR: discriminador caché vs retención de Motive con los avisos 'Decisión con pose vieja'
de las consolas: tick de cada aviso, episodio, y diferencias entre avisos del mismo episodio
(10 ticks = 1 decisión). Se cruza con rechazos/fallas del CSV y con los CONGELADOS del 26-09.
SOLO LECTURA."""
import sys
sys.dont_write_bytecode = True
import os, re, csv
SP = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
CONS = {"s1": ("consola_20260930.txt", "20260930_sesion-evaluacion_etapa7_episodios.csv"),
        "s2": ("consola_20260930_02.txt", "20260930_sesion-evaluacion_etapa7_episodios_02.csv"),
        "s3": ("consola_20260930_03.txt", "20260930_sesion-evaluacion_etapa7_episodios_03.csv"),
        "s5": ("consola_20260930_05.txt", "20260930_sesion-evaluacion_etapa7_episodios_05.csv"),
        "c26": ("consola_20260926.txt", "20260926_sesion-evaluacion_etapa7_episodios.csv")}
out = []
for s, (c, e) in CONS.items():
    with open(os.path.join(D, e), encoding="utf-8", newline="") as fh:
        E = {int(r["episodio"]): r for r in csv.DictReader(fh)}
    ep = None
    avisos = []
    for l in open(os.path.join(SP, c), encoding="utf-8").read().splitlines():
        m = re.match(r"^EPISODIO (\d+)\s+\(válidos", l)
        if m:
            ep = int(m.group(1))
        m = re.search(r"pose vieja: antigüedad=(\d+) ticks .* en tick (\d+)", l)
        if m:
            avisos.append((ep, int(m.group(1)), int(m.group(2))))
    out.append(f"{s}: {len(avisos)} avisos")
    for ep_ in sorted({a[0] for a in avisos}):
        L = [a for a in avisos if a[0] == ep_]
        r = E[ep_]
        dif = [L[k][2] - L[k - 1][2] for k in range(1, len(L))]
        out.append(f"   ep{ep_} (valido={r['valido']}, fallidas={r['poses_fallidas']}, rechazadas={r['poses_rechazadas']}, motivo='{r['motivo'][:45]}'): "
                   f"avisos (antig, tick)={[(a[1], a[2]) for a in L]} diferencias de tick={dif} (=decisiones {[d/10 for d in dif]})")
    cong = [k for k, r in E.items() if "CONGELADO" in r["motivo"]]
    if cong:
        out.append(f"   episodios con marcador CONGELADO (retención de Motive) en este CSV: {cong}; con aviso de pose vieja: {[k for k in cong if any(a[0]==k for a in avisos)]}")
open(os.path.join(SP, "a30f_verif_robots_11_pose_vieja_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
