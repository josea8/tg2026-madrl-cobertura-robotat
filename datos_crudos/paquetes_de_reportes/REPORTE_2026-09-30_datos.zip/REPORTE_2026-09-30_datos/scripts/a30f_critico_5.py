import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico (5): rachas de 'seguimiento de pared' (≥10 s seguidos con d_pared < 0.18) por episodio,
26-09 vs 30-09, con y sin r5, pareado por semilla compartida. SOLO LECTURA; sin réplica.
Uso: python -B a30f_critico_5.py > a30f_critico_5_salida.txt"""
import sys
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SES = {
    "26-09": ("20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
    "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv"),
    "S2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv", "20260930_sesion-evaluacion_etapa7_decisiones_02.csv"),
    "S3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv", "20260930_sesion-evaluacion_etapa7_decisiones_03.csv"),
    "S4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv", "20260930_sesion-evaluacion_etapa7_decisiones_04.csv"),
    "S5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv", "20260930_sesion-evaluacion_etapa7_decisiones_05.csv"),
}
rows = []
for s, (fe, fd) in SES.items():
    e = pd.read_csv(f"{RS}\\{fe}")
    d = pd.read_csv(f"{RS}\\{fd}")
    vv = e[e.valido == 1]
    d = d[d.episodio.isin(set(vv.episodio))].sort_values(["episodio", "agente", "paso"])
    x, y = d.pose_env_x.to_numpy(), d.pose_env_y.to_numpy()
    d["dp"] = np.minimum.reduce([x, 3 - x, y, 3 - y])
    for ep, g_ep in d.groupby("episodio"):
        sem = int(vv[vv.episodio == ep].semilla.iloc[0])
        n10 = n10s5 = 0
        filas_banda = 0
        for a, g in g_ep.groupby("agente"):
            b = (g.dp.to_numpy() < 0.18).astype(int)
            dif = np.diff(np.r_[0, b, 0]); ln = np.where(dif == -1)[0] - np.where(dif == 1)[0]
            k = int((ln >= 100).sum())
            n10 += k
            if int(g.robot.iloc[0]) != 5:
                n10s5 += k
        banda = ((g_ep.dp >= 0.16) & (g_ep.dp < 0.18)).mean()
        rows.append(dict(ses=s, ep=int(ep), semilla=sem, dia30=int(s != "26-09"), n10=n10, n10_sin5=n10s5, banda=banda))
T = pd.DataFrame(rows)
for y in ("n10", "n10_sin5", "banda"):
    a30, a26 = T[T.dia30 == 1][y], T[T.dia30 == 0][y]
    comp = sorted(set(T[T.dia30 == 0].semilla) & set(T[T.dia30 == 1].semilla))
    difs = [T[(T.dia30 == 1) & (T.semilla == s_)][y].mean() - float(T[(T.dia30 == 0) & (T.semilla == s_)][y].iloc[0]) for s_ in comp]
    print(f"{y:9s} 30-09 {a30.mean():.3f}/ep (suma {a30.sum():.0f}) · 26-09 {a26.mean():.3f}/ep (suma {a26.sum():.0f}) · MW p {stats.mannwhitneyu(a30, a26).pvalue:.3f}"
          f" · pareada 5 semillas " + " ".join(f"{d_:+.2f}" for d_ in difs))
    if y != "banda":
        # razón de tasas de Poisson (condicional binomial)
        n1, n0 = int(a30.sum()), int(a26.sum())
        p = stats.binomtest(n1, n1 + n0, 50 / 60).pvalue
        print(f"          razón de tasas {(n1 / 50) / max(n0 / 10, 1e-9):.2f} · prueba binomial condicional p {p:.4f} (supone Poisson independiente: orientativa)")
print("banda = fracción de filas con 0.16 ≤ d_pared < 0.18 (seguimiento de pared bajo el margen)")
