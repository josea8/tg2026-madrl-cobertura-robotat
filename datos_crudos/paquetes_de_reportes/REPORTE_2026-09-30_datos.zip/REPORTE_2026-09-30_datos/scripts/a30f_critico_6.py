import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico (6): ¿sesgo de selección en el control 26-09? Los abortados del 26-09 (9/19) fueron sobre todo por
congelamientos en la esquina +x+y (junto a paredes). Si abortar selecciona contra el tiempo junto a la pared,
el 26-09 'válido' subestima la pared. Compara tasas por decisión en válidos vs abortados (filas vivas antes del aborto).
SOLO LECTURA; sin réplica. Uso: python -B a30f_critico_6.py > a30f_critico_6_salida.txt"""
import sys
sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SES = {
    "26-09": ("20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
    "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv"),
    "S2": ("20260930_sesion-evaluacion_etapa7_episodios_02.csv", "20260930_sesion-evaluacion_etapa7_decisiones_02.csv"),
    "S3": ("20260930_sesion-evaluacion_etapa7_episodios_03.csv", "20260930_sesion-evaluacion_etapa7_decisiones_03.csv"),
    "S4": ("20260930_sesion-evaluacion_etapa7_episodios_04.csv", "20260930_sesion-evaluacion_etapa7_decisiones_04.csv"),
    "S5": ("20260930_sesion-evaluacion_etapa7_episodios_05.csv", "20260930_sesion-evaluacion_etapa7_decisiones_05.csv"),
}
rows = []
for s, (fe, fd) in SES.items():
    e = pd.read_csv(f"{RS}\\{fe}")
    d = pd.read_csv(f"{RS}\\{fd}").sort_values(["episodio", "agente", "paso"])
    x, y = d.pose_env_x.to_numpy(), d.pose_env_y.to_numpy()
    d["dp"] = np.minimum.reduce([x, 3 - x, y, 3 - y])
    g_ = d.groupby(["episodio", "agente"])
    d["rep"] = ((d.pose_env_x == g_.pose_env_x.shift()) & (d.pose_env_y == g_.pose_env_y.shift())
                & (d.pose_env_th == g_.pose_env_th.shift())).fillna(False)
    for _, r in e.iterrows():
        z = d[d.episodio == r.episodio]
        if z.empty:
            continue
        # sólo filas 'vivas': excluye las repetidas (el aborto llega tras poses repetidas/vencidas)
        zv = z[~z.rep.astype(bool)]
        act = 0
        for a, g in z.groupby("agente"):
            e_ = g.en_escape.to_numpy(); act += int(((e_[1:] == 1) & (e_[:-1] == 0)).sum() + (e_[0] == 1))
        cerca_c = np.hypot(zv.pose_env_x - 2.6, zv.pose_env_y - 2.6) < 0.5       # cuadrante de la esquina +x+y
        rows.append(dict(dia="26-09" if s == "26-09" else "30-09", ses=s, ep=int(r.episodio), valido=int(r.valido),
                         pasos=int(z.paso.max()) + 1, filas=len(zv), f018=(zv.dp < 0.18).mean(), f015=(zv.dp < 0.15).mean(),
                         act_x500=act / (z.paso.max() + 1) * 500, esq=cerca_c.mean(), motivo=str(r.motivo)[:60]))
T = pd.DataFrame(rows)
for dia in ("26-09", "30-09"):
    z = T[T.dia == dia]
    for v in (1, 0):
        w = z[z.valido == v]
        pes = w.filas / w.filas.sum()
        print(f"{dia} {'válidos ' if v else 'abortados'} n {len(w):2d} · pasos medios {w.pasos.mean():5.0f} · f018 ponderada {np.sum(pes * w.f018):.4f}"
              f" (mediana por ep {w.f018.median():.4f}) · f015 {np.sum(pes * w.f015):.4f} · escape act/500 dec {w.act_x500.mean():.2f}"
              f" · frac. filas a <0.5 m de (2.6, 2.6) {np.sum(pes * w.esq):.4f}")
    a, b = z[z.valido == 1].f018, z[z.valido == 0].f018
    print(f"   MW f018 válidos vs abortados p {stats.mannwhitneyu(a, b).pvalue:.3f} · MW esquina p {stats.mannwhitneyu(z[z.valido == 1].esq, z[z.valido == 0].esq).pvalue:.3f}")
print("\nAbortados del 26-09 (motivo, pasos, f018, fracción en la esquina +x+y):")
for _, r in T[(T.dia == "26-09") & (T.valido == 0)].iterrows():
    print(f"  ep{r.ep:2d} pasos {r.pasos:3d} f018 {r.f018:.3f} esq {r.esq:.3f} · {r.motivo}")
# si el 26-09 hubiera conservado sus abortados: f018 ponderada por filas de TODOS los episodios
z = T[T.dia == "26-09"]
print(f"\n26-09 f018 ponderada por filas, TODOS los episodios: {np.sum(z.filas / z.filas.sum() * z.f018):.4f} (válidos solos arriba)")
z = T[T.dia == "30-09"]
print(f"30-09 f018 ponderada por filas, TODOS los episodios: {np.sum(z.filas / z.filas.sum() * z.f018):.4f}")
