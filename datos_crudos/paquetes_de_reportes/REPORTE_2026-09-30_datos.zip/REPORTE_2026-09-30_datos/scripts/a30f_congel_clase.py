import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_congel_clase.py — clasificación FINAL de cada evento (la importan mapa y retroceso).
No imprime ni escribe nada. SÓLO LECTURA.

tipo (pedido):  (a) un solo robot, pose retenida por Motive (sin evidencia de caché ni de hipo)
                (b) simultáneo en ≥2 robots en la misma decisión
                (c) otro: un solo robot con caché por pose rechazada, o un solo robot en un hipo de ritmo
mecanismo:      'Motive'            retención (punto ciego u oclusión) — por exclusión
                'caché-fallida'     consulta fallida → pose en caché en los 5 ([sync] + poses_fallidas)
                'caché-rechazo'     pose rechazada (inclinación) → caché en ese robot ([sync] + poses_rechazadas)
                'hipo'              firma de ritmo: otros agentes r_prev>1.6 y r<0.30 (a30f_congel_ritmo.py)
"""
import io, sys
import a30f_congel_comun as K
_o = sys.stdout; sys.stdout = io.TextIOWrapper(io.BytesIO(), encoding='utf-8')
import a30f_congel_ritmo as RIT          # fija it['hipo'], it['r_otros'], it['rprev_otros']
sys.stdout = _o
S, E, C, I = K.S, K.E, K.C, K.I

for ses in I:
    for it in I[ses]:
        e = E[ses][it['ep']]
        pf = int(e['poses_fallidas'] or 0)
        inferido = C[ses] is None
        if it['n_ini_paso'] >= 2:
            it['tipo_f'] = 'b'
            if it['n_ini_paso'] >= it['n_ag'] and pf > 0:
                it['mec'] = 'caché-fallida'
            elif it.get('hipo'):
                it['mec'] = 'hipo'
            else:
                it['mec'] = 'b-sin-explicar'
        elif it['tipo'] == 'c':
            it['tipo_f'] = 'c'; it['mec'] = 'caché-rechazo'
        elif it.get('hipo'):
            it['tipo_f'] = 'c'; it['mec'] = 'hipo'
        else:
            it['tipo_f'] = 'a'; it['mec'] = 'Motive'
        it['inferido'] = inferido

MEC_TXT = {'Motive': 'retención de Motive (punto ciego / oclusión)', 'caché-fallida': 'caché por consulta fallida (5 robots)',
           'caché-rechazo': 'caché por pose rechazada (inclinación)', 'hipo': 'hipo de ritmo del lazo (consultas casi seguidas)',
           'b-sin-explicar': 'simultáneo sin explicación'}
