import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_deriva_metricas.py — SOLO LECTURA. Punto 4: ¿el arreglo pudo cambiar métricas DENTRO del episodio?
#  (a) diff del código: respaldo preDetencion vs sesion_robotat.py vigente, posición de detener_todo()
#      respecto de las métricas que devuelve _correr_episodio; mtimes de código y CSV.
#  (b) descriptivo de duracion_s, decisiones y ciclo_p95_ms: s5 vs s1–s4 (y 26-09 como referencia).
import csv, os, re, difflib, datetime
import numpy as np

C = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
R = os.path.join(C, "resultados_sesion")
S = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
out = []
def P(*a):
    s = " ".join(str(x) for x in a); out.append(s); print(s)

# ---------------- (a) código ----------------
P("=" * 100); P("(a) CÓDIGO: respaldo preDetencion vs vigente"); P("=" * 100)
fa = os.path.join(C, "sesion_robotat_respaldo_20260930_preDetencion.py")
fb = os.path.join(C, "sesion_robotat.py")
A = open(fa, encoding="utf-8").read().splitlines(); B = open(fb, encoding="utf-8").read().splitlines()
d = [l for l in difflib.unified_diff(A, B, "preDetencion", "vigente", lineterm="", n=0)]
cambios_mas = [l for l in d if l.startswith("+") and not l.startswith("+++")]
cambios_menos = [l for l in d if l.startswith("-") and not l.startswith("---")]
P(f"  líneas: respaldo {len(A)}, vigente {len(B)};  añadidas {len(cambios_mas)}, quitadas {len(cambios_menos)}")
P("  quitadas: " + repr([l[1:].strip() for l in cambios_menos]))
P("  añadidas NO comentario: " + repr([l[1:].strip() for l in cambios_mas if not l[1:].strip().startswith("#")]))
# ubicación en _correr_episodio (vigente)
i0 = next(i for i, l in enumerate(B) if l.startswith("def _correr_episodio"))
i1 = next(i for i in range(i0 + 1, len(B)) if B[i].startswith("def "))
marcas = {}
for i in range(i0, i1):
    l = B[i]
    for clave, pat in (("detener_todo", r"canal\.detener_todo\(\)"), ("cerrar_todos", r"gestor\.cerrar_todos\("),
                       ("cob", r"^\s+cob = "), ("duracion (ritmo)", r"^\s+duracion = time\.perf_counter"),
                       ("return dict", r"^\s+return \{"), ("duracion_s", r'"duracion_s":'),
                       ("decisiones", r'"decisiones":\s+len\(tiempos_ciclo_ms\)'),
                       ("ciclo_p95_ms", r'"ciclo_p95_ms":'), ("tramo", r"^\s+tramo = registro\[marca:\]")):
        if re.search(pat, l):
            marcas.setdefault(clave, []).append(i + 1)
for k, v in marcas.items():
    P(f"  {k:18s} línea(s) {v}")
P("  lectura: detener_todo() queda después del lazo de decisiones y de gestor.cerrar_todos(); ANTES de")
P("  'tramo', 'cob', 'duracion' y del dict devuelto. 'decisiones' y 'ciclo_p95_ms' salen de tiempos_ciclo_ms (lazo);")
P("  'duracion_s' = perf_counter()-t0 evaluado DESPUÉS de la llamada → incluye su tiempo (igual que ya pasaba en los abortados).")
# mtimes
def mt(p):
    return datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S")
P(f"  mtime sesion_robotat.py = {mt(fb)};  respaldo preDetencion = {mt(fa)}")
for suf in ("", "_02", "_03", "_04", "_05"):
    P(f"  mtime episodios{suf or '_01'} = {mt(os.path.join(R, f'20260930_sesion-evaluacion_etapa7_episodios{suf}.csv'))}")

# ---------------- (b) descriptivo ----------------
P("\n" + "=" * 100); P("(b) DESCRIPTIVO duracion_s, decisiones, ciclo_p95_ms (DE con ddof=1)"); P("=" * 100)
SES = [("26-09", "20260926", ""), ("s1", "20260930", ""), ("s2", "20260930", "_02"), ("s3", "20260930", "_03"),
       ("s4", "20260930", "_04"), ("s5", "20260930", "_05")]
datos = {}
for k, f, suf in SES:
    datos[k] = list(csv.DictReader(open(os.path.join(R, f"{f}_sesion-evaluacion_etapa7_episodios{suf}.csv"), encoding="utf-8")))
def desc(v):
    v = np.asarray(v, float)
    if len(v) == 0: return "—"
    q1, q3 = np.percentile(v, [25, 75])
    sd = np.std(v, ddof=1) if len(v) > 1 else float("nan")
    return (f"n={len(v):2d} mediana {np.median(v):10.4f}  RIC [{q1:10.4f},{q3:10.4f}]  mín {v.min():10.4f}  máx {v.max():10.4f}  "
            f"media {v.mean():10.4f} ± {sd:.4f}")
for campo in ("duracion_s", "decisiones", "ciclo_p95_ms", "ciclos_sobre_100ms"):
    P(f"\n-- {campo}")
    for filtro, nom in ((lambda e: e["valido"] == "1", "válidos"), (lambda e: True, "todos")):
        for k in ["26-09", "s1", "s2", "s3", "s4", "s5"]:
            P(f"  {k:6s} {nom:8s} {desc([float(e[campo]) for e in datos[k] if filtro(e)])}")
        P(f"  {'s1–s4':6s} {nom:8s} {desc([float(e[campo]) for k in ('s1','s2','s3','s4') for e in datos[k] if filtro(e)])}")
        P(f"  {'s5':6s} {nom:8s} {desc([float(e[campo]) for e in datos['s5'] if filtro(e)])}")
# exceso de duración en válidos (duracion_s − decisiones×0.1)
P("\n-- exceso de duración en VÁLIDOS: duracion_s − 0.1·decisiones  [ms]")
for k in ["26-09", "s1", "s2", "s3", "s4", "s5"]:
    v = [(float(e["duracion_s"]) - 0.1 * float(e["decisiones"])) * 1000 for e in datos[k] if e["valido"] == "1"]
    P(f"  {k:6s} {desc(v)}")
v14 = [(float(e["duracion_s"]) - 0.1 * float(e["decisiones"])) * 1000 for k in ("s1","s2","s3","s4") for e in datos[k] if e["valido"] == "1"]
P(f"  s1–s4  {desc(v14)}")
# extra (no pedido): colocación siguiente
P("\n-- (extra, descriptivo) col_t_s de la colocación, episodios 2..N (la colocación del ep 1 no sigue a otro episodio)")
for k in ["26-09", "s1", "s2", "s3", "s4", "s5"]:
    v = [float(e["col_t_s"]) for e in datos[k][1:] if e["col_t_s"] not in ("", None)]
    P(f"  {k:6s} {desc(v)}")
open(os.path.join(S, "a30f_deriva_metricas_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
