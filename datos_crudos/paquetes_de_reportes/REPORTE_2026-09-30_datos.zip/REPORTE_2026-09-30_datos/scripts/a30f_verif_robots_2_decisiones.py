import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): recálculo independiente sobre los CSV de DECISIONES
(A02, A04, A06, A07, A25, A26, A27). SOLO LECTURA. Escrito desde cero.
Definiciones propias:
  - repetición: fila de un agente con (x, y, θ) textual idéntica a su fila anterior en el
    mismo episodio (comparo el TEXTO del CSV y, como control, los floats).
  - inicio de racha: repetición cuya fila anterior NO era a su vez repetición.
  - seguimiento: réplica de DetectorSeguimiento.observar (sesion_robotat.py): cola de 50 pares
    (avance_k = |p_k - p_{k-1}|, comandado_k = |v_k|·factor·dt), no se juzga si Σcomandado<0.10;
    dt nominal 0.1 s; factor 0.10 en las primeras 50 decisiones del PRIMER intento de cada
    sesión (una sola línea 'ARRANQUE SEGURO' por consola) y 0.40 después; 0 si en_retroceso.
  - pivote: ventanas de 21 poses (2 s) cada 10 decisiones, |Δθ desenrollado|/2 s ≥ 90 °/s,
    radio del círculo ajustado por mínimos cuadrados < 0.07 m, ninguna fila en retroceso."""
import sys
sys.dont_write_bytecode = True
import csv, os, math
from collections import defaultdict, Counter
import numpy as np

D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
DEC = {1: "20260930_sesion-evaluacion_etapa7_decisiones.csv", 2: "20260930_sesion-evaluacion_etapa7_decisiones_02.csv",
       3: "20260930_sesion-evaluacion_etapa7_decisiones_03.csv", 4: "20260930_sesion-evaluacion_etapa7_decisiones_04.csv",
       5: "20260930_sesion-evaluacion_etapa7_decisiones_05.csv", 26: "20260926_sesion-evaluacion_etapa7_decisiones.csv"}
EPI = {1: "20260930_sesion-evaluacion_etapa7_episodios.csv", 2: "20260930_sesion-evaluacion_etapa7_episodios_02.csv",
       3: "20260930_sesion-evaluacion_etapa7_episodios_03.csv", 4: "20260930_sesion-evaluacion_etapa7_episodios_04.csv",
       5: "20260930_sesion-evaluacion_etapa7_episodios_05.csv", 26: "20260926_sesion-evaluacion_etapa7_episodios.csv"}
ROB = [1, 5, 8, 6, 9]
CIEGO = {"A": (2.54, 2.20), "B": (2.82, 2.49), "C": (2.52, 2.79)}
out = []
P = out.append


def dpar(x, y):
    return min(x, 3 - x, y, 3 - y)


def ciego(x, y):
    return min((math.hypot(x - cx, y - cy), k) for k, (cx, cy) in CIEGO.items())


resumen_seg = {}
resumen_rep = {}
resumen_piv = {}
for s in [1, 2, 3, 4, 5, 26]:
    with open(os.path.join(D, EPI[s]), encoding="utf-8", newline="") as fh:
        E = {int(r["episodio"]): r for r in csv.DictReader(fh)}
    G = defaultdict(list)
    with open(os.path.join(D, DEC[s]), encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            G[(int(r["episodio"]), int(r["agente"]))].append(r)
    for k in G:
        G[k].sort(key=lambda r: int(r["paso"]))
    primer = min(E)
    P("=" * 100)
    P(f"SESIÓN s{s}")
    # control: pasos consecutivos y conteo de filas por episodio = decisiones
    for ep in sorted(E):
        n = [len(G[(ep, a)]) for a in range(5)]
        pasos = [int(r["paso"]) for r in G[(ep, 0)]]
        if not (len(set(n)) == 1 and n[0] == int(E[ep]["decisiones"]) and pasos == list(range(n[0]))):
            P(f"   ⚠ ep{ep}: filas por agente {n}, decisiones CSV {E[ep]['decisiones']}, pasos 0..{max(pasos)}")
    # ---------- repeticiones ----------
    inicios = []                       # (ep, paso_inicio, paso_fin, agente, x, y)
    filas_rep = Counter()              # (ep) -> nº de filas repetidas
    for (ep, a), L in G.items():
        k = 1
        while k < len(L):
            t = lambda r: (r["pose_env_x"], r["pose_env_y"], r["pose_env_th"])
            if t(L[k]) == t(L[k - 1]):
                j = k
                while j + 1 < len(L) and t(L[j + 1]) == t(L[j]):
                    j += 1
                inicios.append((ep, int(L[k]["paso"]), int(L[j]["paso"]), a, float(L[k]["pose_env_x"]), float(L[k]["pose_env_y"])))
                filas_rep[ep] += j - k + 1
                k = j + 1
            else:
                k += 1
    # control con floats
    nf = 0
    for (ep, a), L in G.items():
        for k in range(1, len(L)):
            if all(float(L[k][c]) == float(L[k - 1][c]) for c in ("pose_env_x", "pose_env_y", "pose_env_th")):
                nf += 1
    P(f"   filas repetidas (texto) = {sum(filas_rep.values())}; (float) = {nf}")
    por_paso = defaultdict(list)
    for x in inicios:
        por_paso[(x[0], x[1])].append(x)
    P("   inicios de racha:")
    for (ep, p), L in sorted(por_paso.items()):
        for (ep_, p0, p1, a, x, y) in L:
            dc, kc = ciego(x, y)
            P(f"     ep{ep:>2} {'V' if E[ep]['valido'].strip()=='1' else 'INV'} pasos {p0}-{p1} r{ROB[a]} ({x:.3f},{y:.3f}) d_pared={dpar(x,y):.3f} "
              f"ciego {kc} a {dc:.3f} · simultáneos={len(L)} · ep fall={E[ep]['poses_fallidas']} rech={E[ep]['poses_rechazadas']} · ult_paso_ep={int(E[ep]['decisiones'])-1}")
    resumen_rep[s] = (inicios, por_paso, E)
    # ---------- A02: última decisión de s1 ep1/ep2 ----------
    for ep in sorted(E):
        if E[ep]["valido"].strip() != "1":
            ult = []
            for a in range(5):
                L = G[(ep, a)]
                t = lambda r: (r["pose_env_x"], r["pose_env_y"], r["pose_env_th"])
                ult.append(int(len(L) >= 2 and t(L[-1]) == t(L[-2])))
            P(f"   inválido ep{ep}: última decisión paso={G[(ep,0)][-1]['paso']} agentes con pose idéntica a la anterior: {[ROB[a] for a in range(5) if ult[a]]}")
    # ---------- seguimiento ----------
    seg = defaultdict(list)
    dispara = []
    for (ep, a), L in G.items():
        xy = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in L])
        v = np.array([abs(float(r["v_ejecutada"])) for r in L])
        ret = np.array([int(r["en_retroceso"]) for r in L])
        paso = np.array([int(r["paso"]) for r in L])
        fac = np.where((ep == primer) & (paso < 50), 0.10, 0.40)
        com = np.where(ret == 1, 0.0, v * fac * 0.1)
        cola = []
        primero_disp = None
        for k in range(1, len(L)):
            cola.append((float(np.hypot(*(xy[k] - xy[k - 1]))), float(com[k])))
            if len(cola) > 50:
                cola.pop(0)
            if len(cola) < 50:
                continue
            c = sum(q[1] for q in cola)
            if c < 0.10:
                continue
            ratio = sum(q[0] for q in cola) / c
            seg[(ROB[a], E[ep]["valido"].strip())].append((ep, ratio))
            if ratio < 0.5 and primero_disp is None:
                primero_disp = (ep, ROB[a], int(paso[k]), round(ratio, 3))
        if primero_disp:
            dispara.append(primero_disp)
    P(f"   seguimiento: primer disparo (<0.50) por agente-episodio: {sorted(dispara)}")
    for rb in ROB:
        w = seg[(rb, "1")]
        if w:
            mn = min(w, key=lambda q: q[1])
            P(f"     r{rb}: válidos mín={mn[1]:.3f} (ep{mn[0]}) n_ventanas={len(w)}")
    resumen_seg[s] = {rb: min(q[1] for q in seg[(rb, '1')]) for rb in ROB if seg[(rb, '1')]}
    # ---------- pivote ----------
    piv = []
    for (ep, a), L in G.items():
        xy = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in L])
        th = np.unwrap(np.array([float(r["pose_env_th"]) for r in L]))
        ret = np.array([int(r["en_retroceso"]) for r in L])
        for k in range(0, len(L) - 20, 10):
            w = math.degrees(th[k + 20] - th[k]) / 2.0
            if abs(w) < 90 or ret[k:k + 21].any():
                continue
            X = xy[k:k + 21]
            A = np.c_[2 * X[:, 0], 2 * X[:, 1], np.ones(21)]
            sol, *_ = np.linalg.lstsq(A, (X ** 2).sum(1), rcond=None)
            rad = math.sqrt(max(sol[2] + sol[0] ** 2 + sol[1] ** 2, 0.0))
            if rad < 0.07:
                piv.append((ep, ROB[a], k, round(w), round(rad * 100, 1), E[ep]["valido"].strip()))
    P(f"   pivotes (firma geométrica): {len(piv)} {piv[:40]}")
    P(f"     por robot: {dict(Counter(p[1] for p in piv))}")
    resumen_piv[s] = piv
    # ---------- A04 específicos ----------
    if s == 2:
        L3 = G[(3, 1)]; L2 = G[(2, 1)]
        xy3 = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in L3])
        ext = xy3.max(0) - xy3.min(0)
        dmax = max(np.hypot(*(xy3 - xy3[0]).T))
        P(f"   A04 s2 ep3 a1/r5: filas={len(L3)} rango x={ext[0]*1000:.4f} mm y={ext[1]*1000:.4f} mm diag={np.hypot(*ext)*1000:.4f} mm, "
          f"máx dist al inicio={dmax*1000:.4f} mm, |v| media={np.mean([abs(float(r['v_ejecutada'])) for r in L3]):.4f}, pos media=({xy3[:,0].mean():.3f},{xy3[:,1].mean():.3f})")
        fin2 = np.array([float(L2[-1]["pose_env_x"]), float(L2[-1]["pose_env_y"])])
        P(f"   A04 fin ep2 r5=({fin2[0]:.4f},{fin2[1]:.4f}) inicio ep3=({xy3[0,0]:.4f},{xy3[0,1]:.4f}) dist={np.hypot(*(xy3[0]-fin2))*1000:.3f} mm")
        # ep2 r5: cuánto se movió en las últimas 50 decisiones
        xy2 = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in L2])
        P(f"   A04 s2 ep2 r5: camino total {np.sum(np.hypot(*np.diff(xy2,axis=0).T)):.3f} m; últimos 50: {np.sum(np.hypot(*np.diff(xy2[-51:],axis=0).T)):.4f} m")

P("")
P("=" * 100)
P("RESUMEN 30-09")
P("seguimiento mín en válidos por robot y sesión: ")
for rb in ROB:
    P(f"  r{rb}: " + " ".join(f"s{s}={resumen_seg[s].get(rb, float('nan')):.3f}" for s in [1, 2, 3, 4, 5]))
allmin = min((v, s, rb) for s in [1, 2, 3, 4, 5] for rb, v in resumen_seg[s].items())
P(f"  mínimo global en válidos 30-09: {allmin}")
# repeticiones individuales 30-09 por robot
P("repeticiones (inicios de racha) no simultáneas con los 5, por robot:")
indiv = []
for s in [1, 2, 3, 4, 5]:
    inicios, por_paso, E = resumen_rep[s]
    for (ep, p), L in por_paso.items():
        if len(L) >= 5:
            continue
        for (ep_, p0, p1, a, x, y) in L:
            indiv.append((s, ep, p0, p1, ROB[a], x, y, len(L), E[ep]["poses_rechazadas"]))
for rb in ROB:
    L = [x for x in indiv if x[4] == rb]
    P(f"  r{rb}: {len(L)} inicios")
    for x in L:
        dc, kc = ciego(x[5], x[6])
        P(f"     s{x[0]} ep{x[1]} pasos {x[2]}-{x[3]} ({x[5]:.3f},{x[6]:.3f}) ciego {kc} {dc:.3f} simult={x[7]} rech_ep={x[8]}")
P("pivotes 30-09 total: " + str(sum(len(resumen_piv[s]) for s in [1, 2, 3, 4, 5])) + " ; 26-09: " + str(len(resumen_piv[26])) +
  " (por robot 26-09: " + str(dict(Counter(p[1] for p in resumen_piv[26]))) + ")")
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "a30f_verif_robots_2_decisiones_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
