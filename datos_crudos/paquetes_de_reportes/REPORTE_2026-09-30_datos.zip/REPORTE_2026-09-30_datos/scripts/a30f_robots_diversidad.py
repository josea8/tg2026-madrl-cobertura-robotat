import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Tarea 3: chequeo de diversidad del proyecto (diversidad_arranques.evaluar, sin modificarlo,
semilla del Monte Carlo = 0 como la sesión) sobre los 50 arranques válidos del 30-09.

diversidad_arranques importa sólo numpy, pero su Monte Carlo hace
`from sesion_robotat import sortear_poses_arranque`, y sesion_robotat carga la pila. Para NO
importarla se registra un módulo 'sesion_robotat' falso cuya ÚNICA función es el texto LITERAL
de `sortear_poses_arranque` extraído de sesion_robotat.py (lectura de texto, exec en un espacio
de nombres con las mismas constantes leídas del archivo) → mismas llamadas al rng, mismos números.
SOLO LECTURA. Uso: python -B a30f_robots_diversidad.py"""
import sys
sys.dont_write_bytecode = True
COORD = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
sys.path.insert(0, COORD)
import copy, os, re, types
from collections import Counter
from typing import Dict, List, Optional
import numpy as np
from a30f_robots_comun import SES30, leer_ep

# ---- módulo falso 'sesion_robotat' con el texto literal de la función ------------------------
src = open(os.path.join(COORD, "sesion_robotat.py"), encoding="utf-8").read()
ini = src.index("def sortear_poses_arranque(")
fin = src.index("\ndef ", ini + 10)
texto_fn = src[ini:fin]
margen = float(re.search(r"^MARGEN_ARRANQUE_M: float = ([\d.]+)", src, re.M).group(1))
dsep = float(re.search(r"^D_SEPARACION_OBJETIVO_M: float = ([\d.]+)", src, re.M).group(1))
cfgsrc = open(os.path.join(COORD, "config_robotat.py"), encoding="utf-8").read()
wx = float(re.search(r"^ARENA_WX_M: float = ([\d.]+)", cfgsrc, re.M).group(1))
wy = float(re.search(r"^ARENA_WY_M: float = ([\d.]+)", cfgsrc, re.M).group(1))
ns = {"np": np, "Optional": Optional, "Dict": Dict, "List": List, "MARGEN_ARRANQUE_M": margen,
      "D_SEPARACION_OBJETIVO_M": dsep, "cfg": types.SimpleNamespace(ARENA_WX_M=wx, ARENA_WY_M=wy)}
exec(compile("from __future__ import annotations\n" + texto_fn, "sesion_robotat.py[sortear_poses_arranque]", "exec"), ns)
falso = types.ModuleType("sesion_robotat")
falso.sortear_poses_arranque = ns["sortear_poses_arranque"]
sys.modules["sesion_robotat"] = falso
import diversidad_arranques as da   # noqa: E402

assert "torch" not in sys.modules
print(f"sortear_poses_arranque: {len(texto_fn.splitlines())} líneas literales de sesion_robotat.py; MARGEN={margen} "
      f"D_SEP_BLANCOS={dsep} arena={wx}×{wy}; torch cargado: {'torch' in sys.modules}; "
      f"sesion_robotat real cargado: {getattr(sys.modules['sesion_robotat'], '__file__', None)}")
# control de fidelidad: los blancos del CSV deben salir IGUALES del sorteo con la semilla del episodio
E_all = {s: leer_ep(s) for s in SES30}
mx = 0.0
for s in SES30:
    for f in E_all[s]:
        b = falso.sortear_poses_arranque(5, np.random.default_rng(int(f["semilla"])))
        for a in range(5):
            mx = max(mx, abs(b[a][0] - float(f[f"blanco_x_a{a}"])), abs(b[a][1] - float(f[f"blanco_y_a{a}"])))
print(f"control: máx |blanco sorteado − blanco del CSV| en los 57 intentos = {mx:.2e} m (el CSV redondea a 1e-4)")


def fuera(f):
    return [a for a in range(5) if f[f"col_estado_a{a}"] != "listo"]


def sin_fuera(E):
    return [f for f in E if not (f["valido"] == "1" and fuera(f))]


def a_blanco(E):
    E2 = copy.deepcopy(E)
    for f in E2:
        if f["valido"] == "1":
            for a in fuera(f):
                f[f"x0_a{a}"], f[f"y0_a{a}"] = f[f"blanco_x_a{a}"], f[f"blanco_y_a{a}"]
    return E2


resultados = {}


def corre(nombre, eps):
    r = da.evaluar(eps)
    resultados[nombre] = (len(eps), r)
    print(f"--- {nombre} (n_ep={len(eps)}) ---")
    for ln in r["lineas"]:
        print(ln)


print("\n=== informe() tal cual lo corre la sesión, por sesión ===")
for s in SES30:
    print(f"[{s}]")
    da.informe(E_all[s], 5)

todos = [f for s in SES30 for f in E_all[s]]
val = [f for f in todos if f["valido"] == "1"]
sem = Counter(int(f["semilla"]) for f in val)
print(f"\nválidos: {len(val)}; semillas distintas: {len(sem)}; repeticiones por semilla: {dict(sorted(sem.items()))}")
print()
corre("50 válidos, x0 (pose medida al arrancar)", da.episodios_desde_filas(todos, 5))
corre("45 válidos SIN los 5 con robots fuera de su blanco", da.episodios_desde_filas(sin_fuera(todos), 5))
corre("50 válidos con los robots fuera puestos en su blanco", da.episodios_desde_filas(a_blanco(todos), 5))
corre("blancos de los 57 intentos (válidos e inválidos)", da.episodios_desde_filas(todos, 5, ("blanco_x", "blanco_y", "blanco_th"), False))
# 12 escenarios distintos (un blanco por semilla): la diversidad real de configuraciones
uno = {}
for f in todos:
    uno.setdefault(int(f["semilla"]), f)
corre(f"{len(uno)} configuraciones distintas (blanco de cada semilla, una vez)",
      da.episodios_desde_filas(list(uno.values()), 5, ("blanco_x", "blanco_y", "blanco_th"), False))

print("\n=== RESUMEN (valor · percentil · banderas) ===")
cols = [n for n, _ in da.ESTADISTICOS]
print(f"{'conjunto':62s} " + " ".join(f"{c:>17s}" for c in cols) + "  banderas / veredicto")
for k, (n, r) in resultados.items():
    print(f"{k:62s} " + " ".join(f"{r['valores'][c]:7.3f} ({r['percentiles'][c]:5.1f})  " for c in cols)
          + f"  {r['banderas']} {r['veredicto']}")
