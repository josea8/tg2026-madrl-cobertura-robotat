import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Tarea 1 y 4 (parte CSV): intentos / válidos / inválidos por sesión con su motivo,
tasa de validez, causa inmediata (contadores de la fuente de poses, repetición de pose
en decisiones), consultas de pose y ritmo del lazo (ciclo_p95_ms, ciclos_sobre_100ms)
por sesión contra el 26-09. SOLO LECTURA. Uso: python -B a30f_robots_validez.py"""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import csv, math, os
from collections import Counter, defaultdict
from a30f_robots_comun import (SES, SES30, VALIDOS, ROBOT, RS, leer_ep, fl, d_pared,
                               media_de, mediana)

try:
    from scipy.stats import mannwhitneyu
except Exception:          # noqa
    mannwhitneyu = None


def corto(m):
    if not m:
        return "válido"
    if "NO SIGUE" in m:
        ag = int(m.split("agente ")[1].split(" ")[0])
        pct = m.split("recorrió el ")[1].split(" %")[0]
        return f"NO SIGUE a{ag}/r{ROBOT[ag]} ({pct} %)"
    if "CONGELADO" in m:
        return "marcador CONGELADO " + m.split("(robot ")[1].split(")")[0]
    return m[:70]


def repeticiones_finales(s, ep, dec_filas):
    """Última decisión del episodio: agentes cuya (x,y,θ) es idéntica a la decisión anterior;
    y todas las rachas de repetición del episodio (inicio = 1.ª fila igual a la anterior)."""
    por_ag = defaultdict(list)
    for r in dec_filas:
        por_ag[int(r["agente"])].append((int(r["paso"]), r["pose_env_x"], r["pose_env_y"], r["pose_env_th"]))
    rachas = []
    ultimo_paso = max(p for v in por_ag.values() for p, *_ in v)
    rep_final = []
    for ag, v in sorted(por_ag.items()):
        v.sort()
        k = 1
        while k < len(v):
            if v[k][1:] == v[k - 1][1:]:
                j = k
                while j + 1 < len(v) and v[j + 1][1:] == v[j][1:]:
                    j += 1
                x, y = float(v[k][1]), float(v[k][2])
                rachas.append((ag, v[k][0], v[j][0], j - k + 1, x, y, d_pared(x, y)))
                k = j + 1
            else:
                k += 1
        if len(v) >= 2 and v[-1][1:] == v[-2][1:]:
            rep_final.append(ag)
    return ultimo_paso, rep_final, rachas


def main():
    out = []
    P = out.append
    tot = Counter()
    resumen_ses = {}
    for s in SES30 + ["c26"]:
        E = leer_ep(s)
        # decisiones: sólo de los episodios que hagan falta (inválidos) para ahorrar memoria
        inval = [f for f in E if f["valido"] != "1"]
        dec_por_ep = defaultdict(list)
        necesita = {int(f["episodio"]) for f in inval}
        with open(os.path.join(RS, SES[s][1]), encoding="utf-8", newline="") as fh:
            for r in csv.DictReader(fh):
                e = int(r["episodio"])
                if e in necesita:
                    dec_por_ep[e].append(r)
        val = [int(f["episodio"]) for f in E if f["valido"] == "1"]
        if s in VALIDOS:
            assert val == VALIDOS[s], (s, val, VALIDOS[s])
        semillas_ok = all(int(f["semilla"]) == 420000 + int(f["episodio"]) - 1 for f in E)
        P("=" * 118)
        P(f"SESIÓN {s}  ({SES[s][0]}): intentos {len(E)} · válidos {len(val)} · inválidos {len(E) - len(val)} · "
          f"tasa de validez {len(val) / len(E):.3f} ({len(val)}/{len(E)})")
        P(f"   válidos = {val}   (coinciden con la lista fijada: {s not in VALIDOS or val == VALIDOS[s]});"
          f" semilla = 420000+ep−1 en todas las filas: {semillas_ok}")
        for f in inval:
            ep = int(f["episodio"])
            dec = dec_por_ep.get(ep, [])
            txt = ""
            if dec:
                ult, rep_fin, rachas = repeticiones_finales(s, ep, dec)
                txt = (f"última decisión registrada={ult}; agentes con pose IDÉNTICA a la decisión anterior en la última: "
                       f"{[f'a{a}/r{ROBOT[a]}' for a in rep_fin] or 'ninguno'}")
                if rachas:
                    txt += "; rachas de repetición: " + "; ".join(
                        f"a{a}/r{ROBOT[a]} pasos {p0}-{p1} ({n}) en ({x:.2f},{y:.2f}) d_pared {dp:.2f}"
                        for a, p0, p1, n, x, y, dp in rachas)
            P(f"   INVÁLIDO ep {ep:>2} (semilla {f['semilla']}): '{f['motivo']}'")
            P(f"        decisiones={f['decisiones']} dur={fl(f['duracion_s']):.2f} s (exceso sobre 0.1·dec = {fl(f['duracion_s']) - 0.1 * int(f['decisiones']):+.3f} s) · poses consultas={f['poses_consultas']} "
              f"fallidas={f['poses_fallidas']} rechazadas={f['poses_rechazadas']} motivo_rech='{f['poses_rechazos_motivo']}' "
              f"· ciclos>100ms={f['ciclos_sobre_100ms']} p95={fl(f['ciclo_p95_ms']):.1f} ms · retrocesos='{f['retrocesos_detalle']}'")
            P(f"        col: motivo='{f['col_motivo']}' listos={f['col_listos']} estados="
              + ", ".join(f"r{ROBOT[a]}:{f[f'col_estado_a{a}']}" for a in range(5)))
            if txt:
                P("        " + txt)
            tot[(s, corto(f["motivo"]))] += 1
        # ---- consultas de pose y ritmo -------------------------------------------------
        cons = sum(int(fl(f["poses_consultas"], 0)) for f in E)
        fall = sum(int(fl(f["poses_fallidas"], 0)) for f in E)
        rech = sum(int(fl(f["poses_rechazadas"], 0)) for f in E)
        mot = Counter()
        for f in E:
            for parte in (f["poses_rechazos_motivo"] or "").split(";"):
                if parte:
                    k, n = parte.split(":")
                    mot[k] += int(n)
        bytes_d = sum(int(fl(f["poses_bytes_descartados"], 0)) for f in E)
        cdesc = sum(int(fl(f["poses_consultas_con_descarte"], 0)) for f in E)
        p95_t = [fl(f["ciclo_p95_ms"]) for f in E]
        p95_v = [fl(f["ciclo_p95_ms"]) for f in E if f["valido"] == "1"]
        s100_t = sum(int(fl(f["ciclos_sobre_100ms"], 0)) for f in E)
        s100_v = sum(int(fl(f["ciclos_sobre_100ms"], 0)) for f in E if f["valido"] == "1")
        dec_t = sum(int(fl(f["decisiones"], 0)) for f in E)
        dec_v = sum(int(fl(f["decisiones"], 0)) for f in E if f["valido"] == "1")
        dur_v = [fl(f["duracion_s"]) - 0.1 * int(f["decisiones"]) for f in E if f["valido"] == "1"]
        m1, s1 = media_de(p95_v)
        P(f"   POSES: consultas {cons} · fallidas {fall} · rechazadas {rech} {dict(mot) or ''} · bytes descartados {bytes_d} "
          f"· consultas con descarte {cdesc}")
        P(f"   RITMO: p95 válidos media {m1:.1f} ± {s1:.1f} ms (ddof1, n={len(p95_v)}) mediana {mediana(p95_v):.1f} "
          f"[{min(p95_v):.1f}–{max(p95_v):.1f}] · p95 todos mediana {mediana(p95_t):.1f} [{min(p95_t):.1f}–{max(p95_t):.1f}]")
        P(f"          ciclos >100 ms: {s100_t} de {dec_t} decisiones ({100 * s100_t / dec_t:.3f} %); en válidos {s100_v} de {dec_v} "
          f"({100 * s100_v / dec_v:.3f} %) · episodios válidos con ≥1: {sum(1 for f in E if f['valido']=='1' and int(f['ciclos_sobre_100ms'])>0)}/{len(p95_v)}"
          f" · exceso duración−0.1·dec en válidos: mediana {mediana(dur_v):+.3f} s [{min(dur_v):+.3f}, {max(dur_v):+.3f}]")
        P("   p95 por episodio (ep:p95[>100]): " + " ".join(
            f"{f['episodio']}{'' if f['valido']=='1' else '*'}:{fl(f['ciclo_p95_ms']):.1f}[{f['ciclos_sobre_100ms']}]" for f in E)
          + "   (* = inválido)")
        resumen_ses[s] = dict(intentos=len(E), validos=len(val), cons=cons, fall=fall, rech=rech, mot=dict(mot),
                              p95_v=p95_v, p95_t=p95_t, s100_t=s100_t, dec_t=dec_t, s100_v=s100_v, dec_v=dec_v)

    P("")
    P("=" * 118)
    P("RESUMEN VALIDEZ (5 sesiones del 30-09)")
    I = sum(resumen_ses[s]["intentos"] for s in SES30)
    V = sum(resumen_ses[s]["validos"] for s in SES30)
    P(f"   intentos {I} · válidos {V} · inválidos {I - V} · tasa {V / I:.3f}   (26-09: "
      f"{resumen_ses['c26']['validos']}/{resumen_ses['c26']['intentos']} = {resumen_ses['c26']['validos'] / resumen_ses['c26']['intentos']:.3f})")
    for s in SES30:
        r = resumen_ses[s]
        P(f"   {s}: {r['validos']}/{r['intentos']} = {r['validos'] / r['intentos']:.3f}")
    P("   inválidos por motivo: " + "; ".join(f"{k[0]} {k[1]}: {v}" for k, v in sorted(tot.items())))
    P("")
    P("RESUMEN POSES Y RITMO")
    P(f"   {'ses':<4} {'consultas':>9} {'fallidas':>8} {'rechaz':>6} {'p95 válidos media±sd (ddof1)':>30} {'mediana':>8} {'rango':>14} {'>100ms tot':>10} {'por mil dec':>11}")
    for s in SES30 + ["c26"]:
        r = resumen_ses[s]
        m, sd = media_de(r["p95_v"])
        P(f"   {s:<4} {r['cons']:>9} {r['fall']:>8} {r['rech']:>6} {m:>21.1f} ± {sd:4.1f}    {mediana(r['p95_v']):>8.1f} "
          f"{min(r['p95_v']):>6.1f}–{max(r['p95_v']):<6.1f} {r['s100_t']:>10} {1000 * r['s100_t'] / r['dec_t']:>11.2f}")
    todos30 = [x for s in SES30 for x in resumen_ses[s]["p95_v"]]
    m, sd = media_de(todos30)
    P(f"   30-09 (50 válidos): p95 media {m:.1f} ± {sd:.1f} ms mediana {mediana(todos30):.1f} [{min(todos30):.1f}–{max(todos30):.1f}]; "
      f"26-09 (10 válidos): {media_de(resumen_ses['c26']['p95_v'])[0]:.1f} ± {media_de(resumen_ses['c26']['p95_v'])[1]:.1f}")
    P(f"   p95 mínimo del 30-09 ({min(todos30):.1f}) vs máximo del 26-09 válidos ({max(resumen_ses['c26']['p95_v']):.1f}) y todos "
      f"({max(resumen_ses['c26']['p95_t']):.1f}): solapan = {min(todos30) <= max(resumen_ses['c26']['p95_t'])}")
    if mannwhitneyu is not None:
        # tendencia dentro del día: s1..s5 (Spearman con el orden de sesión)
        from scipy.stats import spearmanr, kruskal
        orden = [i for i, s in enumerate(SES30) for _ in resumen_ses[s]["p95_v"]]
        rho, p = spearmanr(orden, todos30)
        H, pk = kruskal(*[resumen_ses[s]["p95_v"] for s in SES30])
        P(f"   diferencias entre sesiones del 30-09 (p95 de válidos): Kruskal-Wallis H={H:.2f} p={pk:.2g}; "
          f"Spearman(orden de sesión, p95) rho={rho:+.3f} p={p:.2g}")
        for a_, b_ in (("s3", "s2"), ("s3", "s1"), ("s5", "s4"), ("s5", "s1")):
            u = mannwhitneyu(resumen_ses[a_]["p95_v"], resumen_ses[b_]["p95_v"], alternative="two-sided")
            P(f"   Mann-Whitney {a_} vs {b_}: U={u.statistic:.0f} p={u.pvalue:.3g}  (medianas {mediana(resumen_ses[a_]['p95_v']):.1f} vs "
              f"{mediana(resumen_ses[b_]['p95_v']):.1f})")
    print("\n".join(out))


if __name__ == "__main__":
    main()
