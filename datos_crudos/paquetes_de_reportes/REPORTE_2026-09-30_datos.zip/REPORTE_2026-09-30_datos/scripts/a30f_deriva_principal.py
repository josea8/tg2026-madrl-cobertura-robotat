import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_deriva_principal.py — SOLO LECTURA. Verificación del arreglo de detención (30-09).
# Extiende a30_flujo_ritmo_deriva26.py:
#   · parsea coordenadas NEGATIVAS (el original usaba [\d.]+ y descartaba robots fuera de la arena),
#   · toma las impresiones SÓLO de la 1.ª ronda de la guía (entre el primer "Despejá la arena..."
#     y el primer "[colocación  N s]"), agrupa por línea en blanco o robot repetido y admite "SIN POSE",
#   · valida el emparejamiento bloque de consola ↔ fila del CSV (número, VÁLIDO/INVÁLIDO, cobertura,
#     d_pared mín, contador "válidos hasta ahora", blancos impresos vs blanco_*_a{i}),
#   · marca robots cuya última pose del ep k está CONGELADA (fila idéntica a la anterior): esa pose no es
#     la real (Motive retiene) y su "deriva" no es medible limpia,
#   · cuenta "detención enviada" entre el último "colocación:" y el ">>> EPISODIO k".
import csv, math, re, os, sys
import numpy as np
from scipy.stats import mannwhitneyu

R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
S = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
ROB2AG = {1: 0, 5: 1, 8: 2, 6: 3, 9: 4}
AG2ROB = {v: k for k, v in ROB2AG.items()}
SES = [  # clave, consola, sufijo CSV, fecha, arreglo
    ("26-09", "consola_20260926.txt", "20260926", "", False),
    ("s1", "consola_20260930.txt", "20260930", "", False),
    ("s2", "consola_20260930_02.txt", "20260930", "_02", False),
    ("s3", "consola_20260930_03.txt", "20260930", "_03", False),
    ("s4", None, "20260930", "_04", False),
    ("s5", "consola_20260930_05.txt", "20260930", "_05", True),
]
RE_HDR = re.compile(r"^EPISODIO (\d+)\s+\(válidos hasta ahora: (\d+)/(\d+)\)")
RE_ROB = re.compile(r"^\s+(?:✔ )?robot (\d+): (?:está \((-?[\d.]+), (-?[\d.]+)\)|SIN POSE)")
RE_BLANCO = re.compile(r"^\s+robot (\d+): \((-?[\d.]+), (-?[\d.]+)\)\s*$")
RE_COLPROG = re.compile(r"^\s*\[colocación\s+\d+ s\]")
RE_COLSUM = re.compile(r"^\s+colocación: ")
RE_RES = re.compile(r">>> EPISODIO (\d+): (VÁLIDO|INVÁLIDO)")
RE_COB = re.compile(r"cobertura AoI ([\d.]+)\s+·\s+colisiones <0\.15 (\d+)\s+·\s+d_pared mín (-?[\d.]+)")
DET = "detención enviada a los 5 robots"
NODET = "NO SE PUDO CONFIRMAR LA DETENCIÓN"

def dpared(x, y):
    return min(x, 3 - x, y, 3 - y)

def parse_consola(path):
    L = open(path, encoding="utf-8").read().splitlines()
    heads = [i for i, l in enumerate(L) if RE_HDR.match(l)]
    bloques = {}
    for j, h in enumerate(heads):
        fin = heads[j + 1] if j + 1 < len(heads) else len(L)
        m = RE_HDR.match(L[h]); k = int(m.group(1))
        B = L[h:fin]
        b = {"k": k, "validos_previos": int(m.group(2)), "linea": h + 1, "prints": [], "blancos": {},
             "res": None, "cob": None, "n_det_total": 0, "n_det_entre": None, "nodet": 0}
        ip = next((i for i, l in enumerate(B) if "Despejá la arena y dale Enter" in l), None)
        # blancos de la 1.ª ronda (antes del prompt)
        for l in B[:ip if ip is not None else 0]:
            mb = RE_BLANCO.match(l)
            if mb:
                b["blancos"][int(mb.group(1))] = (float(mb.group(2)), float(mb.group(3)))
        if ip is not None:
            cur = {}
            for l in B[ip + 1:]:
                if RE_COLPROG.match(l) or RE_COLSUM.match(l) or "⚠ colocación" in l or "BLANCOS DE ESTE" in l:
                    break
                mr = RE_ROB.match(l)
                if mr:
                    r = int(mr.group(1))
                    if r in cur:
                        b["prints"].append(cur); cur = {}
                    cur[r] = None if mr.group(2) is None else (float(mr.group(2)), float(mr.group(3)))
                else:
                    if cur:
                        b["prints"].append(cur); cur = {}
            if cur:
                b["prints"].append(cur)
        ir = next((i for i, l in enumerate(B) if RE_RES.search(l)), None)
        if ir is not None:
            mr = RE_RES.search(B[ir]); b["res"] = (int(mr.group(1)), mr.group(2))
            for l in B[ir:ir + 4]:
                mc = RE_COB.search(l)
                if mc:
                    b["cob"] = (float(mc.group(1)), int(mc.group(2)), float(mc.group(3)))
                    break
            ics = [i for i, l in enumerate(B[:ir]) if RE_COLSUM.match(l)]
            if ics:
                b["n_det_entre"] = sum(1 for l in B[ics[-1] + 1:ir] if DET in l)
                b["det_lineas"] = [h + 1 + i for i in range(ics[-1] + 1, ir) if DET in B[i]]
            b["n_det_post_res"] = sum(1 for l in B[ir + 1:] if DET in l)
            irep = [i for i, l in enumerate(B) if "réplica simulada" in l]
            b["replica_tras_res"] = (all(i > ir for i in irep), len(irep))
        b["n_det_total"] = sum(1 for l in B if DET in l)
        b["nodet"] = sum(1 for l in B if NODET in l)
        bloques[k] = b
    tot_det = sum(1 for l in L if DET in l)
    tot_nodet = sum(1 for l in L if NODET in l)
    return bloques, len(heads), tot_det, tot_nodet

def cargar(fecha, suf):
    eps = list(csv.DictReader(open(os.path.join(R, f"{fecha}_sesion-evaluacion_etapa7_episodios{suf}.csv"), encoding="utf-8")))
    dec = {}
    for r in csv.DictReader(open(os.path.join(R, f"{fecha}_sesion-evaluacion_etapa7_decisiones{suf}.csv"), encoding="utf-8")):
        dec.setdefault((int(r["episodio"]), int(r["agente"])), []).append(r)
    for k in dec:
        dec[k].sort(key=lambda r: int(r["paso"]))
    return eps, dec

def pose(r):
    return (float(r["pose_env_x"]), float(r["pose_env_y"]), float(r["pose_env_th"]))

out = []
def P(*a):
    s = " ".join(str(x) for x in a); out.append(s); print(s)

filas_robot = []   # una por (sesión, k, robot)
resumen_det = {}
P("=" * 100)
P("A30F — VERIFICACIÓN DEL ARREGLO DE DETENCIÓN (deriva entre episodios)  · SOLO LECTURA")
P("=" * 100)
for clave, con, fecha, suf, arreglo in SES:
    eps, dec = cargar(fecha, suf)
    P(f"\n### {clave}  ({fecha}{suf})  filas CSV={len(eps)}  arreglo={'SÍ' if arreglo else 'no'}  consola={con or 'NO EXISTE (sin dato)'}")
    # chequeo mapeo agente→robot en decisiones
    malmap = sum(1 for (e, a), rs in dec.items() for r in rs if int(r["robot"]) != AG2ROB[a])
    P(f"  filas de decisiones con robot≠mapeo esperado: {malmap}")
    ep_by = {int(e["episodio"]): e for e in eps}
    orden_ok = [int(e["episodio"]) for e in eps] == list(range(1, len(eps) + 1))
    P(f"  episodio del CSV = 1..{len(eps)} en orden: {orden_ok}")
    if con is None:
        P("  SIN CONSOLA → deriva, impresiones de la guía y conteo de 'detención enviada': SIN DATO.")
        continue
    bloques, nhead, tot_det, tot_nodet = parse_consola(os.path.join(S, con))
    P(f"  encabezados EPISODIO en consola: {nhead}  (claves {min(bloques)}..{max(bloques)})  "
      f"'detención enviada' total en consola: {tot_det}  'NO SE PUDO CONFIRMAR': {tot_nodet}")
    # --- validación del emparejamiento
    val_prev = 0; problemas = []
    for k in range(1, len(eps) + 1):
        e = ep_by.get(k); b = bloques.get(k)
        if b is None:
            problemas.append(f"ep {k}: sin bloque en consola"); continue
        if b["validos_previos"] != val_prev:
            problemas.append(f"ep {k}: consola dice {b['validos_previos']} válidos previos, CSV {val_prev}")
        if b["res"] is None:
            problemas.append(f"ep {k}: bloque sin '>>> EPISODIO' (no corrió)")
        else:
            if b["res"][0] != k: problemas.append(f"ep {k}: >>> dice {b['res'][0]}")
            if (b["res"][1] == "VÁLIDO") != (e["valido"] == "1"):
                problemas.append(f"ep {k}: consola {b['res'][1]} vs CSV valido={e['valido']}")
        if b["cob"] is not None:
            if abs(b["cob"][0] - float(e["cobertura_aoi"])) > 5.1e-5:
                problemas.append(f"ep {k}: cobertura consola {b['cob'][0]} vs CSV {e['cobertura_aoi']}")
            if abs(b["cob"][2] - float(e["d_pared_min"])) > 5.1e-7:
                problemas.append(f"ep {k}: d_pared consola {b['cob'][2]} vs CSV {e['d_pared_min']}")
        for rob, (bx, by) in b["blancos"].items():
            a = ROB2AG[rob]
            if abs(bx - float(e[f"blanco_x_a{a}"])) > 0.0051 or abs(by - float(e[f"blanco_y_a{a}"])) > 0.0051:
                problemas.append(f"ep {k}: blanco robot {rob} consola ({bx},{by}) vs CSV")
        if len(b["blancos"]) != 5:
            problemas.append(f"ep {k}: {len(b['blancos'])} blancos impresos")
        val_prev += int(e["valido"])
    extra = sorted(set(bloques) - set(range(1, len(eps) + 1)))
    if extra:
        problemas.append(f"bloques en consola sin fila CSV (episodios que no corrieron): {extra}")
    n_cob = sum(1 for k in bloques if bloques[k]["cob"] is not None)
    P(f"  emparejamiento: {len(eps)} episodios CSV, {nhead} bloques; cobertura/d_pared cotejadas en {n_cob} bloques; "
      f"blancos cotejados en {sum(len(b['blancos']) for b in bloques.values())} robots-bloque")
    P(f"  problemas de emparejamiento: {problemas if problemas else 'NINGUNO'}")
    # --- conteo de detenciones por episodio
    P("  Detenciones entre el último 'colocación:' y '>>> EPISODIO k' (1 = sólo la de la colocación; 2 = + fin de episodio):")
    fila = []
    for k in range(1, len(eps) + 1):
        b = bloques[k]; e = ep_by[k]
        fila.append(f"ep{k}({'V' if e['valido']=='1' else 'A'}):{b['n_det_entre']}")
        resumen_det.setdefault(clave, []).append((k, e["valido"] == "1", b["n_det_entre"], b.get("det_lineas"), b["nodet"]))
    P("   " + "  ".join(fila))
    s_entre = sum(bloques[k]["n_det_entre"] or 0 for k in range(1, len(eps) + 1))
    s_bloq = sum(bloques[k]["n_det_total"] for k in range(1, len(eps) + 1))
    s_post_ult = bloques[len(eps)].get("n_det_post_res", 0)
    P(f"  'detención enviada': total consola {tot_det} = {s_entre} entre colocación y resultado + "
      f"{s_bloq - s_entre - s_post_ult} en otras partes de los bloques (rondas de colocación fallidas) + "
      f"{s_post_ult} después del resultado del último episodio (cierre de sesión) + {tot_det - s_bloq} antes del ep 1")
    # orden: en cada bloque, la línea 'réplica simulada' (si existe) va DESPUÉS de '>>> EPISODIO k'
    rr = [bloques[k].get("replica_tras_res", (None, 0)) for k in range(1, len(eps) + 1)]
    P(f"  bloques con 'réplica simulada': {sum(1 for ok, n in rr if n)}; en todos va después de '>>> EPISODIO k' "
      f"(y por tanto después de las detenciones contadas): {all(ok for ok, n in rr if n)}")
    # --- deriva
    P("  Deriva por episodio k (última pose del ep k en decisiones → impresiones de la guía del bloque k+1):")
    P("   k tipo dec  nImp  d1_med d1_max  d2_med d2_max  dU_med dU_max  dpar1_min dpar2_min  congel_fin  robots(d1/d2)")
    for k in range(1, len(eps) + 1):
        e = ep_by[k]; tipo = "V" if e["valido"] == "1" else "A"
        b = bloques.get(k + 1)
        if b is None:
            P(f"  {k:2d}  {tipo}  {e['decisiones']:>3}  — sin bloque k+1 (último episodio de la sesión): NO MEDIBLE")
            continue
        pr = b["prints"]
        d1s, d2s, dus, dp1, dp2, cong = [], [], [], [], [], []
        for a in range(5):
            rob = AG2ROB[a]; rs = dec.get((k, a))
            if not rs: continue
            ult = rs[-1]; x, y, th = pose(ult)
            # racha final de filas idénticas (x,y,θ)
            racha = 1
            for i in range(len(rs) - 1, 0, -1):
                if pose(rs[i]) == pose(rs[i - 1]): racha += 1
                else: break
            congelado = racha >= 2
            def dist(p):
                if len(pr) > p and rob in pr[p] and pr[p][rob] is not None:
                    q = pr[p][rob]; return math.hypot(q[0] - x, q[1] - y) * 100, dpared(*q)
                return None, None
            d1, dq1 = dist(0); d2, dq2 = dist(1)
            q1 = pr[0].get(rob) if len(pr) > 0 else None
            q2 = pr[1].get(rob) if len(pr) > 1 else None
            d12 = math.hypot(q2[0] - q1[0], q2[1] - q1[1]) * 100 if (q1 and q2) else None
            dU, dqU = dist(len(pr) - 1) if pr else (None, None)
            filas_robot.append({"sesion": clave, "arreglo": int(arreglo), "k": k, "tipo": tipo,
                                "decisiones_k": int(e["decisiones"]), "motivo_k": e["motivo"][:50],
                                "robot": rob, "agente": a, "paso_ult": int(ult["paso"]),
                                "x_ult": x, "y_ult": y, "dpared_ult": dpared(x, y),
                                "v_ult": float(ult["v_ejecutada"]), "w_ult": float(ult["w_ejecutada"]),
                                "en_retroceso_ult": int(ult["en_retroceso"]), "racha_identica_final": racha,
                                "congelado_fin": int(congelado), "n_impresiones": len(pr),
                                "d1_cm": d1, "d2_cm": d2, "dU_cm": dU, "dpared_imp1": dq1, "dpared_imp2": dq2,
                                "dpared_impU": dqU, "d12_cm": d12,
                                "x_imp1": q1[0] if q1 else None, "y_imp1": q1[1] if q1 else None,
                                "x_imp2": q2[0] if q2 else None, "y_imp2": q2[1] if q2 else None})
            if d1 is not None: d1s.append(d1); dp1.append(dq1)
            if d2 is not None: d2s.append(d2); dp2.append(dq2)
            if dU is not None: dus.append(dU)
            if congelado: cong.append(rob)
        f = lambda v, fn: f"{fn(v):6.1f}" if v else "   —  "
        g = lambda v: f"{min(v):9.2f}" if v else "      —  "
        P(f"  {k:2d}  {tipo}  {e['decisiones']:>3}  {len(pr):3d}  {f(d1s,np.median)} {f(d1s,max)}  {f(d2s,np.median)} {f(d2s,max)}  "
          f"{f(dus,np.median)} {f(dus,max)}  {g(dp1)} {g(dp2)}  {str(cong) if cong else '-':10s}  {len(d1s)}/{len(d2s)}")

# ---------------------------------------------------------------------------
# Resúmenes por sesión × tipo (a nivel robot-medida y a nivel episodio)
# ---------------------------------------------------------------------------
def resumen(rows, campo):
    v = [r[campo] for r in rows if r[campo] is not None]
    return v

P("\n" + "=" * 100)
P("RESUMEN por sesión y tipo del episodio k (robots-medida; mediana np.median; 'limpio' = sin robots con pose congelada al final del ep k)")
P("=" * 100)
P(f"{'grupo':22s} {'n_ep':>4s} {'n_d1':>4s} {'d1_med':>6s} {'d1_max':>6s} {'n_d2':>4s} {'d2_med':>6s} {'d2_max':>6s} "
  f"{'dU_med':>6s} {'dU_max':>6s} {'dpar1_min':>9s} {'dpar2_min':>9s} {'n<0.05@2':>8s} {'n<0@2':>5s}")
grupos = {}
for r in filas_robot:
    grupos.setdefault((r["sesion"], r["tipo"]), []).append(r)
def linea(nombre, rows):
    eps_ = sorted(set((r["sesion"], r["k"]) for r in rows))
    d1 = resumen(rows, "d1_cm"); d2 = resumen(rows, "d2_cm"); dU = resumen(rows, "dU_cm")
    p1 = resumen(rows, "dpared_imp1"); p2 = resumen(rows, "dpared_imp2")
    fm = lambda v, fn, w=6: f"{fn(v):{w}.2f}" if v else f"{'—':>{w}s}"
    P(f"{nombre:22s} {len(eps_):4d} {len(d1):4d} {fm(d1,np.median)} {fm(d1,max)} {len(d2):4d} {fm(d2,np.median)} {fm(d2,max)} "
      f"{fm(dU,np.median)} {fm(dU,max)} {fm(p1,min,9)} {fm(p2,min,9)} {sum(1 for x in p2 if x<0.05):8d} {sum(1 for x in p2 if x<0):5d}")
    return d1, d2, dU
for ses in ["26-09", "s1", "s2", "s3", "s5"]:
    for t, nom in (("V", "VÁLIDO"), ("A", "ABORTADO")):
        rows = grupos.get((ses, t), [])
        if rows:
            linea(f"{ses} {nom}", rows)
            limp = [r for r in rows if not r["congelado_fin"]]
            if len(limp) != len(rows):
                linea(f"{ses} {nom} limpio", limp)
P("-" * 100)
pre = lambda t: [r for r in filas_robot if not r["arreglo"] and r["tipo"] == t]
pos = lambda t: [r for r in filas_robot if r["arreglo"] and r["tipo"] == t]
A_pre_V = linea("PRE (26-09,s1-s3) VÁL", pre("V"))
A_pre_V30 = linea("PRE 30-09 (s1-s3) VÁL", [r for r in pre("V") if r["sesion"] != "26-09"])
A_pre_A = linea("PRE (26-09,s1-s3) ABO", pre("A"))
linea("PRE ABO limpio", [r for r in pre("A") if not r["congelado_fin"]])
A_pos_V = linea("s5 (arreglo) VÁLIDO", pos("V"))
A_pos_A = linea("s5 (arreglo) ABORTADO", pos("A"))
linea("TODOS ABO (pre+s5)", pre("A") + pos("A"))
linea("TODOS ABO limpio", [r for r in pre("A") + pos("A") if not r["congelado_fin"]])
_m = lambda rows, c: float(np.median([r[c] for r in rows if r[c] is not None]))
P(f"cociente de medianas d2 PRE válidos / s5 válidos = {_m(pre('V'),'d2_cm'):.2f}/{_m(pos('V'),'d2_cm'):.2f} = "
  f"{_m(pre('V'),'d2_cm')/_m(pos('V'),'d2_cm'):.1f}×;  d1: {_m(pre('V'),'d1_cm'):.2f}/{_m(pos('V'),'d1_cm'):.2f} = "
  f"{_m(pre('V'),'d1_cm')/_m(pos('V'),'d1_cm'):.1f}×")
_mx = lambda rows, c: max(r[c] for r in rows if r[c] is not None)
P(f"máximo d1/d2 s5 válidos {_mx(pos('V'),'d1_cm'):.2f}/{_mx(pos('V'),'d2_cm'):.2f} cm  vs  mínimo d1/d2 PRE válidos limpio "
  f"{min(r['d1_cm'] for r in pre('V') if not r['congelado_fin']):.2f}/{min(r['d2_cm'] for r in pre('V') if not r['congelado_fin']):.2f} cm")

# ---------------------------------------------------------------------------
# Nivel episodio: mediana por episodio de d1 y d2 → comparación s5-válidos vs abortados
# ---------------------------------------------------------------------------
P("\n" + "=" * 100)
P("NIVEL EPISODIO (mediana de los robots medidos en cada episodio k; unidad independiente = episodio)")
P("=" * 100)
def ep_meds(rows, campo, excluir_cong=False):
    d = {}
    for r in rows:
        if excluir_cong and r["congelado_fin"]: continue
        if r[campo] is None: continue
        d.setdefault((r["sesion"], r["k"]), []).append(r[campo])
    return {k: float(np.median(v)) for k, v in d.items()}
for campo in ("d1_cm", "d2_cm", "dU_cm"):
    g = {"PRE válidos": ep_meds(pre("V"), campo), "PRE abortados": ep_meds(pre("A"), campo),
         "s5 válidos": ep_meds(pos("V"), campo), "s5 abortados": ep_meds(pos("A"), campo),
         "TODOS abortados": ep_meds(pre("A") + pos("A"), campo),
         "TODOS abortados limpio": ep_meds(pre("A") + pos("A"), campo, True)}
    P(f"-- {campo}")
    for n, d in g.items():
        v = sorted(d.values())
        if v:
            P(f"   {n:24s} n_ep={len(v):2d}  mediana={np.median(v):6.2f}  mín={v[0]:6.2f}  máx={v[-1]:6.2f}  "
              f"valores={[round(x,1) for x in v]}")
    a = list(g["s5 válidos"].values()); bA = list(g["TODOS abortados"].values()); bV = list(g["PRE válidos"].values())
    if a and bA:
        u = mannwhitneyu(a, bA, alternative="two-sided")
        P(f"   Mann-Whitney s5 válidos vs TODOS abortados: U={u.statistic:.1f}  p={u.pvalue:.4f}  (descriptivo; episodios de sesiones distintas)")
    if a and bV:
        u = mannwhitneyu(a, bV, alternative="two-sided")
        P(f"   Mann-Whitney s5 válidos vs PRE válidos:     U={u.statistic:.1f}  p={u.pvalue:.3g}")

# ---------------------------------------------------------------------------
# Sesión 5: conteo de 'detención enviada'
# ---------------------------------------------------------------------------
P("\n" + "=" * 100)
P("CONTEO DE 'detención enviada' ENTRE EL ÚLTIMO 'colocación:' Y '>>> EPISODIO k'")
P("=" * 100)
for ses, lst in resumen_det.items():
    cV = [n for k, v, n, _, _ in lst if v]; cA = [n for k, v, n, _, _ in lst if not v]
    from collections import Counter
    P(f"  {ses:6s}  válidos: {dict(Counter(cV))} (n={len(cV)})   abortados: {dict(Counter(cA))} (n={len(cA)})   "
      f"'NO SE PUDO CONFIRMAR' en bloques: {sum(x[4] for x in lst)}")
P("  s5 detalle (k, válido, n entre colocación y resultado, líneas de consola):")
for k, v, n, lin, nd in resumen_det.get("s5", []):
    P(f"     ep {k:2d}  {'VÁLIDO ' if v else 'ABORTADO'}  n={n}  líneas={lin}")

# ---------------------------------------------------------------------------
# Movimiento entre la 1.ª y la 2.ª impresión (¿el robot seguía andando al imprimir la 1.ª?)
# y tiempo equivalente T = d / (|v_ult|·factor)  [v_ejecutada está en unidades del env; real = ×0.40]
# ---------------------------------------------------------------------------
P("\n" + "=" * 100)
P("MOVIMIENTO ENTRE 1.ª Y 2.ª IMPRESIÓN (|p2-p1|, cm; resolución de impresión 1 cm)  y  T_equiv = d/(|v_ult|·0.40) [s]")
P("=" * 100)
def bloque(nombre, rows):
    v = [r["d12_cm"] for r in rows if r["d12_cm"] is not None]
    if not v:
        P(f"  {nombre:26s} sin pares de impresiones"); return
    n0 = sum(1 for x in v if x < 0.5); n1 = sum(1 for x in v if x >= 1.5)
    T1 = [r["d1_cm"] / 100 / (abs(r["v_ult"]) * 0.40) for r in rows if r["d1_cm"] is not None and abs(r["v_ult"]) > 0.1]
    T2 = [r["d2_cm"] / 100 / (abs(r["v_ult"]) * 0.40) for r in rows if r["d2_cm"] is not None and abs(r["v_ult"]) > 0.1]
    dpu = [r["dpared_ult"] for r in rows]
    P(f"  {nombre:26s} n={len(v):3d}  |p2-p1| mediana {np.median(v):5.2f}  máx {max(v):5.2f}  "
      f"n(<0.5 cm, quieto)={n0}  n(>=1.5 cm, se movía)={n1}   "
      f"T_equiv(d1) med {np.median(T1) if T1 else float('nan'):5.2f} s (n={len(T1)})  "
      f"T_equiv(d2) med {np.median(T2) if T2 else float('nan'):5.2f} s   d_pared mín en última pose {min(dpu):.3f} m")
for ses in ["26-09", "s1", "s2", "s3", "s5"]:
    for t, nom in (("V", "VÁLIDO"), ("A", "ABORTADO")):
        rows = [r for r in grupos.get((ses, t), []) if not r["congelado_fin"]]
        if rows: bloque(f"{ses} {nom} limpio", rows)
P("-" * 100)
bloque("PRE válidos limpio", [r for r in pre("V") if not r["congelado_fin"]])
bloque("PRE abortados limpio", [r for r in pre("A") if not r["congelado_fin"]])
bloque("s5 válidos", pos("V"))
bloque("s5 abortados limpio", [r for r in pos("A") if not r["congelado_fin"]])

# CSV por robot
with open(os.path.join(S, "a30f_deriva_por_robot.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(filas_robot[0].keys()))
    w.writeheader(); w.writerows(filas_robot)
P(f"\n[escrito] a30f_deriva_por_robot.csv  ({len(filas_robot)} filas)")
open(os.path.join(S, "a30f_deriva_principal_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
