import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Verificador a30f_verif_metricas_: instantánea RECURSIVA (todas las subcarpetas)
de mtime_ns + tamaño de la carpeta del coordinador. SOLO os.stat (no abre archivos).
Uso: python a30f_verif_metricas_snap.py <salida.txt>
     python a30f_verif_metricas_snap.py --comparar <a.txt> <b.txt>
     python a30f_verif_metricas_snap.py --contra_analista <mio.txt>   (compara con
         a30f_metricas_mtimes_despues.txt del analista en los archivos que él cubrió)"""
import os
import sys
sys.dont_write_bytecode = True
C = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
SP = (r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis"
      r"\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")


def leer(fn):
    d = {}
    for l in open(os.path.join(SP, fn), encoding="utf-8").read().splitlines():
        if l.strip():
            mt, sz, rel = l.split(" ", 2)
            d[rel] = (mt, sz)
    return d


if sys.argv[1] == "--comparar":
    a, b = leer(sys.argv[2]), leer(sys.argv[3])
    dif = [k for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)]
    print(f"{sys.argv[2]}: {len(a)} archivos · {sys.argv[3]}: {len(b)} archivos · diferencias {len(dif)}")
    for k in dif:
        print("   ", k, a.get(k, "(no existía)"), "->", b.get(k, "(ya no existe)"))
    sys.exit(0)

if sys.argv[1] == "--contra_analista":
    mio = leer(sys.argv[2])
    an = leer("a30f_metricas_mtimes_despues.txt")
    # el analista usa rutas '/x', 'sub/x'; las mías son relativas con '/'
    norm = lambda k: k.lstrip("/")
    an2 = {norm(k): v for k, v in an.items()}
    comunes = [k for k in an2 if k in mio]
    falt = [k for k in an2 if k not in mio]
    dif = [k for k in comunes if an2[k] != mio[k]]
    print(f"analista (después) {len(an2)} archivos · presentes ahora {len(comunes)} · faltan {len(falt)} · "
          f"cambiados desde su 'después' {len(dif)}")
    for k in dif + falt:
        print("   ", k, an2.get(k), "->", mio.get(k, "(no existe)"))
    nuevos = [k for k in mio if k not in an2]
    print(f"archivos que el analista NO cubrió (subcarpetas u otros): {len(nuevos)}")
    for k in sorted(nuevos):
        print("   ", k, mio[k])
    sys.exit(0)

out = []
for raiz, dirs, archivos in os.walk(C):
    dirs.sort()
    for n in sorted(archivos):
        p = os.path.join(raiz, n)
        st = os.stat(p)
        rel = os.path.relpath(p, C).replace("\\", "/")
        out.append(f"{st.st_mtime_ns} {st.st_size} {rel}")
open(os.path.join(SP, sys.argv[1]), "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
print(len(out), "archivos")
