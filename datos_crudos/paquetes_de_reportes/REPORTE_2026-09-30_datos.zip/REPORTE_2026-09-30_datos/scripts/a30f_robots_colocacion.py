import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Tarea 2 (parte CSV) y 3 (arranques fuera de soporte): colocación autónoma por episodio y
robot en las 5 sesiones del 30-09 (+26-09 de control): col_t_s, col_motivo, col_listos,
col_estado_a{i}, |x0−blanco|; conteo de 'no avanza' / 'sin pose' por robot y sesión (sólo la
colocación FINAL de cada intento, que es la que guarda el CSV); episodios VÁLIDOS que
arrancaron con algún robot no 'listo' o a > 0.12 m de su blanco; pares a < 0.31 m y robots
a < 0.45 m de la pared en x0 (fuera del soporte del sorteo de entrenamiento).
SOLO LECTURA. Uso: python -B a30f_robots_colocacion.py"""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import math
from collections import Counter, defaultdict
from a30f_robots_comun import (SES30, ROBOT, leer_ep, fl, x0, blanco, d_blanco, d_pared, pares_x0,
                               TOL_BLANCO, SEP_ENTRENAMIENTO, MARGEN_ENTRENAMIENTO, SEP_CHEQUEO,
                               MARGEN_CHEQUEO, media_de, mediana)


def ang(a):
    return math.degrees(math.atan2(math.sin(a), math.cos(a)))


def main():
    cnt = defaultdict(Counter)          # sesión -> (robot, estado) -> n
    val_fuera = []                      # episodios válidos con algún no-listo o > 0.12
    out_sop = []                        # válidos fuera del soporte de entrenamiento
    col_t = defaultdict(list)
    todos_val = []
    for s in SES30 + ["c26"]:
        E = leer_ep(s)
        print("=" * 118)
        print(f"SESIÓN {s}: {len(E)} intentos")
        for f in E:
            ep = int(f["episodio"])
            ests = [f[f"col_estado_a{a}"] for a in range(5)]
            ds = [d_blanco(f, a) for a in range(5)]
            dth = [abs(ang(x0(f, a)[2] - blanco(f, a)[2])) for a in range(5)]
            dp = [d_pared(x0(f, a)[0], x0(f, a)[1]) for a in range(5)]
            pares = pares_x0(f)
            col_t[s].append((fl(f["col_t_s"]), f["valido"]))
            marca = ""
            for a in range(5):
                cnt[s][(ROBOT[a], ests[a])] += 1
            no_listo = [a for a in range(5) if ests[a] != "listo"]
            lejos = [a for a in range(5) if ds[a] > TOL_BLANCO]
            print(f"  ep {ep:>2} val={f['valido']} col_t={fl(f['col_t_s']):5.1f} s listos={f['col_listos']} motivo='{f['col_motivo']}' "
                  f"par mín {pares[0][0]:.3f} m (r{ROBOT[pares[0][1]]}–r{ROBOT[pares[0][2]]}) d_pared mín {min(dp):.3f} m")
            print("        " + "  ".join(f"r{ROBOT[a]}:{ds[a]*100:5.1f}cm/{dth[a]:5.1f}°[{ests[a]}]" for a in range(5)))
            if f["valido"] == "1":
                todos_val.append((s, ep, f))
                if no_listo or lejos:
                    val_fuera.append((s, ep, [(ROBOT[a], ests[a], round(ds[a], 3)) for a in sorted(set(no_listo) | set(lejos))]))
                p31 = [(round(d, 3), ROBOT[a], ROBOT[b]) for d, a, b in pares if d < SEP_ENTRENAMIENTO]
                w45 = [(ROBOT[a], round(dp[a], 3), ests[a]) for a in range(5) if dp[a] < MARGEN_ENTRENAMIENTO]
                if p31 or w45:
                    out_sop.append((s, ep, p31, w45, [ROBOT[a] for a in no_listo]))
    print()
    print("=" * 118)
    print("CONTEO DE ESTADOS DE COLOCACIÓN (colocación final de cada intento, CSV) por sesión y robot")
    for s in SES30 + ["c26"]:
        c = cnt[s]
        estados = sorted({e for (_, e) in c})
        print(f"  {s}: " + " | ".join(f"r{r}: " + ", ".join(f"{e} {c[(r, e)]}" for e in estados if c[(r, e)]) for r in (1, 5, 8, 6, 9)))
        tot = Counter()
        for (r, e), n in c.items():
            tot[e] += n
        print(f"       total robots-intento: {dict(tot)}")
    tot30 = Counter()
    por_rob30 = Counter()
    for s in SES30:
        for (r, e), n in cnt[s].items():
            tot30[e] += n
            if e != "listo":
                por_rob30[(r, e)] += n
    print(f"  30-09 (5 sesiones, 57 intentos × 5 robots = 285): {dict(tot30)}")
    print(f"  30-09 no-listo por robot: " + ", ".join(f"r{r} {e} {n}" for (r, e), n in sorted(por_rob30.items())))
    print()
    print("TIEMPO DE COLOCACIÓN col_t_s (todos los intentos):")
    for s in SES30 + ["c26"]:
        v = [t for t, _ in col_t[s]]
        m, sd = media_de(v)
        print(f"  {s}: media {m:.1f} ± {sd:.1f} s (ddof1) mediana {mediana(v):.1f} [{min(v):.1f}–{max(v):.1f}] n={len(v)}")
    v30 = [t for s in SES30 for t, _ in col_t[s]]
    m, sd = media_de(v30)
    print(f"  30-09 todas: media {m:.1f} ± {sd:.1f} s mediana {mediana(v30):.1f} n={len(v30)}")
    print()
    print("EPISODIOS VÁLIDOS QUE ARRANCARON CON ALGÚN ROBOT NO 'listo' O A > 0.12 m DE SU BLANCO (30-09 y 26-09):")
    for s, ep, det in val_fuera:
        print(f"  {s} ep {ep}: " + "; ".join(f"r{r} [{e}] a {d:.3f} m" for r, e, d in det))
    v30 = [x for x in val_fuera if x[0] != "c26"]
    print(f"  30-09: {len(v30)} de 50 válidos; robots afectados: {sum(len(x[2]) for x in v30)}")
    # consistencia: ¿todo robot 'listo' está dentro de 0.12 m, y todo no-listo fuera?
    listo_lejos = [(s, ep, ROBOT[a], round(d_blanco(f, a), 3)) for s, ep, f in todos_val for a in range(5)
                   if f[f"col_estado_a{a}"] == "listo" and d_blanco(f, a) > TOL_BLANCO]
    nolisto_cerca = [(s, ep, ROBOT[a], round(d_blanco(f, a), 3)) for s, ep, f in todos_val for a in range(5)
                     if f[f"col_estado_a{a}"] != "listo" and d_blanco(f, a) <= TOL_BLANCO]
    dl = [d_blanco(f, a) for s, ep, f in todos_val if s != "c26" for a in range(5) if f[f"col_estado_a{a}"] == "listo"]
    print(f"  'listo' a > 0.12 m: {listo_lejos or 'ninguno'} · no-'listo' a ≤ 0.12 m: {nolisto_cerca or 'ninguno'}")
    print(f"  30-09 válidos, robots 'listo': n={len(dl)} |x0−blanco| mediana {mediana(dl)*100:.1f} cm, máx {max(dl)*100:.1f} cm")
    print()
    print(f"VÁLIDOS FUERA DEL SOPORTE DEL SORTEO DE ENTRENAMIENTO en x0 (par < {SEP_ENTRENAMIENTO} m o robot a < {MARGEN_ENTRENAMIENTO} m de la pared):")
    for s, ep, p31, w45, nl in out_sop:
        print(f"  {s} ep {ep}: pares<0.31 {p31 or '—'} · pared<0.45 {w45 or '—'} · no-listo {nl or '—'}")
    o30 = [x for x in out_sop if x[0] != "c26"]
    n_p31 = sum(1 for x in o30 if x[2])
    n_w45 = sum(1 for x in o30 if x[3])
    n_w45_listo = sum(1 for x in o30 if any(e == "listo" for _, _, e in x[3]))
    print(f"  30-09: {len(o30)} de 50 válidos fuera del soporte; con par < 0.31 m: {n_p31}; con robot a < 0.45 m de pared: {n_w45} "
          f"(de ellos con el robot 'listo', dentro de la tolerancia de ±0.12 m: {n_w45_listo})")
    # chequeo de arranque de la sesión (0.15 m / 0.20 m): ¿alguno lo viola?
    viol = [(s, ep) for s, ep, f in todos_val if pares_x0(f)[0][0] < SEP_CHEQUEO or
            min(d_pared(x0(f, a)[0], x0(f, a)[1]) for a in range(5)) < MARGEN_CHEQUEO]
    print(f"  válidos que violan el chequeo de arranque de la sesión (par < {SEP_CHEQUEO} o pared < {MARGEN_CHEQUEO}): {viol or 'ninguno'}")
    # separación mínima por válido
    print()
    print("SEPARACIÓN MÍNIMA ENTRE CENTROS EN x0 por válido (30-09):")
    for s in SES30:
        print(f"  {s}: " + ", ".join(f"ep{ep}={pares_x0(f)[0][0]:.3f}" for ss, ep, f in todos_val if ss == s))


if __name__ == "__main__":
    main()
