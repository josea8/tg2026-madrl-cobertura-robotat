import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Tarea 2: ¿cuántos 'no avanza' de la colocación son BLOQUEO MUTUO del CBF robot-robot?
Extiende a las 5 sesiones del 30-09 (+26-09) la metodología de a30_robots_bloqueo_cbf.py
(ley nominal + FiltroColocacion REALES evaluados en x0) y de a30_robots_sim_bloqueo.py
(15 s de la ley + filtro desde x0, uniciclo ideal, moviendo sólo a los no-listo, con la zona
muerta V_MIN/W_MIN de colocacion_autonoma).

Regla de clasificación (fijada ANTES de ver el resultado de s3–s5):
  · BLOQUEO MUTUO CBF  = en x0 el robot tiene una barrera robot-robot activa (h_min ≤ 0.01 con un
    vecino cuyo punto de mira está a < D_ROBOTS + 0.02) Y en la simulación con zona muerta su
    métrica de progreso (d + 0.1·|err|) no mejora ≥ MEJORA_MINIMA en S_SIN_PROGRESO = 12 s.
  · INTERFERENCIA CBF  = barrera robot-robot activa en x0, pero la simulación con zona muerta sí
    progresa (el filtro frena/invierte, no traba del todo) → ambiguo, se reporta aparte.
  · NO ES CBF          = sin barrera robot-robot activa y/o comando filtrado ≈ nominal y la
    simulación llega/progresa → la falla es del robot (rueda, base, enlace) o de la medición.
Limitación: x0 es la pose al ARRANCAR el episodio (con los abandonados ya frenados donde
quedaron), no la del instante del abandono; y la simulación no tiene retardo ni patinaje.
SOLO LECTURA: importa colocacion_autonoma (numpy/scipy, sin torch) sin escribir bytecode.
Uso: python -B a30f_robots_bloqueo_cbf.py"""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import math
import warnings
from collections import Counter, defaultdict
import numpy as np
import colocacion_autonoma as ca
from a30f_robots_comun import SES30, ROBOT, leer_ep, fl

assert "torch" not in sys.modules, "se cargó torch: abortar"
warnings.simplefilter("ignore")
filtro = ca.FiltroColocacion()


def mira(p):
    return np.array([p[0] + ca.ELE_A * math.cos(p[2]), p[1] + ca.ELE_A * math.sin(p[2])])


def metrica(p, b, rumbo, llego):
    if llego:
        return 0.1 * abs(ca._envolver(rumbo - p[2]))
    d = math.hypot(b[0] - p[0], b[1] - p[1])
    err = ca._envolver(math.atan2(b[1] - p[1], b[0] - p[0]) - p[2])
    return d + 0.1 * abs(err)


def simular(poses, blancos, rumbos, mover, zona_muerta, T=15.0, dt=0.1):
    poses = {a: p.copy() for a, p in poses.items()}
    llego = {a: float(np.linalg.norm(blancos[a] - poses[a][:2])) <= ca.TOL_LLEGADA_M for a in poses}
    mejor = {a: metrica(poses[a], blancos[a], rumbos[a], llego[a]) for a in mover}
    t_mejor = {a: 0.0 for a in mover}
    t_primera = {a: None for a in mover}
    m0 = dict(mejor)
    p0 = {a: poses[a].copy() for a in mover}
    for k in range(int(T / dt)):
        acc = {}
        for a in mover:
            p = poses[a]
            d = float(np.linalg.norm(blancos[a] - p[:2]))
            if d <= ca.TOL_LLEGADA_M:
                llego[a] = True
            elif d > ca.TOL_SALIDA_M:
                llego[a] = False
            u_nom, fase = ca.ley_nominal(p, blancos[a], rumbos[a], llego[a])
            if fase == "listo":
                acc[a] = (0.0, 0.0)
                continue
            res = filtro.filtrar(p, np.array(u_nom), filtro.barreras_robots(a, poses))
            u = res.u_seguro if res.exito_qp else np.zeros(2)
            if zona_muerta and abs(u[0]) < ca.V_MIN and abs(u[1]) < ca.W_MIN:
                u = np.zeros(2)
            acc[a] = (float(u[0]), float(u[1]))
        for a, (v, w) in acc.items():
            x, y, th = poses[a]
            poses[a] = np.array([x + v * math.cos(th) * dt, y + v * math.sin(th) * dt, ca._envolver(th + w * dt)])
            m = metrica(poses[a], blancos[a], rumbos[a], llego[a])
            if m < mejor[a] - ca.MEJORA_MINIMA:
                mejor[a] = m
                t_mejor[a] = (k + 1) * dt
                if t_primera[a] is None:
                    t_primera[a] = (k + 1) * dt
    res = {}
    for a in mover:
        res[a] = dict(mejora=m0[a] - mejor[a], t_mejor=t_mejor[a],
                      desp=float(np.linalg.norm(poses[a][:2] - p0[a][:2])),
                      d_fin=float(np.linalg.norm(blancos[a] - poses[a][:2])),
                      t_primera=t_primera[a],
                      progresa_12s=(t_primera[a] is not None and t_primera[a] <= ca.S_SIN_PROGRESO))
    return res


def main():
    print(f"D_ROBOTS={ca.D_ROBOTS:.3f} m entre puntos de mira (ℓa={ca.ELE_A}) · V_MIN={ca.V_MIN} W_MIN={ca.W_MIN} · "
          f"S_SIN_PROGRESO={ca.S_SIN_PROGRESO} s · MEJORA_MINIMA={ca.MEJORA_MINIMA} · TOL_LLEGADA={ca.TOL_LLEGADA_M}")
    clases = Counter()
    por_ses = defaultdict(Counter)
    por_semilla = defaultdict(list)
    for s in SES30 + ["c26"]:
        E = leer_ep(s)
        print("=" * 118)
        print(f"SESIÓN {s}")
        for f in E:
            ep = int(f["episodio"])
            est = {a: f[f"col_estado_a{a}"] for a in range(5)}
            nl = [a for a in range(5) if est[a] != "listo"]
            por_semilla[int(f["semilla"])].append((s, ep, [ROBOT[a] for a in nl if est[a] == "no avanza"]))
            na = [a for a in range(5) if est[a] == "no avanza"]
            if not na:
                continue
            poses = {a: np.array([fl(f[f"x0_a{a}"]), fl(f[f"y0_a{a}"]), fl(f[f"th0_a{a}"])]) for a in range(5)}
            blancos = {a: np.array([fl(f[f"blanco_x_a{a}"]), fl(f[f"blanco_y_a{a}"])]) for a in range(5)}
            rumbos = {a: fl(f[f"blanco_th_a{a}"]) for a in range(5)}
            sim_zm = simular(poses, blancos, rumbos, nl, True)
            sim_sz = simular(poses, blancos, rumbos, nl, False)
            print("-" * 118)
            print(f"ep {ep} (semilla {f['semilla']}) valido={f['valido']} col_t={f['col_t_s']} s · estados: " +
                  ", ".join(f"r{ROBOT[a]}={est[a]}" for a in range(5)))
            pm = {a: mira(poses[a]) for a in range(5)}
            for a in na:
                p = poses[a]
                d = float(np.linalg.norm(blancos[a] - p[:2]))
                u_nom, fase = ca.ley_nominal(p, blancos[a], rumbos[a], d <= ca.TOL_LLEGADA_M)
                r = filtro.filtrar(p, np.array(u_nom), filtro.barreras_robots(a, poses))
                u = r.u_seguro if r.exito_qp else np.zeros(2)
                vec = sorted((float(np.linalg.norm(pm[a] - pm[j])), j) for j in range(5) if j != a)
                activos = [(dj, j) for dj, j in vec if dj < ca.D_ROBOTS + 0.02]
                barrera_rr = r.barrera_activa.startswith("robot") and r.h_minima <= 0.01 and bool(activos)
                bajo_zm = abs(u[0]) < ca.V_MIN and abs(u[1]) < ca.W_MIN
                inv = (u_nom[1] != 0 and np.sign(u[1]) != np.sign(u_nom[1]) and abs(u[1]) > 1e-3)
                zm, sz = sim_zm[a], sim_sz[a]
                if barrera_rr and not zm["progresa_12s"]:
                    clase = "BLOQUEO MUTUO CBF"
                elif barrera_rr:
                    clase = "INTERFERENCIA CBF (progresa en simulación)"
                else:
                    clase = "NO ES CBF"
                clases[clase] += 1
                por_ses[s][clase] += 1
                print(f"   r{ROBOT[a]} x0=({p[0]:.3f},{p[1]:.3f},{math.degrees(p[2]):6.1f}°) d_blanco={d:.3f} fase={fase} "
                      f"u_nom=({u_nom[0]:+.3f},{u_nom[1]:+.3f}) → u_filtrado=({u[0]:+.4f},{u[1]:+.4f}) barrera={r.barrera_activa} h_min={r.h_minima:+.3f}")
                print(f"        vecinos (punto de mira) más cercanos: " + "; ".join(f"r{ROBOT[j]} {dj:.3f} m" for dj, j in vec[:2]) +
                      f" · bajo zona muerta: {'SÍ' if bajo_zm else 'no'} · ω invertido por el filtro: {'SÍ' if inv else 'no'}")
                print(f"        simulación 15 s CON zona muerta: mejora {zm['mejora']*100:5.1f} cm-eq (primera a {zm['t_primera'] if zm['t_primera'] is not None else '—'} s, última a {zm['t_mejor']:.1f} s), "
                      f"desplaz. {zm['desp']*100:5.1f} cm, d_fin {zm['d_fin']:.3f} m | SIN zona muerta: mejora {sz['mejora']*100:5.1f}, "
                      f"desplaz. {sz['desp']*100:5.1f} cm, d_fin {sz['d_fin']:.3f} m")
                print(f"        → {clase}")
    print()
    print("=" * 118)
    print("RESUMEN de 'no avanza' (colocación final de cada intento, CSV):")
    for s in SES30 + ["c26"]:
        print(f"   {s}: {dict(por_ses[s]) or 'ninguno'}")
    t30 = Counter()
    for s in SES30:
        t30.update(por_ses[s])
    print(f"   30-09 total: {dict(t30)} (de {sum(t30.values())})")
    print()
    print("¿El bloqueo es propiedad de la SEMILLA (mismos blancos) o de dónde arrancó la colocación? — 'no avanza' por semilla:")
    for sem in sorted(por_semilla):
        filas = por_semilla[sem]
        con = [(s, ep, r) for s, ep, r in filas if r]
        if con:
            print(f"   semilla {sem}: {len(con)} de {len(filas)} intentos con 'no avanza' → " +
                  "; ".join(f"{s} ep{ep} r{r}" for s, ep, r in con) + "   | sin: " +
                  ", ".join(f"{s} ep{ep}" for s, ep, r in filas if not r))


if __name__ == "__main__":
    main()
