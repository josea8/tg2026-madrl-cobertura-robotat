import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR (a30f_verif_robots_): extras. (a) retrocesos registrados en los episodios con rachas
largas de pose repetida (s3 ep5 r8, s4 ep1 r8, s4 ep6 r6, s1 ep8 r6...); (b) máximo exacto de
|x0-blanco| de los 'listo' en válidos (A13); (c) duración de cada racha individual del 30-09.
SOLO LECTURA."""
import sys
sys.dont_write_bytecode = True
import csv, os, math
import numpy as np

D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
EPI = {1: "20260930_sesion-evaluacion_etapa7_episodios.csv", 2: "20260930_sesion-evaluacion_etapa7_episodios_02.csv",
       3: "20260930_sesion-evaluacion_etapa7_episodios_03.csv", 4: "20260930_sesion-evaluacion_etapa7_episodios_04.csv",
       5: "20260930_sesion-evaluacion_etapa7_episodios_05.csv"}
out = []
P = out.append
casos = {(1, 8), (1, 9), (2, 10), (3, 1), (3, 5), (4, 1), (4, 6), (4, 9), (5, 9), (4, 7), (5, 6)}
mx = (0, None)
for s, a in EPI.items():
    with open(os.path.join(D, a), encoding="utf-8", newline="") as fh:
        F = list(csv.DictReader(fh))
    for r in F:
        ep = int(r["episodio"])
        if (s, ep) in casos:
            P(f"s{s} ep{ep} valido={r['valido']} decisiones_retroceso={r['decisiones_retroceso']} retroceso_max_s={float(r['retroceso_max_s']):.2f} "
              f"recuperados={r['retrocesos_recuperados']} detalle={r['retrocesos_detalle']!r} cobertura_aoi={float(r['cobertura_aoi']):.4f}")
        if r["valido"].strip() == "1":
            for i in range(5):
                if r[f"col_estado_a{i}"].strip() == "listo":
                    d = math.hypot(float(r[f"x0_a{i}"]) - float(r[f"blanco_x_a{i}"]), float(r[f"y0_a{i}"]) - float(r[f"blanco_y_a{i}"]))
                    if d > mx[0]:
                        mx = (d, (s, ep, i))
P(f"A13: máximo |x0-blanco| de 'listo' en válidos = {mx[0]*100:.4f} cm en {mx[1]}")
open(os.path.join(r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad", "a30f_verif_robots_8_extras_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print("\n".join(out))
