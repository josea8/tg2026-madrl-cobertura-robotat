"""
ANÁLISIS FINAL de la evaluación física del 2026-09-30 — FIJADO ANTES de ver las réplicas
(escrito el 30-09 mientras corrían; decisión de Jose: "esas 50 corridas son mis resultados").

Conjunto de resultados: los 50 episodios válidos de las 5 sesiones del 30-09
(20260930_…_episodios{,_02,_03,_04,_05}.csv), regla de validez del protocolo, robots
[1,5,8,6,9], factor 0.40, 500 decisiones, colocación autónoma, retroceso. La sesión 5 corrió
con el arreglo de detención al final del episodio (actúa DESPUÉS de cerrar las métricas).

Diseño: las 5 sesiones reusan las mismas semillas (420000 + ep − 1) → ~12 escenarios
repetidos hasta 5 veces. Los pares NO son independientes entre sí dentro de una semilla.

  PRINCIPAL   : diferencia pareada d = hw − réplica con capas (media de 3 reps).
                Estimación puntual = media de los 50 d.
                IC95 PRINCIPAL = por semilla (cluster): media de d por semilla, t sobre las
                semillas (cada semilla pesa igual). Es el conservador.
                Referencia: IC t sobre los 50 pares (ignora el agrupamiento) y Wilcoxon.
  SENSIBILIDAD: (A) sin arranques fuera del soporte (algún par a < 0.31 m, o algún robot
                col_estado != 'listo' / |x0 − blanco| > 0.12 m); (B) sin episodios con pose
                repetida; (C) por sesión (bloque) con ANOVA de heterogeneidad.
  DECLARADOS  : + 26-09 (n=60, mismas semillas en parte, otro adaptador WiFi, sin retroceso
                de flujo), + 11-09 (n=65, otra composición y arranques compactos).
  REPETIBILIDAD: desvío dentro de semilla del hw y de la réplica; ICC(1) del hw por semilla.
  SEGURIDAD   : hw vs réplica (d_pared_min, viola_018, frac_cbf, n_escape, colisiones).
  RÉPLICAS INVÁLIDAS (regla agregada a las 13:45, tras ver que algunas corridas simuladas
                abortan por antigüedad de pose — 1/23 en la corrida parcial de las 12:3x,
                2/7 al arrancar la definitiva — y ANTES de ver cualquier resultado de pareo):
                la réplica de un episodio es la media de sus reps VÁLIDAS (1–3); una corrida
                simulada abortada es una falla de temporización del PC, no de la política, y
                su cobertura es de un episodio truncado. Si un episodio queda con 0 reps
                válidas, se corre una pasada suplementaria SÓLO de ese episodio y se declara.

Desvíos con ddof = 1. Solo lectura. Uso: python pareo_final_0930.py [carpeta_csv]
"""
import csv, math, sys
from pathlib import Path
import numpy as np
from scipy import stats

_PAQUETE = Path(__file__).resolve().parent.parent / "csv"
RS = (Path(sys.argv[1]) if len(sys.argv) > 1 else
      _PAQUETE if _PAQUETE.is_dir() else
      Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"))

S30 = [(f"30-09{l}", f"20260930_sesion-evaluacion_etapa7_episodios{s}.csv",
        f"*_sesion-replica_etapa7_capas-on_de-20260930{s}.csv")
       for l, s in (("a", ""), ("b", "_02"), ("c", "_03"), ("d", "_04"), ("e", "_05"))]
OTRAS = [("26-09", "20260926_sesion-evaluacion_etapa7_episodios.csv", "*_sesion-replica_etapa7_capas-on_de-20260926.csv"),
         ("11-09", "20260911_sesion-evaluacion_etapa7_episodios.csv", "20260912_sesion-replica_etapa7_capas-on.csv")]
SEGURIDAD = ("d_pared_min", "viola_018", "frac_cbf", "n_escape", "colisiones_015", "colisiones_022")


def leer_replica(patron):
    arch = sorted(RS.glob(patron))
    if not arch:
        sys.exit(f"falta la réplica {patron}")
    por_ep = {}
    for r in csv.DictReader(open(arch[-1], encoding="utf-8")):
        if str(r.get("valido", "1")) not in ("1", "True", "true"):
            print(f"  ⚠ réplica inválida {arch[-1].name}: ep {r['episodio']} rep {r['rep']}: {r.get('motivo')}")
            continue
        por_ep.setdefault(int(r["episodio"]), []).append(r)
    return arch[-1].name, por_ep


def validos(nombre):
    return {int(r["episodio"]): r for r in csv.DictReader(open(RS / nombre, encoding="utf-8"))
            if r["valido"] in ("1", "True")}


def fuera_de_soporte(r, n=5, tol=0.12, sep=0.31):
    motivos = []
    pts = []
    for i in range(n):
        est = (r.get(f"col_estado_a{i}") or "").strip()
        try:
            x0, y0 = float(r[f"x0_a{i}"]), float(r[f"y0_a{i}"])
            pts.append((x0, y0))
            dist = math.hypot(x0 - float(r[f"blanco_x_a{i}"]), y0 - float(r[f"blanco_y_a{i}"]))
        except (KeyError, ValueError, TypeError):
            dist = float("nan")
        if (est and est != "listo") or (dist == dist and dist > tol):
            motivos.append(f"a{i} {est or '-'} {dist:.2f} m")
    dmin = min((math.dist(p, q) for k, p in enumerate(pts) for q in pts[k + 1:]), default=float("inf"))
    if dmin < sep:
        motivos.append(f"par a {dmin:.2f} m")
    return motivos


def semiancho(sd, n):
    return stats.t.ppf(0.975, n - 1) * sd / math.sqrt(n)


def cargar(sesiones):
    pares = []
    for et, eps, patron in sesiones:
        v = validos(eps); nom, rep = leer_replica(patron)
        for e, r in v.items():
            if e not in rep:
                print(f"  ⚠ {et} ep {e}: sin réplica"); continue
            reps = rep[e]
            pares.append(dict(
                sesion=et, ep=e, semilla=int(r["semilla"]),
                hw=float(r["cobertura_aoi"]), sim=float(np.mean([float(x["cobertura_aoi"]) for x in reps])),
                sd_reps=float(np.std([float(x["cobertura_aoi"]) for x in reps], ddof=1)) if len(reps) > 1 else 0.0,
                retro=bool((r.get("retrocesos_detalle") or "").strip()),
                fuera=fuera_de_soporte(r),
                seg_hw={k: float(r[k]) for k in SEGURIDAD if r.get(k) not in (None, "")},
                seg_sim={k: float(np.mean([float(x[k]) for x in reps if x.get(k) not in (None, "")]))
                         for k in SEGURIDAD if any(x.get(k) not in (None, "") for x in reps)}))
        print(f"{et}: {len(v)} válidos · réplica {nom}")
    return pares


def informe(nombre, pares, cluster=True):
    d = np.array([p["hw"] - p["sim"] for p in pares]); n = len(d)
    if n < 3:
        print(f"\n== {nombre}: n = {n}, insuficiente"); return
    m = d.mean(); sd = d.std(ddof=1); w = semiancho(sd, n)
    pw = stats.wilcoxon(d, method="exact" if n <= 25 else "approx").pvalue
    print(f"\n== {nombre}  (n = {n} pares)")
    print(f"   hw {np.mean([p['hw'] for p in pares]):.4f} ± {np.std([p['hw'] for p in pares], ddof=1):.4f}   "
          f"réplica con capas {np.mean([p['sim'] for p in pares]):.4f} ± {np.std([p['sim'] for p in pares], ddof=1):.4f}")
    print(f"   hw − réplica = {m:+.4f} ± {sd:.4f}  ·  IC95 por pares [{m - w:+.4f}, {m + w:+.4f}] (±{w:.4f})  "
          f"t p = {stats.ttest_1samp(d, 0).pvalue:.4f}  Wilcoxon p = {pw:.4f}  positivas {int((d > 0).sum())}/{n}")
    if cluster:
        por = {}
        for p in pares:
            por.setdefault(p["semilla"], []).append(p["hw"] - p["sim"])
        ms = np.array([np.mean(x) for x in por.values()]); k = len(ms)
        if k >= 3:
            wc = semiancho(ms.std(ddof=1), k)
            print(f"   POR SEMILLA ({k} escenarios, {min(len(x) for x in por.values())}–{max(len(x) for x in por.values())} pares c/u): "
                  f"media {ms.mean():+.4f} ± {ms.std(ddof=1):.4f}  ·  IC95 [{ms.mean() - wc:+.4f}, {ms.mean() + wc:+.4f}] (±{wc:.4f})  "
                  f"t p = {stats.ttest_1samp(ms, 0).pvalue:.4f}")


if __name__ == "__main__":
    P = cargar(S30)
    print("\nArranques fuera del soporte:", [(p["sesion"], p["ep"], p["fuera"]) for p in P if p["fuera"]] or "ninguno")
    print("Episodios con pose repetida:", [(p["sesion"], p["ep"]) for p in P if p["retro"]] or "ninguno")
    print(f"Ruido de la réplica entre reps: mediana {np.median([p['sd_reps'] for p in P]):.4f}, máx {max(p['sd_reps'] for p in P):.4f}")
    informe("PRINCIPAL: los 50 válidos del 30-09", P)
    informe("SENS. A: sin arranques fuera del soporte", [p for p in P if not p["fuera"]])
    informe("SENS. B: sin episodios con pose repetida", [p for p in P if not p["retro"]])
    grupos = {}
    for p in P:
        grupos.setdefault(p["sesion"], []).append(p)
    for et in sorted(grupos):
        informe(f"sesión {et}", grupos[et], cluster=False)
    dif = [np.array([p["hw"] - p["sim"] for p in g]) for g in grupos.values()]
    print(f"\nheterogeneidad entre las 5 sesiones del 30-09: ANOVA p = {stats.f_oneway(*dif).pvalue:.4f} · Kruskal p = {stats.kruskal(*dif).pvalue:.4f}")
    O = cargar(OTRAS)
    informe("DECLARADO: 30-09 + 26-09", P + [p for p in O if p["sesion"] == "26-09"])
    informe("DECLARADO: 30-09 + 26-09 + 11-09", P + O)
    # Repetibilidad por semilla (sólo 30-09)
    por = {}
    for p in P:
        por.setdefault(p["semilla"], []).append(p)
    rep = [g for g in por.values() if len(g) >= 2]
    def dentro(clave):
        num = sum(sum((x[clave] - np.mean([y[clave] for y in g])) ** 2 for x in g) for g in rep)
        gl = sum(len(g) - 1 for g in rep)
        return math.sqrt(num / gl), gl
    sw_h, gl = dentro("hw"); sw_s, _ = dentro("sim")
    todos = [x["hw"] for g in rep for x in g]; N = len(todos); k = len(rep)
    n0 = (N - sum(len(g) ** 2 for g in rep) / N) / (k - 1)
    msb = sum(len(g) * (np.mean([x["hw"] for x in g]) - np.mean(todos)) ** 2 for g in rep) / (k - 1)
    icc = (msb - sw_h ** 2) / (msb + (n0 - 1) * sw_h ** 2)
    print(f"\nREPETIBILIDAD (30-09, {k} semillas con ≥2 episodios, gl {gl}): desvío dentro de semilla hw {sw_h:.4f} · "
          f"réplica {sw_s:.4f} · desvío total hw {np.std(todos, ddof=1):.4f} · ICC(1) hw {icc:.3f}")
    # Seguridad
    print("\nSEGURIDAD (50 válidos del 30-09): hw vs réplica con capas")
    for k2 in SEGURIDAD:
        h = [p["seg_hw"][k2] for p in P if k2 in p["seg_hw"]]; s = [p["seg_sim"][k2] for p in P if k2 in p["seg_sim"]]
        if h and s:
            print(f"   {k2:15s} hw {np.mean(h):.4f} ± {np.std(h, ddof=1):.4f} (mín {min(h):.4f})   réplica {np.mean(s):.4f} ± {np.std(s, ddof=1):.4f}")
