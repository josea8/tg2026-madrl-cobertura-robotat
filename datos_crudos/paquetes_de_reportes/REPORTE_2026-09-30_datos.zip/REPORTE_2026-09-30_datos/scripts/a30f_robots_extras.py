import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Complementos (SOLO LECTURA):
 1) qué celda de la grilla 4×4 de diversidad_arranques queda vacía en las 12 configuraciones
    distintas (explica el ⚠ de 'blancos de los 57 intentos': repetición de semillas, no colocación);
 2) robot 5 en la sesión 2: posición al final del ep 2, durante todo el ep 3 y en x0 del ep 4
    (¿quedó inmóvil en el mismo punto desde el NO SIGUE hasta la reconexión?);
 3) cobertura AoI (descriptiva) de los 5 válidos con arranque fuera de soporte vs los otros 45
    (NO es hw − réplica; sólo sensibilidad del conjunto de resultados a esos 5).
Uso: python -B a30f_robots_extras.py"""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import csv, math, os
import numpy as np
from scipy.stats import mannwhitneyu
from a30f_robots_comun import SES, SES30, ROBOT, RS, leer_ep, fl, media_de, mediana

LO, HI, G = 0.45, 2.55, 4
# 1) celdas
todos = [f for s in SES30 for f in leer_ep(s)]
uno = {}
for f in todos:
    uno.setdefault(int(f["semilla"]), f)
celdas = set()
for f in uno.values():
    for a in range(5):
        x, y = fl(f[f"blanco_x_a{a}"]), fl(f[f"blanco_y_a{a}"])
        cx = min(max(int((x - LO) / (HI - LO) * G), 0), G - 1)
        cy = min(max(int((y - LO) / (HI - LO) * G), 0), G - 1)
        celdas.add((cx, cy))
vacias = [(i, j) for i in range(G) for j in range(G) if (i, j) not in celdas]
paso = (HI - LO) / G
print(f"1) {len(uno)} configuraciones distintas (semillas {sorted(uno)}): celdas cubiertas {len(celdas)}/16; vacías: " +
      ", ".join(f"({i},{j}) = x∈[{LO + i * paso:.3f},{LO + (i + 1) * paso:.3f}] y∈[{LO + j * paso:.3f},{LO + (j + 1) * paso:.3f}]" for i, j in vacias))
val = [f for f in todos if f["valido"] == "1"]
celdas_x0 = set()
for f in val:
    for a in range(5):
        x, y = fl(f[f"x0_a{a}"]), fl(f[f"y0_a{a}"])
        celdas_x0.add((min(max(int((x - LO) / (HI - LO) * G), 0), G - 1), min(max(int((y - LO) / (HI - LO) * G), 0), G - 1)))
quien = []
for f in val:
    for a in range(5):
        x, y = fl(f[f"x0_a{a}"]), fl(f[f"y0_a{a}"])
        c = (min(max(int((x - LO) / (HI - LO) * G), 0), G - 1), min(max(int((y - LO) / (HI - LO) * G), 0), G - 1))
        if c in vacias:
            quien.append((f["episodio"], ROBOT[a], f[f"col_estado_a{a}"], round(x, 3), round(y, 3)))
print(f"   en x0 de los 50 válidos las celdas cubiertas son {len(celdas_x0)}/16; robots que caen en la celda vacía de los blancos: {quien}")

# 2) robot 5, sesión 2
D = {}
with open(os.path.join(RS, SES["s2"][1]), encoding="utf-8", newline="") as fh:
    for r in csv.DictReader(fh):
        if r["agente"] == "1" and r["episodio"] in ("2", "3", "4"):
            D.setdefault(int(r["episodio"]), []).append((int(r["paso"]), float(r["pose_env_x"]), float(r["pose_env_y"]),
                                                         float(r["v_ejecutada"])))
for e in D:
    D[e].sort()
e2 = np.array([[x, y] for _, x, y, _ in D[2]])
e3 = np.array([[x, y] for _, x, y, _ in D[3]])
e4 = np.array([[x, y] for _, x, y, _ in D[4]])
print(f"2) s2 robot 5: fin ep 2 ({e2[-1,0]:.3f},{e2[-1,1]:.3f}); ep 3 ({len(e3)} decisiones) x∈[{e3[:,0].min():.4f},{e3[:,0].max():.4f}] "
      f"y∈[{e3[:,1].min():.4f},{e3[:,1].max():.4f}] → rango {max(np.ptp(e3[:,0]), np.ptp(e3[:,1]))*1000:.3f} mm, "
      f"|v_ejecutada| media {np.mean([abs(v) for *_, v in D[3]]):.3f} (política, antes del factor); "
      f"distancia fin ep2 → inicio ep3 {np.linalg.norm(e3[0]-e2[-1])*1000:.1f} mm; ep 4 arranca en ({e4[0,0]:.3f},{e4[0,1]:.3f}) "
      f"a {np.linalg.norm(e4[0]-e2[-1]):.3f} m del punto donde quedó")

# 3) cobertura de los 5 válidos fuera de soporte
fuera = {("s1", 8), ("s2", 5), ("s2", 10), ("s2", 12), ("s5", 9)}
cf, cr = [], []
for s in SES30:
    for f in leer_ep(s):
        if f["valido"] != "1":
            continue
        (cf if (s, int(f["episodio"])) in fuera else cr).append(fl(f["cobertura_aoi"]))
m1, s1 = media_de(cf)
m2, s2_ = media_de(cr)
u = mannwhitneyu(cf, cr, alternative="two-sided")
print(f"3) cobertura AoI (hardware, descriptiva): 5 válidos fuera de soporte {m1:.4f} ± {s1:.4f} (ddof1) {sorted(round(x, 4) for x in cf)}; "
      f"otros 45 {m2:.4f} ± {s2_:.4f}; Mann-Whitney U={u.statistic:.0f} p={u.pvalue:.2f}; los 50: {media_de(cf + cr)[0]:.4f} ± {media_de(cf + cr)[1]:.4f}")

# 4) arreglo de detención: qué código corrió cada sesión (mtimes) y qué cambió (difflib, solo lectura)
import datetime, difflib
COORD = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
act = os.path.join(COORD, "sesion_robotat.py")
res = os.path.join(COORD, "sesion_robotat_respaldo_20260930_preDetencion.py")
ts = lambda p: datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S")
print(f"4) sesion_robotat.py modificado {ts(act)}; respaldo preDetencion {ts(res)}; CSV episodios: " +
      ", ".join(f"{s} {ts(os.path.join(RS, SES[s][0]))}" for s in SES30))
d = [l for l in difflib.unified_diff(open(res, encoding='utf-8').read().splitlines(),
                                     open(act, encoding='utf-8').read().splitlines(), lineterm='', n=0)
     if (l.startswith('+') or l.startswith('-')) and not l.startswith('+++') and not l.startswith('---')]
cod = [l for l in d if l[1:].strip() and not l[1:].strip().startswith('#')]
print(f"   diff respaldo→actual: {len(d)} líneas (+/−), de ellas de código (no comentario): {cod}")
