import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_verif_congel_2.py — verificaciones complementarias (robustez y sesgos) sobre las
afirmaciones F7, F14, F16, F19/F20, F12–F13. Reutiliza SÓLO mi propio cargador
(a30f_verif_congel_1.py, importado con la salida silenciada). SÓLO LECTURA.
"""
import io, math, sys, contextlib
from collections import Counter, defaultdict
import numpy as np
from scipy import stats
sys.stdout.reconfigure(encoding='utf-8')
_buf = io.TextIOWrapper(io.BytesIO(), encoding='utf-8')
with contextlib.redirect_stdout(_buf):
    import a30f_verif_congel_1 as V
DEC, EPI, CON, EV, DEL = V.DEC, V.EPI, V.CON, V.EV, V.DEL
S30, ORD = V.S30, V.ORD
fisher = V.fisher

print('=' * 100)
print('A) F14 — centro D redondeado (1.471, 1.269) vs exacto; s1 ep9 r6 al miembro más cercano de D')
lug = [v for v in EV if v['mec'] in V.LUGAR]
for cx, cy, nom in ((1.471, 1.269, 'redondeado'),):
    no = sum(1 for d in ORD for L in DEC[d].values() for r in L if r['robot'] != 6 and not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < 0.15)
    print(f'  {nom}: filas vivas de otros robots a <15 cm en 6 días: {no}')
Dm = [v for v in lug if v['robot'] == 6 and v['dia'] in S30 and math.hypot(v['x'] - 1.471, v['y'] - 1.269) < 0.08]
s19 = [v for v in EV if v['dia'] == 's1' and v['ep'] == 9][0]
print('  s1 ep9 r6 a miembros de D: ' + ', '.join(f"{w['dia']} ep{w['ep']} p{w['paso']} {100*math.hypot(w['x']-s19['x'], w['y']-s19['y']):.2f} cm" for w in Dm))

print('=' * 100)
print('B) F7 — robustez de la asociación hipo ↔ inicio: umbrales y exclusión de las 2 decisiones que motivaron la firma')


def barrido(r_bajo, r_alto, excluir=()):
    n = nh = hi = nhi = 0
    for d in S30:
        for ep, pasos in DEL[d].items():
            if EPI[d][ep]['valido'] != '1':
                continue
            for p, dd in pasos.items():
                if p < 12 or len(dd) < 5 or (d, ep, p) in excluir:
                    continue
                n += 1
                m0, mp, rf, r, rp = V.firma(d, ep, p)
                h = (not math.isnan(r)) and r < r_bajo and rp > r_alto
                ini = V.nini.get((d, ep, p), 0) > 0
                if h:
                    nh += 1; hi += ini
                else:
                    nhi += ini
    return n, nh, hi, nhi


for rb, ra in ((0.30, 1.6), (0.30, 1.4), (0.30, 1.8), (0.20, 1.6), (0.50, 1.6), (0.50, 1.4)):
    n, nh, hi, nhi = barrido(rb, ra)
    print(f'  r<{rb} y r_prev>{ra}: hipos {nh}/{n}; con inicio {hi}/{nh} vs no-hipo {nhi}/{n-nh}; Fisher p {fisher(hi, nh, nhi, n-nh) if nh else float("nan"):.3g}')
n, nh, hi, nhi = barrido(0.30, 1.6, excluir={('s5', 9, 157), ('s4', 9, 270)})
print(f'  sin las 2 decisiones motivadoras (s5 ep9 157, s4 ep9 270): hipos {nh}/{n}; con inicio {hi}/{nh} vs {nhi}/{n-nh}; Fisher p {fisher(hi, nh, nhi, n-nh):.3g}')
# agentes repetidos por decisión-hipo (5 cuerpos por decisión)
reps = []
for d in S30:
    for ep, pasos in DEL[d].items():
        for p, dd in pasos.items():
            if p < 12 or len(dd) < 5:
                continue
            m0, mp, rf, r, rp = V.firma(d, ep, p)
            if (not math.isnan(r)) and r < 0.30 and rp > 1.6:
                reps.append((d, ep, p, EPI[d][ep]['valido'], sum(1 for ag, (dm, rp_) in dd.items() if rp_), round(m0, 2), round(mp, 1)))
print('  decisiones-hipo (sesión, ep, paso, válido, n.º de agentes con fila repetida, m(p) mm, m(p−1) mm):')
for x in reps:
    print('     ', x)
print(f"  cuerpos repetidos / cuerpos en decisiones-hipo: {sum(x[4] for x in reps)}/{5*len(reps)}")

print('=' * 100)
print('C) F19/F20 — neto observado vs avance esperado SIN retroceso (v_in·(racha+1)·dt), Motive 30-09')
for v in sorted([v for v in EV if v['dia'] in S30 and v['mec'] in ('Motive', 'hipo') and v['reap']], key=lambda v: v['racha']):
    L, i = v['L'], v['i']
    viv = [r for r in L[:i] if not r['rep']]
    a, b = viv[-6], viv[-1]
    vin = math.hypot(b['x'] - a['x'], b['y'] - a['y']) / ((b['paso'] - a['paso']) * v['dt'])
    esp = 100 * vin * (v['racha'] + 1) * v['dt']
    print(f"  {v['dia']} ep{v['ep']} r{v['robot']} p{v['paso']} {v['mec']:6s} racha {v['racha']:2d}: v_in {100*vin:.1f} cm/s; avance esperado sin retroceso +{esp:.1f} cm;"
          f" observado {-v['neto']:+.1f} cm por delante → efecto aparente del retroceso {esp + v['neto']:+.1f} cm; plan {v['det']['cm']} cm")

print('=' * 100)
print('D) F12/F13 — dependencia de las pasadas: episodios/agentes distintos y pasadas del 26-09 posteriores al congelamiento')
for P in ('A', 'B', 'C'):
    cx, cy = V.PC[P]
    for d in ('26-09',):
        ps = V.pasadas(d, cx, cy)
        print(f"  {P} {d}: pasadas {len(ps)}; (ep, robot, n filas, cong): {[(p['ep'], p['robot'], p['n'], p['cong']) for p in ps]}")
    tot = [(d, p['ep'], p['ag']) for d in S30 for p in V.pasadas(d, cx, cy)]
    print(f"  {P} 30-09: pasadas {len(tot)} en {len(set(tot))} (sesión, ep, agente) distintos y {len({(e, a) for _, e, a in tot})} (semilla, agente) distintos")

print('=' * 100)
print('E) F3 — ¿cuántas filas se perdieron en el 26-09 por abortos causados por el congelamiento? (sesgo de la tasa en válidos)')
for ep, e in sorted(EPI['26-09'].items()):
    if e['motivo'].startswith('marcador CONGELADO'):
        print(f"  ep{ep}: abortado en la decisión {e['decisiones']} de 500 → {5*(500-int(e['decisiones']))} filas no observadas")

print('=' * 100)
print('F) F3 — unidad episodio (menos sensible a la autocorrelación de filas): episodios con ≥1 inicio Motive')
for nom, cond in (('todos', lambda d, ep: True), ('válidos', lambda d, ep: EPI[d][ep]['valido'] == '1')):
    e26 = [ep for ep in EPI['26-09'] if cond('26-09', ep)]
    e30 = [(d, ep) for d in S30 for ep in EPI[d] if cond(d, ep)]
    k26 = sum(1 for ep in e26 if any(v['dia'] == '26-09' and v['ep'] == ep and v['mec'] == 'Motive' for v in EV))
    k30 = sum(1 for d, ep in e30 if any(v['dia'] == d and v['ep'] == ep and v['mec'] == 'Motive' for v in EV))
    print(f'  {nom}: 26-09 {k26}/{len(e26)} vs 30-09 {k30}/{len(e30)}  Fisher p {fisher(k26, len(e26), k30, len(e30)):.3g}')
# prueba de tasas de Poisson condicionada (binomial) con exposición en decisiones-agente
k1 = sum(1 for v in EV if v['dia'] == '26-09' and v['mec'] == 'Motive'); n1 = sum(len(L) for L in DEC['26-09'].values())
k2 = sum(1 for v in EV if v['dia'] in S30 and v['mec'] == 'Motive'); n2 = sum(len(L) for d in S30 for L in DEC[d].values())
bt = stats.binomtest(k1, k1 + k2, n1 / (n1 + n2))
print(f'  Poisson condicionada (todos): {k1} en {n1} vs {k2} en {n2}; p {bt.pvalue:.3g}')
