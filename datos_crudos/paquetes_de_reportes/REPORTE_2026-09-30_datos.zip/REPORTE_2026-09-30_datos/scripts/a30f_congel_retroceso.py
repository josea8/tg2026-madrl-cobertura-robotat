import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_congel_retroceso.py — retrocesos por pose repetida en las 5 sesiones del 30-09 (+26-09):
cuántos, resultado, filas en_retroceso, desplazamiento neto medido a la reaparición, y relación
con el mecanismo del congelamiento (a30f_congel_clase.py). SÓLO LECTURA.

Definiciones:
* P0 = pose congelada (última viva); u = dirección de entrada (últimas 5 filas vivas antes del
  inicio); v_in = |desplazamiento| / (pasos · dt).
* Reaparición = primera fila viva tras la racha (fila j). a_lo_largo = (P_j − P0)·u (cm; + = por
  delante de la congelada, − = por detrás); lateral = componente perpendicular.
* NETO RETROCEDIDO (medido) = −a_lo_largo: > 0 si el robot reaparece DETRÁS de la pose congelada.
* Esperado sin retroceso (INFERIDO, modelo de velocidad constante) = v_in · (paso_j − paso_{i−1}) · dt.
  Efecto aparente del retroceso = esperado − a_lo_largo.
* 'cm' de retrocesos_detalle = largo del camino COMANDADO del plan, no lo recorrido.
"""
import math, sys
from collections import Counter, defaultdict
import numpy as np
sys.stdout.reconfigure(encoding='utf-8')
import a30f_congel_clase as CL
K = CL.K
S, E, C, I = K.S, K.E, K.C, K.I
ORDEN = ['26-09', 's1', 's2', 's3', 's4', 's5']

print('=' * 118)
print('1) RECUENTO de retrocesos (retrocesos_detalle) por sesión, válidos/abortados y resultado; filas en_retroceso')
TOT = defaultdict(Counter)
for ses in ORDEN:
    for grupo, cond in [('válidos', '1'), ('abortados', '0')]:
        dets = [d for ep, e in E[ses].items() if e['valido'] == cond for d in K.detalle(e)]
        res = Counter(d['res'] for d in dets)
        filas_ret = sum(r['retro'] for (ep, ag), s in S[ses].items() if E[ses][ep]['valido'] == cond for r in s['f'])
        col = sum(int(e['decisiones_retroceso'] or 0) for e in E[ses].values() if e['valido'] == cond)
        rec_col = sum(int(e['retrocesos_recuperados'] or 0) for e in E[ses].values() if e['valido'] == cond)
        filas = sum(len(s['f']) for (ep, ag), s in S[ses].items() if E[ses][ep]['valido'] == cond)
        TOT[(ses, grupo)].update(dict(n=len(dets), filas_ret=filas_ret, col=col, filas=filas, **res))
        print(f"  {ses:6s} {grupo:9s} retrocesos {len(dets):2d}  resultados {dict(res)}  (columna retrocesos_recuperados {rec_col})"
              f"  filas en_retroceso {filas_ret} (columna decisiones_retroceso {col})  = {100*filas_ret/max(filas,1):.3f} % de {filas} filas")
for grupo in ['válidos', 'abortados']:
    t = Counter()
    for s in K.SES30:
        t.update(TOT[(s, grupo)])
    print(f"  30-09 {grupo:9s} retrocesos {t['n']}  recuperada {t['recuperada']}  sigue_congelada {t['sigue_congelada']}  episodio_abortado {t['episodio_abortado']}"
          f"  fin_del_episodio {t['fin_del_episodio']}  filas en_retroceso {t['filas_ret']} / {t['filas']} = {100*t['filas_ret']/t['filas']:.3f} %")

print('=' * 118)
print('2) CADA RETROCESO: mecanismo del disparo, duración, desplazamiento a la reaparición')
FILAS = []
for ses in ORDEN:
    print(f'--- {ses}')
    for it in I[ses]:
        d = it['det']
        f = it['s']['f']; i, j = it['i'], it['j']
        dx, dy, n, npas = K.entrada(f, i)
        dt = it['dt']
        if n > 1e-6:
            ux, uy = dx / n, dy / n
        else:
            ux, uy = math.cos(it['r']['th']), math.sin(it['r']['th'])
        v_in = n / (npas * dt) if npas else float('nan')
        P0 = it['r']
        filas_ret = sum(f[k]['retro'] for k in range(i, min(len(f), j + 1)))
        if j < len(f):
            Pj = f[j]
            al = (Pj['x'] - P0['x']) * ux + (Pj['y'] - P0['y']) * uy
            la = -(Pj['x'] - P0['x']) * uy + (Pj['y'] - P0['y']) * ux
            trans = (Pj['paso'] - (P0['paso'] - 1)) * dt
            esp = v_in * trans
            # mínimo a lo largo en las 6 filas siguientes (¿sigue retrocediendo tras reaparecer?)
            mn = min(((f[k]['x'] - P0['x']) * ux + (f[k]['y'] - P0['y']) * uy) for k in range(j, min(len(f), j + 6)))
            txt = (f"reaparece paso {Pj['paso']}: a lo largo {100*al:+.1f} cm, lateral {100*la:+.1f} cm → NETO retrocedido {100*(-al):+.1f} cm;"
                   f" esperado sin retroceso {100*esp:+.1f} cm (v_in {100*v_in:.1f} cm/s × {trans:.2f} s) → efecto aparente {100*(esp-al):+.1f} cm;"
                   f" mín. a lo largo en 6 filas {100*mn:+.1f} cm")
        else:
            al = la = esp = mn = float('nan'); trans = float('nan')
            txt = 'no reaparece (fin de la secuencia: episodio terminado/abortado)'
        dtxt = f"{d['p_ini']}-{d['p_fin']} {d['dur']} s, plan {d['cm']} cm, {d['res']}" if d else 'sin retroceso'
        print(f"  ep{it['ep']:2d} (V={it['valido']}) a{it['ag']}/r{it['robot']} paso {P0['paso']:3d} [{it['tipo_f']}/{it['mec']}] racha {it['racha']:2d}"
              f" (≈ {it['racha']*dt:.2f} s)  filas en_retroceso {filas_ret}  d_pared {P0['d']:.3f} | {dtxt}")
        print(f"      {txt}")
        FILAS.append(dict(ses=ses, it=it, al=al, la=la, esp=esp, mn=mn, v_in=v_in, filas_ret=filas_ret, res=d['res'] if d else None,
                          dur=d['dur'] if d else None, cm=d['cm'] if d else None))

print('=' * 118)
print('3) RESUMEN 30-09 por mecanismo del disparo')
f30 = [q for q in FILAS if q['ses'] in K.SES30]
for mec in ['Motive', 'caché-fallida', 'caché-rechazo', 'hipo']:
    q = [x for x in f30 if x['it']['mec'] == mec]
    if not q:
        continue
    res = Counter(x['res'] for x in q)
    val = sum(1 for x in q if x['it']['valido'] == 1)
    rea = [x for x in q if not math.isnan(x['al'])]
    neto = [-100 * x['al'] for x in rea]
    efe = [100 * (x['esp'] - x['al']) for x in rea]
    print(f"  {mec:14s} retrocesos {len(q):2d} ({val} en válidos)  resultados {dict(res)}  filas en_retroceso {sum(x['filas_ret'] for x in q)}")
    if rea:
        print(f"      reaparecen {len(rea)}: NETO retrocedido (cm) {', '.join(f'{v:+.1f}' for v in neto)}"
              f"  → media {np.mean(neto):+.2f}, DE(ddof=1) {np.std(neto, ddof=1) if len(neto)>1 else float('nan'):.2f}")
        print(f"      efecto aparente (esperado − observado, cm; INFERIDO) {', '.join(f'{v:+.1f}' for v in efe)}")
# por racha corta vs larga (Motive)
print('  --- Motive, por duración de la racha (retardo de actuación 0.45 s ≈ 4-5 decisiones)')
for nom, cond in [('racha ≤ 3 (≤ 0.3 s)', lambda x: x['it']['racha'] <= 3), ('racha ≥ 10 (≥ 1 s)', lambda x: x['it']['racha'] >= 10)]:
    q = [x for x in f30 if x['it']['mec'] == 'Motive' and cond(x) and not math.isnan(x['al'])]
    if q:
        neto = [-100 * x['al'] for x in q]
        print(f"      {nom}: n {len(q)}  NETO (cm) {', '.join(f'{v:+.1f}' for v in neto)}  media {np.mean(neto):+.2f}"
              f"  DE(ddof=1) {np.std(neto, ddof=1) if len(q) > 1 else float('nan'):.2f}  | lateral (cm) {', '.join(f'{100*x['la']:+.1f}' for x in q)}")
q = [x for x in FILAS if x['ses'] == '26-09' and not math.isnan(x['al'])]
print('  --- control 26-09 (reaparecen): ' + ', '.join(f"ep{x['it']['ep']} r{x['it']['robot']} racha {x['it']['racha']} neto {-100*x['al']:+.1f} cm" for x in q))

print('=' * 118)
print('4) RETROCESOS DISPARADOS SIN PUNTO CIEGO (defecto conocido de caché, y el hipo de ritmo)')
for x in FILAS:
    it = x['it']
    if it['mec'] == 'Motive':
        continue
    print(f"  {x['ses']:6s} ep{it['ep']:2d} (V={it['valido']}) a{it['ag']}/r{it['robot']} paso {it['r']['paso']:3d} [{it['mec']}{' INFERIDO (sin consola)' if it['inferido'] else ''}]"
          f" resultado {x['res']} {x['dur']} s, plan {x['cm']} cm; filas en_retroceso {x['filas_ret']}; d_pared {it['r']['d']:.3f}")
n_val_cache = sum(1 for x in f30 if x['it']['mec'].startswith('caché') and x['it']['valido'] == 1)
n_val_hipo = sum(1 for x in f30 if x['it']['mec'] == 'hipo' and x['it']['valido'] == 1)
pfpr = [(s, ep) for s in K.SES30 for ep, e in E[s].items() if e['valido'] == '1' and (int(e['poses_fallidas'] or 0) or int(e['poses_rechazadas'] or 0))]
print(f"  30-09 válidos: retrocesos por caché {n_val_cache}; por hipo {n_val_hipo}; episodios válidos con poses_fallidas>0 o poses_rechazadas>0: {pfpr or 'ninguno'}")

print('=' * 118)
print('5) CONSOLA ▶ (duración hasta reanudar) contra la racha del CSV (sesiones con consola)')
for ses in ORDEN:
    c = C[ses]
    if c is None:
        print(f'  {ses}: sin consola'); continue
    for v in c['vivas']:
        its = [it for it in I[ses] if it['ep'] == v['ep'] and it['ag'] == v['ag']]
        its = [it for it in its if it['det'] and it['det']['res'] == 'recuperada']
        rr = [f"paso {it['r']['paso']} racha {it['racha']} det {it['det']['dur']} s" for it in its]
        print(f"  {ses:6s} ep{v['ep']:2d} a{v['ag']}: ▶ tras {v['tras']} s  | CSV: {rr}")
