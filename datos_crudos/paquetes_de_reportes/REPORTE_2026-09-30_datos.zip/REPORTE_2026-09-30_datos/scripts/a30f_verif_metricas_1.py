import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""VERIFICADOR ADVERSARIAL de las afirmaciones A01–A25 del análisis a30f_metricas_.
Escrito DESDE CERO (no importa ni ejecuta nada del analista; sólo lee los CSV
crudos con el módulo csv y las consolas pegadas). SOLO LECTURA de la carpeta del
coordinador. NO lee ningún archivo de réplica y NO usa 'cobertura_replica'.
Salida: a30f_verif_metricas_1_salida.txt y a30f_verif_metricas_tabla.csv."""
import sys
sys.dont_write_bytecode = True
import os
import csv
import re
import math
import datetime
import numpy as np
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
SP = (r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis"
      r"\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
OUT = open(os.path.join(SP, "a30f_verif_metricas_1_salida.txt"), "w", encoding="utf-8", newline="\n")


def P(*a):
    print(*a, file=OUT)


SES = ["C26", "S1", "S2", "S3", "S4", "S5"]
S30 = ["S1", "S2", "S3", "S4", "S5"]
ARCH = {"C26": ("20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
        "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv")}
for k in range(2, 6):
    ARCH[f"S{k}"] = (f"20260930_sesion-evaluacion_etapa7_episodios_0{k}.csv",
                     f"20260930_sesion-evaluacion_etapa7_decisiones_0{k}.csv")
CONS = {"C26": "consola_20260926.txt", "S1": "consola_20260930.txt", "S2": "consola_20260930_02.txt",
        "S3": "consola_20260930_03.txt", "S4": "consola_20260930_04.txt", "S5": "consola_20260930_05.txt"}
ESPERADOS = {"S1": list(range(3, 13)), "S2": [1] + list(range(4, 13)), "S3": [1, 2] + list(range(4, 12)),
             "S4": list(range(1, 7)) + list(range(8, 12)), "S5": list(range(1, 6)) + list(range(7, 12))}
ROB = [1, 5, 8, 6, 9]            # agente i -> robot
ESC, ROT, TX, TY = 1.0166876, 0.0084726, 1.5061547, 1.2563353


def env_a_lab(xe, ye):
    vx, vy = xe - TX, ye - TY
    c, s = math.cos(ROT), math.sin(ROT)
    # R^-1 = R(-rot)
    return (c * vx + s * vy) / ESC, (-s * vx + c * vy) / ESC


def leer_ep(fn):
    with open(os.path.join(RS, fn), encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def leer_dec(fn):
    with open(os.path.join(RS, fn), encoding="utf-8-sig", newline="") as fh:
        rd = csv.reader(fh)
        cab = next(rd)
        filas = list(rd)
    A = np.array([[float(v) for v in f] for f in filas])
    D = {c: A[:, i] for i, c in enumerate(cab)}
    ix, iy, it = cab.index("pose_env_x"), cab.index("pose_env_y"), cab.index("pose_env_th")
    D["_clave"] = np.array([f[ix] + "|" + f[iy] + "|" + f[it] for f in filas], dtype=object)
    return D, cab


def arrays_ep(D, ep):
    m = np.where(D["episodio"] == ep)[0]
    ag = D["agente"][m].astype(int)
    pa = D["paso"][m].astype(int)
    pasos = np.unique(pa)
    n = len(pasos)
    ip = np.searchsorted(pasos, pa)
    cnt = np.zeros((n, 5), int)
    np.add.at(cnt, (ip, ag), 1)
    o = dict(n=n, nfilas=len(m), completo=bool((cnt == 1).all()),
             consecutivos=bool((pasos == np.arange(pasos[0], pasos[0] + n)).all()), paso0=int(pasos[0]))
    for c in ("pose_env_x", "pose_env_y", "pose_env_th", "v_ejecutada", "en_escape", "cbf_intervino",
              "con_vecino", "en_retroceso"):
        M = np.full((n, 5), np.nan)
        M[ip, ag] = D[c][m]
        o[c] = M
    K = np.empty((n, 5), dtype=object)
    K[ip, ag] = D["_clave"][m]
    rep = np.zeros((n, 5), bool)
    rep[1:] = K[1:] == K[:-1]
    o["rep"] = rep
    o["pasos"] = pasos
    return o


def metricas_ep(o):
    x, y = o["pose_env_x"], o["pose_env_y"]
    dp = np.minimum(np.minimum(x, 3.0 - x), np.minimum(y, 3.0 - y))
    r = {}
    r["dp"] = dp
    r["dpmin"] = float(dp.min())
    r["viola"] = int((dp.min(axis=0) < 0.18).sum())
    r["cbf"] = float(o["cbf_intervino"].mean())
    r["esc"] = int(o["en_escape"].sum())
    r["vec"] = float(o["con_vecino"].mean())
    c15 = c22 = 0
    best = (np.inf, None, None, None)
    for i in range(5):
        for j in range(i + 1, 5):
            d = np.hypot(x[:, i] - x[:, j], y[:, i] - y[:, j])
            c15 += int((d < 0.15).any())
            c22 += int((d < 0.22).any())
            k = int(np.argmin(d))
            if d[k] < best[0]:
                best = (float(d[k]), k, i, j)
    r["c15"], r["c22"] = c15, c22
    r["sep_min"], r["sep_k"], r["sep_i"], r["sep_j"] = best
    rec = np.hypot(np.diff(x, axis=0), np.diff(y, axis=0)).sum(axis=0)
    r["rec_min"], r["rec_max"] = float(rec.min()), float(rec.max())
    e = o["en_escape"]
    r["act"] = int(((e[1:] == 1) & (e[:-1] == 0)).sum())
    r["act_ini"] = int((e[0] == 1).sum())
    r["n_rep"] = int(o["rep"].sum())
    r["n_ret"] = int(o["en_retroceso"].sum())
    r["rep_y_ret"] = int((o["rep"] & (o["en_retroceso"] == 1)).sum())
    k, a = np.unravel_index(int(np.argmin(dp)), dp.shape)
    r["dp_k"], r["dp_a"] = int(k), int(a)
    r["dp_x"], r["dp_y"] = float(x[k, a]), float(y[k, a])
    r["dp_esc"] = int(o["en_escape"][k, a])
    r["dp_ret"] = int(o["en_retroceso"][k, a])
    r["dp_rep"] = bool(o["rep"][k, a])
    r["dp_rep_sig"] = bool(k + 1 < o["n"] and o["rep"][k + 1, a])
    return r


# ─────────────────────────────── carga ───────────────────────────────
EPS = []          # una fila por intento
DEC = {}
for s in SES:
    fe, fd = ARCH[s]
    E = leer_ep(fe)
    D, cab = leer_dec(fd)
    DEC[s] = D
    for row in E:
        ep = int(row["episodio"])
        o = arrays_ep(D, ep)
        r = metricas_ep(o)
        est = [row[f"col_estado_a{i}"] for i in range(5)]
        err = [float(row[f"col_err_m_a{i}"]) if row[f"col_err_m_a{i}"] not in ("", None) else np.nan for i in range(5)]
        EPS.append(dict(
            ses=s, ep=ep, semilla=int(row["semilla"]), valido=int(row["valido"]), motivo=row["motivo"],
            dec=int(row["decisiones"]), dur=float(row["duracion_s"]), factor=row["factor"], coloc=row["colocacion"],
            rpm_ab=row["rpm_aborto"],
            cob=float(row["cobertura_aoi"]), c15_csv=int(row["colisiones_015"]), c22_csv=int(row["colisiones_022"]),
            dpmin_csv=float(row["d_pared_min"]), viola_csv=int(row["viola_018"]), cbf_csv=float(row["frac_cbf"]),
            esc_csv=int(row["n_escape"]), vec_csv=float(row["frac_vecino"]), dmin_csv=float(row["dist_min_robot"]),
            dmax_csv=float(row["dist_max_robot"]), p95=float(row["ciclo_p95_ms"]), s100=int(row["ciclos_sobre_100ms"]),
            ret_csv=int(row["decisiones_retroceso"]), pf=int(row["poses_fallidas"]), prech=int(row["poses_rechazadas"]),
            col_t=float(row["col_t_s"]) if row["col_t_s"] else np.nan, col_listos=int(row["col_listos"]),
            estados=est, errs=err, fuera=[ROB[i] for i in range(5) if est[i] != "listo"],
            n=o["n"], nfilas=o["nfilas"], completo=o["completo"], consecutivos=o["consecutivos"], paso0=o["paso0"],
            **{k: v for k, v in r.items() if k != "dp"}, _o=o, _dp=r["dp"]))

V = [e for e in EPS if e["valido"] == 1]
V30 = [e for e in V if e["ses"] in S30]
V26 = [e for e in V if e["ses"] == "C26"]


def col(lst, k):
    return np.array([e[k] for e in lst], float)


# tabla propia
with open(os.path.join(SP, "a30f_verif_metricas_tabla.csv"), "w", encoding="utf-8", newline="") as fh:
    ks = ["ses", "ep", "semilla", "valido", "cob", "c15", "c22", "dpmin", "viola", "cbf", "esc", "act", "act_ini", "vec",
          "rec_min", "sep_min", "p95", "s100", "n_rep", "n_ret", "rep_y_ret", "ret_csv", "pf", "prech", "col_t",
          "col_listos", "dur"]
    w = csv.writer(fh)
    w.writerow(ks + ["fuera"])
    for e in EPS:
        w.writerow([e[k] for k in ks] + ["".join(f"r{r}" for r in e["fuera"]) or "-"])

# ─────────────────────────────── A01 ───────────────────────────────
P("=== A01: válidos, intentos, semillas ===")
for s in SES:
    todos = [e for e in EPS if e["ses"] == s]
    val = [e["ep"] for e in todos if e["valido"] == 1]
    ok = (val == ESPERADOS[s]) if s in ESPERADOS else None
    P(f"  {s}: intentos {len(todos)} (eps {[e['ep'] for e in todos]}) · válidos {val} · coincide con la lista fija: {ok}")
    P(f"       semilla==420000+ep-1 en TODOS los intentos: {all(e['semilla'] == 420000 + e['ep'] - 1 for e in todos)}"
      f" · factor {sorted(set(e['factor'] for e in todos))} · colocacion {sorted(set(e['coloc'] for e in todos))}"
      f" · rpm_aborto {sorted(set(e['rpm_ab'] for e in todos))} · decisiones válidos {sorted(set(e['dec'] for e in todos if e['valido']))}")
P(f"  total válidos 30-09: {len(V30)} · semillas distintas {len(set(e['semilla'] for e in V30))} "
  f"{sorted(set(e['semilla'] for e in V30))}")
P(f"  26-09 válidos: {[e['ep'] for e in V26]} semillas {[e['semilla'] for e in V26]}")

# ─────────────────────────────── A02 ───────────────────────────────
P("\n=== A02: recálculo de las métricas del CSV de episodios desde decisiones (todos los intentos) ===")
for grupo, lst in (("válidos", V), ("inválidos", [e for e in EPS if e["valido"] == 0])):
    P(f"  {grupo} (n={len(lst)}):")
    P(f"    filas = 5*decisiones: {all(e['nfilas'] == 5 * e['dec'] for e in lst)} · n pasos = decisiones: "
      f"{all(e['n'] == e['dec'] for e in lst)} · tabla (paso x agente) completa: {all(e['completo'] for e in lst)}"
      f" · pasos consecutivos desde 0: {all(e['consecutivos'] and e['paso0'] == 0 for e in lst)}")
    for a, b, nom in (("dpmin", "dpmin_csv", "d_pared_min"), ("cbf", "cbf_csv", "frac_cbf"), ("vec", "vec_csv", "frac_vecino"),
                      ("rec_min", "dmin_csv", "dist_min_robot"), ("rec_max", "dmax_csv", "dist_max_robot")):
        P(f"    {nom:15s} máx |dif| = {max(abs(e[a] - e[b]) for e in lst):.3e}")
    for a, b, nom in (("viola", "viola_csv", "viola_018"), ("esc", "esc_csv", "n_escape"), ("c15", "c15_csv", "colisiones_015"),
                      ("c22", "c22_csv", "colisiones_022")):
        P(f"    {nom:15s} discrepancias enteras = {sum(e[a] != e[b] for e in lst)}")
inv_rec = [(e["ses"], e["ep"], abs(e["rec_min"] - e["dmin_csv"]), abs(e["rec_max"] - e["dmax_csv"]))
           for e in EPS if e["valido"] == 0]
P("    inválidos con |dif| de recorrido > 1e-9:", [(a, b, round(max(c, d), 4)) for a, b, c, d in inv_rec if max(c, d) > 1e-9])

# ─────────────────────────────── A03 ───────────────────────────────
P("\n=== A03: cruce con las consolas (media y desvío ddof 0; mismo formato que imprime la sesión) ===")
ETQ = [("cobertura AoI", "cob", "{:.4f}"), ("colisiones < 0.15 m", "c15", "{:.2f}"),
       ("colisiones < 0.22 m", "c22", "{:.2f}"), ("d_pared mínima [m]", "dpmin", "{:.6f}"),
       ("agentes que violan 0.18", "viola", "{:.2f}"), ("intervención CBF", "cbf", "{:.3f}"),
       ("activaciones de escape", "esc", "{:.1f}"), ("decisiones con vecino", "vec", "{:.3f}"),
       ("distancia mín. por robot [m]", "rec_min", "{:.2f}"), ("ciclo p95 [ms]", "p95", "{:.1f}")]
for s in SES:
    fn = os.path.join(SP, CONS[s])
    if not os.path.exists(fn):
        P(f"  {s}: {CONS[s]} NO EXISTE -> sin dato")
        continue
    L = open(fn, encoding="utf-8", errors="replace").read().splitlines()
    cabs = [i for i, l in enumerate(L) if l.startswith("métrica") and "media" in l and "desv" in l]
    evs = [l for l in L if l.startswith("EVALUACIÓN —")]
    i0 = cabs[-1]
    sub = [e for e in V if e["ses"] == s]
    malos = []
    for et, k, fmt in ETQ:
        l = [q for q in L[i0 + 1:i0 + 12] if q.startswith(et)][0]
        mc, sc = l[len(et):].split()[:2]
        a = col(sub, k)
        mm, sm = fmt.format(float(np.mean(a))), fmt.format(float(np.std(a)))
        if (mc, sc) != (mm, sm):
            malos.append(f"{k}: consola {mc}/{sc} vs mío {mm}/{sm}")
    # por episodio: '>>> EPISODIO k: VÁLIDO' + línea siguiente
    vc, per = [], []
    for i, l in enumerate(L):
        mt = re.search(r">>> EPISODIO (\d+): (VÁLIDO|INVÁLIDO)", l)
        if mt and mt.group(2) == "VÁLIDO":
            vc.append(int(mt.group(1)))
            m2 = re.search(r"cobertura AoI ([0-9.]+)\s+·\s+colisiones <0\.15 (\d+)\s+·\s+d_pared mín ([0-9.]+)", L[i + 1])
            if m2:
                per.append((int(mt.group(1)), m2.group(1), int(m2.group(2)), m2.group(3)))
    mis = {e["ep"]: e for e in sub}
    per_mal = [(ep, c, d) for ep, c, n15, d in per
               if f"{mis[ep]['cob']:.4f}" != c or f"{mis[ep]['dpmin']:.6f}" != d or mis[ep]["c15"] != n15]
    P(f"  {s}: bloques 'métrica/media/desv' {len(cabs)} · encabezados {evs} · discrepancias del resumen {len(malos)} {malos}")
    P(f"       válidos según consola {vc} == CSV {[e['ep'] for e in sub]}: {vc == [e['ep'] for e in sub]} · "
      f"líneas por episodio cruzadas {len(per)} · discrepancias {len(per_mal)} {per_mal}")

# ─────────────────────────────── A04 ───────────────────────────────
P("\n=== A04: activaciones de escape (0->1) vs n_escape ===")
act = col(V30, "act")
P(f"  30-09: n_escape medio {col(V30, 'esc').mean():.2f} · activaciones 0->1 medio {act.mean():.3f} (suma {int(act.sum())}) · "
  f"episodios-agente que ARRANCAN en escape (paso 0): {int(col(V30, 'act_ini').sum())}")

# ─────────────────────────────── A05/A06 ───────────────────────────────
P("\n=== A05/A06: resúmenes (media ± sd ddof1; mín; máx; mediana) ===")
MET = [("cob", "cobertura_aoi"), ("c15", "colisiones_015"), ("c22", "colisiones_022"), ("dpmin", "d_pared_min"),
       ("viola", "viola_018"), ("cbf", "frac_cbf"), ("esc", "n_escape"), ("act", "activaciones 0->1"),
       ("vec", "frac_vecino"), ("rec_min", "dist_min_robot"), ("sep_min", "separación mín. par"),
       ("p95", "ciclo_p95_ms"), ("s100", "ciclos>100ms"), ("dur", "duración_s"), ("col_t", "colocación t")]
GR = [(s, [e for e in V if e["ses"] == s]) for s in S30] + [("TOTAL30", V30), ("C26", V26)]
for g, sub in GR:
    P(f"  --- {g} n={len(sub)}")
    for k, nom in MET:
        a = col(sub, k)
        P(f"     {nom:20s} {a.mean():10.4f} ± {a.std(ddof=1):9.4f} · mín {a.min():.4f} · máx {a.max():.4f} · "
          f"med {np.median(a):.4f} · suma {a.sum():.4f}")
imn = int(np.argmin(col(V30, "cob")))
imx = int(np.argmax(col(V30, "cob")))
P(f"  cob mín: {V30[imn]['ses']} ep{V30[imn]['ep']} sem {V30[imn]['semilla']} {V30[imn]['cob']:.4f} · "
  f"cob máx: {V30[imx]['ses']} ep{V30[imx]['ep']} sem {V30[imx]['semilla']} {V30[imx]['cob']:.4f}")


# ─────────────────────────────── utilidades estadísticas ───────────────────────────────
def welch(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
    d = a.mean() - b.mean()
    se = math.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
    q = stats.t.ppf(0.975, df)
    return d, d - q * se, d + q * se, 2 * stats.t.sf(abs(d / se), df)


def fe(y, g, x):
    """coeficiente de x con efectos fijos del grupo g (Frisch–Waugh)."""
    y, x, g = np.asarray(y, float), np.asarray(x, float), np.asarray(g)
    yt, xt = y.copy(), x.copy()
    ug = np.unique(g)
    for k in ug:
        s = g == k
        yt[s] -= y[s].mean()
        xt[s] -= x[s].mean()
    sxx = (xt ** 2).sum()
    b = (xt * yt).sum() / sxx
    rr = yt - b * xt
    df = len(y) - len(ug) - 1
    se = math.sqrt((rr ** 2).sum() / df / sxx)
    q = stats.t.ppf(0.975, df)
    return b, b - q * se, b + q * se, 2 * stats.t.sf(abs(b / se), df), df


def mw_propio(a, b):
    """Mann-Whitney bilateral, aproximación normal con corrección por empates y por continuidad."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    z_ = np.concatenate([a, b])
    rk = stats.rankdata(z_)
    n1, n2 = len(a), len(b)
    U1 = rk[:n1].sum() - n1 * (n1 + 1) / 2
    N = n1 + n2
    _, cnt = np.unique(z_, return_counts=True)
    var = n1 * n2 / 12 * ((N + 1) - (cnt ** 3 - cnt).sum() / (N * (N - 1)))
    mu = n1 * n2 / 2
    if var == 0:
        return float("nan")
    z = (abs(U1 - mu) - 0.5) / math.sqrt(var)
    return 2 * stats.norm.sf(z)


# ─────────────────────────────── A07 ───────────────────────────────
P("\n=== A07: 30-09 (n=50) vs 26-09 (n=10) ===")
W = V30 + V26
gW = np.array([e["semilla"] for e in W])
iW = np.array([1.0] * len(V30) + [0.0] * len(V26))
compartidas = sorted(set(e["semilla"] for e in V26) & set(e["semilla"] for e in V30))
P(f"  semillas del 26-09 compartidas con el 30-09: {compartidas}")
for k, nom in MET[:13]:
    a, b = col(V30, k), col(V26, k)
    if a.std() == 0 and b.std() == 0:
        P(f"  {nom:20s} constante: {a.mean():.4f} vs {b.mean():.4f}")
        continue
    d, lo, hi, p = welch(a, b)
    pmw = stats.mannwhitneyu(a, b, alternative="two-sided").pvalue
    bb, blo, bhi, bp, df = fe(col(W, k), gW, iW)
    P(f"  {nom:20s} {a.mean():9.4f} vs {b.mean():9.4f} · dif {d:+.4f} [{lo:+.4f}, {hi:+.4f}] p {p:.4f} · "
      f"MW p {pmw:.4f} (propio {mw_propio(a, b):.4f}) · FE semilla {bb:+.4f} [{blo:+.4f}, {bhi:+.4f}] p {bp:.4f} gl {df}")

# ─────────────────────────────── A08 ───────────────────────────────
P("\n=== A08: heterogeneidad de la cobertura entre S1..S5 ===")
gs = [col([e for e in V30 if e["ses"] == s], "cob") for s in S30]
y = np.concatenate(gs)
N = len(y)
gm = y.mean()
ssb = sum(len(g) * (g.mean() - gm) ** 2 for g in gs)
sst = ((y - gm) ** 2).sum()
ssw = sst - ssb
F = (ssb / 4) / (ssw / (N - 5))
P(f"  ANOVA propio F(4,{N-5}) = {F:.4f} p {stats.f.sf(F, 4, N-5):.4f} · eta2 {ssb/sst:.4f} · scipy F {stats.f_oneway(*gs).statistic:.4f}")
# Kruskal propio
rk = stats.rankdata(y)
off = np.cumsum([0] + [len(g) for g in gs])
H = 12 / (N * (N + 1)) * sum((rk[off[i]:off[i + 1]].sum()) ** 2 / len(gs[i]) for i in range(5)) - 3 * (N + 1)
_, cnt = np.unique(y, return_counts=True)
H /= 1 - (cnt ** 3 - cnt).sum() / (N ** 3 - N)
P(f"  Kruskal propio H = {H:.4f} p {stats.chi2.sf(H, 4):.4f} · scipy {stats.kruskal(*gs).statistic:.4f}")
# Levene propio (centro media) = ANOVA sobre |y - media de grupo|
zs = [np.abs(g - g.mean()) for g in gs]
zz = np.concatenate(zs)
ssbz = sum(len(z) * (z.mean() - zz.mean()) ** 2 for z in zs)
sswz = sum(((z - z.mean()) ** 2).sum() for z in zs)
Fz = (ssbz / 4) / (sswz / (N - 5))
zs2 = [np.abs(g - np.median(g)) for g in gs]
P(f"  Levene (media) propio p {stats.f.sf(Fz, 4, N-5):.4f} · Brown-Forsythe scipy p {stats.levene(*gs, center='median').pvalue:.4f}")


def dums(lab):
    u = sorted(set(lab))
    return np.array([[1.0 if l == v else 0.0 for v in u[1:]] for l in lab]).reshape(len(lab), len(u) - 1)


def ssr(X, yy):
    b = np.linalg.lstsq(X, yy, rcond=None)[0]
    r = yy - X @ b
    return float(r @ r)


sem30 = [e["semilla"] for e in V30]
ses30 = [e["ses"] for e in V30]
y30 = col(V30, "cob")
one = np.ones((50, 1))
Xs, Xd = dums(sem30), dums(ses30)
ss_f = ssr(np.hstack([one, Xs, Xd]), y30)
ss_ns = ssr(np.hstack([one, Xd]), y30)
ss_nd = ssr(np.hstack([one, Xs]), y30)
glr = 50 - 1 - Xs.shape[1] - Xd.shape[1]
Fs = ((ss_ns - ss_f) / Xs.shape[1]) / (ss_f / glr)
Fd = ((ss_nd - ss_f) / Xd.shape[1]) / (ss_f / glr)
sst30 = ((y30 - y30.mean()) ** 2).sum()
P(f"  aditivo: sesión F({Xd.shape[1]},{glr}) = {Fd:.4f} p {stats.f.sf(Fd, Xd.shape[1], glr):.4f} ({(ss_nd-ss_f)/sst30*100:.1f} % SS) · "
  f"semilla F({Xs.shape[1]},{glr}) = {Fs:.4f} p {stats.f.sf(Fs, Xs.shape[1], glr):.4f} ({(ss_ns-ss_f)/sst30*100:.1f} % SS)")

# ─────────────────────────────── A09 / A12 ───────────────────────────────
P("\n=== A09/A12: tendencia por orden de sesión (1..5) ===")
orden = np.array([int(e["ses"][1]) for e in V30], float)
lr = stats.linregress(orden, y30)
q48 = stats.t.ppf(0.975, 48)
P(f"  cob cruda: {lr.slope:+.5f} [{lr.slope - q48*lr.stderr:+.5f}, {lr.slope + q48*lr.stderr:+.5f}] p {lr.pvalue:.4f}")
b, lo, hi, p, df = fe(y30, sem30, orden)
P(f"  cob FE semilla: {b:+.5f} [{lo:+.5f}, {hi:+.5f}] p {p:.4f} gl {df} · x4: {4*b:+.4f} [{4*lo:+.4f}, {4*hi:+.4f}]")


def jt(groups):
    J = 0.0
    for i in range(len(groups)):
        for j in range(i + 1, len(groups)):
            J += (groups[j][None, :] > groups[i][:, None]).sum() + 0.5 * (groups[j][None, :] == groups[i][:, None]).sum()
    return J


J0 = jt(gs)
rng = np.random.default_rng(424242)
lab = np.repeat(np.arange(5), 10)
Jp = np.empty(20000)
for t in range(len(Jp)):
    pm = rng.permutation(y)
    Jp[t] = jt([pm[lab == i] for i in range(5)])
EJ = (N ** 2 - sum(len(g) ** 2 for g in gs)) / 4
P(f"  JT J = {J0:.1f} · E[J] = {EJ:.1f} · p perm (20000, semilla propia) {np.mean(np.abs(Jp - EJ) >= abs(J0 - EJ) - 1e-9):.4f}")
P("  pendiente FE semilla por métrica (por sesión):")
for k, nom in MET:
    if k in ("c15", "c22", "cob"):
        continue
    yk = col(V30, k)
    b, lo, hi, p, df = fe(yk, sem30, orden)
    P(f"     {nom:20s} {b:+10.5f} [{lo:+10.5f}, {hi:+10.5f}] p {p:.4f}")
for s in S30:
    P(f"  p95 {s}: {col([e for e in V30 if e['ses'] == s], 'p95').mean():.2f} ms · por episodio "
      f"{[round(e['p95'], 1) for e in V30 if e['ses'] == s]}")

# ─────────────────────────────── A13 / A15 ───────────────────────────────
P("\n=== A13/A15: S3 y S5 frente al resto ===")
for s in ("S3", "S5"):
    ind = np.array([1.0 if e["ses"] == s else 0.0 for e in V30])
    for k in ("cob", "p95", "s100", "col_t", "dpmin"):
        yk = col(V30, k)
        a, r_ = yk[ind == 1], yk[ind == 0]
        d, lo, hi, p = welch(a, r_)
        b, blo, bhi, bp, df = fe(yk, sem30, ind)
        P(f"  {s} {k:6s} {a.mean():9.4f} vs {r_.mean():9.4f} (suma {a.sum():.1f} vs {r_.sum():.1f}) · dif {d:+.4f} "
          f"[{lo:+.4f}, {hi:+.4f}] p {p:.4f} · FE {b:+.4f} [{blo:+.4f}, {bhi:+.4f}] p {bp:.4f}")

# ─────────────────────────────── A14 ───────────────────────────────
P("\n=== A14: tiempos de archivo (os.stat; hora local del PC) ===")
for s in S30:
    for f in ARCH[s]:
        st = os.stat(os.path.join(RS, f))
        cr = getattr(st, "st_birthtime", st.st_ctime)
        P(f"  {s} {f}: creado {datetime.datetime.fromtimestamp(cr):%H:%M:%S} · modificado "
          f"{datetime.datetime.fromtimestamp(st.st_mtime):%H:%M:%S}")


# ─────────────────────────────── A16–A18 ───────────────────────────────
def icc1(yv, g):
    yv, g = np.asarray(yv, float), np.asarray(g)
    ug = np.unique(g)
    a = len(ug)
    Nn = len(yv)
    n = np.array([(g == k).sum() for k in ug], float)
    mg = np.array([yv[g == k].mean() for k in ug])
    ssb_ = (n * (mg - yv.mean()) ** 2).sum()
    ssw_ = sum(((yv[g == k] - yv[g == k].mean()) ** 2).sum() for k in ug)
    msb, msw = ssb_ / (a - 1), ssw_ / (Nn - a)
    n0 = (Nn - (n ** 2).sum() / Nn) / (a - 1)
    s2b = max((msb - msw) / n0, 0.0)
    icc = s2b / (s2b + msw)
    Fv = msb / msw
    FL = Fv / stats.f.ppf(0.975, a - 1, Nn - a)
    FU = Fv * stats.f.ppf(0.975, Nn - a, a - 1)
    return dict(a=a, N=Nn, n0=n0, icc=icc, lo=(FL - 1) / (FL + n0 - 1), hi=(FU - 1) / (FU + n0 - 1), F=Fv,
                p=stats.f.sf(Fv, a - 1, Nn - a), sdw=math.sqrt(msw), sdb=math.sqrt(s2b), sdm=float(np.std(mg, ddof=1)),
                sdt=float(np.std(yv, ddof=1)), msw=msw, n=n, mg=mg)


def pr_icc(nom, yv, g):
    r = icc1(yv, g)
    P(f"  {nom}: a={r['a']} N={r['N']} n0={r['n0']:.3f} · ICC {r['icc']:.3f} [{r['lo']:.3f}, {r['hi']:.3f}] · "
      f"sd dentro {r['sdw']:.4f} · sd entre {r['sdb']:.4f} · sd medias {r['sdm']:.4f} · sd total {r['sdt']:.4f} · "
      f"F({r['a']-1},{r['N']-r['a']}) = {r['F']:.3f} p {r['p']:.4g}")
    return r


P("\n=== A16–A18: ICC(1) ===")
R0 = pr_icc("principal 30-09", y30, sem30)
rngb = np.random.default_rng(777)
useeds = np.unique(sem30)
grp = {s: y30[np.array(sem30) == s] for s in useeds}
bs = []
for _ in range(10000):
    pick = rngb.choice(useeds, size=len(useeds), replace=True)
    yy = np.concatenate([grp[s] for s in pick])
    gg = np.concatenate([[i] * len(grp[s]) for i, s in enumerate(pick)])
    bs.append(icc1(yy, gg)["icc"])
P(f"  bootstrap por semilla (10000, semilla propia 777) IC95 [{np.percentile(bs, 2.5):.3f}, {np.percentile(bs, 97.5):.3f}]")
comp = [e for e in V26 if e["semilla"] in compartidas]
pr_icc("variante A (+26-09 compartidas)", col(V30 + comp, "cob"), [e["semilla"] for e in V30 + comp])
pr_icc("variante B (+26-09 completo)", col(V30 + V26, "cob"), [e["semilla"] for e in V30 + V26])
sin = [e for e in V30 if not e["fuera"]]
pr_icc("sin episodios con robots fuera", col(sin, "cob"), [e["semilla"] for e in sin])
mses = {s: col([e for e in V30 if e["ses"] == s], "cob").mean() for s in S30}
yc = np.array([e["cob"] - mses[e["ses"]] + y30.mean() for e in V30])
pr_icc("centrado por sesión", yc, sem30)
P("  episodios con robots fuera del blanco (col_estado != 'listo'):")
dev_f, dev_n = [], []
for e in V30:
    otros = [q["cob"] for q in V30 if q["semilla"] == e["semilla"] and q is not e]
    d = e["cob"] - np.mean(otros)
    (dev_f if e["fuera"] else dev_n).append(abs(d))
    if e["fuera"]:
        idx = [ROB.index(r) for r in e["fuera"]]
        P(f"     {e['ses']} ep{e['ep']} sem {e['semilla']} fuera {e['fuera']} estados {[e['estados'][i] for i in idx]} "
          f"err_m {[round(e['errs'][i], 3) for i in idx]} col_listos {e['col_listos']} · cob {e['cob']:.4f} · "
          f"resto semilla {np.mean(otros):.4f} (n={len(otros)}) · desvío {d:+.4f}")
P(f"  |desvío| medio fuera {np.mean(dev_f):.4f} (n={len(dev_f)}) · resto {np.mean(dev_n):.4f} (n={len(dev_n)}) · "
  f"MW p {stats.mannwhitneyu(dev_f, dev_n, alternative='two-sided').pvalue:.4f}")
P(f"  estados de colocación presentes en los válidos 30-09: {sorted(set(x for e in V30 for x in e['estados']))}")
# robots 'listo' pero con error grande, por si 'fuera' no captura todo
P("  robots 'listo' con col_err_m > 0.12 en válidos 30-09:",
  [(e["ses"], e["ep"], ROB[i], round(e["errs"][i], 3)) for e in V30 for i in range(5)
   if e["estados"][i] == "listo" and e["errs"][i] > 0.12])

# ─────────────────────────────── A19–A22 ───────────────────────────────
P("\n=== A19–A22: seguridad ===")
for g, sub in GR:
    P(f"  {g}: eps con c15>0 {sum(e['c15'] > 0 for e in sub)} · c22>0 {sum(e['c22'] > 0 for e in sub)} · "
      f"dpmin<0.05 {sum(e['dpmin'] < 0.05 for e in sub)} · <0.10 {sum(e['dpmin'] < 0.10 for e in sub)} · "
      f"sep mín {min(e['sep_min'] for e in sub):.4f} · dpmin mín {min(e['dpmin'] for e in sub):.4f}")
orden_sep = sorted(V30, key=lambda e: e["sep_min"])[:3]
for e in orden_sep:
    P(f"  sep: {e['ses']} ep{e['ep']} paso {e['sep_k']} r{ROB[e['sep_i']]}-r{ROB[e['sep_j']]} {e['sep_min']:.4f} m · fuera {e['fuera']}")
orden_dp = sorted(V30, key=lambda e: e["dpmin"])[:8]
for e in orden_dp:
    xl, yl = env_a_lab(e["dp_x"], e["dp_y"])
    P(f"  dp: {e['ses']} ep{e['ep']} robot {ROB[e['dp_a']]} paso {e['dp_k']} {e['dpmin']:.4f} env ({e['dp_x']:.3f}, {e['dp_y']:.3f}) "
      f"lab ({xl:.3f}, {yl:.3f}) esc {e['dp_esc']} rep {e['dp_rep']} ret {e['dp_ret']} sigue congelada {e['dp_rep_sig']}")
P(f"  quién fija dpmin 30-09: { {r: sum(ROB[e['dp_a']] == r for e in V30) for r in ROB} } · 26-09: "
  f"{ {r: sum(ROB[e['dp_a']] == r for e in V26) for r in ROB} }")
P(f"  mínimos 30-09 con escape {sum(e['dp_esc'] for e in V30)}/50 · con pose repetida {sum(e['dp_rep'] for e in V30)} · "
  f"en retroceso {sum(e['dp_ret'] for e in V30)} · mínimo seguido de congelamiento {sum(e['dp_rep_sig'] for e in V30)}")
# distribución por fila
for g, sub in GR:
    dp = np.concatenate([e["_dp"].ravel() for e in sub])
    pc = np.percentile(dp, [0, 0.1, 1, 5, 10, 25, 50])
    P(f"  {g}: filas {len(dp)} · pctl {np.round(pc, 4).tolist()} · <0.10 {np.mean(dp < 0.10):.4f} ({int((dp < 0.10).sum())}) · "
      f"<0.15 {np.mean(dp < 0.15):.4f} ({int((dp < 0.15).sum())}) · <0.18 {np.mean(dp < 0.18):.4f} · <0.35 {np.mean(dp < 0.35):.4f}")
# filas < 0.15 del 30-09
F15 = []
for e in V30:
    o = e["_o"]
    kk, aa = np.where(e["_dp"] < 0.15)
    for k, a in zip(kk, aa):
        F15.append((e["ses"], e["ep"], e["semilla"], ROB[a], float(o["pose_env_x"][k, a]), float(o["pose_env_y"][k, a])))
P(f"  filas 30-09 < 0.15: {len(F15)} · episodios {len(set((a, b) for a, b, *_ in F15))} · por robot "
  f"{ {r: sum(f[3] == r for f in F15) for r in ROB} }")
caja = [f for f in F15 if 2.60 < f[4] < 2.85 and f[5] < 0.15]
caja5 = [f for f in caja if f[3] == 5]
P(f"  caja x(2.60,2.85) y<0.15: {len(caja)} filas · robot 5: {len(caja5)} filas en {len(set((a, b) for a, b, *_ in caja5))} "
  f"episodios y {len(set(f[2] for f in caja5))} semillas · (todas las filas de la caja: {len(set((a, b) for a, b, *_ in caja))} "
  f"episodios, {len(set(f[2] for f in caja))} semillas)")
inv = [e for e in EPS if e["valido"] == 0]
inv22 = [(e["ses"], e["ep"], "r%d-r%d" % (ROB[e["sep_i"]], ROB[e["sep_j"]]), round(e["sep_min"], 4))
         for e in inv if e["sep_min"] < 0.22]
P(f"  inválidos: n={len(inv)} ({sum(e['ses'] in S30 for e in inv)} del 30-09) · con par <0.22: {inv22}"
  f" · con par <0.15: {sum(e['sep_min'] < 0.15 for e in inv)}")
mi = min(inv, key=lambda e: e["dpmin"])
mi30 = min([e for e in inv if e["ses"] in S30], key=lambda e: e["dpmin"])
P(f"  mínimo de pared en inválidos: {mi['ses']} ep{mi['ep']} {mi['dpmin']:.4f} · sólo 30-09: {mi30['ses']} ep{mi30['ep']} {mi30['dpmin']:.4f}")

# ─────────────────────────────── A23 ───────────────────────────────
P("\n=== A23: IC95 de la cobertura media ===")
m = y30.mean()
se_a = y30.std(ddof=1) / math.sqrt(50)
P(f"  (a) {m:.4f} ± {se_a:.4f} [{m - stats.t.ppf(0.975, 49)*se_a:.4f}, {m + stats.t.ppf(0.975, 49)*se_a:.4f}] semiancho {stats.t.ppf(0.975, 49)*se_a:.4f}")
u = y30 - m
gsum = np.array([u[np.array(sem30) == s].sum() for s in useeds])
G = len(gsum)
se_b = math.sqrt(G / (G - 1) * (gsum ** 2).sum()) / 50
qb = stats.t.ppf(0.975, G - 1)
P(f"  (b) CR1 ± {se_b:.4f} [{m - qb*se_b:.4f}, {m + qb*se_b:.4f}] semiancho {qb*se_b:.4f} · Deff {(se_b/se_a)**2:.3f} · "
  f"cociente semianchos {(qb*se_b)/(stats.t.ppf(0.975, 49)*se_a):.3f}")
mg = R0["mg"]
se_c = mg.std(ddof=1) / math.sqrt(len(mg))
P(f"  (c) {mg.mean():.4f} ± {se_c:.4f} [{mg.mean() - qb*se_c:.4f}, {mg.mean() + qb*se_c:.4f}]")
rngc = np.random.default_rng(99)
bm = np.array([np.concatenate([grp[s] for s in rngc.choice(useeds, size=G, replace=True)]).mean() for _ in range(20000)])
P(f"  (d) bootstrap por semilla (20000, semilla propia) [{np.percentile(bm, 2.5):.4f}, {np.percentile(bm, 97.5):.4f}]")
w_ = 1 / (R0["sdb"] ** 2 + R0["msw"] / R0["n"])
mre = (w_ * mg).sum() / w_.sum()
se_e = math.sqrt(1 / w_.sum())
P(f"  (e) {mre:.4f} ± {se_e:.4f} [{mre - qb*se_e:.4f}, {mre + qb*se_e:.4f}]")
mbar = (R0["n"] ** 2).sum() / R0["n"].sum()
deff_k = 1 + (mbar - 1) * R0["icc"]
P(f"  Kish m̄_w {mbar:.3f} · Deff {deff_k:.3f} · n_eff {50/deff_k:.2f}")

# ─────────────────────────────── A24 ───────────────────────────────
P("\n=== A24: operación ===")
for g, sub in GR:
    P(f"  {g}: pf {int(col(sub, 'pf').sum())} · prech {int(col(sub, 'prech').sum())} · filas repetidas {int(col(sub, 'n_rep').sum())} · "
      f"dec retroceso (CSV) {int(col(sub, 'ret_csv').sum())} · filas en_retroceso (decisiones) {int(col(sub, 'n_ret').sum())} · "
      f"filas repetida Y en_retroceso {int(col(sub, 'rep_y_ret').sum())} · ciclos>100 {int(col(sub, 's100').sum())} · "
      f"eps fuera {sum(bool(e['fuera']) for e in sub)} · dur {col(sub, 'dur').mean():.3f} ± {col(sub, 'dur').std(ddof=1):.3f}")
P("  por episodio (n_rep, ret_csv, n_ret) donde alguno > 0:",
  [(e["ses"], e["ep"], e["n_rep"], e["ret_csv"], e["n_ret"]) for e in V if e["n_rep"] or e["ret_csv"] or e["n_ret"]])

# ─────────────────────────────── A11 ───────────────────────────────
P("\n=== A11: proxy recorrido medido / comandado (réplica independiente del método declarado) ===")


def proxy(sub, alinear="misma_fila"):
    num = np.zeros(5)
    den = np.zeros(5)
    for e in sub:
        o = e["_o"]
        x, yv, v = o["pose_env_x"], o["pose_env_y"], o["v_ejecutada"]
        rep, ret, esc, pasos = o["rep"], o["en_retroceso"], o["en_escape"], o["pasos"]
        rec = np.hypot(np.diff(x, axis=0), np.diff(yv, axis=0))           # rec[t-1] = |p_t - p_{t-1}|
        for a in range(5):
            if alinear == "misma_fila":          # fila t: |p_t − p_{t−1}| con v_t (como el código y el analista)
                t = np.arange(1, o["n"])
                ok = (pasos[t] >= 50) & (ret[t, a] == 0) & (esc[t, a] == 0) & ~rep[t, a] & ~rep[t - 1, a]
                num[a] += rec[t[ok] - 1, a].sum()
                den[a] += (np.abs(v[t[ok], a]) * 0.40 * 0.1).sum()
            else:                                # fila t: |p_{t+1} − p_t| con v_t
                t = np.arange(0, o["n"] - 1)
                ok = (pasos[t] >= 50) & (ret[t, a] == 0) & (esc[t, a] == 0) & ~rep[t, a] & ~rep[t + 1, a]
                num[a] += rec[t[ok], a].sum()
                den[a] += (np.abs(v[t[ok], a]) * 0.40 * 0.1).sum()
    return num, den


for alin in ("misma_fila", "siguiente"):
    P(f"  alineación: {alin}")
    tab = {}
    for g in ["C26"] + S30:
        sub = [e for e in V if e["ses"] == g]
        num, den = proxy(sub, alin)
        tab[g] = num / den
        P(f"     {g}: todos {num.sum()/den.sum():.4f} · por robot " + " ".join(f"r{ROB[a]} {num[a]/den[a]:.4f}" for a in range(5)))
    for a in range(5):
        l_ = stats.linregress(np.arange(1, 6), [tab[s][a] for s in S30])
        P(f"     tendencia r{ROB[a]}: {l_.slope:+.4f}/sesión p {l_.pvalue:.3f}")

P("\nFIN")
OUT.close()
print("listo")
