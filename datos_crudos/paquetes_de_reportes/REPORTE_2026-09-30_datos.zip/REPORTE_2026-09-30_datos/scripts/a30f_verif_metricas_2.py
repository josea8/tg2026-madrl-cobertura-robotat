import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Verificador a30f_verif_metricas_ (parte 2): comprobaciones complementarias
para las omisiones y matices (desde cero; SOLO LECTURA; sin réplica).
 - motivo de los inválidos con discrepancia de recorrido (A02)
 - desfase fila a fila entre pose repetida y en_retroceso (A24)
 - robot 5 en la caja de la pared y=0: episodios y semillas (A21)
 - d_pared en las rachas de pose congelada (seguridad durante el congelamiento)
 - cobertura sin los 5 episodios con robots fuera del blanco (IC ingenuo y CR1)
 - p95 de S3/S5 contra la tendencia (FE semilla + orden + indicador)
 - fecha máxima de mtime de los archivos del coordinador no cubiertos por el analista (A25)
Salida: a30f_verif_metricas_2_salida.txt"""
import sys
sys.dont_write_bytecode = True
import os
import csv
import math
import datetime
import numpy as np
from scipy import stats

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
C = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
SP = (r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis"
      r"\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
OUT = open(os.path.join(SP, "a30f_verif_metricas_2_salida.txt"), "w", encoding="utf-8", newline="\n")


def P(*a):
    print(*a, file=OUT)


S30 = ["S1", "S2", "S3", "S4", "S5"]
ARCH = {"C26": ("20260926_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_decisiones.csv"),
        "S1": ("20260930_sesion-evaluacion_etapa7_episodios.csv", "20260930_sesion-evaluacion_etapa7_decisiones.csv")}
for k in range(2, 6):
    ARCH[f"S{k}"] = (f"20260930_sesion-evaluacion_etapa7_episodios_0{k}.csv",
                     f"20260930_sesion-evaluacion_etapa7_decisiones_0{k}.csv")
ROB = [1, 5, 8, 6, 9]


def leer_ep(fn):
    with open(os.path.join(RS, fn), encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def leer_dec(fn):
    with open(os.path.join(RS, fn), encoding="utf-8-sig", newline="") as fh:
        rd = csv.reader(fh)
        cab = next(rd)
        filas = list(rd)
    idx = {c: i for i, c in enumerate(cab)}
    out = {}
    for f in filas:
        ep, ag, pa = int(float(f[idx["episodio"]])), int(float(f[idx["agente"]])), int(float(f[idx["paso"]]))
        out.setdefault((ep, ag), []).append((pa, f[idx["pose_env_x"]], f[idx["pose_env_y"]], f[idx["pose_env_th"]],
                                              int(float(f[idx["en_retroceso"]])), int(float(f[idx["en_escape"]]))))
    for k in out:
        out[k].sort()
    return out


EP, DEC = {}, {}
for s in ["C26"] + S30:
    EP[s] = leer_ep(ARCH[s][0])
    DEC[s] = leer_dec(ARCH[s][1])

# ── A02: motivos de los inválidos con discrepancia de recorrido ──
P("=== A02: inválidos — motivo y |recorrido recalculado − CSV| ===")
for s in ["C26"] + S30:
    for r in EP[s]:
        if r["valido"] == "1":
            continue
        ep = int(r["episodio"])
        recs = []
        for ag in range(5):
            q = DEC[s][(ep, ag)]
            x = np.array([float(t[1]) for t in q])
            y = np.array([float(t[2]) for t in q])
            recs.append(np.hypot(np.diff(x), np.diff(y)).sum())
        dif = max(abs(min(recs) - float(r["dist_min_robot"])), abs(max(recs) - float(r["dist_max_robot"])))
        P(f"  {s} ep{ep}: dif {dif:.4f} m · decisiones {r['decisiones']} · motivo: {r['motivo'][:95]}")

# ── A24: repetida vs en_retroceso fila a fila ──
P("\n=== A24: rachas de pose repetida y filas en_retroceso (válidos 30-09 y 26-09) ===")
rachas = []
for s in ["C26"] + S30:
    val = {int(r["episodio"]): r for r in EP[s] if r["valido"] == "1"}
    for (ep, ag), q in DEC[s].items():
        if ep not in val:
            continue
        clave = [t[1] + "|" + t[2] + "|" + t[3] for t in q]
        rep = [False] + [clave[i] == clave[i - 1] for i in range(1, len(q))]
        ret = [t[4] for t in q]
        i = 0
        while i < len(q):
            if rep[i]:
                j = i
                while j + 1 < len(q) and rep[j + 1]:
                    j += 1
                rr = [k for k in range(max(0, i - 2), min(len(q), j + 4)) if ret[k]]
                x, y = float(q[i][1]), float(q[i][2])
                dp = min(x, 3 - x, y, 3 - y)
                rachas.append(dict(ses=s, ep=ep, robot=ROB[ag], ini=i, fin=j, largo=j - i + 1,
                                   ret_ini=rr[0] if rr else None, ret_fin=rr[-1] if rr else None,
                                   n_ret=len(rr), dp=dp, x=x, y=y, esc_prev=q[i - 1][5] if i > 0 else None))
                i = j + 1
            else:
                i += 1
for r in rachas:
    P(f"  {r['ses']} ep{r['ep']} r{r['robot']}: repetida pasos {r['ini']}–{r['fin']} (largo {r['largo']}) · en_retroceso "
      f"{r['ret_ini']}–{r['ret_fin']} ({r['n_ret']}) · desfase inicio {None if r['ret_ini'] is None else r['ret_ini'] - r['ini']}"
      f" · d_pared de la pose congelada {r['dp']:.3f} m en ({r['x']:.3f}, {r['y']:.3f})")
r30 = [r for r in rachas if r["ses"] in S30]
P(f"  30-09: rachas {len(r30)} · con d_pared de la pose congelada < 0.25 m: {sum(r['dp'] < 0.25 for r in r30)} · "
  f"mín {min(r['dp'] for r in r30):.3f} m · largo máx {max(r['largo'] for r in r30)} decisiones")

# ── A21: robot 5 en la caja ──
P("\n=== A21: filas < 0.15 del robot 5 en la caja x∈(2.60, 2.85), y<0.15 (válidos 30-09) ===")
eps5, sem5, eps_all, sem_all = set(), set(), set(), set()
n5 = nall = 0
for s in S30:
    val = {int(r["episodio"]): int(r["semilla"]) for r in EP[s] if r["valido"] == "1"}
    for (ep, ag), q in DEC[s].items():
        if ep not in val:
            continue
        for t in q:
            x, y = float(t[1]), float(t[2])
            if min(x, 3 - x, y, 3 - y) < 0.15 and 2.60 < x < 2.85 and y < 0.15:
                nall += 1
                eps_all.add((s, ep))
                sem_all.add(val[ep])
                if ROB[ag] == 5:
                    n5 += 1
                    eps5.add((s, ep))
                    sem5.add(val[ep])
P(f"  todas: {nall} filas · {len(eps_all)} episodios · {len(sem_all)} semillas {sorted(x - 420000 for x in sem_all)}")
P(f"  robot 5: {n5} filas · {len(eps5)} episodios · {len(sem5)} semillas {sorted(x - 420000 for x in sem5)}")

# ── cobertura sin los 5 episodios con robots fuera del blanco ──
P("\n=== Cobertura 30-09 con y sin los episodios con robots fuera del blanco ===")
y, g, f = [], [], []
for s in S30:
    for r in EP[s]:
        if r["valido"] != "1":
            continue
        y.append(float(r["cobertura_aoi"]))
        g.append(int(r["semilla"]))
        f.append(any(r[f"col_estado_a{i}"] != "listo" for i in range(5)))
y, g, f = np.array(y), np.array(g), np.array(f)


def ic(yv, gv):
    m = yv.mean()
    se = yv.std(ddof=1) / math.sqrt(len(yv))
    u = yv - m
    gs = np.array([u[gv == k].sum() for k in np.unique(gv)])
    G = len(gs)
    se_c = math.sqrt(G / (G - 1) * (gs ** 2).sum()) / len(yv)
    qa, qc = stats.t.ppf(0.975, len(yv) - 1), stats.t.ppf(0.975, G - 1)
    return m, (m - qa * se, m + qa * se), (m - qc * se_c, m + qc * se_c)


for nom, msk in (("todos (50)", np.ones(len(y), bool)), ("sin fuera (45)", ~f)):
    m, a, b = ic(y[msk], g[msk])
    P(f"  {nom}: media {m:.4f} · IC95 ingenuo [{a[0]:.4f}, {a[1]:.4f}] · CR1 semilla [{b[0]:.4f}, {b[1]:.4f}]")


# ── p95 de S3/S5 contra la tendencia ──
def fe_multi(yv, gv, X):
    """OLS con efectos fijos de gv (demeaning) y regresores X (n×k)."""
    yt = yv.astype(float).copy()
    Xt = X.astype(float).copy()
    for k in np.unique(gv):
        s_ = gv == k
        yt[s_] -= yv[s_].mean()
        Xt[s_] -= X[s_].mean(axis=0)
    b = np.linalg.lstsq(Xt, yt, rcond=None)[0]
    r = yt - Xt @ b
    df = len(yv) - len(np.unique(gv)) - X.shape[1]
    cov = (r @ r) / df * np.linalg.inv(Xt.T @ Xt)
    se = np.sqrt(np.diag(cov))
    q = stats.t.ppf(0.975, df)
    return b, b - q * se, b + q * se, 2 * stats.t.sf(np.abs(b / se), df)


P("\n=== p95: indicador de sesión contra la tendencia lineal (FE semilla + orden + indicador) ===")
p95, orden, ses = [], [], []
for s in S30:
    for r in EP[s]:
        if r["valido"] == "1":
            p95.append(float(r["ciclo_p95_ms"]))
            orden.append(int(s[1]))
            ses.append(s)
p95, orden, ses = np.array(p95), np.array(orden, float), np.array(ses)
for s in ("S3", "S5"):
    X = np.column_stack([orden, (ses == s).astype(float)])
    b, lo, hi, p = fe_multi(p95, g, X)
    P(f"  {s}: pendiente {b[0]:+.2f} ms/sesión · indicador {s} {b[1]:+.2f} ms [{lo[1]:+.2f}, {hi[1]:+.2f}] p {p[1]:.3f}")
    Xc = np.column_stack([orden, (ses == s).astype(float)])
    yc = np.array([float(r["cobertura_aoi"]) for s_ in S30 for r in EP[s_] if r["valido"] == "1"])
    b, lo, hi, p = fe_multi(yc, g, Xc)
    P(f"      cobertura: indicador {s} {b[1]:+.4f} [{lo[1]:+.4f}, {hi[1]:+.4f}] p {p[1]:.3f} (con tendencia)")

# ── A25: fechas de los archivos no cubiertos por la instantánea del analista ──
P("\n=== A25: mtime máximo por subcarpeta del coordinador ===")
for raiz, dirs, archivos in os.walk(C):
    if not archivos:
        continue
    mt = max(os.stat(os.path.join(raiz, a)).st_mtime for a in archivos)
    P(f"  {os.path.relpath(raiz, C)}: {len(archivos)} archivos · mtime máx {datetime.datetime.fromtimestamp(mt):%Y-%m-%d %H:%M:%S}")
P("\nFIN")
OUT.close()
print("listo")
