import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# a30f_deriva_detalle.py — SOLO LECTURA. Detalle a nivel robot desde a30f_deriva_por_robot.csv (salida de a30f_deriva_principal.py):
# rangos por sesión (válidos, sin robots congelados), casos fuera de la arena / <5 cm de pared en la 2.ª impresión,
# y el efecto del bug de regex del script de referencia (coordenadas negativas) en el bloque 16 del 26-09.
import csv, os
import numpy as np
S = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
F = lambda x: None if x in ("", "None") else float(x)
rows = list(csv.DictReader(open(os.path.join(S, "a30f_deriva_por_robot.csv"), encoding="utf-8")))
out = []
def P(*a):
    s = " ".join(str(x) for x in a); out.append(s); print(s)
P("Rango robot-nivel (válidos, sin congelados al final):")
for ses in ["26-09", "s1", "s2", "s3", "s5"]:
    rs = [r for r in rows if r["sesion"] == ses and r["tipo"] == "V" and r["congelado_fin"] == "0"]
    d1 = [F(r["d1_cm"]) for r in rs if F(r["d1_cm"]) is not None]; d2 = [F(r["d2_cm"]) for r in rs if F(r["d2_cm"]) is not None]
    P(f"  {ses:6s} n_d1={len(d1)} d1 [{min(d1):.2f}, {max(d1):.2f}]  n_d2={len(d2)} d2 [{min(d2):.2f}, {max(d2):.2f}]  "
      f"P10/P90 d2 [{np.percentile(d2,10):.2f}, {np.percentile(d2,90):.2f}]")
P("\nRobots con d_pared < 0.05 m en la 2.ª impresión (todas las sesiones):")
for r in rows:
    p2 = F(r["dpared_imp2"])
    if p2 is not None and p2 < 0.05:
        P(f"  {r['sesion']:6s} k={r['k']:>2s} {r['tipo']} robot {r['robot']}  d_pared última pose {F(r['dpared_ult']):.3f} → imp1 {F(r['dpared_imp1']):.2f} → imp2 {p2:.2f}  "
          f"(imp2 = ({r['x_imp2']}, {r['y_imp2']}))  d2 {F(r['d2_cm']):.1f} cm")
P("\nEfecto del regex [\\d.]+ del script de referencia en 26-09 k=15 (bloque 16): robots con coordenada negativa")
rs = [r for r in rows if r["sesion"] == "26-09" and r["k"] == "15"]
todos = [F(r["d2_cm"]) for r in rs]; sin_neg = [F(r["d2_cm"]) for r in rs if F(r["x_imp2"]) >= 0 and F(r["y_imp2"]) >= 0]
P(f"  con los 5 robots: d2 mediana {np.median(todos):.2f} máx {max(todos):.2f}  d_pared mín imp2 {min(F(r['dpared_imp2']) for r in rs):.2f}")
P(f"  sin los negativos (n={len(sin_neg)}): d2 mediana {np.median(sin_neg):.2f} máx {max(sin_neg):.2f}  "
  f"d_pared mín imp2 {min(F(r['dpared_imp2']) for r in rs if F(r['x_imp2']) >= 0 and F(r['y_imp2']) >= 0):.2f}")
for t in ("V", "A"):
    rr = [r for r in rows if r["sesion"] == "s5" and r["tipo"] == t and F(r["d12_cm"]) is not None]
    P(f"s5 tipo {t}: pares de impresiones {len(rr)}; con |p2-p1| > 0: {sum(1 for r in rr if F(r['d12_cm']) > 0)}")
P("s5: n impresiones por bloque k+1:", [(r["k"], r["n_impresiones"]) for r in rows if r["sesion"] == "s5" and r["agente"] == "0"])
open(os.path.join(S, "a30f_deriva_detalle_salida.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
