import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
# -*- coding: utf-8 -*-
"""
a30f_verif_congel_1.py — VERIFICACIÓN ADVERSARIAL, escrita desde cero, de las afirmaciones
F1–F25 del analista sobre congelamientos y retrocesos (30-09, 5 sesiones; control 26-09).
No importa ni ejecuta nada de a30f_congel_*.py. SÓLO LECTURA de la carpeta de la tesis;
no abre ningún archivo de réplica (sólo los nombres de evaluación listados abajo).
Salida: stdout (se redirige a a30f_verif_congel_1_salida.txt).

Diferencias de método deliberadas respecto del analista (para detectar errores):
* Repetición detectada de DOS formas: igualdad de floats y igualdad del TEXTO del CSV.
* El paso de cada [sync] se obtiene del tick con una base por episodio calculada de forma
  INDEPENDIENTE del '↩' (base = 15 + Σ_{k<ep}(10·decisiones_k + 5)); se valida contra '↩'.
* Pasadas, grupos, hipos y neto retrocedido reimplementados sin copiar código.
"""
import csv, math, os, re, sys
from collections import defaultdict, Counter
import numpy as np
from scipy import stats

sys.stdout.reconfigure(encoding='utf-8')
RES = r'C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion'
SP = r'C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad'
DIAS = [('26-09', '20260926', '', 'consola_20260926.txt'),
        ('s1', '20260930', '', 'consola_20260930.txt'),
        ('s2', '20260930', '_02', 'consola_20260930_02.txt'),
        ('s3', '20260930', '_03', 'consola_20260930_03.txt'),
        ('s4', '20260930', '_04', None),
        ('s5', '20260930', '_05', 'consola_20260930_05.txt')]
ORD = [d[0] for d in DIAS]
S30 = ['s1', 's2', 's3', 's4', 's5']
VAL_DADOS = {'s1': set(range(3, 13)), 's2': {1} | set(range(4, 13)), 's3': {1, 2} | set(range(4, 12)),
             's4': set(range(1, 7)) | set(range(8, 12)), 's5': set(range(1, 6)) | set(range(7, 12))}
MAPEO = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
ESC, ROT, TX, TY = 1.0166876, 0.0084726, 1.5061547, 1.2563353
PC = {'A': (2.54, 2.20), 'B': (2.82, 2.49), 'C': (2.52, 2.79)}
NAN = float('nan')


def a_lab(x, y):
    dx, dy = x - TX, y - TY
    c, s = math.cos(ROT), math.sin(ROT)
    return (c * dx + s * dy) / ESC, (-s * dx + c * dy) / ESC


def a_env(xl, yl):
    c, s = math.cos(ROT), math.sin(ROT)
    return ESC * (c * xl - s * yl) + TX, ESC * (s * xl + c * yl) + TY


def dpared(x, y):
    return min(x, 3.0 - x, y, 3.0 - y)


def fisher(a, n1, b, n2):
    return stats.fisher_exact([[a, n1 - a], [b, n2 - b]])[1]


# ------------------------------------------------------------------ carga
DEC, EPI, CON = {}, {}, {}
for dia, fecha, suf, cons in DIAS:
    g = defaultdict(list)
    with open(os.path.join(RES, f'{fecha}_sesion-evaluacion_etapa7_decisiones{suf}.csv'), encoding='utf-8-sig', newline='') as fh:
        for r in csv.DictReader(fh):
            g[(int(r['episodio']), int(r['agente']))].append(r)
    seqs = {}
    for k, rows in g.items():
        rows.sort(key=lambda r: int(r['paso']))
        L = []
        for r in rows:
            L.append(dict(paso=int(r['paso']), sx=r['pose_env_x'], sy=r['pose_env_y'], sth=r['pose_env_th'],
                          x=float(r['pose_env_x']), y=float(r['pose_env_y']), th=float(r['pose_env_th']),
                          retro=int(r['en_retroceso']), v=float(r['v_ejecutada']), w=float(r['w_ejecutada']),
                          esc=int(r['en_escape']), cbf=int(r['cbf_intervino']), robot=int(r['robot']), vec=int(r['con_vecino'])))
        for q in range(len(L)):
            if q == 0:
                L[q]['rep'] = L[q]['rep_s'] = False; L[q]['gap'] = None
                continue
            a, b = L[q - 1], L[q]
            b['rep'] = (a['x'], a['y'], a['th']) == (b['x'], b['y'], b['th'])
            b['rep_s'] = (a['sx'], a['sy'], a['sth']) == (b['sx'], b['sy'], b['sth'])
            b['gap'] = b['paso'] - a['paso']
        seqs[k] = L
    DEC[dia] = seqs
    with open(os.path.join(RES, f'{fecha}_sesion-evaluacion_etapa7_episodios{suf}.csv'), encoding='utf-8-sig', newline='') as fh:
        EPI[dia] = {int(r['episodio']): r for r in csv.DictReader(fh)}

RX_HDR = re.compile(r'^EPISODIO (\d+)\s')
RX_SYNC = re.compile(r'\[sync\] Decisi\S+ con pose vieja: antig\S+=(\d+) ticks .*en tick (\d+)')
RX_RET = re.compile(r'↩ agente (\d+) \(robot (\d+)\): pose repetida en \(([-\d.]+), ([-\d.]+)\), a ([\d.]+) m de la pared.*\(decisi\S+ (\d+)\)')
RX_VIV = re.compile(r'▶ agente (\d+) \(robot (\d+)\): pose viva otra vez tras ([\d.]+) s')
RX_VEN = re.compile(r'frenando por pose vencida: \[([^\]]*)\]')
RX_CIE = re.compile(r'>>> EPISODIO (\d+): (\S+)')
for dia, fecha, suf, cons in DIAS:
    if cons is None:
        CON[dia] = None; continue
    lin = open(os.path.join(SP, cons), encoding='utf-8', errors='replace').read().splitlines()
    ep = None
    c = dict(sync=[], ret=[], viv=[], ven=[], cie={}, lin=lin)
    for n, l in enumerate(lin, 1):
        m = RX_HDR.match(l)
        if m:
            ep = int(m.group(1)); continue
        m = RX_SYNC.search(l)
        if m:
            c['sync'].append(dict(ep=ep, antig=int(m.group(1)), tick=int(m.group(2)), n=n)); continue
        m = RX_RET.search(l)
        if m:
            c['ret'].append(dict(ep=ep, ag=int(m.group(1)), robot=int(m.group(2)), x=float(m.group(3)), y=float(m.group(4)),
                                 d=float(m.group(5)), paso=int(m.group(6)), n=n)); continue
        m = RX_VIV.search(l)
        if m:
            c['viv'].append(dict(ep=ep, ag=int(m.group(1)), tras=float(m.group(3)), n=n)); continue
        m = RX_VEN.search(l)
        if m:
            c['ven'].append(dict(ep=ep, ags=[int(t) for t in m.group(1).split(',') if t.strip()], n=n)); continue
        m = RX_CIE.search(l)
        if m:
            c['cie'][int(m.group(1))] = (m.group(2), n)
    CON[dia] = c

print('=' * 110)
print('0) CARGA, VÁLIDOS, CONTINUIDAD DE PASOS, IGUALDAD FLOAT vs TEXTO, CONSULTAS')
for dia in ORD:
    E = EPI[dia]
    val = sorted(ep for ep, e in E.items() if e['valido'] == '1')
    chk = '' if dia not in VAL_DADOS else ('= lista dada' if set(val) == VAL_DADOS[dia] else f'DISTINTO de {sorted(VAL_DADOS[dia])}')
    gaps = sum(1 for L in DEC[dia].values() for r in L[1:] if r['gap'] != 1)
    dis = sum(1 for L in DEC[dia].values() for r in L if r['rep'] != r['rep_s'])
    mape = {(ag, L[0]['robot']) for (ep, ag), L in DEC[dia].items()}
    mape_ok = all(MAPEO[a] == r for a, r in mape)
    # decisiones del CSV de episodios vs pasos en el CSV de decisiones; consultas
    dd = []
    for ep, e in E.items():
        pas = {r['paso'] for (e2, ag), L in DEC[dia].items() if e2 == ep for r in L}
        nag = sum(1 for (e2, ag) in DEC[dia] if e2 == ep)
        dd.append((ep, int(e['decisiones']), len(pas), max(pas) + 1, nag, int(e['poses_consultas']) - int(e['decisiones']),
                   int(e['poses_bytes_descartados'] or 0), int(e['poses_consultas_con_descarte'] or 0)))
    mal = [x for x in dd if not (x[1] == x[2] == x[3]) or x[4] != 5]
    cons_dif = Counter(x[5] for x in dd)
    desc = [(x[0], x[6], x[7]) for x in dd if x[6] or x[7]]
    print(f'  {dia:6s} eps {len(E)} válidos {val} {chk}; mapeo ok {mape_ok}; saltos de paso {gaps}; rep float≠texto {dis};'
          f' eps con decisiones≠pasos o ≠5 agentes: {mal or "ninguno"}; consultas−decisiones {dict(cons_dif)}; bytes descartados (ep, B, consultas): {desc or "ninguno"}')

# ------------------------------------------------------------------ eventos
EV = []
for dia in ORD:
    for (ep, ag), L in sorted(DEC[dia].items()):
        for i, r in enumerate(L):
            if r['rep'] and not L[i - 1]['rep']:
                j = i
                while j < len(L) and L[j]['rep']:
                    j += 1
                e = EPI[dia][ep]
                xl, yl = a_lab(r['x'], r['y'])
                EV.append(dict(dia=dia, ep=ep, ag=ag, robot=r['robot'], paso=r['paso'], i=i, j=j, racha=j - i, reap=j < len(L),
                               x=r['x'], y=r['y'], th=r['th'], xl=xl, yl=yl, d=dpared(r['x'], r['y']), valido=int(e['valido']),
                               dt=float(e['duracion_s']) / int(e['decisiones']), L=L,
                               nret=sum(L[k]['retro'] for k in range(i, min(j + 1, len(L))))))
nini = Counter((v['dia'], v['ep'], v['paso']) for v in EV)
for v in EV:
    v['nini'] = nini[(v['dia'], v['ep'], v['paso'])]
    v['nag'] = sum(1 for (e2, ag) in DEC[v['dia']] if e2 == v['ep'])

print('=' * 110)
print('1) F1 — filas, vivas, repetidas, inicios (30-09 y 26-09), válidos/abortados')
TT = {}
for dia in ORD:
    for grp, cond in (('V', '1'), ('A', '0')):
        F = [r for (ep, ag), L in DEC[dia].items() if EPI[dia][ep]['valido'] == cond for r in L]
        rep = sum(r['rep'] for r in F)
        ni = sum(1 for v in EV if v['dia'] == dia and str(v['valido']) == cond)
        TT[(dia, grp)] = (len(F), len(F) - rep, rep, ni)
        print(f'  {dia:6s} {grp} filas {len(F):6d} vivas {len(F)-rep:6d} repetidas {rep:4d} inicios {ni:3d}')
for grp in ('V', 'A', 'T'):
    f = sum(TT[(d, g)][0] for d in S30 for g in (('V', 'A') if grp == 'T' else (grp,)))
    vv = sum(TT[(d, g)][1] for d in S30 for g in (('V', 'A') if grp == 'T' else (grp,)))
    ni = sum(TT[(d, g)][3] for d in S30 for g in (('V', 'A') if grp == 'T' else (grp,)))
    print(f'  30-09 {grp}: filas {f} vivas {vv} inicios {ni} → {1000*ni/f:.3f} ‰ de filas ({1000*ni/vv:.3f} ‰ de vivas)')
f26 = sum(TT[('26-09', g)][0] for g in 'VA'); v26 = sum(TT[('26-09', g)][1] for g in 'VA'); i26 = sum(TT[('26-09', g)][3] for g in 'VA')
print(f'  26-09 T: filas {f26} vivas {v26} inicios {i26}')

# ------------------------------------------------------------------ consola: base de ticks independiente
print('=' * 110)
print('2) CONSOLA — paso de cada [sync] con base de ticks independiente del ↩: base(ep) = 15 + Σ_{k<ep}(10·dec_k + 5)')


def base_tick(dia, ep):
    return 15 + sum(10 * int(EPI[dia][k]['decisiones']) + 5 for k in EPI[dia] if k < ep)


for dia in ORD:
    c = CON[dia]
    if c is None:
        print(f'  {dia}: SIN CONSOLA'); continue
    for s in c['sync']:
        b = base_tick(dia, s['ep'])
        s['paso'] = (s['tick'] - b) / 10
        # ↩ en las 3 líneas siguientes (mismo episodio)
        ret_sig = [q for q in c['ret'] if q['ep'] == s['ep'] and 0 < q['n'] - s['n'] <= 3]
        rep_ags = sorted(ag for (e2, ag), L in DEC[dia].items() if e2 == s['ep'] for r in L if r['paso'] == s['paso'] and r['rep'])
        print(f"  {dia:6s} ep{s['ep']:2d} línea {s['n']} tick {s['tick']} antig {s['antig']} → paso {s['paso']:.1f}"
              f" | ↩ siguiente: {[(q['ag'], q['paso']) for q in ret_sig] or '—'} | agentes con fila repetida en ese paso: {rep_ags}")
    print(f"  {dia:6s} total [sync] {len(c['sync'])}, ↩ {len(c['ret'])}, ▶ {len(c['viv'])}, vencida {[(q['ep'], q['ags']) for q in c['ven']]}")


def sync_en(dia, ep, paso):
    c = CON[dia]
    if c is None:
        return None
    m = [s['antig'] for s in c['sync'] if s['ep'] == ep and s['paso'] == paso]
    return max(m) if m else 0


# ------------------------------------------------------------------ hipo (Δ entre decisiones)
DEL = {}
for dia in ORD:
    t = defaultdict(lambda: defaultdict(dict))
    for (ep, ag), L in DEC[dia].items():
        for q in range(1, len(L)):
            a, b = L[q - 1], L[q]
            if b['gap'] == 1:
                t[ep][b['paso']][ag] = (1000 * math.hypot(b['x'] - a['x'], b['y'] - a['y']), b['rep'])
    DEL[dia] = t


def mmed(dia, ep, p, ex=()):
    d = DEL[dia][ep].get(p, {})
    v = [dm for ag, (dm, rp) in d.items() if not rp and ag not in ex]
    return float(np.median(v)) if v else NAN


def mref(dia, ep, p, ex=()):
    v = [mmed(dia, ep, q, ex) for q in range(p - 10, p + 11) if abs(q - p) > 1]
    v = [x for x in v if not math.isnan(x)]
    return float(np.median(v)) if v else NAN


def firma(dia, ep, p, ex=()):
    rf = mref(dia, ep, p, ex)
    m0, mp = mmed(dia, ep, p, ex), mmed(dia, ep, p - 1, ex)
    return m0, mp, rf, m0 / rf if rf else NAN, mp / rf if rf else NAN


# ------------------------------------------------------------------ clasificación
for v in EV:
    e = EPI[v['dia']][v['ep']]
    v['pf'], v['pr'] = int(e['poses_fallidas'] or 0), int(e['poses_rechazadas'] or 0)
    v['sync'] = sync_en(v['dia'], v['ep'], v['paso'])
    ex = {w['ag'] for w in EV if (w['dia'], w['ep'], w['paso']) == (v['dia'], v['ep'], v['paso'])}
    v['m0'], v['mp'], v['rf'], v['r'], v['rp'] = firma(v['dia'], v['ep'], v['paso'], ex)
    # variante: excluir sólo en el paso, no en la ventana de referencia
    rf2 = mref(v['dia'], v['ep'], v['paso'])
    v['r_v2'] = v['m0'] / rf2 if rf2 else NAN; v['rp_v2'] = v['mp'] / rf2 if rf2 else NAN
    v['hipo'] = v['r'] < 0.30 and v['rp'] > 1.6
    v['tipo'] = 'b' if v['nini'] >= 2 else None
    if v['nini'] >= v['nag'] and v['pf'] > 0:
        v['mec'] = 'caché-fallida'
    elif v['sync'] is not None and v['sync'] >= 10:
        v['mec'] = 'caché-rechazo' if v['pr'] > 0 else ('caché-fallida' if v['pf'] > 0 else 'caché-¿?')
    elif v['sync'] is None and v['pr'] > 0 and v['nini'] == 1:
        v['mec'] = 'caché-rechazo(inferido)'
    elif v['hipo']:
        v['mec'] = 'hipo'
    else:
        v['mec'] = 'Motive'
    if v['tipo'] is None:
        v['tipo'] = 'a' if v['mec'] == 'Motive' else 'c'
LUGAR = ('Motive', 'caché-rechazo', 'caché-rechazo(inferido)')


def neto(v, k=5):
    L, i, j = v['L'], v['i'], v['j']
    viv = [r for r in L[:i] if not r['rep']]
    if len(viv) < 2 or j >= len(L):
        return NAN, NAN
    a, b = viv[max(0, len(viv) - 1 - k)], viv[-1]
    ux, uy = b['x'] - a['x'], b['y'] - a['y']
    n = math.hypot(ux, uy)
    if n < 1e-9:
        return NAN, NAN
    ux, uy = ux / n, uy / n
    P = L[j]
    al = (P['x'] - b['x']) * ux + (P['y'] - b['y']) * uy
    la = -(P['x'] - b['x']) * uy + (P['y'] - b['y']) * ux
    return -100 * al, 100 * la


def det(e):
    return [dict(ag=int(m.group(1)), p0=int(m.group(2)), p1=int(m.group(3)), dur=float(m.group(4)), cm=float(m.group(5)), res=m.group(6))
            for m in re.finditer(r'a(\d+):(\d+)-(\d+)\(([\d.]+)s,([\d.]+)cm,(\w+)\)', e['retrocesos_detalle'] or '')]


for v in EV:
    dd = [q for q in det(EPI[v['dia']][v['ep']]) if q['ag'] == v['ag'] and q['p0'] == v['paso']]
    v['det'] = dd[0] if dd else None
    v['neto'], v['lat'] = neto(v)
    v['neto4'], _ = neto(v, 4)
    v['neto10'], _ = neto(v, 10)

print('=' * 110)
print('3) TABLA DE INICIOS (mi clasificación). mec: caché-fallida | caché-rechazo (consola) | caché-rechazo(inferido) | hipo | Motive')
for v in sorted(EV, key=lambda v: (ORD.index(v['dia']), v['ep'], v['paso'], v['ag'])):
    dd = v['det']
    print(f"  {v['dia']:6s} ep{v['ep']:2d} {'V' if v['valido'] else 'A'} a{v['ag']}/r{v['robot']} paso {v['paso']:3d} racha {v['racha']:2d} (≈{v['racha']*v['dt']:.2f} s)"
          f"{'' if v['reap'] else ' SIN reaparición'} env ({v['x']:.3f}, {v['y']:.3f}) lab ({v['xl']:+.3f}, {v['yl']:+.3f}) d {v['d']:.3f}"
          f" | ini en paso {v['nini']}/{v['nag']} | sync {v['sync']} pf {v['pf']} pr {v['pr']} | r_prev {v['rp']:.2f} r {v['r']:.2f}"
          f" (v2 {v['rp_v2']:.2f}/{v['r_v2']:.2f}) m(p−1) {v['mp']:.1f} m(p) {v['m0']:.1f} ref {v['rf']:.1f} | tipo {v['tipo']} mec {v['mec']}"
          f" | det {dd['p0'] if dd else '—'}-{dd['p1'] if dd else ''} {dd['dur'] if dd else ''}s {dd['cm'] if dd else ''}cm {dd['res'] if dd else ''}"
          f" | en_retroceso {v['nret']} | neto {v['neto']:+.2f} cm (k4 {v['neto4']:+.2f}, k10 {v['neto10']:+.2f}) lateral {v['lat']:+.2f}")

print('=' * 110)
print('4) F2 — recuentos por tipo y mecanismo (30-09) y por sesión')
e30 = [v for v in EV if v['dia'] in S30]
print('  30-09 tipos', dict(Counter(v['tipo'] for v in e30)), ' mecanismos', dict(Counter(v['mec'] for v in e30)))
print('  30-09 mecanismo × validez', dict(Counter((v['mec'], v['valido']) for v in e30)))
for dia in ORD:
    ev = [v for v in EV if v['dia'] == dia]
    print(f"  {dia:6s} inicios {len(ev)} tipos {dict(sorted(Counter(v['tipo'] for v in ev).items()))} mec {dict(sorted(Counter(v['mec'] for v in ev).items()))}")

print('=' * 110)
print('5) F3 — Motive 26-09 vs 30-09')
for nom, cond in (('válidos', lambda d, ep: EPI[d][ep]['valido'] == '1'), ('todos', lambda d, ep: True)):
    n1 = sum(len(L) for (ep, ag), L in DEC['26-09'].items() if cond('26-09', ep))
    n2 = sum(len(L) for d in S30 for (ep, ag), L in DEC[d].items() if cond(d, ep))
    k1 = sum(1 for v in EV if v['dia'] == '26-09' and v['mec'] == 'Motive' and cond('26-09', v['ep']))
    k2 = sum(1 for v in EV if v['dia'] in S30 and v['mec'] == 'Motive' and cond(v['dia'], v['ep']))
    print(f'  {nom}: 26-09 {k1}/{n1} = {1000*k1/n1:.3f} ‰ ; 30-09 {k2}/{n2} = {1000*k2/n2:.3f} ‰ ; cociente {(k2/n2)/(k1/n1):.3f} ; Fisher p {fisher(k1, n1, k2, n2):.3g}')
r26 = sorted(v['racha'] for v in EV if v['dia'] == '26-09' and v['mec'] == 'Motive')
r30 = sorted(v['racha'] for v in EV if v['dia'] in S30 and v['mec'] == 'Motive')
a1, a2 = sum(x >= 10 for x in r26), sum(x >= 10 for x in r30)
print(f'  rachas Motive 26-09 {r26}; 30-09 {r30}; ≥10: {a1}/{len(r26)} vs {a2}/{len(r30)} Fisher p {fisher(a1, len(r26), a2, len(r30)):.3g}')
# sesgo de selección: ¿cuántos episodios del 26-09 se invalidaron POR un congelamiento?
print('  26-09 episodios abortados y su motivo (¿por congelamiento?):')
for ep, e in sorted(EPI['26-09'].items()):
    if e['valido'] == '0':
        nm = sum(1 for v in EV if v['dia'] == '26-09' and v['ep'] == ep and v['mec'] == 'Motive')
        print(f"     ep{ep:2d} dec {e['decisiones']:>3s} Motive {nm} motivo {e['motivo'][:60]!r}")

print('=' * 110)
print('6) F4 — s1 ep1 y ep2')
for ep in (1, 2):
    e = EPI['s1'][ep]
    ev = [v for v in EV if v['dia'] == 's1' and v['ep'] == ep]
    last = {ag: (L[-1]['paso'], L[-1]['rep']) for (e2, ag), L in DEC['s1'].items() if e2 == ep}
    print(f"  ep{ep}: motivo {e['motivo']!r} dec {e['decisiones']} fallidas {e['poses_fallidas']} rechazadas {e['poses_rechazadas']} consultas {e['poses_consultas']}"
          f" | inicios {[(v['ag'], v['paso'], v['racha'], v['reap']) for v in ev]} | última fila por agente (paso, rep) {last}"
          f" | en_retroceso {sum(r['retro'] for (e2, ag), L in DEC['s1'].items() if e2 == ep for r in L)} | det {[(q['ag'], q['dur'], q['res']) for q in det(e)]}"
          f" | d_pared {min(v['d'] for v in ev):.3f}–{max(v['d'] for v in ev):.3f}")

print('=' * 110)
print('7) F5/F6 — firmas en s5 ep9 157 y s4 ep9 270, y ventanas de Δ')
for dia, ep, p in (('s5', 9, 157), ('s4', 9, 270), ('s2', 10, 76)):
    e = EPI[dia][ep]
    ev = [v for v in EV if v['dia'] == dia and v['ep'] == ep and v['paso'] == p]
    print(f"  {dia} ep{ep} paso {p}: fallidas {e['poses_fallidas']} rechazadas {e['poses_rechazadas']}; inicios {[(v['robot'], v['racha']) for v in ev]};"
          f" r_prev {ev[0]['rp']:.3f} r {ev[0]['r']:.3f} m(p−1) {ev[0]['mp']:.2f} m(p) {ev[0]['m0']:.2f} ref {ev[0]['rf']:.2f};"
          f" [sync] en consola en ese ep: {[s['paso'] for s in CON[dia]['sync'] if s['ep'] == ep] if CON[dia] else 'SIN CONSOLA'}")
    for ag in range(5):
        L = DEC[dia][(ep, ag)]
        print('     a%d/r%d ' % (ag, MAPEO[ag]) + ' '.join(f"{p2}:{DEL[dia][ep][p2][ag][0]:.1f}{'R' if DEL[dia][ep][p2][ag][1] else ''}"
                                                   for p2 in range(p - 3, p + 3) if ag in DEL[dia][ep].get(p2, {})))
    for v in ev:
        print(f"     r{v['robot']}: det {v['det']}; neto {v['neto']:+.2f} cm")

print('=' * 110)
print('8) F7 — tasa base de hipos (decisiones con 5 agentes, paso ≥ 12)')
HIP = []
TB = {}
for dia in ORD:
    for grp, cond in (('V', '1'), ('A', '0')):
        n = nh = hi = nhi = 0
        for ep, pasos in DEL[dia].items():
            if EPI[dia][ep]['valido'] != cond:
                continue
            for p, d in pasos.items():
                if p < 12 or len(d) < 5:
                    continue
                n += 1
                m0, mp, rf, r, rp = firma(dia, ep, p)
                h = (not math.isnan(r)) and r < 0.30 and rp > 1.6
                ini = nini.get((dia, ep, p), 0) > 0
                if h:
                    nh += 1; hi += ini; HIP.append((dia, ep, p, ini, round(rp, 2), round(r, 2), grp))
                else:
                    nhi += ini
        TB[(dia, grp)] = (n, nh, hi, nhi)
        print(f'  {dia:6s} {grp}: decisiones {n} hipos {nh} (con inicio {hi}); no-hipo con inicio {nhi}')
for grp in ('V', 'A'):
    n, nh, hi, nhi = [sum(TB[(d, grp)][k] for d in S30) for k in range(4)]
    print(f'  30-09 {grp}: {nh} hipos en {n}; con inicio {hi}/{nh} vs no-hipo {nhi}/{n-nh}; Fisher p {fisher(hi, nh, nhi, n-nh) if nh else NAN:.3g}')
n, nh, hi, nhi = [sum(TB[('26-09', g)][k] for g in 'VA') for k in range(4)]
print(f'  26-09 todos: {nh} hipos en {n}; no-hipo con inicio {nhi}')
print('  hipos 30-09:', [h for h in HIP if h[0] in S30])
# decisiones con inicio excluidas por paso < 12
print('  inicios de válidos 30-09 con paso < 12:', [(v['dia'], v['ep'], v['paso']) for v in e30 if v['valido'] and v['paso'] < 12])
# por episodio
hep = Counter((h[0], h[1]) for h in HIP)
xs, ys, lst = [], [], []
for d in S30:
    for ep, e in sorted(EPI[d].items()):
        c100 = int(e['ciclos_sobre_100ms']); xs.append(c100); ys.append(hep[(d, ep)])
        if hep[(d, ep)]:
            lst.append((d, ep, e['valido'], hep[(d, ep)], c100))
rho, pr = stats.spearmanr(xs, ys)
print(f'  episodios 30-09 {len(xs)}; con hipo {lst}; Spearman rho {rho:.3f} p {pr:.3g}')
xs2 = [int(EPI[d][ep]['ciclos_sobre_100ms']) for d in S30 for ep in sorted(EPI[d]) if EPI[d][ep]['valido'] == '1']
ys2 = [hep[(d, ep)] for d in S30 for ep in sorted(EPI[d]) if EPI[d][ep]['valido'] == '1']
rho2, pr2 = stats.spearmanr(xs2, ys2)
print(f'  sólo válidos (50 eps): episodios con hipo {sum(1 for y in ys2 if y)}; Spearman rho {rho2:.3f} p {pr2:.3g};'
      f' episodios válidos con ciclos>100ms>0: {sum(1 for x in xs2 if x)}; con hipo y ciclos>0: {sum(1 for x, y in zip(xs2, ys2) if x and y)}')

print('=' * 110)
print('9) F9/F10 — rechazos: distancias, vecino más cercano, pared, CBF/escape')
rech = [v for v in EV if v['mec'].startswith('caché-rechazo')]
for v in rech:
    for pp in (v['paso'] - 1, v['paso']):
        yo = [r for r in DEC[v['dia']][(v['ep'], v['ag'])] if r['paso'] == pp][0]
        ds = []
        for ag2 in range(5):
            if ag2 == v['ag']:
                continue
            q = [r for r in DEC[v['dia']][(v['ep'], ag2)] if r['paso'] == pp]
            if q:
                ds.append((100 * math.hypot(q[0]['x'] - yo['x'], q[0]['y'] - yo['y']), MAPEO[ag2]))
        print(f"  {v['dia']} ep{v['ep']} r{v['robot']} paso {pp}: vecino más cercano {min(ds)[0]:.1f} cm (r{min(ds)[1]}); d_pared {dpared(yo['x'], yo['y']):.3f};"
              f" cbf {yo['cbf']} esc {yo['esc']} v {yo['v']:+.3f}")
s5r8 = [v for v in EV if v['dia'] == 's5' and v['ep'] == 6 and v['robot'] == 8][0]
e4 = [v for v in EV if v['dia'] == '26-09' and v['ep'] == 4][0]
print(f"  s5 ep6 r8 ({s5r8['x']:.4f}, {s5r8['y']:.4f}) a C {100*math.hypot(s5r8['x']-2.52, s5r8['y']-2.79):.2f} cm; a 26-09 ep4 r{e4['robot']} ({e4['x']:.4f}, {e4['y']:.4f}) {100*math.hypot(s5r8['x']-e4['x'], s5r8['y']-e4['y']):.2f} cm;"
      f" 26-09 ep4 pr {e4['pr']} motivo {EPI['26-09'][4]['poses_rechazos_motivo']!r} sync {e4['sync']}")
print(f"  motivos de rechazo por episodio con rechazadas>0: {[(d, ep, e['poses_rechazadas'], e['poses_rechazos_motivo']) for d in ORD for ep, e in EPI[d].items() if int(e['poses_rechazadas'] or 0)]}")
print(f"  rechazadas = Σ rachas de caché-rechazo por episodio: " +
      str([(d, ep, int(EPI[d][ep]['poses_rechazadas']), sum(v['racha'] for v in rech if (v['dia'], v['ep']) == (d, ep))) for d, ep in sorted({(v['dia'], v['ep']) for v in rech})]))

print('=' * 110)
print('10) F12–F15 — grupos (enlace simple 8 cm) y pasadas por disco de 8 cm')
lug = [v for v in EV if v['mec'] in LUGAR]
n = len(lug); par = list(range(n))


def raiz(a):
    while par[a] != a:
        a = par[a]
    return a


for a in range(n):
    for b in range(a + 1, n):
        if math.hypot(lug[a]['x'] - lug[b]['x'], lug[a]['y'] - lug[b]['y']) <= 0.08:
            par[raiz(a)] = raiz(b)
G = defaultdict(list)
for a in range(n):
    G[raiz(a)].append(lug[a])
CENT = {}
for m in sorted(G.values(), key=lambda m: -len(m)):
    cx, cy = np.mean([v['x'] for v in m]), np.mean([v['y'] for v in m])
    diam = max([math.hypot(a['x'] - b['x'], a['y'] - b['y']) for a in m for b in m])
    near = {P: 100 * math.hypot(cx - px, cy - py) for P, (px, py) in PC.items()}
    xl, yl = a_lab(cx, cy)
    print(f"  grupo n={len(m)} centro ({cx:.3f}, {cy:.3f}) lab ({xl:+.3f}, {yl:+.3f}) |lab| {100*math.hypot(xl, yl):.1f} cm diám {100*diam:.1f} cm"
          f" d_pared {min(v['d'] for v in m):.3f}–{max(v['d'] for v in m):.3f} a A/B/C {near['A']:.1f}/{near['B']:.1f}/{near['C']:.1f} cm")
    for v in m:
        print(f"      {v['dia']} ep{v['ep']} r{v['robot']} paso {v['paso']} ({v['x']:.3f}, {v['y']:.3f}) racha {v['racha']} {v['mec']}")
    if len(m) >= 2 and min(near.values()) > 8:
        CENT[f"nuevo_{cx:.2f}_{cy:.2f}"] = (cx, cy)
# aislado s1 ep9 r6 respecto del centro D
KEYL = {(v['dia'], v['ep'], v['ag'], v['paso']) for v in lug}


def pasadas(dia, cx, cy, rad=0.08):
    out = []
    for (ep, ag), L in DEC[dia].items():
        cur = None
        for k, r in enumerate(L):
            if r['rep']:
                continue
            if math.hypot(r['x'] - cx, r['y'] - cy) < rad:
                if cur is None:
                    cur = dict(ep=ep, ag=ag, robot=r['robot'], n=0, cong=0)
                cur['n'] += 1
                if k + 1 < len(L) and L[k + 1]['rep'] and (dia, ep, ag, L[k + 1]['paso']) in KEYL:
                    cur['cong'] += 1
            elif cur is not None:
                out.append(cur); cur = None
        if cur is not None:
            out.append(cur)
    return out


PTS = dict(PC); PTS.update(CENT)
PAS = {}
for P, (cx, cy) in PTS.items():
    lin = []
    for dia in ORD:
        ps = pasadas(dia, cx, cy)
        PAS[(P, dia)] = ps
        lin.append(f"{dia} {len(ps)}({sum(1 for p in ps if p['cong'])})")
    k1 = sum(1 for p in PAS[(P, '26-09')] if p['cong']); n1 = len(PAS[(P, '26-09')])
    k2 = sum(1 for d in S30 for p in PAS[(P, d)] if p['cong']); n2 = sum(len(PAS[(P, d)]) for d in S30)
    rob26 = sorted({p['robot'] for p in PAS[(P, '26-09')]})
    print(f"  {P} ({cx:.3f}, {cy:.3f}) d_pared {dpared(cx, cy):.3f}: " + ' | '.join(lin) + f" | 26-09 {k1}/{n1} vs 30-09 {k2}/{n2} Fisher p {fisher(k1, n1, k2, n2):.3g}; robots 26-09 {rob26}")
    rc = Counter(p['robot'] for d in S30 for p in PAS[(P, d)] if p['cong']); rt = Counter(p['robot'] for d in S30 for p in PAS[(P, d)])
    if rc:
        top = rc.most_common(1)[0][0]
        a_, b_ = rc[top], rt[top]; c_, d_ = sum(rc.values()) - a_, sum(rt.values()) - b_
        print(f"      30-09 por robot: pasadas {dict(sorted(rt.items()))} con cong {dict(sorted(rc.items()))}; r{top} {a_}/{b_} vs otros {c_}/{d_} Fisher p {fisher(a_, b_, c_, d_):.3g}")

print('=' * 110)
print('11) F14 — robot 6 alrededor de D (radio 15 cm), por día; otros robots')
Dc = [c for k, c in CENT.items() if abs(c[0] - 1.47) < 0.1 and abs(c[1] - 1.27) < 0.1]
cx, cy = Dc[0] if Dc else (1.471, 1.269)
print(f'  centro D usado ({cx:.4f}, {cy:.4f})')
for dia in ORD:
    lin = []
    for rob in (1, 5, 8, 6, 9):
        viv = sum(1 for L in DEC[dia].values() for r in L if r['robot'] == rob and not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < 0.15)
        k = sum(1 for v in lug if v['dia'] == dia and v['robot'] == rob and math.hypot(v['x'] - cx, v['y'] - cy) < 0.15)
        lin.append(f'r{rob} {k}/{viv}')
    print(f'  {dia:6s} ' + '  '.join(lin))
k26 = sum(1 for v in lug if v['dia'] == '26-09' and v['robot'] == 6 and math.hypot(v['x'] - cx, v['y'] - cy) < 0.15)
n26 = sum(1 for L in DEC['26-09'].values() for r in L if r['robot'] == 6 and not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < 0.15)
k30 = sum(1 for v in lug if v['dia'] in S30 and v['robot'] == 6 and math.hypot(v['x'] - cx, v['y'] - cy) < 0.15)
n30 = sum(1 for d in S30 for L in DEC[d].values() for r in L if r['robot'] == 6 and not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < 0.15)
ko = sum(1 for v in lug if v['robot'] != 6 and math.hypot(v['x'] - cx, v['y'] - cy) < 0.15)
no = sum(1 for d in ORD for L in DEC[d].values() for r in L if r['robot'] != 6 and not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < 0.15)
print(f'  r6 26-09 {k26}/{n26} vs r6 30-09 {k30}/{n30} Fisher p {fisher(k26, n26, k30, n30):.3g}; otros robots 6 días {ko}/{no}')
for v in [v for v in lug if v['robot'] == 6 and v['dia'] in S30]:
    print(f"     r6 {v['dia']} ep{v['ep']} paso {v['paso']} a D {100*math.hypot(v['x']-cx, v['y']-cy):.2f} cm, lab ({v['xl']:+.3f}, {v['yl']:+.3f})")
print(f"  distancia del centro D al origen del lab: {100*math.hypot(*a_lab(cx, cy)):.2f} cm")

print('=' * 110)
print('12) F16 — pareo por semilla (esquina x>2.3, y>2.5): mismo agente, misma semilla, otro día')
SEM = {d: {int(e['semilla']): ep for ep, e in EPI[d].items()} for d in ORD}
print('  semilla = 420000 + ep − 1 en los 6 días:', all(int(e['semilla']) == 420000 + ep - 1 for d in ORD for ep, e in EPI[d].items()))
n3 = c3 = n8 = c8 = 0
for v in [v for v in lug if v['dia'] in S30 and v['x'] > 2.3 and v['y'] > 2.5]:
    sem = int(EPI[v['dia']][v['ep']]['semilla'])
    for d in ORD:
        if d == v['dia'] or sem not in SEM[d]:
            continue
        ep2 = SEM[d][sem]
        L = DEC[d].get((ep2, v['ag']))
        if not L:
            continue
        dmin = min(math.hypot(r['x'] - v['x'], r['y'] - v['y']) for r in L if not r['rep'])
        cg = any(w['dia'] == d and w['ep'] == ep2 and w['ag'] == v['ag'] and math.hypot(w['x'] - v['x'], w['y'] - v['y']) < 0.08 for w in lug)
        cg_any = any(w['dia'] == d and w['ep'] == ep2 and w['ag'] == v['ag'] and math.hypot(w['x'] - v['x'], w['y'] - v['y']) < 0.08 for w in EV)
        if dmin <= 0.03:
            n3 += 1; c3 += cg or cg_any
            print(f"     par ≤3 cm: {v['dia']} ep{v['ep']} r{v['robot']} paso {v['paso']} ↔ {d} ep{ep2} (V={EPI[d][ep2]['valido']}) dmin {100*dmin:.1f} cm cong {cg or cg_any}")
        if dmin <= 0.08:
            n8 += 1; c8 += cg or cg_any
print(f'  pares ≤3 cm: {n3} (con cong. {c3}); ≤8 cm: {n8} (con cong. {c8})')

print('=' * 110)
print('13) F18/F21/F23 — retrocesos (retrocesos_detalle), filas en_retroceso, columnas')
for dia in ORD:
    for grp, cond in (('V', '1'), ('A', '0')):
        ds = [q for ep, e in EPI[dia].items() if e['valido'] == cond for q in det(e)]
        fr = sum(r['retro'] for (ep, ag), L in DEC[dia].items() if EPI[dia][ep]['valido'] == cond for r in L)
        col = sum(int(e['decisiones_retroceso'] or 0) for e in EPI[dia].values() if e['valido'] == cond)
        rec = sum(int(e['retrocesos_recuperados'] or 0) for e in EPI[dia].values() if e['valido'] == cond)
        print(f"  {dia:6s} {grp}: retrocesos {len(ds)} {dict(Counter(q['res'] for q in ds))} col_recuperados {rec}; filas en_retroceso {fr} col decisiones_retroceso {col}")
fv = sum(r['retro'] for d in S30 for (ep, ag), L in DEC[d].items() if EPI[d][ep]['valido'] == '1' for r in L)
nv = sum(len(L) for d in S30 for (ep, ag), L in DEC[d].items() if EPI[d][ep]['valido'] == '1')
print(f'  30-09 válidos: filas en_retroceso {fv}/{nv} = {100*fv/nv:.4f} %')
# por episodio: columna vs filas
difs = []
for d in ORD:
    for ep, e in EPI[d].items():
        fr = sum(r['retro'] for (e2, ag), L in DEC[d].items() if e2 == ep for r in L)
        if fr != int(e['decisiones_retroceso'] or 0):
            difs.append((d, ep, fr, e['decisiones_retroceso']))
print(f'  episodios con decisiones_retroceso ≠ filas en_retroceso: {difs or "ninguno"}')
# emparejamiento inicio ↔ detalle ↔ consola
sin_det = [(v['dia'], v['ep'], v['ag'], v['paso']) for v in EV if v['det'] is None]
det_sin = [(d, ep, q['ag'], q['p0']) for d in ORD for ep, e in EPI[d].items() for q in det(e)
           if not any(v['dia'] == d and v['ep'] == ep and v['ag'] == q['ag'] and v['paso'] == q['p0'] for v in EV)]
print(f'  inicios sin detalle {sin_det or "ninguno"}; detalle sin inicio {det_sin or "ninguno"}')
for d in ORD:
    c = CON[d]
    if c is None:
        print(f'  {d}: sin consola → cruce ↩ no verificable'); continue
    ret_sin = [(q['ep'], q['ag'], q['paso']) for q in c['ret'] if not any(v['dia'] == d and v['ep'] == q['ep'] and v['ag'] == q['ag'] and v['paso'] == q['paso'] for v in EV)]
    ev_sin = [(v['ep'], v['ag'], v['paso']) for v in EV if v['dia'] == d and not any(q['ep'] == v['ep'] and q['ag'] == v['ag'] and q['paso'] == v['paso'] for q in c['ret'])]
    # ▶ vs detalle recuperada, en orden por (ep, ag)
    malv = []
    for (ep, ag) in {(q['ep'], q['ag']) for q in c['viv']}:
        vv = [q['tras'] for q in c['viv'] if (q['ep'], q['ag']) == (ep, ag)]
        dr = [q['dur'] for q in det(EPI[d][ep]) if q['ag'] == ag and q['res'] == 'recuperada']
        if vv != dr:
            malv.append((ep, ag, vv, dr))
    nrec = sum(1 for e in EPI[d].values() for q in det(e) if q['res'] == 'recuperada')
    # coordenadas de ↩ vs CSV
    dx = []
    for q in c['ret']:
        vv = [v for v in EV if v['dia'] == d and v['ep'] == q['ep'] and v['ag'] == q['ag'] and v['paso'] == q['paso']]
        if vv:
            dx.append(max(abs(round(vv[0]['x'], 2) - q['x']), abs(round(vv[0]['y'], 2) - q['y'])))
    print(f"  {d}: ↩ {len(c['ret'])} vs inicios {sum(1 for v in EV if v['dia']==d)}; ↩ sin inicio {ret_sin or 'ninguno'}; inicio sin ↩ {ev_sin or 'ninguno'};"
          f" ▶ {len(c['viv'])} vs recuperadas {nrec}; ▶≠detalle {malv or 'ninguno'}; máx |coord ↩ − CSV redondeado| {max(dx) if dx else NAN:.3f}")

print('=' * 110)
print('14) F19/F20/F21 — neto retrocedido por mecanismo (30-09) y 26-09')
for mec in ('Motive', 'hipo', 'caché-rechazo', 'caché-rechazo(inferido)', 'caché-fallida'):
    q = [v for v in e30 if v['mec'] == mec]
    if not q:
        continue
    nt = [v['neto'] for v in q if not math.isnan(v['neto'])]
    print(f"  {mec:24s} n {len(q)} (válidos {sum(v['valido'] for v in q)}) resultados {dict(Counter(v['det']['res'] if v['det'] else None for v in q))}"
          f" filas en_retroceso {sum(v['nret'] for v in q)} dur det {sorted(v['det']['dur'] for v in q if v['det'])}"
          f" | neto {[round(x, 2) for x in nt]} media {np.mean(nt) if nt else NAN:+.3f} DE1 {np.std(nt, ddof=1) if len(nt) > 1 else NAN:.3f}")
for nom, cond in (('≤3', lambda v: v['racha'] <= 3), ('≥10', lambda v: v['racha'] >= 10)):
    q = [v for v in e30 if v['mec'] == 'Motive' and cond(v) and not math.isnan(v['neto'])]
    nt = [v['neto'] for v in q]; n4 = [v['neto4'] for v in q]; n10 = [v['neto10'] for v in q]
    print(f"  Motive racha {nom}: n {len(q)} neto {[round(x, 2) for x in nt]} media {np.mean(nt):+.3f} DE1 {np.std(nt, ddof=1):.3f}"
          f" | variante k=4 media {np.mean(n4):+.3f}; k=10 media {np.mean(n10):+.3f}; positivos (detrás) {sum(x > 0 for x in nt)}/{len(nt)}")
print('  26-09:', [(v['ep'], v['robot'], v['racha'], round(v['neto'], 2), v['det']['res'] if v['det'] else None) for v in EV if v['dia'] == '26-09'])
pfpr = [(d, ep) for d in S30 for ep, e in EPI[d].items() if e['valido'] == '1' and (int(e['poses_fallidas'] or 0) or int(e['poses_rechazadas'] or 0))]
print(f'  episodios válidos 30-09 con fallidas>0 o rechazadas>0: {pfpr or "ninguno"}')

print('=' * 110)
print('15) F22 — s3 ep3')
e = EPI['s3'][3]
rep = sum(r['rep'] for (ep, ag), L in DEC['s3'].items() if ep == 3 for r in L)
print(f"  motivo {e['motivo']!r} dec {e['decisiones']} filas repetidas {rep} fallidas {e['poses_fallidas']} rechazadas {e['poses_rechazadas']}"
      f" ciclos>100 {e['ciclos_sobre_100ms']} p95 {e['ciclo_p95_ms']} duración {e['duracion_s']} s; [sync] en consola s3 {len(CON['s3']['sync'])}; vencida {CON['s3']['ven']}")
print('  últimas decisiones Δ mm por agente:')
for p in range(int(e['decisiones']) - 6, int(e['decisiones'])):
    d = DEL['s3'][3].get(p, {})
    print(f"    {p}: " + ' '.join(f"a{ag}:{d[ag][0]:.1f}" for ag in sorted(d)))

print('=' * 110)
print('16) F24 — líneas "detención enviada" entre el fin de la colocación y el cierre de cada episodio VÁLIDO')
for d in ORD:
    c = CON[d]
    if c is None:
        print(f'  {d}: sin consola'); continue
    lin = c['lin']; cnt = Counter()
    for ep, (est, n) in c['cie'].items():
        if not est.startswith('V'):
            continue
        k = n - 2; nd = 0
        while k >= 0 and not lin[k].strip().startswith('colocación:') and not RX_HDR.match(lin[k]):
            if 'detención enviada a los 5 robots' in lin[k]:
                nd += 1
            k -= 1
        cnt[nd] += 1
    print(f'  {d}: episodios válidos por n.º de líneas de detención tras la colocación: {dict(cnt)}')

print('=' * 110)
print('17) F25 — ciclo_p95_ms y ciclos_sobre_100ms (válidos)')
for d in ORD:
    v = [(float(e['ciclo_p95_ms']), int(e['ciclos_sobre_100ms'])) for e in EPI[d].values() if e['valido'] == '1']
    print(f"  {d:6s} p95 {min(a for a, _ in v):.1f}–{max(a for a, _ in v):.1f} ms; ciclos>100 ms {sum(b for _, b in v)}")

print('=' * 110)
print('18) Extras: (x,y) idéntica con θ distinto (vivas); sensibilidad de umbrales de hipo en los inicios')
for d in ORD:
    n_xy = sum(1 for L in DEC[d].values() for q in range(1, len(L)) if not L[q]['rep'] and (L[q]['x'], L[q]['y']) == (L[q - 1]['x'], L[q - 1]['y']))
    print(f'  {d}: filas vivas con (x,y) idéntica y θ distinto: {n_xy}')
for v in e30:
    if v['mec'] in ('Motive',) and (v['r'] < 0.5 or v['rp'] > 1.4):
        print(f"  Motive cerca del umbral de hipo: {v['dia']} ep{v['ep']} r{v['robot']} paso {v['paso']} r_prev {v['rp']:.2f} r {v['r']:.2f}")
