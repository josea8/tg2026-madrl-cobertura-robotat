#!/usr/bin/env python3
# verificar_s5_deriva.py — verificación INDEPENDIENTE del §5 (arreglo de detención: deriva entre episodios)
# y del ítem 4 del §1 de REPORTE_2026-09-30.md.  SOLO LECTURA.  Python 3 + numpy + scipy.
#
# Fuentes: únicamente ../csv y ../consola (rutas relativas a este archivo).
#
# Método (escrito desde cero; no importa ni copia los scripts a30f_*):
#   · última pose de cada agente en el ep k = fila de paso máximo del CSV de decisiones;
#     el agente está "congelado al final" si esa fila tiene (x, y, θ) idéntica a la fila anterior.
#   · impresiones de la guía = 1.ª ronda del bloque "EPISODIO k+1" de la consola: líneas de robot entre el
#     primer "Despejá la arena…" y la primera línea de colocación ("[colocación N s]", "colocación:", …).
#     Una impresión nueva empieza cuando el agente de la fila NO es posterior al de la fila anterior
#     (las tablas listan siempre r1, r5, r8, r6, r9). Así, cualquier texto intercalado
#     ("✘ robot N: marcador CONGELADO…", "[ruedas] fallo…", ".") NO corta una impresión.
#     Como control se agrupa también por líneas en blanco y se informa si los dos agrupamientos difieren.
#   · coordenadas impresas leídas con signo y convertidas a centímetros ENTEROS con Decimal (sin coma flotante);
#     d_pared impresa = min(x, 300−x, y, 300−y) cm, en el marco env (el de la consola y del CSV).
#   · d1 / d2 = distancia (cm) entre la última pose del ep k y la 1.ª / 2.ª impresión del bloque k+1.
#   · grupos: PRE válidos = 26-09, s1, s2, s3 (válido = 'valido' en {'1','True'}); s5 válidos;
#     abortados "sin robots congelados" = abortados de 26-09, s1, s2, s3 y s5, excluyendo los ROBOTS congelados
#     al final del ep k y excluyendo s1 ep 1–2.  s4 no tiene consola (sin dato).
#   · "detención enviada": se cuentan las líneas "detención enviada a los 5 robots" entre el último
#     "colocación: …" y ">>> EPISODIO k" de cada bloque.
#
# Salida: una línea por cifra "id | descripción | valor en el reporte | recalculado | OK/FALLA",
# tolerancia = media unidad del último decimal mostrado en el reporte; termina con "RESUMEN s5_deriva: …".
import csv
import math
import re
import sys
from decimal import Decimal
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.stats import mannwhitneyu

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

BASE = Path(__file__).resolve().parent.parent
DCSV = BASE / "csv"
DCON = BASE / "consola"

AG2ROB = [1, 5, 8, 6, 9]
ROB2AG = {r: a for a, r in enumerate(AG2ROB)}

SESIONES = [  # nombre, consola, fecha, sufijo, arreglo aplicado
    ("26-09", "consola_20260926.txt", "20260926", "", False),
    ("s1", "consola_20260930.txt", "20260930", "", False),
    ("s2", "consola_20260930_02.txt", "20260930", "_02", False),
    ("s3", "consola_20260930_03.txt", "20260930", "_03", False),
    ("s4", None, "20260930", "_04", False),
    ("s5", "consola_20260930_05.txt", "20260930", "_05", True),
]
PRE = ("26-09", "s1", "s2", "s3")


def es_valido(fila):
    return fila["valido"].strip() in ("1", "True")


# ---------------------------------------------------------------- CSV
def leer_episodios(fecha, suf):
    with open(DCSV / f"{fecha}_sesion-evaluacion_etapa7_episodios{suf}.csv", encoding="utf-8-sig", newline="") as f:
        return {int(r["episodio"]): r for r in csv.DictReader(f)}


def leer_decisiones(fecha, suf):
    """(ep, agente) -> lista de (paso, x_str, y_str, th_str, x, y, th) ordenada por paso."""
    d = {}
    malmap = 0
    with open(DCSV / f"{fecha}_sesion-evaluacion_etapa7_decisiones{suf}.csv", encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            ep, ag = int(r["episodio"]), int(r["agente"])
            if int(r["robot"]) != AG2ROB[ag]:
                malmap += 1
            d.setdefault((ep, ag), []).append(
                (int(r["paso"]), r["pose_env_x"], r["pose_env_y"], r["pose_env_th"],
                 float(r["pose_env_x"]), float(r["pose_env_y"]), float(r["pose_env_th"])))
    for k in d:
        d[k].sort(key=lambda t: t[0])
    return d, malmap


# ---------------------------------------------------------------- consola
RE_HDR = re.compile(r"^EPISODIO (\d+)\s+\(válidos hasta ahora: (\d+)/(\d+)\)")
RE_FILA = re.compile(r"^\s*(?:[✔✘]\s*)?robot (\d+): (?:está \((-?\d+\.\d+), (-?\d+\.\d+)\)|(SIN POSE)|(marcador CONGELADO))")
RE_FIN_RONDA = re.compile(r"^\s*(?:\[colocación\s+\d+\s*s\]|colocación: |⚠ colocación|✘ no se arranca|BLANCOS DE ESTE|>>> EPISODIO)")
RE_RES = re.compile(r"^\s*>>> EPISODIO (\d+): (VÁLIDO|INVÁLIDO)")
RE_COLSUM = re.compile(r"^\s+colocación: ")
DET = "detención enviada a los 5 robots"


def a_cm(s):
    return int(Decimal(s) * 100)


def leer_consola(nombre):
    L = (DCON / nombre).read_text(encoding="utf-8-sig").splitlines()
    heads = [i for i, l in enumerate(L) if RE_HDR.match(l)]
    bloques = {}
    n_coord = n_coord_2dec = 0
    for j, h in enumerate(heads):
        k = int(RE_HDR.match(L[h]).group(1))
        B = L[h:(heads[j + 1] if j + 1 < len(heads) else len(L))]
        b = {"prints": [], "prints_blanco": [], "det_entre": None, "res": None}
        ip = next((i for i, l in enumerate(B) if "Despejá la arena" in l), None)
        if ip is not None:
            ronda = []
            for l in B[ip + 1:]:
                if RE_FILA.match(l):
                    ronda.append(l)
                    continue
                if RE_FIN_RONDA.match(l):
                    break
                ronda.append(l)
            # agrupamiento principal: por orden de agente
            cur, ult_ag = None, 99
            # agrupamiento de control: por línea en blanco
            curb, blanco_visto = None, True
            for l in ronda:
                m = RE_FILA.match(l)
                if not m:
                    if l.strip() == "":
                        blanco_visto = True
                    continue
                rob = int(m.group(1))
                ag = ROB2AG[rob]
                if m.group(2) is not None:
                    est = ("esta", a_cm(m.group(2)), a_cm(m.group(3)))
                    for s in (m.group(2), m.group(3)):
                        n_coord += 1
                        n_coord_2dec += len(s.split(".")[1]) == 2
                elif m.group(4):
                    est = ("sin_pose",)
                else:
                    est = ("congelado",)
                if cur is None or ag <= ult_ag:
                    cur = {}
                    b["prints"].append(cur)
                cur[rob] = est
                ult_ag = ag
                if curb is None or blanco_visto:
                    curb = {}
                    b["prints_blanco"].append(curb)
                curb[rob] = est
                blanco_visto = False
        ir = next((i for i, l in enumerate(B) if RE_RES.match(l)), None)
        if ir is not None:
            mr = RE_RES.match(B[ir])
            b["res"] = (int(mr.group(1)), mr.group(2))
            ics = [i for i in range(ir) if RE_COLSUM.match(B[i])]
            if ics:
                b["det_entre"] = sum(1 for l in B[ics[-1] + 1:ir] if DET in l)
        bloques[k] = b
    return bloques, n_coord, n_coord_2dec, any("se refresca cada 1 s" in l for l in L)


# ---------------------------------------------------------------- cálculo
def dpar_cm(p):
    return min(p[1], 300 - p[1], p[2], 300 - p[2])


medidas = []      # una por (sesión, k, agente)
det = []          # (sesión, k, válido, n detenciones entre colocación y resultado)
sep = []          # (sesión, k, válido, min par última pose, min par imp1, min par imp2, min par cualquier impr.)
dur = {}          # sesión -> lista (duracion, decisiones, p95) de válidos
info = []
n_coord_tot = n_coord_2dec_tot = 0
refresca_1s = True
discrep_agrup = 0
consistencia = []

for ses, con, fecha, suf, arreglo in SESIONES:
    eps = leer_episodios(fecha, suf)
    dur[ses] = [(float(e["duracion_s"]), int(e["decisiones"]), float(e["ciclo_p95_ms"]))
                for e in eps.values() if es_valido(e)]
    if con is None:
        info.append(f"# {ses}: sin consola -> deriva y detenciones SIN DATO")
        continue
    dec, malmap = leer_decisiones(fecha, suf)
    bloques, nc, nc2, ref = leer_consola(con)
    n_coord_tot += nc
    n_coord_2dec_tot += nc2
    refresca_1s &= ref
    # control de emparejamiento: resultado de consola = 'valido' del CSV, mismo conjunto de episodios
    for k, e in eps.items():
        b = bloques.get(k)
        ok = b is not None and b["res"] is not None and b["res"][0] == k and \
            ((b["res"][1] == "VÁLIDO") == es_valido(e))
        consistencia.append(ok)
    consistencia.append(set(bloques) == set(eps))
    for k, b in bloques.items():
        if [sorted(p.items()) for p in b["prints"]] != [sorted(p.items()) for p in b["prints_blanco"]]:
            discrep_agrup += 1
    info.append(f"# {ses}: episodios CSV={len(eps)}  bloques consola={len(bloques)}  "
                f"filas decisiones con robot≠mapeo={malmap}  tamaños de impresión de la 1.ª ronda="
                f"{sorted(set(len(p) for b in bloques.values() for p in b['prints']))}")
    for k in sorted(eps):
        e = eps[k]
        val = es_valido(e)
        b = bloques[k]
        det.append((ses, k, val, b["det_entre"]))
        if k + 1 not in bloques:
            continue  # último episodio de la sesión: sin guía siguiente
        pr = bloques[k + 1]["prints"]
        p1 = pr[0] if len(pr) > 0 else {}
        p2 = pr[1] if len(pr) > 1 else {}
        ult_xy = []
        for ag in range(5):
            filas = dec[(k, ag)]
            u = filas[-1]
            cong = len(filas) > 1 and u[1:4] == filas[-2][1:4]
            x, y, th = u[4], u[5], u[6]
            ult_xy.append((x, y))
            rob = AG2ROB[ag]
            q1 = p1.get(rob)
            q2 = p2.get(rob)
            q1 = q1 if q1 and q1[0] == "esta" else None
            q2 = q2 if q2 and q2[0] == "esta" else None
            d = lambda q: math.hypot(q[1] / 100 - x, q[2] / 100 - y) * 100 if q else None
            medidas.append({
                "ses": ses, "k": k, "val": val, "arreglo": arreglo, "rob": rob, "cong": cong,
                "x": x, "y": y, "dpar_ult": min(x, 3 - x, y, 3 - y),
                "d1": d(q1), "d2": d(q2),
                "dp1": dpar_cm(q1) if q1 else None, "dp2": dpar_cm(q2) if q2 else None,
                "q1": q1, "q2": q2,
                "d12": math.hypot(q2[1] - q1[1], q2[2] - q1[2]) if (q1 and q2) else None,
                "dpU_min": min((dpar_cm(p[rob]) for p in pr if p.get(rob, ("",))[0] == "esta"), default=None),
            })

        def minpar(pts):
            return min((math.dist(a, c) for a, c in combinations(pts, 2)), default=None)

        def pts_imp(p):
            return [(v[1], v[2]) for v in p.values() if v[0] == "esta"]
        todas = [minpar(pts_imp(p)) for p in pr]
        todas = [t for t in todas if t is not None]
        sep.append((ses, k, val, minpar(ult_xy) * 100,
                    minpar(pts_imp(p1)) if p1 else None, minpar(pts_imp(p2)) if p2 else None,
                    min(todas) if todas else None))

# grupos
PREV = [m for m in medidas if m["ses"] in PRE and m["val"]]
S5V = [m for m in medidas if m["ses"] == "s5" and m["val"]]
ABO = [m for m in medidas if not m["val"] and not m["cong"] and not (m["ses"] == "s1" and m["k"] in (1, 2))]


def col(rows, c):
    return [r[c] for r in rows if r[c] is not None]


def ep_med(rows, c):
    g = {}
    for r in rows:
        if r[c] is not None:
            g.setdefault((r["ses"], r["k"]), []).append(r[c])
    return {kk: float(np.median(v)) for kk, v in g.items()}


# ---------------------------------------------------------------- comprobaciones
filas_out = []
cuenta = {"OK": 0, "FALLA": 0, "NR": 0}


def _num(s):
    return Decimal(s.replace("−", "-").replace("+", ""))


def chk(i, desc, rep, valor, fmt="{:.4f}"):
    """rep: texto tal cual en el reporte; tolerancia = media unidad de su último decimal."""
    r = _num(rep)
    dec_ = -r.as_tuple().exponent if r.as_tuple().exponent < 0 else 0
    tol = 0.5 * 10 ** (-dec_)
    ok = abs(float(valor) - float(r)) <= tol + 1e-9
    est = "OK" if ok else "FALLA"
    cuenta[est] += 1
    filas_out.append(f"{i} | {desc} | {rep} | {fmt.format(valor)} | {est}")


def chk_txt(i, desc, rep, recalc, ok):
    est = "OK" if ok else "FALLA"
    cuenta[est] += 1
    filas_out.append(f"{i} | {desc} | {rep} | {recalc} | {est}")


def nr(i, desc, rep, fuente):
    cuenta["NR"] += 1
    filas_out.append(f"{i} | {desc} | {rep} | — | NO RECALCULABLE (fuente: {fuente})")


# --- Tabla del §5: válidos antes del arreglo
n_ep_prev = len({(m["ses"], m["k"]) for m in PREV})
chk("T01", "válidos antes del arreglo: episodios medibles (26-09 y s1–s3)", "36", n_ep_prev, "{:d}")
chk("T02", "válidos antes: medidas robot (2.ª impresión)", "180", len(col(PREV, "d2")), "{:d}")
chk("T03", "válidos antes: d1 mediana (cm)", "27.5", np.median(col(PREV, "d1")))
chk("T04", "válidos antes: d1 máximo (cm)", "55.9", max(col(PREV, "d1")))
chk("T05", "válidos antes: d2 mediana (cm)", "30.8", np.median(col(PREV, "d2")))
chk("T06", "válidos antes: d2 máximo (cm)", "61.9", max(col(PREV, "d2")))
chk("T07", "válidos antes: d_pared mín en la 2.ª impresión (m)", "−0.06", min(col(PREV, "dp2")) / 100, "{:.2f}")
chk("T08", "válidos antes: robots fuera de la arena (d_pared 2.ª < 0)", "4", sum(1 for v in col(PREV, "dp2") if v < 0), "{:d}")
for idx, (s, rm, rx) in enumerate([("26-09", "34.6", "41.5"), ("s1", "30.0", "46.5"),
                                   ("s2", "27.5", "38.0"), ("s3", "36.4", "61.9")]):
    rows = [m for m in PREV if m["ses"] == s]
    chk(f"T{9 + 3 * idx:02d}", f"{s} válidos: medidas d2", "45", len(col(rows, "d2")), "{:d}")
    chk(f"T{10 + 3 * idx:02d}", f"{s} válidos: d2 mediana (cm)", rm, np.median(col(rows, "d2")))
    chk(f"T{11 + 3 * idx:02d}", f"{s} válidos: d2 máximo (cm)", rx, max(col(rows, "d2")))
# --- abortados sin robots congelados
chk("T21", "abortados sin robots congelados: medidas (d1 = d2)", "58",
    len(col(ABO, "d1")) if len(col(ABO, "d1")) == len(col(ABO, "d2")) else -1, "{:d}")
chk("T22", "abortados: d1 mediana (cm)", "2.6", np.median(col(ABO, "d1")))
chk("T23", "abortados: d1 máximo (cm)", "7.1", max(col(ABO, "d1")))
chk("T24", "abortados: d2 mediana (cm)", "4.1", np.median(col(ABO, "d2")))
chk("T25", "abortados: d2 máximo (cm)", "9.6", max(col(ABO, "d2")))
chk("T26", "abortados: d_pared mín en la 2.ª impresión (m)", "0.17", min(col(ABO, "dp2")) / 100, "{:.2f}")
chk("T27", "abortados: robots fuera de la arena", "0", sum(1 for v in col(ABO, "dp2") if v < 0), "{:d}")
# --- s5 válidos
chk("T28", "s5 válidos: medidas 1.ª impresión", "45", len(col(S5V, "d1")), "{:d}")
chk("T29", "s5 válidos: medidas 2.ª impresión", "40", len(col(S5V, "d2")), "{:d}")
chk("T30", "s5 válidos: d1 mediana (cm)", "4.2", np.median(col(S5V, "d1")))
chk("T31", "s5 válidos: d1 máximo (cm)", "7.2", max(col(S5V, "d1")))
chk("T32", "s5 válidos: d2 mediana (cm)", "4.0", np.median(col(S5V, "d2")))
chk("T33", "s5 válidos: d2 máximo (cm)", "6.5", max(col(S5V, "d2")))
chk("T34", "s5 válidos: d_pared mín en la 2.ª impresión (m)", "0.15", min(col(S5V, "dp2")) / 100, "{:.2f}")
chk("T35", "s5 válidos: robots fuera de la arena", "0", sum(1 for v in col(S5V, "dp2") if v < 0), "{:d}")

# --- los 4 casos fuera de la arena
fuera = sorted([m for m in PREV if m["dp2"] is not None and m["dp2"] < 0], key=lambda m: (m["ses"], m["k"], m["rob"]))
fset = {(m["ses"], m["k"], m["rob"]) for m in fuera}
esperado = {("26-09", 12, 1), ("26-09", 15, 5), ("26-09", 15, 9), ("s3", 1, 8)}
chk_txt("F01", "identidad de los robots fuera (26-09 ep12 r1; 26-09 ep15 r5, r9; s3 ep1 r8)",
        "4 casos listados", "; ".join(f"{s} ep{k} r{r}" for s, k, r in sorted(fset)), fset == esperado)


def dp2_de(s, k, r):
    return next(m["dp2"] for m in PREV if (m["ses"], m["k"], m["rob"]) == (s, k, r)) / 100


chk("F02", "26-09 ep 12: r1 d_pared 2.ª impresión (m)", "−0.02", dp2_de("26-09", 12, 1), "{:.2f}")
chk("F03", "26-09 ep 15: r5 d_pared 2.ª impresión (m)", "−0.01", dp2_de("26-09", 15, 5), "{:.2f}")
chk("F04", "26-09 ep 15: r9 d_pared 2.ª impresión (m)", "−0.06", dp2_de("26-09", 15, 9), "{:.2f}")
q = next(m["q2"] for m in PREV if (m["ses"], m["k"], m["rob"]) == ("s3", 1, 8))
chk("F05", "s3 ep 1: r8, coordenada y en la 2.ª impresión (m)", "3.03", q[2] / 100, "{:.2f}")
bajo5 = [m for m in PREV if m["dp2"] is not None and m["dp2"] < 5]
otras = [m for m in bajo5 if m["dp2"] >= 0]
chk("F06", "'Otras' medidas (además de las 4 de afuera) a < 0.05 m de la pared, 2.ª impresión",
    "6", len(otras), "{:d}")
info.append(f"# F06: total de medidas con d_pared 2.ª < 5 cm = {len(bajo5)} (incluye las 4 negativas); "
            f"exactamente 5 cm = {sum(1 for m in PREV if m['dp2'] == 5)}; "
            f"en la 1.ª impresión < 5 cm = {sum(1 for v in col(PREV, 'dp1') if v < 5)}")
info.append("# F06 detalle (<5 cm): " + "; ".join(
    f"{m['ses']} k{m['k']} r{m['rob']} dp2={m['dp2'] / 100:.2f} dpar_ult={m['dpar_ult']:.4f}"
    for m in sorted(bajo5, key=lambda m: m["dp2"])))
chk("F07", "mínimo de d_pared de la última pose del ep k entre esos casos (m) [≥ 0.168]", "0.168",
    min(m["dpar_ult"] for m in bajo5), "{:.4f}")
s3_dp1 = min(m["dp1"] for m in PREV if m["ses"] == "s3") / 100
chk("F08", "s3 válidos: d_pared mín en la 1.ª impresión (m) ('hasta 2 cm' del comentario)", "0.02", s3_dp1, "{:.2f}")
info.append(f"# F08: d_pared mín 1.ª impresión por sesión (válidos): " + ", ".join(
    f"{s} {min(m['dp1'] for m in PREV if m['ses'] == s) / 100:.2f}" for s in PRE)
    + f"; 2.ª impresión s3: {min(m['dp2'] for m in PREV if m['ses'] == 's3') / 100:.2f}")
fuera_cualq = sum(1 for m in PREV if m["dpU_min"] is not None and m["dpU_min"] < 0)
info.append(f"# robots de válidos previos fuera de la arena en CUALQUIER impresión de la 1.ª ronda: {fuera_cualq}; "
            f"en la 1.ª impresión: {sum(1 for v in col(PREV, 'dp1') if v < 0)}")

# --- impresiones idénticas
s5_pares = [m["d12"] for m in S5V if m["d12"] is not None]
chk_txt("I01", "s5 válidos: 1.ª y 2.ª impresión idénticas", "40 de 40",
        f"{sum(1 for v in s5_pares if v == 0)} de {len(s5_pares)}",
        sum(1 for v in s5_pares if v == 0) == 40 and len(s5_pares) == 40)
pre_l = [m["d12"] for m in PREV if m["d12"] is not None and not m["cong"]]
pre_t = [m["d12"] for m in PREV if m["d12"] is not None]
n15_l = sum(1 for v in pre_l if v >= 1.5)
n15_t = sum(1 for v in pre_t if v >= 1.5)
chk_txt("I02", "válidos antes: pares con |p2−p1| ≥ 1.5 cm (excluye robots congelados al final)", "174 de 179",
        f"{n15_l} de {len(pre_l)}", n15_l == 174 and len(pre_l) == 179)
info.append(f"# I02: con los 180 pares (sin excluir el r8 congelado de 26-09 k=17): {n15_t} de {len(pre_t)}")

# --- detenciones
d5 = [d for d in det if d[0] == "s5"]
chk_txt("D01", "s5: episodios con 2 'detención enviada' entre colocación y resultado", "11 de 11",
        f"{sum(1 for d in d5 if d[3] == 2)} de {len(d5)}", sum(1 for d in d5 if d[3] == 2) == 11 and len(d5) == 11)
dv = [d for d in det if d[0] in PRE and d[2]]
chk_txt("D02", "antes: válidos con 1 'detención enviada'", "40 de 40",
        f"{sum(1 for d in dv if d[3] == 1)} de {len(dv)}", sum(1 for d in dv if d[3] == 1) == 40 and len(dv) == 40)
da = [d for d in det if d[0] in PRE and not d[2]]
chk_txt("D03", "antes: abortados con 2 'detención enviada'", "14 de 14",
        f"{sum(1 for d in da if d[3] == 2)} de {len(da)}", sum(1 for d in da if d[3] == 2) == 14 and len(da) == 14)

# --- Mann-Whitney por episodio, 2.ª impresión
e_s5 = list(ep_med(S5V, "d2").values())
e_ab = list(ep_med(ABO, "d2").values())
mw = mannwhitneyu(e_s5, e_ab, alternative="two-sided")
chk("M01", f"Mann-Whitney por episodio, d2: s5 válidos ({len(e_s5)} ep) vs abortados sin congelados ({len(e_ab)} ep), p",
    "0.46", mw.pvalue)
info.append(f"# M01: U={mw.statistic:.1f}; medianas por episodio s5 {sorted(round(v, 2) for v in e_s5)}; "
            f"abortados {sorted(round(v, 2) for v in e_ab)}")
chk("M02", "residuo tras la detención: d2 mediana s5 válidos (cm) [~4 cm]", "4", np.median(col(S5V, "d2")), "{:.2f}")

# --- separación entre robots
sp = [s for s in sep if s[0] in PRE and s[2]]
chk("P01", "separación mín. entre robots, 2.ª impresión, válidos antes (cm)", "16.1", min(s[5] for s in sp if s[5] is not None))
chk("P02", "separación mín. entre robots, última pose registrada, mismos episodios (cm)", "34.3", min(s[3] for s in sp))
min_cualq = min(s[6] for s in sp if s[6] is not None)
chk_txt("P03", "ningún par a < 15 cm en los instantes impresos (toda la 1.ª ronda, válidos antes)", "ninguno < 15 cm",
        f"mín {min_cualq:.2f} cm", min_cualq >= 15)
info.append(f"# P: mín 1.ª impresión {min(s[4] for s in sp if s[4] is not None):.2f} cm; "
            f"s5 válidos 2.ª impresión {min(s[5] for s in sep if s[0] == 's5' and s[2] and s[5] is not None):.2f} cm")

# --- script viejo sin negativos (26-09 ep 15)
r15 = [m for m in PREV if m["ses"] == "26-09" and m["k"] == 15]
chk("V01", "26-09 ep 15: d_pared mín 2.ª impresión con los 5 robots (m)", "−0.06", min(m["dp2"] for m in r15) / 100, "{:.2f}")
sin_neg = [m["dp2"] for m in r15 if m["q2"][1] >= 0 and m["q2"][2] >= 0]
chk("V02", "26-09 ep 15: idem descartando coordenadas negativas (patrón [\\d.]+) (m)", "0.06", min(sin_neg) / 100, "{:.2f}")

# --- otros enunciados del §5
chk_txt("R01", "la consola imprime con resolución de 1 cm (coordenadas 'está' con 2 decimales)", "1 cm",
        f"{n_coord_2dec_tot}/{n_coord_tot} coordenadas con 2 decimales", n_coord_2dec_tot == n_coord_tot)
rng = {c: (min(v[c] for s in ("s1", "s2", "s3", "s4") for v in dur[s]),
           max(v[c] for s in ("s1", "s2", "s3", "s4") for v in dur[s])) for c in range(3)}
dentro = all(rng[c][0] <= v[c] <= rng[c][1] for v in dur["s5"] for c in range(3))
chk_txt("R02", "s5: duración, decisiones y p95 de los válidos dentro del rango de s1–s4", "dentro del rango",
        "s5 dur [{:.4f}, {:.4f}] vs [{:.4f}, {:.4f}]; dec {} vs {}; p95 [{:.2f}, {:.2f}] vs [{:.2f}, {:.2f}]".format(
            min(v[0] for v in dur["s5"]), max(v[0] for v in dur["s5"]), *rng[0],
            sorted({v[1] for v in dur["s5"]}), sorted({rng[1][0], rng[1][1]}),
            min(v[2] for v in dur["s5"]), max(v[2] for v in dur["s5"]), *rng[2]), dentro)
nr("N01", "latido de la guía: envía (0,0) cada ~1 s sin imprimir", "~1 s",
   "código sesion_robotat.py latir(); la consola sólo dice 'La guía se refresca cada 1 s'" +
   (" (texto presente)" if refresca_1s else " (texto AUSENTE)"))
nr("N02", "tras un válido el robot seguía mientras se calculaba la réplica sin capas", "—", "código de la sesión")
nr("N03", "prueba de regresión: falla sin el arreglo y pasa con él; pruebas OK", "198", "corrida de pytest, no incluida en csv/ ni consola/")
nr("N04", "el diff sólo saca canal.detener_todo() del if abortado:", "—", "codigo/arreglo_detencion_sesion_robotat.diff")
nr("N05", "CSV de la s4 cerró a las", "13:12:14", "fecha de modificación del archivo")
nr("N06", "código cambió a las", "13:13:50", "fecha de modificación de sesion_robotat.py")
nr("N07", "script viejo a30_flujo_ritmo_deriva26.py no leía negativos", "—", "script no incluido en el paquete (se emuló en V02)")

# --- §1, ítem 4
chk("S01", "§1.4 antes: mediana de la deriva (cm)", "30.8", np.median(col(PREV, "d2")))
chk("S02", "§1.4 antes: máximo (cm)", "61.9", max(col(PREV, "d2")))
chk("S03", "§1.4 robots fuera de la arena", "4", sum(1 for v in col(PREV, "dp2") if v < 0), "{:d}")
chk("S04", "§1.4 hasta X cm afuera", "6", -min(col(PREV, "dp2")), "{:d}")
chk("S05", "§1.4 s5: mediana (cm)", "4.0", np.median(col(S5V, "d2")))
chk("S06", "§1.4 s5: máximo (cm)", "6.5", max(col(S5V, "d2")))
ep_prev_d2 = ep_med(PREV, "d2")
chk_txt("S07", "§1.4 'tras cada episodio válido' seguían: mediana por episodio de d2, mín de los 36 vs máx de s5",
        "cada válido", f"mín PRE {min(ep_prev_d2.values()):.2f} cm (n={len(ep_prev_d2)}) > máx s5 {max(e_s5):.2f} cm",
        min(ep_prev_d2.values()) > max(e_s5) and len(ep_prev_d2) == 36)
chk_txt("S08", "§1.4 'el mismo nivel que tras un aborto' (no hay diferencia detectable)", "mismo nivel",
        f"MW p={mw.pvalue:.3f}; mediana d2 s5 {np.median(col(S5V, 'd2')):.2f} vs abortados {np.median(col(ABO, 'd2')):.2f} cm",
        mw.pvalue > 0.05)
nr("S09", "§1.4 el arreglo no toca nada dentro del episodio", "—", "codigo/ (diff); R02 sólo muestra compatibilidad")

# ---------------------------------------------------------------- salida
print("# verificar_s5_deriva.py — §5 y §1 ítem 4 de REPORTE_2026-09-30.md (solo lectura)")
for l in info:
    print(l)
print(f"# control: resultado de consola = 'valido' del CSV en todos los episodios y mismos episodios: {all(consistencia)}")
print(f"# control: bloques donde el agrupamiento por orden de agente difiere del agrupamiento por línea en blanco: {discrep_agrup}")
print("id | descripción | valor en el reporte | recalculado | OK/FALLA")
for l in filas_out:
    print(l)
print(f"RESUMEN s5_deriva: {cuenta['OK']} ok, {cuenta['FALLA']} fallas, {cuenta['NR']} no recalculables")
