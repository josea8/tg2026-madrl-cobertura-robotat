import ctypes; ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x40)  # IDLE
"""Crítico (7): cronología por fechas de archivo (SOLO os.stat, sin abrir nada) para acotar cuándo entró el arreglo
de detención y si el código cambió entre el 26-09 y el 30-09. Uso: python -B a30f_critico_7_tiempos.py"""
import os
import datetime as dt

C = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
R = C + r"\resultados_sesion"
f = lambda t: dt.datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S")
print("CSV de evaluación (escritos al FINAL de cada sesión: creación = modificación):")
for n in sorted(os.listdir(R)):
    if ("20260930_sesion-evaluacion" in n or "20260926_sesion-evaluacion" in n) and "episodios" in n:
        st = os.stat(os.path.join(R, n))
        print(f"  {n:55s} creado {f(st.st_ctime)} · modificado {f(st.st_mtime)}")
print("\nsesion_robotat.py, su respaldo previo al arreglo y la prueba:")
for n in ("sesion_robotat.py", "sesion_robotat_respaldo_20260930_preDetencion.py", "test_sesion_robotat.py",
          "test_sesion_robotat_respaldo_20260930_preDetencion.py"):
    st = os.stat(os.path.join(C, n))
    print(f"  {n:55s} modificado {f(st.st_mtime)} · {st.st_size} B")
corte_ini = dt.datetime(2026, 9, 26, 0, 0).timestamp()
print("\nArchivos de código/config (fuera de resultados_sesion, sin respaldos) modificados desde el 26-09 00:00:")
ult = []
for raiz, dirs, archivos in os.walk(C):
    if "resultados_sesion" in raiz:
        continue
    for n in archivos:
        p = os.path.join(raiz, n)
        st = os.stat(p)
        if "respaldo" not in n:
            ult.append((st.st_mtime, os.path.relpath(p, C)))
for t, n in sorted(ult):
    if t >= corte_ini:
        print(f"  {f(t)}  {n}")
previos = [x for x in sorted(ult) if x[0] < corte_ini and x[1].endswith((".py", ".json", ".zip", ".yaml", ".txt"))]
print(f"\nÚltimo archivo de código/config modificado ANTES del 26-09: {f(previos[-1][0])} {previos[-1][1]}")
