# Datos crudos del reporte del 2026-09-30

Copias byte a byte de los archivos del proyecto que respaldan `REPORTE_2026-09-30.md` (incluido acá), más los scripts de cada cifra y sus salidas. Nada de esto modifica el proyecto.

## Cómo verificar las cifras

```bash
cd scripts
python -B verificar_cifras.py     # corre verificar_s*.py: recalcula cada cifra del reporte desde ../csv y ../consola
python -B pareo_final_0930.py     # el pareo PREESPECIFICADO (§3), sin cambios desde las 13:45 del 30-09
python -B pareo_extra_0930.py     # complementos post hoc (§3 CR1 y semillas, §4 seguridad pareada, §7 p95 de la réplica)
```

Requiere Python ≥ 3.9, numpy y scipy. `verificar_cifras.py` imprime, por sección, cuántas cifras coinciden, cuántas fallan y cuántas no se pueden recalcular desde el paquete (registro de Windows, líneas de código, horas de archivos: su fuente está en `derivados/`). Las salidas de referencia están en `derivados/`.

Los scripts `a30f_*` son las trazas de los análisis de cada dimensión (deriva, congelamientos, robots, métricas, crítico) y de sus verificaciones independientes (`a30f_verif_*`). Apuntan a las rutas del proyecto y del scratchpad donde se corrieron; leen los mismos CSV y consolas que están acá. `derivados/wf_0930_extraido.txt` resume sus afirmaciones con el veredicto del verificador (confirmada / corregida).

## Origen

- `csv/`: `primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/` (la calibración, de `coordinador_enjambre/`). Las 5 réplicas `20260930_sesion-replica_etapa7_capas-on_de-20260930*.csv` se generaron el 30-09 entre 13:39 y 15:46 con `replica_con_capas.py --capas on --reps 3`.
- `consola/`: las consolas de las sesiones que pegaste en el chat (no existen como archivo en el proyecto). **No hay consola de la sesión 4.**
- `derivados/replica_0930_hashes_pila_final.txt`: sha256 de la pila con la que corrió la réplica; se comprobó idéntica al terminar.
- `derivados/pareo_final_0930_sha256_antes_de_correr.txt`: sha256 del script preespecificado antes de correrlo contra las réplicas.
- `derivados/replica_0930_todas_log.txt`: registro de la réplica definitiva. `derivados/replica_0930_log.txt`: la réplica parcial que corrió por error en paralelo con la sesión 3 y se detuvo; no escribió CSV y no se usa en ninguna cifra.
- `codigo/`: diff del arreglo de detención (`sesion_robotat.py`) y de su prueba de regresión, contra los respaldos `*_respaldo_20260930_preDetencion.py`.
- `figuras/a30f_congel_mapa.png`: mapa de inicios de congelamiento, 26-09 y s1–s5.

## Manifiesto (sha256)

| archivo | bytes | tamaño | sha256 |
|---|---|---|---|
| `REPORTE_2026-09-30.md` | 39809 |  | `331111bfb805a4a9046fbe17e67018f2eb9407f79af9449cbcb5e0b5fdd35da0` |
| `codigo/arreglo_detencion_sesion_robotat.diff` | 885 |  | `f800686e712d2a9a062bee00f1d018cc72b603aac5b93705dd03141b5b7fa272` |
| `codigo/prueba_regresion_test_sesion_robotat.diff` | 2294 |  | `23ef1584f584b2681df57724a866cf333852dcd1800f9dada29097f5e8ed3a88` |
| `consola/consola_20260926.txt` | 290670 |  | `8a9bb06977c8d21b1b0c46bec3150a747fff9eed765427b3b113852b90874619` |
| `consola/consola_20260930.txt` | 66175 |  | `991c0d4c4744e0895e0a733e25c90216eaf39d3265ed729629a92467594f4be0` |
| `consola/consola_20260930_02.txt` | 84719 |  | `9f24116db750fc7773ee8f0a3dd48b4794274b9365950b42dd58c0eb7e669cac` |
| `consola/consola_20260930_03.txt` | 59935 |  | `c44d5c1ac3de877d923cad41ea9219221ece6637414c965ea28546f13909302a` |
| `consola/consola_20260930_05.txt` | 50338 |  | `d2d4bbcdb34f784f4dadda8672789dfc0d9fec7ac0921c5f06e77e6649b36d5c` |
| `csv/20260911_sesion-evaluacion_etapa7_episodios.csv` | 7977 | 19 filas | `b9459feb99fb5c641298ab3a4f4bbc64f4b27c833d571cbeaf560fc0b5b95977` |
| `csv/20260912_sesion-replica_etapa7_capas-on.csv` | 3176 | 15 filas | `e889c989c39c97c0d46444b3b04431e8978f916993d43fbff6781211400c7466` |
| `csv/20260926_sesion-evaluacion_etapa7_decisiones.csv` | 4567596 | 34260 filas | `7f47dc62623b8466adf3e768dc0c911ac0808e8d5e2a229cfd6039515253b89d` |
| `csv/20260926_sesion-evaluacion_etapa7_episodios.csv` | 23676 | 19 filas | `c3c07ab50ac0a1910aa1333539b9c92c3d979f36d3e80e2f78bf1f2c8bbfafb7` |
| `csv/20260926_sesion-replica_etapa7_capas-on_de-20260926.csv` | 8364 | 30 filas | `7f0daf9deabc3106fabd842001aac69b92f019bc565b344f0b3653c80d580601` |
| `csv/20260930_sesion-evaluacion_etapa7_decisiones.csv` | 3653614 | 27435 filas | `a39dadcc69706e0b3fbcbc9f36bf83b6a0004cca6d7691afce97f5c4624a5624` |
| `csv/20260930_sesion-evaluacion_etapa7_decisiones_02.csv` | 3535707 | 26565 filas | `9ce211e223e79ee239e866c79fb3f56f28d6df79b00cacd075eabfc3d59d24cc` |
| `csv/20260930_sesion-evaluacion_etapa7_decisiones_03.csv` | 3579014 | 26905 filas | `b2119005e666fc4c3f524c9ab30197d7c69d5811b308b6cc4fb87b87a6215e10` |
| `csv/20260930_sesion-evaluacion_etapa7_decisiones_04.csv` | 3462157 | 26025 filas | `856c535e20c8f7f40726d5e273505168e5d20111559904ec0ae024df1ea4a0e3` |
| `csv/20260930_sesion-evaluacion_etapa7_decisiones_05.csv` | 3643156 | 27385 filas | `8ec694c1efd5161c08b35d202e6f24daa2aecf52f7cbcee01ea02294806fb7cf` |
| `csv/20260930_sesion-evaluacion_etapa7_episodios.csv` | 14760 | 12 filas | `9cbcf04164b82877707514a35cbce85eb58bd835e2d5ca5db61a263fb1680969` |
| `csv/20260930_sesion-evaluacion_etapa7_episodios_02.csv` | 14555 | 12 filas | `d67d0d1eccddc7df57c2ae64a0539291943b2c48b750e4c6ae0cb3af7f51e2ee` |
| `csv/20260930_sesion-evaluacion_etapa7_episodios_03.csv` | 13143 | 11 filas | `5001d2a11f85de1b3e1fa646807a5dd6a1058274ba498854372e03403b350b3a` |
| `csv/20260930_sesion-evaluacion_etapa7_episodios_04.csv` | 13413 | 11 filas | `0ab82d0341ca33dd41f9e9a7b982bf0b37a338cb7eaf40a83d4d2fa6e6018290` |
| `csv/20260930_sesion-evaluacion_etapa7_episodios_05.csv` | 13246 | 11 filas | `804190cb23522ec2fde452d4462a19a4d27a7f33a026ed0dd781bf52d56e4e26` |
| `csv/20260930_sesion-replica_etapa7_capas-on_de-20260930.csv` | 8421 | 30 filas | `f9c509619b4939aac64d7e5b7f35b6ff394049b9da32fe2ecbe7219b76ea6015` |
| `csv/20260930_sesion-replica_etapa7_capas-on_de-20260930_02.csv` | 8511 | 30 filas | `a363428b35b70bae2e9b497ed00d02dd84d38df1f425e82b982f4786d2e8edbd` |
| `csv/20260930_sesion-replica_etapa7_capas-on_de-20260930_03.csv` | 8492 | 30 filas | `504b66c6e00b94be883deff0b7aa3f7a9969594081be6684de30739ba8e9775c` |
| `csv/20260930_sesion-replica_etapa7_capas-on_de-20260930_04.csv` | 8500 | 30 filas | `a01e16986f3c4ca8672ee6c9bd69de82efed3e5a922648afbd43dc1587410115` |
| `csv/20260930_sesion-replica_etapa7_capas-on_de-20260930_05.csv` | 8570 | 30 filas | `8930bb6f1acdaa3550a3384c42243dfe0c32b9f1558411b4d261660f7ba48ac0` |
| `csv/calibracion_medida.json` | 12788 |  | `9d1033124c2646ffad07863dc65a12af4f530f3aaceefbdc0ac793f8ce73db66` |
| `derivados/a30f_congel_eventos.csv` | 8410 | 41 filas | `b03899c81d6a26f958b3047176012594d60b554584bed6e6fde85b29943f510e` |
| `derivados/a30f_congel_eventos_salida.txt` | 37861 |  | `a588a0fcc3176403d656102fa9a54b238e1f5cf803fa4928ce7d15d22a9c791a` |
| `derivados/a30f_congel_extra_salida.txt` | 16032 |  | `a258639299d17e5a79dd6e2398e2e1ef826fae77a08251398566a38e8617a30e` |
| `derivados/a30f_congel_mapa_salida.txt` | 12405 |  | `01120d771334e32205ada83e3eeef4b3facd7d75a922560ac16bbdc2ff53e05b` |
| `derivados/a30f_congel_retroceso_salida.txt` | 21192 |  | `dc9b66aafa0772870aeb99ceb6d627c5c1e7077718055afe57dde39f8c04c79b` |
| `derivados/a30f_congel_ritmo_salida.txt` | 13298 |  | `fc2878a01e6622402acee7f6a6830e48c9f9d0a477c89dac0d15e89a409bbd31` |
| `derivados/a30f_congel_tabla_salida.txt` | 5524 |  | `643e297857395635d89f5aa36161adf7a4b3947976a30a4344533948764e9fd2` |
| `derivados/a30f_critico_1_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_critico_1_salida.txt` | 10952 |  | `b5fe0b53b5151e08ca02d978021726e8978237333cb4ac854b84f4a21027d95f` |
| `derivados/a30f_critico_2_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_critico_2_salida.txt` | 13364 |  | `5b87651f8bff8cdc162e7b3777a22b1807e0e33a3c80eb80578c9965ef1e27b8` |
| `derivados/a30f_critico_3_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_critico_3_salida.txt` | 2571 |  | `575d14a6cd3b6334e0979b4d05ec5c17f91fc7036984704619c0ab6dcb089c2e` |
| `derivados/a30f_critico_4_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_critico_4_salida.txt` | 1404 |  | `18099ed3ade6f1b58e20474055d6a1b512df0b87216b1dca2543010c38eeb4a6` |
| `derivados/a30f_critico_5_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_critico_5_salida.txt` | 712 |  | `2777375b687b64b4fa0f29b8a4a14795c3fdbf7c9e39d572cf17db444a7ac885` |
| `derivados/a30f_critico_6_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_critico_6_salida.txt` | 2002 |  | `1babaaa2d254ee6bf8f303f46029690f8fce58f583c9d6073eeee34860500650` |
| `derivados/a30f_critico_7_tiempos_salida.txt` | 1646 |  | `acb6ac00d115035d9531c24bc9ae1dd2ceb28c09c890810dcd19e79e44418d63` |
| `derivados/a30f_critico_8_punto_salida.txt` | 289 |  | `75d084be270994f625f97cf216f23e62b1f0ee9b81fecf3bebf78954ef824437` |
| `derivados/a30f_deriva_detalle_salida.txt` | 2380 |  | `53a7bc627582034513bfaedac336adf75ff650070a614144de9db58420c59c56` |
| `derivados/a30f_deriva_explora_salida.txt` | 17010 |  | `3a297f9a98daafdb46d124044f050d23410d5cd584ecb2e8af803d1088cecf88` |
| `derivados/a30f_deriva_metricas_salida.txt` | 12245 |  | `b0ce0a4e7fec6dda9f1bdc1f953aa9a624edfba30395d03450dd8d071783d7a9` |
| `derivados/a30f_deriva_por_robot.csv` | 77808 | 300 filas | `c9ca17eb9d19f463eb30334bcd45acc91fce7a4e89a2c2a09480e3302bfead7c` |
| `derivados/a30f_deriva_principal_salida.txt` | 25671 |  | `f54486e77a0b15ffcbd74adefaee984046e32dd91ad26e41f5f1638ca87dce5e` |
| `derivados/a30f_metricas_1_salida.txt` | 29563 |  | `a92baaaf66d9344714c4baf490fce12729dbfc2ec7458ef56d7e67de2b7d16c1` |
| `derivados/a30f_metricas_2_salida.txt` | 11098 |  | `8de8fb543b5a61d4c36004948edc8c496b103a02ffd704fb9bce85dac36e30d5` |
| `derivados/a30f_metricas_3_salida.txt` | 10036 |  | `97a7c327a7f39c5fef3be8e388a8a96af2bedab322acad648cbec94ad4ecc93a` |
| `derivados/a30f_metricas_4_salida.txt` | 9709 |  | `6360899fc3bd743921e686247a3e7104408d905c80292c0626e21460078352e2` |
| `derivados/a30f_metricas_5_salida.txt` | 3032 |  | `0ab42438a181a2fb8171440dfdabbdde7daa64c282af75819cd00e8edd399a2e` |
| `derivados/a30f_metricas_mtimes_antes.txt` | 18085 |  | `61bd3be20803a9f7e1080faeb43948b5050e3bcd5d6beee2cc1db5a157142df9` |
| `derivados/a30f_metricas_mtimes_comparacion.txt` | 62 |  | `5e647ba2ba78a7444e7431f139bad8ad31ff1e1bcfb1cd9355a1019443573b10` |
| `derivados/a30f_metricas_mtimes_despues.txt` | 18085 |  | `61bd3be20803a9f7e1080faeb43948b5050e3bcd5d6beee2cc1db5a157142df9` |
| `derivados/a30f_metricas_tabla.csv` | 23249 | 76 filas | `a6c99c8716b58ece6925ef69b852cb52eae52030522a5bd63cc73b91c77c6894` |
| `derivados/a30f_robots_anomalias_salida.txt` | 13917 |  | `23ffeba8512925dca79fae4f9043530dea302546274216cd14623808df5a76aa` |
| `derivados/a30f_robots_bloqueo_cbf_salida.txt` | 14725 |  | `58b47ab51a29a7535e5ff7aad0d6c1b2e5a708a578b66e12e0c3e6e5b18b375e` |
| `derivados/a30f_robots_colocacion_salida.txt` | 24441 |  | `a0d67ae566aabdd88e84250b542cc99a368752a765004f66a2809fdfbbb5176a` |
| `derivados/a30f_robots_consola_salida.txt` | 45130 |  | `d8c0f28b912f9c695ec5c22aa215c01cb41ce019b209f2baa3ae087f87aaf3cb` |
| `derivados/a30f_robots_diversidad_salida.txt` | 10019 |  | `81ae3adc929b805d07f917fc3d7cd8343cf0c32bcadec693ccbce59203eb0779` |
| `derivados/a30f_robots_extras_salida.txt` | 1379 |  | `a840b880e5de23e614251dfb8a574b6b241072bb21496d57fcf7e599df979654` |
| `derivados/a30f_robots_mtimes_antes.txt` | 20453 |  | `ed2e740110e067f2a7d7e19ed3cfbcebfb7ecfef7e1c222358b3a0e1f5754f02` |
| `derivados/a30f_robots_mtimes_despues.txt` | 20553 |  | `cc38c13c9b1c69be85c6370df6641a664f39fdd082cc60d5b7cd133c5d9f7b3e` |
| `derivados/a30f_robots_ritmo_salida.txt` | 4892 |  | `415e007b3186eba22bf4d31a9fd26d9c9fd32c83a94efe540fb08fd09d9ad669` |
| `derivados/a30f_robots_validez_salida.txt` | 19834 |  | `c0d65b6fab9408274ac5645b6453acb27d10d2071790bc4956054dfa200df346` |
| `derivados/a30f_robots_wlan_salida.txt` | 14227 |  | `be1fe7ccb0473eafb00dc24406a1be14020f4ca7bb17b414b942d8ba451a23d1` |
| `derivados/a30f_verif_congel_1_salida.txt` | 42062 |  | `e04e6c62bff54bfca43e3096e81a6bb62e5ef827ca96062a934049d74ccbbb18` |
| `derivados/a30f_verif_congel_2_salida.txt` | 7059 |  | `f41e35d9fad8ea393574fc2355945a53986f14092adb31b49b6b6f05937a06bb` |
| `derivados/a30f_verif_deriva_1_consola_salida.txt` | 37016 |  | `4ddc74dcdb58d5f403ec6e6f025dd2d7af468034d8c98dfcd5567b1630fa00c1` |
| `derivados/a30f_verif_deriva_1_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_verif_deriva_2_codigo_metricas_salida.txt` | 8095 |  | `940f78142ce6fdc236e1ba2aef08f404240f7c5165904d67f57cfbc7ab11da19` |
| `derivados/a30f_verif_deriva_2_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_verif_deriva_3_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_verif_deriva_3_extras_salida.txt` | 3608 |  | `207f456f898f362e529957fe140f6699bd68dfe4d8d5c4399f603236ebce6253` |
| `derivados/a30f_verif_deriva_4_direccion_salida.txt` | 2586 |  | `65d32502eea4c44b7c1f51985daf7e1a85eab065765a89a075ebb8ad8c390de6` |
| `derivados/a30f_verif_deriva_4_err.txt` | 0 |  | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `derivados/a30f_verif_deriva_grep_tmp.txt` | 43213 |  | `1c2da13208a1a3bc56e877e2b2754c9044213bad321fc0a4db2c61a1e2cce1fa` |
| `derivados/a30f_verif_deriva_por_robot.csv` | 73507 | 325 filas | `8c3434c7f17b00bef37cf77f83605edb1d3aa9d49be76361015160ad32e49a1d` |
| `derivados/a30f_verif_metricas_1_salida.txt` | 33473 |  | `9bf40d136f6c0cf975c6db08ded2ab54d0ae33042681b2ca18c7703f9db14452` |
| `derivados/a30f_verif_metricas_2_salida.txt` | 7044 |  | `de174c05ff2497471a4e03cc036c77b48370d31cd6e4d745ffe0a27b61706104` |
| `derivados/a30f_verif_metricas_3_salida.txt` | 3994 |  | `57d0de4088ff1f72f259d6488336f17afb66ba40e9f99fe97ad4fb2890aea88f` |
| `derivados/a30f_verif_metricas_snap_antes.txt` | 20185 |  | `bd79b5b9264972a5c11e361a56b2d947544455b497f23141dcf84472028dddca` |
| `derivados/a30f_verif_metricas_snap_comparacion.txt` | 471 |  | `30c66ffcf65f8a71008f8671dae8c17d5c24d5b7761e4ebfe05df2d103ed5913` |
| `derivados/a30f_verif_metricas_snap_despues.txt` | 20284 |  | `3d633e4c11a00ebe46afdb22d00a9d0ea53f89268dd2873cb3cb952269ad457b` |
| `derivados/a30f_verif_metricas_tabla.csv` | 14121 | 76 filas | `5b71cd8a3f062ad64eed53d75c5e10baeaa70a0c5cea0725572bb500acee929f` |
| `derivados/a30f_verif_robots_10_solo_lectura_salida.txt` | 54 |  | `5853b3a0b721ded090d9c45fbdb9f40ee243b692e0dcb1f6e93121c68cd4c336` |
| `derivados/a30f_verif_robots_11_pose_vieja_salida.txt` | 867 |  | `986a29ecf5ecf79e09b392300128015fffb2647da8085e7d380c3f2aa3216b1f` |
| `derivados/a30f_verif_robots_1_episodios_salida.txt` | 11128 |  | `baf1ff37edd8acd5eedbc59bb968d3cfd7f96c569b0d8ec26e64783c8e1e046e` |
| `derivados/a30f_verif_robots_2_decisiones_salida.txt` | 13556 |  | `d82f09303e3fce85ffcdb8f7fe6c9be0e0b4af43fcd39b6c6f86d90c891792e8` |
| `derivados/a30f_verif_robots_3_consola_salida.txt` | 18620 |  | `461a69b12a30df51f76e5e43f32982eabca0ddc39a867d13952463ea735b2807` |
| `derivados/a30f_verif_robots_4_diversidad_salida.txt` | 4108 |  | `47e0b3bcd9caec46c650f1ac7c747a1d8652700a649a0d6ce1c92173780f1a59` |
| `derivados/a30f_verif_robots_5_wlan_salida.txt` | 17390 |  | `867a94fff0893b3bb7184be61cf8246266e4e3804781b4b961a9282a14736b00` |
| `derivados/a30f_verif_robots_6_codigo_ritmo_salida.txt` | 3843 |  | `3293217c753c28efcc7425e6edde6ab06319b8dd474dd3ae4a051794562aaa5b` |
| `derivados/a30f_verif_robots_7_cbf_salida.txt` | 10540 |  | `82a93055eeaf4d7b2dc2a89f9a06bc15c8edde045787b561bd1d8888707889a9` |
| `derivados/a30f_verif_robots_8_extras_salida.txt` | 1903 |  | `844fa7acff1725b4d8f7ffdd5e1508d212e16a6dab90bd60aafe55a91515259f` |
| `derivados/a30f_verif_robots_9_seguridad_arranque_salida.txt` | 730 |  | `ef2480327170f21e4b1a21e067277b5c2af5fc232c07fed673fb6febfe742658` |
| `derivados/pareo_extra_0930_salida.txt` | 5643 |  | `36d6390e5d179344afbd6261de22e45876b5e3cc69f0589e8bc3c725078c5ed7` |
| `derivados/pareo_final_0930_salida.txt` | 5525 |  | `65903f9ce3d565a8cbdc5a74d3ada925e50ec80da14a81c3cc4c1f6470fca66e` |
| `derivados/pareo_final_0930_sha256_antes_de_correr.txt` | 221 |  | `5e321279ed12999d685983409dd52a2fdaf7ce354b9d5fc5fe27bbd81213b8a3` |
| `derivados/replica_0930_hashes_pila_comprobacion.txt` | 491 |  | `4238f89c6efee0f2792894dc3431e2eb188917672d66aa77fc6e3a4f6a199ec0` |
| `derivados/replica_0930_hashes_pila_final.txt` | 880 |  | `b7b95cf927f596fe7367992f51ce7ee2df83bb54ba07f6459d09aa635b82ccce` |
| `derivados/replica_0930_log.txt` | 5987 |  | `6d052c9194b4de8b13eaab9112b81dd1a6f9be168db10b1a5f64cfdf7a98f26d` |
| `derivados/replica_0930_todas_log.txt` | 47586 |  | `c0492e6b1f54cb1eac698b209fcbab71d6b98e195fed5c4c2908597063b5de69` |
| `derivados/verificar_s1_coherencia_salida.txt` | 18510 |  | `d52e4011a46ce81905e23228dcf707657bf39961494a9ba42c8067e30d0a6ac0` |
| `derivados/verificar_s2_corridas_salida.txt` | 19559 |  | `faad89b864bb15cdebfedc878535bab221e9e82fefbf671ddbe88d8992b93037` |
| `derivados/verificar_s3_pareo_salida.txt` | 15375 |  | `3ec8e35e864f827bce53b978edbcd5685c958677b2f0e307dcf60606d0fd270d` |
| `derivados/verificar_s4_seguridad_salida.txt` | 14931 |  | `5c78e8ec54f78f68fdfe6a8182e6cd67d64a8d6cca3137ba608fc1b8524d9fd6` |
| `derivados/verificar_s5_deriva_salida.txt` | 8545 |  | `a677822bb0304c89a12104c7f1203b6758dd842dd2193e0c2f0af363b3575bbb` |
| `derivados/verificar_s6_congel_salida.txt` | 23931 |  | `e775545d21abd9c3e32ca24f22673b35c4928aef4ae164633272ba13611483ba` |
| `derivados/verificar_s7_robots_salida.txt` | 17578 |  | `02f95c0929219297a52555b3a25f5d6fbcd4e16df20186ebc93691d7a7053d1a` |
| `derivados/verificar_s8_correcciones_salida.txt` | 3347 |  | `fc1aaa3ab85419d9e9cd5240c4806d99d1edfd6169e310b02121bab049c7f4ed` |
| `derivados/wf_0930_extraido.txt` | 151939 |  | `0b041eb863bb3667e4c5203b41bae7a7b42dc58c9fff0fec5918b23b205999cb` |
| `figuras/a30f_congel_mapa.png` | 616582 |  | `3f5fbcecf595df4e7d093960168ffcded86005f2881a73f04cf1cb47cd247c5b` |
| `scripts/a30f_congel_clase.py` | 2335 |  | `9d992a410672dfd36db5f0109c6323e43683303aec5a80835fd1ef4b1e3b28da` |
| `scripts/a30f_congel_comun.py` | 11611 |  | `c5713aa780c9fe33b37b1f3c30e44e09b0cc62b6f7fd59bb42cb39b178b77e34` |
| `scripts/a30f_congel_eventos.py` | 14196 |  | `7af06a7bda5b2a2256f29f83d0d8e36a2aa402aa565f7fb85dbe3cc677ba71f0` |
| `scripts/a30f_congel_extra.py` | 10948 |  | `92ed654b2e85fa57e6a59cd4aeaa26b46147c8b2c546efe1845a3b1bee620862` |
| `scripts/a30f_congel_mapa.py` | 14732 |  | `0be504d6042a7f03189fb8587ce0b18d005877d21441f9e136a98c5f9ac39d42` |
| `scripts/a30f_congel_retroceso.py` | 8817 |  | `4129ac9fba6e0e6a14bb465a1785e3dcd054252031f8d28a7633b9b730aed095` |
| `scripts/a30f_congel_ritmo.py` | 7812 |  | `6f003dde1d9b1d5b1c087cbf77fcf58e1412b94c4fddf0b85566832f45466899` |
| `scripts/a30f_congel_tabla.py` | 4576 |  | `911f43948d1036231550d6f581b5b37cbaa63c480d8844f103aedd763f78ebb0` |
| `scripts/a30f_critico_1.py` | 15033 |  | `991de9050c86528c235315840b089ddbc7411b9c4f47e2b364ebfad5f96fb130` |
| `scripts/a30f_critico_2.py` | 8934 |  | `681d856ec54e61bc620264fc2d5764b7171c9f54be60ba2e395d569fcdfaf602` |
| `scripts/a30f_critico_3.py` | 7314 |  | `1700cc9dc793d1d4a5e73f17f6f1e34af3606346ad161084b7a5529dd21ac9d5` |
| `scripts/a30f_critico_4.py` | 3158 |  | `1615aa4f648bdddba4c926a28fa0d5f8825aa40f815e14c743be79530c5fdf89` |
| `scripts/a30f_critico_5.py` | 3357 |  | `831743b161b835c85369915b3f562d2468fe01060128ecb902c41228066ac670` |
| `scripts/a30f_critico_6.py` | 4291 |  | `70d8a4f4abd9b5f8ca1de11fe7c6b46182ba60f48cbc3e073fce72f035070da0` |
| `scripts/a30f_critico_7_tiempos.py` | 2038 |  | `1327416f01b7a45f0319ba4e9bced10b1910d9d85ac2516a8a634835f6851877` |
| `scripts/a30f_critico_8_punto.py` | 739 |  | `f184ed0251c9e9e4e76733b1bc6b5081711d656ad8587df686fe0773af3586c3` |
| `scripts/a30f_deriva_detalle.py` | 2978 |  | `997173b964da8ce68982ca7b852fa093ea12cad7cfb87236418400ef3951c0c9` |
| `scripts/a30f_deriva_explora.py` | 1620 |  | `903bddbf529c5b775d34e6f089c131e3627446bfc70bf968fa3f0990016237e2` |
| `scripts/a30f_deriva_metricas.py` | 5813 |  | `cbf543a931aba53819f1193284e587d317bdb0f2d32494368765aa486bc8c067` |
| `scripts/a30f_deriva_principal.py` | 22500 |  | `84ec1c5a03355eb5dd78f63ca4ab79bcc09a09fb991216af0035820feff3dc1b` |
| `scripts/a30f_metricas_1_tabla.py` | 13501 |  | `b665235f2004ca6a728555e4ae9e297b78df5381f49a556f4a16046d83e1f2be` |
| `scripts/a30f_metricas_2_heterogeneidad.py` | 15028 |  | `1f7f6ed8fdc6dcf4b35db25363dee020a4eabdcfbddb66792d29ab71c4fd1388` |
| `scripts/a30f_metricas_3_repetibilidad.py` | 8560 |  | `d3eca6f1c8939534a135187fe5b7f1187600b9c2889b6698153e0b8ff62c1692` |
| `scripts/a30f_metricas_4_seguridad.py` | 8890 |  | `334b05c47110eacfcc41b5f068205e5832355acbe8e1a69d015226d139a77ef7` |
| `scripts/a30f_metricas_5_ic.py` | 5935 |  | `7ff8e93bfe7d2a774c1c59b9c0e2b56df572629c51c3bca1207583947791dcdd` |
| `scripts/a30f_metricas_comun.py` | 4230 |  | `5864a189be5bf50a9e6f72a35f77b9f751e968362140bd8f98a57dd9a28fd3a6` |
| `scripts/a30f_metricas_mtimes.py` | 1640 |  | `048fe7c8fb08e46df52afdb088e94328da04eb85f155b93e766072109efdd877` |
| `scripts/a30f_robots_anomalias.py` | 7151 |  | `7ceb9b48d11469987d5c0412d7a8ec18d03da95df6440b3dc030966f011f37e6` |
| `scripts/a30f_robots_bloqueo_cbf.py` | 9538 |  | `4954a2e793ad0b7a039d47aa137c21cd9dd54d16452c97b655c7a6fd382546af` |
| `scripts/a30f_robots_colocacion.py` | 7440 |  | `7aab829f51a230139683f0af5017c34ccbd8ad132f979d2b5e289429f4afce6a` |
| `scripts/a30f_robots_comun.py` | 4084 |  | `baa855e7882cb4ac5cab55974a4ee78468f512b711b9307a2ad26921c178f361` |
| `scripts/a30f_robots_consola.py` | 16590 |  | `a0c102f75fd16a597d3574c42b0cabff72bba09a7ec46df2fcd0d0520586e284` |
| `scripts/a30f_robots_diversidad.py` | 5553 |  | `eaab7dce23c1b6a53e1f8cfda421d82a19b3f9a229d0822ef5172221c2137cf9` |
| `scripts/a30f_robots_extras.py` | 5654 |  | `452b26743bf4759bebb960c8260f624d4b7c116fd8dc01e265dfa3738c6246d4` |
| `scripts/a30f_robots_mtimes.py` | 1037 |  | `6dd7295c04c80a2bffe3458d1ef42dc67393dd1f4ed3db405a04d160a852875d` |
| `scripts/a30f_robots_ritmo.py` | 5278 |  | `e6fe65e436b8eeaccee1f85af7d665bec18aae16acc2a739861c194b50a232a4` |
| `scripts/a30f_robots_validez.py` | 10739 |  | `ed1b064cebf07aae6629771222fef3207ae0e1afc8e4d85574a67e94b580d83d` |
| `scripts/a30f_robots_wlan.ps1` | 2715 |  | `e90b2bd41a84806af4e2c32b923fb5a0680a5ac57010d54b0ced49581cd8fb0c` |
| `scripts/a30f_verif_congel_1.py` | 38038 |  | `0771a2f1ea418c2b4567ffaec2eabfa13a01559d69e931070716758d14953f40` |
| `scripts/a30f_verif_congel_2.py` | 6664 |  | `6b4094e9abf732ae27904eff28d1a9fc219a3e78fd00b5fa64eebd0a2e84c895` |
| `scripts/a30f_verif_deriva_1_consola.py` | 27988 |  | `c4828d5ef48c1b7c8d44fe04852ac41ea53d05759fc8cb50d013b2a576693c3d` |
| `scripts/a30f_verif_deriva_2_codigo_metricas.py` | 5712 |  | `1f2e03c1fa57edc2068bc60b35eb328dd65df7ec48b1a482d272f75f2b42b283` |
| `scripts/a30f_verif_deriva_3_extras.py` | 5751 |  | `6ffaefbdc3434dd09209af99d9f888bc1123bd7b8400febc80c918fe2ce8f666` |
| `scripts/a30f_verif_deriva_4_direccion.py` | 5387 |  | `699c5ffed54c1cd9e01b7ecf134b57cd3678ca67274c12c06887c2f571b1f703` |
| `scripts/a30f_verif_metricas_1.py` | 35510 |  | `ff765387635a7c907b986a6b8443c09689de55192803ffc51fdf2886580fd8b6` |
| `scripts/a30f_verif_metricas_2.py` | 9580 |  | `fad424ad30d8ed9dce54c9530cce95f78ad2529cf23edba4df8a440682d21906` |
| `scripts/a30f_verif_metricas_3.py` | 5802 |  | `015743f7b56db4cd772d5081376a09e405b2770c697cceabbf50c3b8c2643ebd` |
| `scripts/a30f_verif_metricas_snap.py` | 2754 |  | `4306410474fd468526d0ebccfa766421684f3ddd1ac62ec240ae139d22e38da1` |
| `scripts/a30f_verif_robots_10_solo_lectura.py` | 1501 |  | `4d8020f675142215a9aa81ac24be47e3eb5816e9475197803432b457b26d5a65` |
| `scripts/a30f_verif_robots_11_pose_vieja.py` | 2673 |  | `86c6a2973c89d43ca3886d68a2786ea288bd0e1bd6186cdb293c4dee9a872d36` |
| `scripts/a30f_verif_robots_1_episodios.py` | 11176 |  | `fcd0c38e8b35e53081be95c3d5215d16e9b9741aec9865e0055926ee84ea245e` |
| `scripts/a30f_verif_robots_2_decisiones.py` | 10649 |  | `6ac137c0fc4babb26880d13ac8176b1e923e5e1bdd753afe97e6b627c29016a1` |
| `scripts/a30f_verif_robots_3_consola.py` | 5396 |  | `762cfb36ed29427606bbc3e5c53906f83badabcea5b638969688ebdc317f67a5` |
| `scripts/a30f_verif_robots_4_diversidad.py` | 7338 |  | `72fcda8c6c5d8926cfb77b157e0953ca2cfc3ef79b1d7d81bfe55ce2dbb8860e` |
| `scripts/a30f_verif_robots_5_wlan.ps1` | 2453 |  | `ef91ccb95df7ea6920dcfce71a030a743a9287ef47d37a7ef25182ddcc019366` |
| `scripts/a30f_verif_robots_6_codigo_ritmo.py` | 4692 |  | `59c10e74c78597a0f026edcbf063d7d2f3dbfea2942420656b89657250afd831` |
| `scripts/a30f_verif_robots_7_cbf.py` | 8341 |  | `0202713cd385c1c3e37396e15dbfddc0aabe9997e2eb850592d86b057d04451e` |
| `scripts/a30f_verif_robots_8_extras.py` | 2263 |  | `25fdcd2526905c7b3427c774f60c7f57a2af1c8bc8bad34c8f89f265822fdc87` |
| `scripts/a30f_verif_robots_9_seguridad_arranque.py` | 2529 |  | `07d0def8a0526c178a919de69f7d9f65cb631c150af572f0b32c7a4cc45aab3f` |
| `scripts/arreglo_detencion.py` | 4310 |  | `b834a5e6b819a2a69b7d1824df82a1c32863b08628f9456dc577892d12193241` |
| `scripts/pareo_extra_0930.py` | 7028 |  | `5221bc6987d1aa9a707ace2b8a5487ba4b6f81d2e088f57f11b7705177b0ce11` |
| `scripts/pareo_final_0930.py` | 10073 |  | `a5cc45b63990699af21a5633236abb587e90ef0f464d28b4b1a31edcbbcb4de3` |
| `scripts/verificar_cifras.py` | 1999 |  | `5e1efa6d5f1be6210376dde995590a197f7a980220f5ecc6fb0f04b6d2c76140` |
| `scripts/verificar_s1_coherencia.py` | 45249 |  | `bb278a20deb6750d3261f81c420eb4efc760396c4453f8504167d791d3c27f50` |
| `scripts/verificar_s2_corridas.py` | 38334 |  | `5c934ae03975d574c8b4148acb26b1961c67eb874c1b06d4ab53666ec4d9c992` |
| `scripts/verificar_s3_pareo.py` | 29998 |  | `82454efadd5dcc482f25790e94da225b999497d4718d78d772c2818f8d52384b` |
| `scripts/verificar_s4_seguridad.py` | 40533 |  | `b592ef2e2e67a2b2475b18d7e409c630053a609d4f2770d0da790744336dcc6a` |
| `scripts/verificar_s5_deriva.py` | 25403 |  | `14944e7b2f25a2e51ac14b8b9161c312d133f07b0fd13d5af97ce25bc41fa461` |
| `scripts/verificar_s6_congel.py` | 44838 |  | `b06f137ef1c948c20e058bb1318b16911ae604641598a37d51f5a1d2e6800d46` |
| `scripts/verificar_s7_robots.py` | 42136 |  | `594a5326f0e4fe23877e4a3a4ea95f507e3e387e8d7093a08e4c7fad5cfdc886` |
| `scripts/verificar_s8_correcciones.py` | 14466 |  | `91202ead1321ab3abd747c93d164faca9df918b74dade355bac050212a675fd6` |
