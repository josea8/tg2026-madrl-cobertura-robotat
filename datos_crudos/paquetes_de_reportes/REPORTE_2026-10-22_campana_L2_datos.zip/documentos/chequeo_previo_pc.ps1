Add-Type -Namespace Chequeo -Name Energia -MemberDefinition '[DllImport("kernel32.dll")] public static extern bool GetSystemPowerStatus(byte[] estado);'
$ref = @{ plan = '381b4222-f694-41f0-9685-ff5bb260df2e'; modo = 'ded574b5-45a0-4f42-8737-46345c09c238' }
$nombres = @{ '00000000-0000-0000-0000-000000000000' = 'Equilibrado'; '961cc777-2547-4f9d-8174-7d86181b8a7a' = 'Mejor eficiencia energetica'; 'ded574b5-45a0-4f42-8737-46345c09c238' = 'Mejor rendimiento'; '381b4222-f694-41f0-9685-ff5bb260df2e' = 'Equilibrado' }
$k = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes'
$plan = "$($k.ActivePowerScheme)"
$modo = "$($k.ActiveOverlayAcPowerScheme)"; if (-not $modo) { $modo = '00000000-0000-0000-0000-000000000000' }
$e = New-Object byte[] 12; if (-not [Chequeo.Energia]::GetSystemPowerStatus($e)) { $e[0] = 255; $e[3] = 255 }
$enchufada = $e[0] -eq 1; $ahorro = $e[3]
$procesos = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'chrome|chatgpt|omen|overlayhelper|systemoptimizer' -or $_.CommandLine -match 'servidor_inventor_mcp' })
"chequeo previo de la PC: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
"  corriente: $(switch ($e[0]) { 1 {'enchufada'} 0 {'A BATERIA'} default {'desconocida'} }) | ahorro de energia: $(switch ($ahorro) { 0 {'apagado'} 1 {'ACTIVO'} default {'desconocido'} })"
"  plan: $plan ($($nombres[$plan])) | modo enchufada: $modo ($($nombres[$modo]))"
"  procesos: $(if ($procesos.Count) { ($procesos | ForEach-Object { "$($_.Name) [$($_.ProcessId)]" }) -join ', ' } else { 'ninguno' })"
if ($enchufada -and $ahorro -eq 0 -and $plan -eq $ref.plan -and $modo -eq $ref.modo -and -not $procesos.Count) { 'CHEQUEO OK' } else { 'CHEQUEO FALLA: no lanzar' }
