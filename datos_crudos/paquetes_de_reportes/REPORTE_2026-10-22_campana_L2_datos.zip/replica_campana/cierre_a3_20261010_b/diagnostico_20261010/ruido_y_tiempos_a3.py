"""Diagnóstico del a3 NO PASA (2026-10-10), sólo lectura; no cambia el veredicto
ni el margen. Tres cosas:
1. por episodio, las reps nuevas y las del 30-09, con el ciclo p95 y el error
   de pose inicial de cada corrida;
2. en qué paso se separan las reps nuevas entre sí (> 1 mm y > 5 cm);
3. bajo intercambiabilidad (las 6 coberturas de cada episodio, 3 nuevas + 3
   del 30-09, mezcladas), la probabilidad de que la regla dé PASA y la de una
   |media Δ| como la observada.
Correr desde cualquier carpeta: python ruido_y_tiempos_a3.py
"""
import csv
import itertools
import math
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

AQUI = Path(__file__).resolve().parent
A3 = AQUI.parent
C = A3.parents[2]
os.chdir(C)
sys.path.insert(0, str(C))
import replica_con_obstaculo as R  # noqa: E402

SES = {"30-09": "", "30-09_02": "_02", "30-09_03": "_03", "30-09_04": "_04", "30-09_05": "_05"}


def leer(p):
    with open(p, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


tomas = leer(sorted(A3.glob("*_replica_tomas.csv"))[0])
viejo = {}
for s in SES.values():
    for r in leer(R.DIR_3009 / f"20260930_sesion-replica_etapa7_capas-on_de-20260930{s}.csv"):
        viejo[(s, int(r["episodio"]), int(r["rep"]))] = r

print("1. Reps por episodio (cobertura · ciclo p95 ms · error de pose inicial m)")
nuevo = defaultdict(list)
for r in sorted(tomas, key=lambda r: (SES[r["id_sesion"]], int(r["intento_campana"]), int(r["rep"]))):
    s, ep, rep = SES[r["id_sesion"]], int(r["intento_campana"]), int(r["rep"])
    v = viejo[(s, ep, rep)]
    nuevo[(s, ep)].append(float(r["cobertura_aoi"]))
    print(f"  s{s or '_01'} ep {ep:>2} rep {rep} | nuevo {float(r['cobertura_aoi']):.4f} "
          f"{float(r['ciclo_p95_ms']):5.1f} {float(r['error_pose_inicial_m']):.1e} | "
          f"30-09 {float(v['cobertura_aoi']):.4f} {float(v['ciclo_p95_ms']):5.1f} "
          f"{float(v['error_pose_inicial_m']):.1e}")
p95n = [float(r["ciclo_p95_ms"]) for r in tomas]
p95v = [float(viejo[(SES[r["id_sesion"]], int(r["intento_campana"]), int(r["rep"]))]["ciclo_p95_ms"])
        for r in tomas]
print(f"  ciclo p95 medio: nuevo {np.mean(p95n):.1f} ms · 30-09 (mismas corridas) {np.mean(p95v):.1f} ms; "
      f"ciclos > 100 ms: nuevo {sum(int(r['ciclos_sobre_100ms']) for r in tomas)}")

print("\n2. Paso en que se separan las reps nuevas (> 1 mm · > 5 cm)")
P = defaultdict(dict)
for r in leer(sorted(A3.glob("*_replica_decisiones.csv"))[0]):
    P[(int(r["intento_campana"]), int(r["rep"]))][(int(r["paso"]), int(r["agente"]))] = (
        float(r["pose_env_x"]), float(r["pose_env_y"]))


def primera(ep, a, b, umbral):
    pa, pb = P[(ep, a)], P[(ep, b)]
    for p in sorted({p for p, _ in pa}):
        if max(math.dist(pa[(p, i)], pb[(p, i)]) for i in range(R.N_AGENTES)) > umbral:
            return p
    return None


for s, ep in sorted(nuevo):
    print(f"  s{s or '_01'} ep {ep:>2}: " + " | ".join(
        f"r{a}-r{b} {primera(ep, a, b, 1e-3)} · {primera(ep, a, b, 0.05)}"
        for a, b in ((1, 2), (1, 3), (2, 3))))

print("\n3. Intercambiabilidad (no cambia el veredicto: el margen y la regla son los aprobados)")
reps_v = R._reps_3009(R.DIR_3009)
delta = R.delta_a3()
claves = sorted(nuevo)
obs = np.array([np.mean(nuevo[k]) - np.mean(reps_v[k]) for k in claves])
perm = []
for k in claves:
    v = nuevo[k] + reps_v[k]
    perm.append(np.array([np.mean([v[i] for i in a]) - np.mean([v[i] for i in range(6) if i not in a])
                          for a in itertools.combinations(range(6), 3)]))
rng = np.random.default_rng(20261010)
M = 200000
idx = rng.integers(0, 20, size=(M, len(claves)))
D = np.stack([perm[j][idx[:, j]] for j in range(len(claves))], axis=1)
m, s_ = D.mean(1), D.std(1, ddof=1)
t = stats.t.ppf(0.975, len(claves) - 1)
semi = t * s_ / math.sqrt(len(claves))
pasa = (m - semi >= -delta) & (m + semi <= delta)
print(f"  δ = {delta:.5f} · media Δ observada {obs.mean():+.5f} · mediana Δ {np.median(obs):+.5f}")
print(f"  P(PASA | intercambiables) = {pasa.mean():.3f} · P(|media Δ| ≥ observada) = "
      f"{np.mean(np.abs(m) >= abs(obs.mean())):.3f} · Wilcoxon de los 12 Δ p = {stats.wilcoxon(obs).pvalue:.3f}")
print("  Δ por episodio: " + ", ".join(f"s{k[0] or '_01'} ep {k[1]} {d:+.4f}" for k, d in zip(claves, obs)))
