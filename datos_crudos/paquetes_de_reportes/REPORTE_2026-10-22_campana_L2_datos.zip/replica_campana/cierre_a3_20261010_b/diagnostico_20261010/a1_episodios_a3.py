"""Diagnóstico del a3 (sólo lectura): el a1 a nivel de decisión sobre los
episodios que más pesan en el NO PASA. Pila A (30-09) vs pila B (nueva, sin
obstáculo) ante las MISMAS observaciones (poses hw del 30-09)."""
import contextlib
import io
import os
import sys
import unittest

import numpy as np

C = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
os.chdir(C)
sys.path.insert(0, C)
import replica_con_obstaculo as R  # noqa: E402
import test_replica_con_obstaculo as T  # noqa: E402

CASOS = [("_05", 2), ("_05", 8), ("_02", 12)]

prueba = T.PruebaA1Decision("test_mismas_acciones_ante_mismas_observaciones")
for suf, ep in CASOS:
    prueba.setUp()
    try:
        eps = R._leer(R.DIR_3009 / f"20260930_sesion-evaluacion_etapa7_episodios{suf}.csv")
        fila = [r for r in eps if r["episodio"] == str(ep)][0]
        semilla = int(float(fila["semilla"]))
        previas = R.previas_por_suma(eps, "episodio", ep)
        matrices = prueba._matrices(suf, ep)
        with contextlib.redirect_stdout(io.StringIO()):
            obs_a, rpm_a, cob_a = prueba._correr("A", matrices, previas, semilla)
            obs_b, rpm_b, cob_b = prueba._correr("B", matrices, previas, semilla)
        dif = 0
        primera = None
        for fa, fb in zip(obs_a, obs_b):
            igual = (fa[:2] == fb[:2] and all(np.array_equal(x, y) for x, y in zip(fa[2:6], fb[2:6]))
                     and fa[6:] == fb[6:])
            if not igual:
                dif += 1
                primera = primera or fa[:2]
        escapes = sum(f[6] for f in obs_a)
        cbf = sum(f[7] for f in obs_a)
        print(f"s{suf or '_01'} ep {ep} (semilla {semilla}, previas {previas}): "
              f"{len(matrices)} decisiones · filas {len(obs_a)}/{len(obs_b)} · distintas {dif}"
              f"{' (primera ' + str(primera) + ')' if primera else ''} · rpm iguales {rpm_a == rpm_b}"
              f" · cobertura A {cob_a!r} B {cob_b!r} · escapes {escapes} · CBF {cbf}", flush=True)
    finally:
        prueba.tearDown()
