"""Diversidad de arranques 24-09 / 22-09 / 11-09 con las funciones de
diversidad_arranques.py (solo lectura; ejecutar con python -B)."""
import csv, sys
from pathlib import Path
import numpy as np

CARP = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
sys.path.insert(0, str(CARP))
import diversidad_arranques as da  # noqa: E402

RES = CARP / "resultados_sesion"
def leer(n):
    return list(csv.DictReader(open(RES / n, encoding="utf-8")))

X0 = ("x0", "y0", "th0")
BL = ("blanco_x", "blanco_y", "blanco_th")


def eval_n1(episodios, semilla=0, n_ref=da.N_REFERENCIA):
    """Igual que da.evaluar pero admite 1 episodio (disp_centroide degenerada)."""
    episodios = [np.asarray(e, float) for e in episodios]
    n_ep, n_ag = len(episodios), episodios[0].shape[0]
    rng = np.random.default_rng(semilla)
    grande = np.concatenate(da._sortear_sesion(400, n_ag, rng))
    rx, ry = grande[:, 0], grande[:, 1]
    val = da.estadisticos(episodios, rx, ry)
    sims = [da.estadisticos(da._sortear_sesion(n_ep, n_ag, rng), rx, ry) for _ in range(n_ref)]
    for nombre, cola in da.ESTADISTICOS:
        dist = np.array([s[nombre] for s in sims])
        pct = 100.0 * (np.mean(dist < val[nombre]) + 0.5 * np.mean(dist == val[nombre]))
        lo, hi = np.percentile(dist, [2.5, 97.5])
        print(f"     {nombre:<17} {val[nombre]:7.3f}  percentil {pct:5.1f}  (ref 95 %: {lo:.3f}-{hi:.3f})  cola {cola}")


def mostrar(titulo, eps):
    print(f"\n## {titulo}: {len(eps)} episodios")
    if not eps:
        print("   (sin episodios)")
        return
    if len(eps) >= 2:
        r = da.evaluar(eps)
        for ln in r["lineas"]:
            print(ln)
        print("   celdas =", round(r["valores"]["celdas_cubiertas"] * 16), "/16  banderas", r["banderas"], "extremos", r.get("extremos"))
    else:
        print("   (n=1: evaluar() exige >=2; Monte Carlo propio con n_ep=1, misma semilla 0)")
        eval_n1(eps)
        s = da.estadisticos(eps, np.zeros(1), np.zeros(1))
        print("   celdas =", round(s["celdas_cubiertas"] * 16), "/16")


f24 = leer("20260924_sesion-evaluacion_etapa7_episodios.csv")
mostrar("24-09 (a) valido, pose MEDIDA x0", da.episodios_desde_filas(f24, 5, X0, True))
mostrar("24-09 (a) valido, BLANCO", da.episodios_desde_filas(f24, 5, BL, True))
mostrar("24-09 (b) todos, BLANCO", da.episodios_desde_filas(f24, 5, BL, False))
mostrar("24-09 (b) todos, pose MEDIDA x0", da.episodios_desde_filas(f24, 5, X0, False))
print("\n   filas 24-09 con x0 completo:", len(da.episodios_desde_filas(f24, 5, X0, False)), "de", len(f24))
# diferencia blanco vs medido por intento
err = []
for r in f24:
    for i in range(5):
        try:
            err.append(float(r[f"col_err_m_a{i}"]))
        except ValueError:
            pass
print(f"   col_err_m (todos los intentos, agentes con dato): n={len(err)} mediana {np.median(err):.4f} max {np.max(err):.4f}")
print("   estados de colocacion:", sorted({r[f'col_estado_a{i}'] for r in f24 for i in range(5)}))

print("\n# informe() tal cual sobre el 24-09:")
da.informe(f24, 5)

f22_1 = leer("20260922_sesion-evaluacion_etapa7_episodios.csv")
f22_2 = leer("20260922_sesion-evaluacion_etapa7_episodios_02.csv")
f22_3 = leer("20260922_sesion-evaluacion_etapa7_episodios_03.csv")
for nom, f in (("22-09 _01", f22_1), ("22-09 _02", f22_2), ("22-09 _03", f22_3)):
    print(f"\n{nom}: {len(f)} filas, validos {sum(r['valido']=='1' for r in f)}, blanco? {'blanco_x_a0' in f[0]}, x0? {'x0_a0' in f[0]}")
bl22 = (da.episodios_desde_filas(f22_2, 5, BL, False) + da.episodios_desde_filas(f22_3, 5, BL, False))
mostrar("22-09 _02 BLANCO todos", da.episodios_desde_filas(f22_2, 5, BL, False))
mostrar("22-09 _03 BLANCO todos", da.episodios_desde_filas(f22_3, 5, BL, False))
mostrar("22-09 _02+_03 BLANCO todos", bl22)
mostrar("22-09 _03 x0 todos", da.episodios_desde_filas(f22_3, 5, X0, False))
mostrar("22-09 _01 x0 todos (colocacion a mano)", da.episodios_desde_filas(f22_1, 5, X0, False))
mostrar("22-09 + 24-09 BLANCO todos (combinado)", bl22 + da.episodios_desde_filas(f24, 5, BL, False))

f11 = leer("20260911_sesion-evaluacion_etapa7_episodios.csv")
mostrar("11-09 validos x0 (referencia)", da.episodios_desde_filas(f11, 5, X0, True))
