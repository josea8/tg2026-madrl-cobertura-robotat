"""Recalculo independiente (solo lectura) del analisis pareado sim/real.
No escribe nada en el proyecto. Ejecutar con python -B."""
import csv, sys, math
from math import sqrt
from pathlib import Path
import numpy as np
from scipy import stats

CARP = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
RES = CARP / "resultados_sesion"

def leer(nombre):
    return list(csv.DictReader(open(RES / nombre, encoding="utf-8")))

# ---------------- 11-09 -----------------
hw_f = leer("20260911_sesion-evaluacion_etapa7_episodios.csv")
val = [r for r in hw_f if r["valido"] == "1"]
EPS = [int(r["episodio"]) for r in val]
H = {int(r["episodio"]): float(r["cobertura_aoi"]) for r in val}
V = {int(r["episodio"]): float(r["cobertura_replica"]) for r in val}
print("11-09 validos", EPS, "de", len(hw_f))
h = np.array([H[e] for e in EPS])
print("hw por ep", [f"{H[e]:.4f}" for e in EPS], "media %.4f sd %.4f" % (h.mean(), h.std(ddof=1)))
t4 = stats.t.ppf(0.975, 4)
print("t975_4 exacto %.6f" % t4, " IC95 hw [%.4f, %.4f]" % (h.mean() - t4*h.std(ddof=1)/sqrt(5), h.mean() + t4*h.std(ddof=1)/sqrt(5)))

on = leer("20260912_sesion-replica_etapa7_capas-on.csv")
off = leer("20260912_sesion-replica_etapa7_capas-off.csv")
print("cols replica on:", list(on[0].keys()))
con = {}
for r in on:
    if r["valido"] in ("1", "True"):
        con.setdefault(int(r["episodio"]), []).append(float(r["cobertura_aoi"]))
print("on: filas", len(on), "validas", sum(r["valido"] in ("1","True") for r in on))
for e in EPS:
    print("  ep", e, "reps", con[e], "media %.4f sd %.4f" % (np.mean(con[e]), np.std(con[e], ddof=1)))
M = {e: float(np.mean(con[e])) for e in EPS}
m = np.array([M[e] for e in EPS]); v = np.array([V[e] for e in EPS])
print("replica con capas por ep", [f"{M[e]:.4f}" for e in EPS], "media %.4f" % m.mean())
print("replica vieja por ep", [f"{V[e]:.4f}" for e in EPS], "media %.4f" % v.mean())
ruido = [np.std(x, ddof=1) for x in con.values()]
print("ruido on mediana %.4f max %.4f" % (np.median(ruido), np.max(ruido)))

def par(nom, a, b):
    d = a - b; n = len(d); sd = d.std(ddof=1)
    ic = stats.t.ppf(0.975, n-1) * sd / sqrt(n)
    print(f"{nom}: dif {d.mean():+.4f} ± {sd:.4f} IC95 [{d.mean()-ic:+.4f}, {d.mean()+ic:+.4f}] pos {(d>0).sum()}/{n} "
          f"t p={stats.ttest_rel(a,b).pvalue:.4f} W p={stats.wilcoxon(a,b).pvalue:.4f}")
    print("   por ep", [f"{x:+.4f}" for x in d], " relativo %.2f %%" % (100*d.mean()/b.mean()))
    return d
d = par("hw - con capas", h, m)
par("hw - vieja", h, v)

mm, sd = abs(d.mean()), d.std(ddof=1)
n_ic = next(n for n in range(3, 10000) if stats.t.ppf(0.975, n-1)*sd/sqrt(n) < mm)
def pot(n):
    gl, nc = n-1, mm/sd*sqrt(n); tc = stats.t.ppf(0.975, gl)
    return 1 - stats.nct.cdf(tc, gl, nc) + stats.nct.cdf(-tc, gl, nc)
n80 = next(n for n in range(3, 10000) if pot(n) >= 0.80)
z = stats.norm.ppf(0.975); zb = stats.norm.ppf(0.80)
print(f"n IC excluye 0 (t) = {n_ic}; n potencia .80 (t) = {n80}; potencia n5 {pot(5):.4f} n10 {pot(10):.4f} n20 {pot(20):.4f}")
print(f"aprox normal: n_ic_z = {math.ceil((z*sd/mm)**2)}  n80_z = {math.ceil(((z+zb)*sd/mm)**2)}")

# sin capas
inv = [r for r in off if r["valido"] not in ("1", "True")]
t = np.array([float(r["duracion_s"]) for r in inv])
print(f"sin capas: {len(inv)}/{len(off)} invalidas; motivos", {r['motivo'] for r in inv})
print(f"  dur mediana {np.median(t):.2f} min {t.min():.2f} max {t.max():.2f}")
print("  fuera de arena:", sum('fuera de la arena' in r['motivo'] for r in off))

# seguridad hw vs on
for k in ("d_pared_min", "viola_018", "frac_cbf", "colisiones_015"):
    print(f"  {k}: hw {np.mean([float(r[k]) for r in val]):.4f}  on {np.mean([float(r[k]) for r in on if r['valido'] in ('1','True')]):.4f}")

# ---------------- 24-09 -----------------
f24 = leer("20260924_sesion-evaluacion_etapa7_episodios.csv")
v24 = [r for r in f24 if r["valido"] == "1"]
print("\n24-09: intentos", len(f24), "validos", [r["episodio"] for r in v24])
for r in v24:
    c, rp = float(r["cobertura_aoi"]), float(r["cobertura_replica"])
    print(f"  ep {r['episodio']} cob {r['cobertura_aoi']} rep_vieja {r['cobertura_replica']} dif {c-rp:+.6f}")
    for k in ("colisiones_015", "colisiones_022", "d_pared_min", "viola_018", "frac_cbf", "n_escape", "duracion_s", "ciclo_p95_ms", "decisiones", "factor", "rpm_aborto", "colocacion", "col_t_s", "col_motivo", "col_listos"):
        print(f"    {k} = {r.get(k)}")
    for i in range(5):
        print(f"    a{i}: robot {r['robot_a'+str(i)]} blanco ({r[f'blanco_x_a{i}']}, {r[f'blanco_y_a{i}']}, {r[f'blanco_th_a{i}']}) x0 ({r[f'x0_a{i}']}, {r[f'y0_a{i}']}, {r[f'th0_a{i}']}) err_m {r[f'col_err_m_a{i}']} err_rumbo {r[f'col_err_rumbo_deg_a{i}']} estado {r[f'col_estado_a{i}']}")
from collections import Counter
cnt = Counter()
for r in f24:
    mo = r["motivo"]
    k = "valido" if r["valido"] == "1" else ("congelado" if "CONGELADO" in mo else ("antiguedad" if "antigüedad" in mo else ("no sigue" if "NO SIGUE" in mo else mo[:40])))
    cnt[k] += 1
print("  motivos 24-09:", dict(cnt))
print("  colocacion por intento:", [(r['episodio'], r['colocacion'], r['col_t_s'], r['col_listos']) for r in f24])
