from v45_lib import *
from collections import defaultdict
ok = 0; tot = 0
for s in ('11', '22', '24'):
    out, ev, ra = res[s]
    idx = {}
    for r in out:
        idx[(r['key'][0], r['key'][1], r['key'][2], r['paso'])] = r
    for e in ev:
        fi, ep, ag = e['key']
        tot += 1
        todos = True
        for p in range(e['paso'], e['paso'] + 10):
            for a in range(5):
                if a == ag: continue
                r = idx.get((fi, ep, a, p))
                if r is None or r['rep']:
                    todos = False
        ok += todos
        print(s, e['rob'], 'otros vivos en toda la racha:', todos)
print(ok, '/', tot)
