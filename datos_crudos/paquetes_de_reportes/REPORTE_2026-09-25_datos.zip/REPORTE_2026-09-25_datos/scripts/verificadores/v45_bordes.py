# Recalculo independiente (solo lectura) de las cifras de la seccion 4 del borrador.
import csv, sys, io, math
from collections import defaultdict
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
R = "C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/"
FILES = {
 '11': ['20260911_sesion-evaluacion_etapa7_decisiones.csv'],
 '22': ['20260922_sesion-evaluacion_etapa7_decisiones.csv', '20260922_sesion-evaluacion_etapa7_decisiones_02.csv'],
 '24': ['20260924_sesion-evaluacion_etapa7_decisiones.csv'],
}
def fisher_one(a, b, c, d):
    # tabla [[a,b],[c,d]]; P(X>=a) hipergeometrica
    n1 = a + b; n2 = c + d; k = a + c; N = n1 + n2
    def lc(n, r): return math.lgamma(n+1)-math.lgamma(r+1)-math.lgamma(n-r+1)
    tot = 0.0
    for x in range(a, min(n1, k)+1):
        tot += math.exp(lc(n1, x)+lc(n2, k-x)-lc(N, k))
    return tot
def fisher_two(a,b,c,d):
    n1=a+b; n2=c+d; k=a+c; N=n1+n2
    def lc(n,r): return math.lgamma(n+1)-math.lgamma(r+1)-math.lgamma(n-r+1)
    def p(x): return math.exp(lc(n1,x)+lc(n2,k-x)-lc(N,k))
    p0=p(a); tot=0.0
    for x in range(max(0,k-n2), min(n1,k)+1):
        px=p(x)
        if px <= p0*(1+1e-7): tot+=px
    return tot
rows_by = {}
for s, fl in FILES.items():
    allr = []
    for fi, f in enumerate(fl):
        with open(R+f, encoding='utf-8') as fh:
            for r in csv.DictReader(fh):
                allr.append((fi, int(r['episodio']), int(r['agente']), int(r['robot']), int(r['paso']), float(r['pose_env_x']), float(r['pose_env_y']), float(r['pose_env_th'])))
    rows_by[s] = allr
def analiza(s):
    seqs = defaultdict(list)
    for fi, ep, ag, rob, paso, x, y, th in rows_by[s]:
        seqs[(fi, ep, ag)].append((paso, x, y, th, rob))
    out = []  # per row: dict
    eventos = []
    rachas = []
    for key, lst in seqs.items():
        lst.sort()
        prev = None; run = 0
        for i, (paso, x, y, th, rob) in enumerate(lst):
            rep = prev is not None and (x, y, th) == prev
            inicio = rep and run == 0
            if rep: run += 1
            else:
                if run > 0: rachas.append(run)
                run = 0
            d = min(x, 3-x, y, 3-y)
            out.append(dict(key=key, paso=paso, x=x, y=y, th=th, rob=rob, rep=rep, inicio=inicio, d=d))
            if inicio:
                eventos.append(dict(key=key, paso=paso, x=x, y=y, th=th, rob=rob, d=d))
            prev = (x, y, th)
        if run > 0: rachas.append(run)
    return out, eventos, rachas
res = {s: analiza(s) for s in FILES}
for s in FILES:
    out, ev, ra = res[s]
    print(f"== {s}-09: filas {len(out)}, repetidas {sum(r['rep'] for r in out)}, inicios {len(ev)}, largo rachas {sorted(set(ra))} n={len(ra)}")
    for e in ev:
        print(f"   ev file{e['key'][0]} ep{e['key'][1]} ag{e['key'][2]} robot{e['rob']} paso{e['paso']} x={e['x']:.3f} y={e['y']:.3f} d={e['d']:.3f}")
bands = [(0,0.20),(0.20,0.35),(0.35,0.60),(0.60,99)]
def banda_cnt(ss, live=False):
    for lo, hi in bands:
        n = 0; k = 0
        for s in ss:
            out, ev, ra = res[s]
            n += sum(1 for r in out if lo <= r['d'] < hi and (not live or not r['rep']))
            k += sum(1 for e in ev if lo <= e['d'] < hi)
        print(f"   [{lo},{hi}) inicios {k} / {'vivas' if live else 'filas'} {n} = {1000*k/n:.3f} por mil")
print("22+24 por banda, filas totales:"); banda_cnt(['22','24'])
print("22+24 por banda, filas vivas:"); banda_cnt(['22','24'], live=True)
def near(ss, live, th=0.35):
    n=0;k=0
    for s in ss:
        out, ev, ra = res[s]
        n += sum(1 for r in out if r['d'] < th and (not live or not r['rep']))
        k += sum(1 for e in ev if e['d'] < th)
    return k, n
for live in (False, True):
    k11,n11 = near(['11'], live); k2,n2 = near(['22','24'], live)
    print(f"<0.35 {'vivas' if live else 'totales'}: 11-09 {k11}/{n11} ({1000*k11/n11:.3f}‰) vs 22+24 {k2}/{n2} ({1000*k2/n2:.3f}‰), razon {(k2/n2)/(k11/n11):.2f}")
# far contrast
kf=0;nf=0
for s in ['22','24']:
    out,ev,ra=res[s]; nf+=sum(1 for r in out if r['d']>=0.60); kf+=sum(1 for e in ev if e['d']>=0.60)
k2,n2=near(['22','24'],True)
print(f"Fisher unilateral cerca(vivas) {k2}/{n2} vs lejos {kf}/{nf}: p={fisher_one(k2,n2-k2,kf,nf-kf):.3g}")
k2t,n2t=near(['22','24'],False)
print(f"Fisher unilateral cerca(totales) {k2t}/{n2t} vs lejos {kf}/{nf}: p={fisher_one(k2t,n2t-k2t,kf,nf-kf):.3g}")
# per wall: pared mas cercana
def pared(x,y):
    ds = {'x=0':x,'x=3':3-x,'y=0':y,'y=3':3-y}
    return min(ds, key=ds.get)
for ss,lab in ((['22','24'],'22+24'),(['24'],'24'),(['22'],'22')):
    for live in (False,True):
        cnt=defaultdict(lambda:[0,0])
        for s in ss:
            out,ev,ra=res[s]
            for r in out:
                if r['d']<0.35 and (not live or not r['rep']): cnt[pared(r['x'],r['y'])][1]+=1
            for e in ev:
                if e['d']<0.35: cnt[pared(e['x'],e['y'])][0]+=1
        ky=cnt['y=0'][0]+cnt['y=3'][0]; ny=cnt['y=0'][1]+cnt['y=3'][1]
        kx=cnt['x=0'][0]+cnt['x=3'][0]; nx=cnt['x=0'][1]+cnt['x=3'][1]
        # binomial condicional P(>= ky | ky+kx, p=ny/(nx+ny))
        K=ky+kx; p=ny/(nx+ny)
        P=sum(math.comb(K,j)*p**j*(1-p)**(K-j) for j in range(ky,K+1))
        print(f"{lab} {'vivas' if live else 'totales'}: y {ky}/{ny}={1000*ky/ny:.2f}‰  x {kx}/{nx}={1000*kx/nx:.2f}‰  P(>=ky)={P:.3f} por pared {dict((k,tuple(v)) for k,v in sorted(cnt.items()))}")
