"""
El ancho de la franja por lado (mapa_seguimiento, el MISMO código que la
sonda) aplicado a las sesiones de evaluación del 11, 22 y 24-09. Sólo lectura.

Cada secuencia (archivo, episodio, agente) es un "marcador" virtual (robot ×
1000 + índice) para no unir secuencias distintas. Umbral 1: el criterio del
lazo (primera repetición). Las sesiones sólo tienen entradas: los episodios se
abortaban a las 10 decisiones congeladas.
"""
import contextlib
import csv
import io
import json
import sys
from collections import defaultdict

sys.path.insert(0, r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/"
                   r"controllers/coordinador_enjambre")
import calibracion_sesion as calib  # noqa: E402

with contextlib.redirect_stdout(io.StringIO()):
    calib.aplicar_a_config()
import config_robotat as cfg  # noqa: E402
from mapa_seguimiento import (MapaSeguimiento, Rejilla, env_a_lab_xy,  # noqa: E402
                              plataforma_por_defecto)

RES = (r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/"
       r"controllers/coordinador_enjambre/resultados_sesion/")
SESIONES = {
    "11-09": ["20260911_sesion-evaluacion_etapa7_decisiones.csv"],
    "22-09": ["20260922_sesion-evaluacion_etapa7_decisiones.csv",
              "20260922_sesion-evaluacion_etapa7_decisiones_02.csv"],
    "24-09": ["20260924_sesion-evaluacion_etapa7_decisiones.csv"],
}
print(f"calibración: E={cfg.ESCALA_POSICION:.6f} θ={cfg.ROTACION_MARCO_RAD:.6f} "
      f"t=({cfg.TRASLACION_X_M:.6f}, {cfg.TRASLACION_Y_M:.6f})")
salida = {}
for fecha, archivos in SESIONES.items():
    mapa = MapaSeguimiento(Rejilla(*plataforma_por_defecto(), celda=0.25),
                           umbral=1, orden="peine")
    n_seq = 0
    for archivo in archivos:
        seqs = defaultdict(list)
        with open(RES + archivo, newline="", encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                seqs[(int(r["episodio"]), int(r["agente"]))].append(r)
        for (_ep, _ag), filas in sorted(seqs.items()):
            filas.sort(key=lambda r: int(r["paso"]))
            n_seq += 1
            marcador = int(filas[0]["robot"]) * 1000 + n_seq
            previa = None
            for j, r in enumerate(filas):
                pose = (float(r["pose_env_x"]), float(r["pose_env_y"]),
                        float(r["pose_env_th"]))
                x_lab, y_lab = env_a_lab_xy(pose[0], pose[1])
                mapa.observar(marcador, 0.1 * j, x_lab, y_lab,
                              repite=(pose == previa))
                previa = pose
    print("=" * 100)
    print(f"SESIÓN {fecha}: {len(mapa.congelamientos)} inicios")
    for linea in mapa.lineas_franja():
        print(linea)
    r = mapa.franja_por_lado("arena")
    por_robot = defaultdict(int)
    detalle = []
    for l in r["lados"]:
        for m, n in l["inicios_por_marcador"].items():
            por_robot[int(m) // 1000] += n
        for d in l["detalle"]:
            detalle.append({**d, "lado": l["lado"],
                            "robot": d["marcador"] // 1000})
    print("  inicios por robot:", dict(sorted(por_robot.items())))
    for d in sorted(detalle, key=lambda d: (d["lado"], d["d_m"])):
        print(f"    {d['lado']:<4} d={d['d_m']:.3f} tramo {d['tramo']} "
              f"{d['clase']:<13} ángulo {d['angulo_deg']} robot {d['robot']}")
    salida[fecha] = {"franja_arena": r, "por_robot": dict(por_robot)}
with open("franja_sesiones.json", "w", encoding="utf-8") as fh:
    json.dump(salida, fh, ensure_ascii=False, indent=1)
