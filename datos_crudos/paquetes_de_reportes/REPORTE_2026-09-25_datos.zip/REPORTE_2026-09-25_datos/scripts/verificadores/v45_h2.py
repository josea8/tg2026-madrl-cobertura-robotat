import math
from v45_lib import *
from collections import defaultdict
tot=0; quiet=0; quiet_wall=0; minchg=1e9; nseq=0; allpairs=0
for s in ('11','22','24'):
    out, ev, ra = res[s]
    seq = defaultdict(list)
    for r in out: seq[r['key']].append(r)
    nseq += len(seq)
    for k, lst in seq.items():
        lst.sort(key=lambda r: r['paso'])
        for a, b in zip(lst, lst[1:]):
            allpairs += 1
            if b['rep']: continue
            tot += 1
            dp = math.hypot(b['x']-a['x'], b['y']-a['y'])
            dth = abs((b['th']-a['th']+math.pi) % (2*math.pi) - math.pi)
            ch = max(abs(b['x']-a['x']), abs(b['y']-a['y']), abs(b['th']-a['th']))
            minchg = min(minchg, dp if dp>0 else 1e9)
            if dp < 0.0005 and math.degrees(dth) < 0.2:
                quiet += 1
                if b['d'] < 0.25: quiet_wall += 1
print('secuencias', nseq, 'pares totales', allpairs, 'pares sin repeticion (no congelados)', tot, 'quietos', quiet, 'quietos a <0.25', quiet_wall, 'cambio min pos (m)', minchg)
