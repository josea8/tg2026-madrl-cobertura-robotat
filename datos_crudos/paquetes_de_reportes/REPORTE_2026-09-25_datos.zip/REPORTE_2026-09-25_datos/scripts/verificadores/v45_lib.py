# Recalculo independiente (solo lectura) de las cifras de la seccion 4 del borrador.
import csv, sys, io, math
from collections import defaultdict

R = "C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/"
FILES = {
 '11': ['20260911_sesion-evaluacion_etapa7_decisiones.csv'],
 '22': ['20260922_sesion-evaluacion_etapa7_decisiones.csv', '20260922_sesion-evaluacion_etapa7_decisiones_02.csv'],
 '24': ['20260924_sesion-evaluacion_etapa7_decisiones.csv'],
}
def fisher_one(a, b, c, d):
    # tabla [[a,b],[c,d]]; P(X>=a) hipergeometrica
    n1 = a + b; n2 = c + d; k = a + c; N = n1 + n2
    def lc(n, r): return math.lgamma(n+1)-math.lgamma(r+1)-math.lgamma(n-r+1)
    tot = 0.0
    for x in range(a, min(n1, k)+1):
        tot += math.exp(lc(n1, x)+lc(n2, k-x)-lc(N, k))
    return tot
def fisher_two(a,b,c,d):
    n1=a+b; n2=c+d; k=a+c; N=n1+n2
    def lc(n,r): return math.lgamma(n+1)-math.lgamma(r+1)-math.lgamma(n-r+1)
    def p(x): return math.exp(lc(n1,x)+lc(n2,k-x)-lc(N,k))
    p0=p(a); tot=0.0
    for x in range(max(0,k-n2), min(n1,k)+1):
        px=p(x)
        if px <= p0*(1+1e-7): tot+=px
    return tot
rows_by = {}
for s, fl in FILES.items():
    allr = []
    for fi, f in enumerate(fl):
        with open(R+f, encoding='utf-8') as fh:
            for r in csv.DictReader(fh):
                allr.append((fi, int(r['episodio']), int(r['agente']), int(r['robot']), int(r['paso']), float(r['pose_env_x']), float(r['pose_env_y']), float(r['pose_env_th'])))
    rows_by[s] = allr
def analiza(s):
    seqs = defaultdict(list)
    for fi, ep, ag, rob, paso, x, y, th in rows_by[s]:
        seqs[(fi, ep, ag)].append((paso, x, y, th, rob))
    out = []  # per row: dict
    eventos = []
    rachas = []
    for key, lst in seqs.items():
        lst.sort()
        prev = None; run = 0
        for i, (paso, x, y, th, rob) in enumerate(lst):
            rep = prev is not None and (x, y, th) == prev
            inicio = rep and run == 0
            if rep: run += 1
            else:
                if run > 0: rachas.append(run)
                run = 0
            d = min(x, 3-x, y, 3-y)
            out.append(dict(key=key, paso=paso, x=x, y=y, th=th, rob=rob, rep=rep, inicio=inicio, d=d))
            if inicio:
                eventos.append(dict(key=key, paso=paso, x=x, y=y, th=th, rob=rob, d=d))
            prev = (x, y, th)
        if run > 0: rachas.append(run)
    return out, eventos, rachas
res = {s: analiza(s) for s in FILES}
