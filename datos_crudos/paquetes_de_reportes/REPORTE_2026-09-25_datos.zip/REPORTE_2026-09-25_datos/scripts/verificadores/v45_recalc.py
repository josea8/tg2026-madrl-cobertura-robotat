"""
Recálculo independiente (solo lectura) de las cifras de §4.5 y §6 del borrador,
directamente desde los CSV crudos de decisiones del Robotat.
Definiciones:
  secuencia = (archivo, episodio, agente), ordenada por paso entero
  repetida  = fila cuya (x, y, th) del entorno es idéntica a la fila anterior
  inicio    = repetida cuya anterior NO era repetida; su pose = la última viva
  viva      = fila no repetida
  d         = distancia a la pared más cercana de [0,3]^2; u = coordenada a lo
              largo de esa pared; c = min(u, 3-u)
"""
import csv
import math
from collections import defaultdict
from scipy.stats import fisher_exact
import numpy as np

import sys
# Carpeta de los CSV crudos: argumento 1, o la del proyecto por defecto.
RES = (sys.argv[1].rstrip("/\\") + "/" if len(sys.argv) > 1 and __name__ == "__main__"
       else "C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/"
            "controllers/coordinador_enjambre/resultados_sesion/")
SES = {
    "11-09": ["20260911_sesion-evaluacion_etapa7_decisiones.csv"],
    "22-09": ["20260922_sesion-evaluacion_etapa7_decisiones.csv",
              "20260922_sesion-evaluacion_etapa7_decisiones_02.csv"],
    "24-09": ["20260924_sesion-evaluacion_etapa7_decisiones.csv"],
}
W = 3.0


def pared(x, y):
    c = [("x=0", x, y, (-1, 0)), ("x=3", W - x, y, (1, 0)),
         ("y=0", y, x, (0, -1)), ("y=3", W - y, x, (0, 1))]
    c.sort(key=lambda t: t[1])
    return c[0], c[1]


def cargar(fecha):
    filas = []  # dicts: fecha, robot, x, y, th, rep, ini, seq, idx
    nseq = 0
    for a in SES[fecha]:
        seqs = defaultdict(list)
        with open(RES + a, newline="", encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                seqs[(int(r["episodio"]), int(r["agente"]))].append(r)
        for k, rs in sorted(seqs.items()):
            rs.sort(key=lambda r: int(r["paso"]))
            nseq += 1
            prev = None
            prev_rep = False
            seq = []
            for i, r in enumerate(rs):
                p = (r["pose_env_x"], r["pose_env_y"], r["pose_env_th"])
                rep = (p == prev)
                ini = rep and not prev_rep
                seq.append(dict(fecha=fecha, archivo=a, ep=k[0], ag=k[1],
                                robot=int(r["robot"]), x=float(p[0]),
                                y=float(p[1]), th=float(p[2]), rep=rep,
                                ini=ini, i=i,
                                cbf=int(r["cbf_intervino"])))
                prev = p
                prev_rep = rep
            filas.append(seq)
    return filas


datos = {f: cargar(f) for f in SES}


def inicios(fecha):
    out = []
    for seq in datos[fecha]:
        for j, f in enumerate(seq):
            if f["ini"]:
                out.append((seq, j))
    return out


def vivas(fecha):
    for seq in datos[fecha]:
        for f in seq:
            if not f["rep"]:
                yield f


print("== conteos")
for fe in SES:
    n = sum(len(s) for s in datos[fe])
    print(fe, "filas", n, "secuencias", len(datos[fe]), "inicios",
          len(inicios(fe)), "vivas", sum(1 for _ in vivas(fe)))

print("\n== inicios por sesión (pose = última viva)")
ini_d = {}
for fe in SES:
    ini_d[fe] = []
    for seq, j in inicios(fe):
        f = seq[j]
        (lp, d, u, nrm), (lp2, d2, u2, _) = pared(f["x"], f["y"])
        c = min(u, W - u)
        vert = min(math.hypot(f["x"] - vx, f["y"] - vy)
                   for vx in (0, W) for vy in (0, W))
        ini_d[fe].append(dict(f, pared=lp, d=d, u=u, c=c, d2=d2, pared2=lp2,
                              vert=vert, j=j, seq=seq))
        print(f"  {fe} ep{f['ep']} ag{f['ag']} r{f['robot']} ({f['x']:.4f},"
              f"{f['y']:.4f}) {lp} d={d:.4f} u={u:.3f} c={c:.3f} "
              f"2a:{lp2} {d2:.3f} vértice {vert:.3f}")

# --- 24-09 tercios
print("\n== 24-09 tercios (vivas d<0.35; inicio cuenta en su pose)")
for fe in ("24-09", "22-09"):
    med = [0, 0]
    ext = [0, 0]
    for f in vivas(fe):
        (lp, d, u, _), _b = pared(f["x"], f["y"])
        if d < 0.35:
            (med if 1.0 <= u <= 2.0 else ext)[1] += 1
    for e in ini_d[fe]:
        if e["d"] < 0.35:
            (med if 1.0 <= e["u"] <= 2.0 else ext)[0] += 1
    t = [[ext[0], ext[1] - ext[0]], [med[0], med[1] - med[0]]]
    print(fe, "extremos", ext, "medio", med,
          "Fisher unilateral", fisher_exact(t, alternative="greater")[1],
          "bilateral", fisher_exact(t)[1])
print("24-09 vértice 2D de los 10 inicios:",
      sorted(round(e["vert"], 3) for e in ini_d["24-09"]))

# --- robot 6
print("\n== robot 6, 24-09")
por_r = defaultdict(lambda: [0, 0])
por_r_esq = defaultdict(lambda: [0, 0])
for f in vivas("24-09"):
    (lp, d, u, _), _b = pared(f["x"], f["y"])
    if d < 0.35:
        por_r[f["robot"]][1] += 1
        if min(u, W - u) <= 0.75:
            por_r_esq[f["robot"]][1] += 1
for e in ini_d["24-09"]:
    if e["d"] < 0.35:
        por_r[e["robot"]][0] += 1
        if e["c"] <= 0.75:
            por_r_esq[e["robot"]][0] += 1
print("d<0.35 por robot [inicios, vivas]:", dict(por_r))
print("esquina c<=0.75 por robot:", dict(por_r_esq))
r6 = por_r_esq[6]
resto = [sum(v[0] for k, v in por_r_esq.items() if k != 6),
         sum(v[1] for k, v in por_r_esq.items() if k != 6)]
t = [[r6[0], r6[1] - r6[0]], [resto[0], resto[1] - resto[0]]]
p2 = fisher_exact(t)[1]
p1 = fisher_exact(t, alternative="less")[1]
print("r6 esquina", r6, "resto", resto, "Fisher bilateral", p2,
      "unilateral", p1, "Bonferroni x5", min(1, 5 * p2))
print("22-09 inicios por robot:",
      {r: sum(1 for e in ini_d['22-09'] if e['robot'] == r)
       for r in set(e['robot'] for e in ini_d['22-09'])})

# --- dirección
print("\n== dirección de entrada (desplazamiento pose inicio - pose 5 filas antes)")
for fe in ("24-09", "22-09"):
    n60 = n75 = 0
    for e in ini_d[fe]:
        seq, j = e["seq"], e["j"]
        a = seq[max(0, j - 5)]
        dx, dy = e["x"] - a["x"], e["y"] - a["y"]
        (lp, d, u, nrm), (lp2, d2, u2, _) = pared(e["x"], e["y"])
        ang = math.degrees(math.acos((dx * nrm[0] + dy * nrm[1]) /
                                     math.hypot(dx, dy)))
        # ángulo respecto de la pared adyacente (segunda más cercana)
        nrm2 = {"x=0": (-1, 0), "x=3": (1, 0), "y=0": (0, -1),
                "y=3": (0, 1)}[lp2]
        ang2 = math.degrees(math.acos((dx * nrm2[0] + dy * nrm2[1]) /
                                      math.hypot(dx, dy)))
        par = 60 <= ang <= 120
        n60 += par
        n75 += 75 <= ang <= 105
        print(f"  {fe} r{e['robot']} {lp} d={d:.3f} ang={ang:.1f}"
              f" {'PARALELA' if par else ''} | 2a {lp2} d2={d2:.3f}"
              f" ang2={ang2:.1f}")
    print(f"  {fe}: 60-120 {n60}/{len(ini_d[fe])}, 75-105 {n75}")

# --- 22+24 últimas poses vivas
ds = sorted(e["d"] for fe in ("22-09", "24-09") for e in ini_d[fe])
print("\n== 22+24 d de las últimas poses vivas:", [round(x, 4) for x in ds])
print("  mediana", np.median(ds), "en [0.17,0.29]:",
      sum(1 for x in ds if 0.17 <= x <= 0.295), "de", len(ds))

# --- máximo por lado (pared más cercana), 24-09
mx = defaultdict(float)
for e in ini_d["24-09"]:
    mx[e["pared"]] = max(mx[e["pared"]], e["d"])
print("24-09 máximo d por pared más cercana:",
      {k: round(v, 3) for k, v in sorted(mx.items())})

# --- dependencia de pared y cambio entre fechas
print("\n== 11-09 vs 22+24, vivas d<0.35")
cnt = {}
for fe in SES:
    viv = sum(1 for f in vivas(fe) if pared(f["x"], f["y"])[0][1] < 0.35)
    ini = sum(1 for e in ini_d[fe] if e["d"] < 0.35)
    lejos = sum(1 for f in vivas(fe) if pared(f["x"], f["y"])[0][1] >= 0.60)
    cnt[fe] = (ini, viv, lejos)
    print(fe, "inicios", ini, "vivas<0.35", viv, "vivas>=0.60", lejos)
a = cnt["11-09"]
b = (cnt["22-09"][0] + cnt["24-09"][0], cnt["22-09"][1] + cnt["24-09"][1])
print("11-09 %d/%d = %.3f permil ; 22+24 %d/%d = %.3f permil ; razón %.2f" % (
    a[0], a[1], 1000 * a[0] / a[1], b[0], b[1], 1000 * b[0] / b[1],
    (b[0] / b[1]) / (a[0] / a[1])))

# --- Exp N
print("\n== W_eq = 3 - 2*max(0, w + 0.05 - 0.18)")
for w in (0.229, 0.28, 0.35, 0.458, 0.48, 0.53, 0.534):
    print(f"  w={w}: W_eq={3 - 2 * max(0, w + 0.05 - 0.18):.3f}")
for w in (0.35,):
    lo, hi = w - 0.15, W - w + 0.15
    print("  alcanzable (cuadrado) con w=0.35, r=0.15:", (hi - lo) ** 2 / 9,
          " con esquinas redondeadas:",
          ((W - 2 * w) ** 2 + 4 * (W - 2 * w) * 0.15 + math.pi * 0.15 ** 2) / 9)
