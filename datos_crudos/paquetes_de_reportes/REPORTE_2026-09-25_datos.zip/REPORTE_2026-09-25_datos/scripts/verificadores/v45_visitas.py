import math, sys
from v45_lib import *
from collections import defaultdict
def pared(x,y):
    ds={'x=0':x,'x=3':3-x,'y=0':y,'y=3':3-y}; return min(ds,key=ds.get)
def visitas(s, th=0.35, cortar_pared=True):
    out, ev, ra = res[s]
    seq = defaultdict(list)
    for r in out: seq[r['key']].append(r)
    nv = 0; nvc = 0
    for k, lst in seq.items():
        lst.sort(key=lambda r: r['paso'])
        cur = None; has = False
        for r in lst:
            if r['rep']:
                if r['inicio'] and cur is not None: has = True
                continue  # filas repetidas: no abren ni cierran (misma pose)
            inside = r['d'] < th
            w = pared(r['x'], r['y']) if inside else None
            if inside:
                if cur is None or (cortar_pared and w != cur):
                    if cur is not None:
                        nv += 1; nvc += has
                    cur = w; has = False
            else:
                if cur is not None:
                    nv += 1; nvc += has
                cur = None; has = False
        if cur is not None:
            nv += 1; nvc += has
    return nvc, nv
for cp in (True, False):
    a = visitas('11', cortar_pared=cp); b = visitas('22', cortar_pared=cp); c = visitas('24', cortar_pared=cp)
    bc = (b[0]+c[0], b[1]+c[1])
    print('cortar_pared', cp, '11:', a, '22:', b, '24:', c, '22+24:', bc, 'Fisher 2-lados p=', round(fisher_two(bc[0], bc[1]-bc[0], a[0], a[1]-a[0]), 4))
for th in (0.25, 0.30, 0.40, 0.50, 0.60):
    a = visitas('11', th); b = visitas('22', th); c = visitas('24', th)
    bc = (b[0]+c[0], b[1]+c[1])
    print(th, a, bc, round(fisher_two(bc[0], bc[1]-bc[0], a[0], a[1]-a[0]), 4))
