"""
Barrido del retroceso en el banco cinemático (tiempo virtual): el MISMO gestor
y plan que la sesión, uniciclo con retardo puro y fricción de arranque opcional,
Motive que retiene la última pose en el semiplano x >= 0. Sólo lectura.
"""
import sys, itertools, statistics as st
sys.path.insert(0, r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre")
import contextlib, io
with contextlib.redirect_stdout(io.StringIO()):
    import test_retroceso_congelamiento as T

VEL = (0.031, 0.05, 0.07, 0.10, 0.124)
ENT = ((0.0, 0.0), (30.0, 0.0), (60.0, 0.0), (0.0, 0.8), (0.0, -0.8))
FASES = tuple(i / 10 for i in range(10))
CONFIGS = {
    "propuesta (L .45, M .4 ret)": {},
    "literal (L 0, M 0)":          {"retardo_s": 0.0, "margen_s": 0.0},
}
filas = []
for lr, extra in itertools.product((0.30, 0.45, 0.60), (0.0, 0.2, 0.4)):
    for nombre, kw in CONFIGS.items():
        res = []
        for v, (ang, w), fase in itertools.product(VEL, ENT, FASES):
            r = T.correr_banco(v, w, ang, fase, retardo_robot_s=lr,
                               arranque_extra_s=extra, gestor_kw=kw)
            res.append((v, r))
        ok = [r for _v, r in res if r.evento_final == "recuperada"]
        mal = [(v, r) for v, r in res if r.evento_final != "recuperada"]
        t_rec = [r.t_final - r.t_deteccion for r in ok]
        afuera = [-r.x_final_m for r in ok]
        por_v = {v: sum(1 for vv, _ in mal if vv == v) for v in VEL}
        filas.append((lr, extra, nombre, len(ok), len(res),
                      st.median(t_rec) if t_rec else float("nan"),
                      max(t_rec) if t_rec else float("nan"),
                      min(afuera) if afuera else float("nan"),
                      max(r.penetracion_max_m for _v, r in res),
                      por_v))
print(f"{'L_robot':>7} {'extra':>5}  {'config':<28} {'sale':>9}  {'t_rec med/max s':>15}  {'afuera min cm':>13}  {'penetr. máx cm':>14}  fallos por v")
for lr, extra, nombre, n_ok, n, tmed, tmax, afmin, pen, por_v in filas:
    fallos = " ".join(f"{v}:{k}" for v, k in por_v.items() if k)
    print(f"{lr:7.2f} {extra:5.1f}  {nombre:<28} {n_ok:4d}/{n:<4d}  {tmed:6.2f}/{tmax:5.2f}     {100*afmin:9.1f}      {100*pen:10.1f}      {fallos or '—'}")
