"""Verificación §7: conteos de la base, tiempos de lanzamiento, paralelo, potencia, controles, manifiesto P."""
import json, sqlite3, hashlib, os, re
from collections import Counter, defaultdict
from datetime import datetime as D
import numpy as np
from scipy import stats
SP = os.path.dirname(os.path.abspath(__file__))
J = r"C:/Users/velas/OneDrive/Documents/tesis/fase_preliminar2/experimento_J"
PDIR = r"C:/Users/velas/OneDrive/Documents/tesis/fase_preliminar2/experimento_P"
c = sqlite3.connect(os.path.join(SP, "v7_tmp", "expJ_copia.db"))
rows = c.execute("select trial_id,number,state,datetime_start,datetime_complete from trials order by number").fetchall()
print("registros", len(rows), Counter(r[2] for r in rows))
par = defaultdict(dict)
for tid, n, v in c.execute("select trial_id,param_name,param_value from trial_params"): par[tid][n] = v
cf = {r[1]: tuple(sorted(par[r[0]].items())) for r in rows}
g = defaultdict(list)
for k, v in cf.items(): g[v].append(k)
print("configs distintas", len(g), "duplicados", [v for v in g.values() if len(v) > 1])
print("2o lanzamiento (s)", (D.fromisoformat(rows[-1][4]) - D.fromisoformat(rows[2][3])).total_seconds())
log0 = open(J + "/resultados/estudio_ejecucion_prueba0.log", encoding="utf-8").read()
t0 = re.findall(r"^(\d\d:\d\d:\d\d) \[INFO\]", log0, re.M)
print("1er lanzamiento log", t0[0], "->", t0[-1])
f = lambda s: D.strptime(s, "%H:%M:%S")
s1 = (f(t0[-1]) - f(t0[0])).seconds; s2 = 7454
print("1er s", s1, "total s", s1 + s2, "h", round((s1 + s2) / 3600, 3), "2o h", round(s2 / 3600, 4))
log = open(J + "/resultados/estudio_ejecucion.log", encoding="utf-8").read().splitlines()
ini = {}; s42 = {}; fin = {}
cur = None
for L in log:
    m = re.match(r"^(\d\d:\d\d:\d\d) \[INFO\] Prueba (\d+) — ", L)
    if m: cur = int(m.group(2)); ini[cur] = m.group(1); continue
    m = re.match(r"^(\d\d:\d\d:\d\d) \[INFO\]   semilla 42 — retenido", L)
    if m and cur is not None: s42[cur] = m.group(1); continue
    m = re.match(r"^(\d\d:\d\d:\d\d) \[INFO\] Prueba (\d+) COMPLETA", L)
    if m: fin[int(m.group(2))] = m.group(1)
S = P = 0; razones = []
for k in sorted(fin):
    if k not in s42: continue
    a = (f(s42[k]) - f(ini[k])).seconds; b = (f(fin[k]) - f(s42[k])).seconds
    S += a; P += b; razones.append(b / (2 * a))
print("par paralelo: pruebas", len(razones), "pared", P, "serie estimada", 2 * S, "razon", round(P / (2 * S), 3), "rango", round(min(razones), 3), round(max(razones), 3))
def pot(s1, s2, n=20, d=0.0126, a=0.05):
    v = s1**2 / n + s2**2 / n; df = v**2 / ((s1**2 / n)**2 / (n - 1) + (s2**2 / n)**2 / (n - 1))
    tc = stats.t.ppf(1 - a / 2, df); nc = d / np.sqrt(v)
    return 1 - stats.nct.cdf(tc, df, nc) + stats.nct.cdf(-tc, df, nc)
for s in [(0.0086, 0.0086), (0.0156, 0.0156), (0.0086, 0.0537), (0.0086, 0.0909), (0.0557, 0.0909)]:
    print("potencia", s, round(pot(*s), 3))
m = json.load(open(r"C:/Users/velas/OneDrive/Documents/tesis/fase_preliminar2/modelos/tesis_v1/RESULTADO_PRIMERO/metricas_100eps.json", encoding="utf-8"))
print("C1 oficial", m["resultados"]["madrl"]["agregados"]["cobertura_aoi_final"]["media"], "C3 oficial", m["resultados"]["heuristica"]["agregados"]["cobertura_aoi_final"]["media"])
dg = json.load(open(J + "/resultados/diagnostico_presupuesto/resumen.json", encoding="utf-8"))
c200 = [p for s in dg["semillas"] for p in s["puntos"] if p["pasos"] == 200000]
cob = np.array([p["cobertura"] for p in c200]); col = np.array([p["colisiones"] for p in c200])
ref = json.load(open(J + "/resultados/analisis/referencia_recomputada.json", encoding="utf-8"))
print("prueba7 200k fijo: media", cob.mean(), "sd", cob.std(ddof=1), "CV", cob.std(ddof=1) / cob.mean(), "col", col.mean(), "T13 col final", ref["conjunto_final_30eps"]["colisiones"], "razon", col.mean() / ref["conjunto_final_30eps"]["colisiones"])
man = json.load(open(PDIR + "/manifiesto_P.json", encoding="utf-8"))
h = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
malos = [k for k, v in man["scripts_P"].items() if h(PDIR + "/" + k) != v]
if h(PDIR + "/PREREGISTRO_P.md") != man["preregistro_sha256"]: malos.append("PREREGISTRO_P.md")
malos += [os.path.basename(x["copia"]) for x in man["copias_propias"] if h(x["copia"]) != x["sha256"] or h(x["original"]) != x["sha256"]]
malos += [k for k, v in man["configs"].items() if h(v["ruta"]) != v["sha256"]]
print("manifiesto P: no coinciden", malos, "| variables_hilos presente:", "variables_hilos" in man)
print("existe experimento_P/resultados:", os.path.exists(PDIR + "/resultados"), "resultados_humo:", os.path.exists(PDIR + "/resultados_humo"))
