import math, sys
from v45_lib import *
from collections import defaultdict
# IC95 exacto de la razon de tasas 24-09 y vs x (condicional binomial, Clopper-Pearson)
def cp(k, n, a=0.05):
    from math import comb
    def cdf(k, n, p): return sum(comb(n, j)*p**j*(1-p)**(n-j) for j in range(0, k+1))
    def lo():
        if k == 0: return 0.0
        a0, b0 = 0.0, 1.0
        for _ in range(200):
            m = (a0+b0)/2
            if 1-cdf(k-1, n, m) < a/2: a0 = m
            else: b0 = m
        return (a0+b0)/2
    def hi():
        if k == n: return 1.0
        a0, b0 = 0.0, 1.0
        for _ in range(200):
            m = (a0+b0)/2
            if cdf(k, n, m) > a/2: a0 = m
            else: b0 = m
        return (a0+b0)/2
    return lo(), hi()
for (ky, ny, kx, nx, lab) in ((6, 1821, 3, 1232, '24 totales'), (6, 1761, 3, 1202, '24 vivas')):
    K = ky+kx
    pl, ph = cp(ky, K)
    f = nx/ny
    print(lab, 'RR', (ky/ny)/(kx/nx), 'IC95', pl/(1-pl)*f, ph/(1-ph)*f)
# tercios, robot 6, esquinas (24-09, vivas, d<0.35)
out, ev, ra = res['24']
def pared_u(x, y):
    ds = {'x=0': x, 'x=3': 3-x, 'y=0': y, 'y=3': 3-y}
    w = min(ds, key=ds.get)
    u = y if w in ('x=0', 'x=3') else x
    return w, u
ini = set((e['key'], e['paso']) for e in ev)
# asigno el inicio a la fila viva previa (misma pose) -> la fila del inicio es repetida; contamos inicio con d y u de su pose
med = [0, 0]; ext = [0, 0]
r6 = [0, 0]; esq6 = [0, 0]; esqO = [0, 0]
for r in out:
    if r['rep'] or r['d'] >= 0.35: continue
    w, u = pared_u(r['x'], r['y'])
    if 1 <= u <= 2: med[1] += 1
    else: ext[1] += 1
    c = min(u, 3-u)
    if r['rob'] == 6:
        r6[1] += 1
        if c <= 0.75: esq6[1] += 1
    else:
        if c <= 0.75: esqO[1] += 1
for e in ev:
    if e['d'] >= 0.35: continue
    w, u = pared_u(e['x'], e['y'])
    if 1 <= u <= 2: med[0] += 1
    else: ext[0] += 1
    c = min(u, 3-u)
    if e['rob'] == 6:
        r6[0] += 1
        if c <= 0.75: esq6[0] += 1
    else:
        if c <= 0.75: esqO[0] += 1
print('tercio medio', med, 'extremos', ext, 'Fisher 1-lado ext>med p=', fisher_one(ext[0], ext[1]-ext[0], med[0], med[1]-med[0]), '2-lados', fisher_two(ext[0], ext[1]-ext[0], med[0], med[1]-med[0]))
print('robot6 cerca', r6, 'esquina r6', esq6, 'esquina otros', esqO, 'Fisher 2-lados', fisher_two(esqO[0], esqO[1]-esqO[0], esq6[0], esq6[1]-esq6[0]), '1-lado', fisher_one(esqO[0], esqO[1]-esqO[0], esq6[0], esq6[1]-esq6[0]))
# decisiones por robot cerca de pared (vivas) 24-09
cnt = defaultdict(int)
for r in out:
    if not r['rep'] and r['d'] < 0.35: cnt[r['rob']] += 1
print('vivas d<0.35 por robot 24-09', dict(cnt))
# Direccion de entrada: rumbo de la pose del inicio vs pared mas cercana
for e in ev:
    w, u = pared_u(e['x'], e['y'])
    th = e['th']
    # direccion de la pared (tangente): paredes x -> eje y; paredes y -> eje x
    tang = math.pi/2 if w in ('x=0', 'x=3') else 0.0
    ang = abs(((th - tang + math.pi/2) % math.pi) - math.pi/2)
    print(f"  ev robot{e['rob']} ({e['x']:.3f},{e['y']:.3f}) pared {w} u={u:.2f} th={math.degrees(th):.1f} angulo a la pared {math.degrees(ang):.1f}")
