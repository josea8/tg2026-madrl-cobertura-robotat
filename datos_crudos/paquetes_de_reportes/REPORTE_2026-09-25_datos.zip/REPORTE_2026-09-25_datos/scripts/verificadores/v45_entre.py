"""¿Hubo filas VIVAS entre el punto de inicio y la pared a la que se atribuyó
el 'ancho' (banda lateral ±0.05 m), en la misma sesión del 24-09? Solo lectura."""
import runpy, io, contextlib
from collections import defaultdict
with contextlib.redirect_stdout(io.StringIO()):
    g = runpy.run_path("v45_recalc.py")
datos = g["datos"]
casos = [((2.8281, 2.2985), "y=3", 0.7015), ((2.4493, 0.1775), "x=3", 0.5507),
         ((2.3777, 0.1779), "x=3", 0.6223), ((0.5601, 2.7880), "x=0", 0.5601),
         ((0.5509, 2.7743), "x=0", 0.5509), ((0.1891, 0.4251), "y=0", 0.4251),
         ((2.6904, 0.2417), "y=0", 0.2417)]
for (x0, y0), w, ancho in casos:
    n = 0; mind = None; rob = defaultdict(int)
    for seq in datos["24-09"]:
        for f in seq:
            if f["rep"]:
                continue
            x, y = f["x"], f["y"]
            if w in ("y=3", "y=0"):
                ok = abs(x - x0) <= 0.05 and ((y > y0) if w == "y=3" else (y < y0))
                dw = 3 - y if w == "y=3" else y
            else:
                ok = abs(y - y0) <= 0.05 and ((x > x0) if w == "x=3" else (x < x0))
                dw = 3 - x if w == "x=3" else x
            if ok:
                n += 1; rob[f["robot"]] += 1
                mind = dw if mind is None else min(mind, dw)
    print(f"({x0},{y0}) -> {w} ancho {ancho}: vivas entre punto y pared {n}, "
          f"mínimo a la pared {None if mind is None else round(mind,3)}, por robot {dict(rob)}")
