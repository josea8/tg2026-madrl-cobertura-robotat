import math, sys
from v45_lib import *
from collections import defaultdict
for s in ('24','22'):
    out, ev, ra = res[s]
    seq = defaultdict(list)
    for r in out: seq[r['key']].append(r)
    for k in seq: seq[k].sort(key=lambda r: r['paso'])
    n15=n30=0
    for e in ev:
        lst = seq[e['key']]
        i = [j for j, r in enumerate(lst) if r['paso'] == e['paso']][0]
        p0 = lst[i-5]
        dx, dy = e['x']-p0['x'], e['y']-p0['y']
        ds = {'x=0': (e['x'], (-1,0)), 'x=3': (3-e['x'], (1,0)), 'y=0': (e['y'], (0,-1)), 'y=3': (3-e['y'], (0,1))}
        w = min(ds, key=lambda k: ds[k][0]); nx, ny = ds[w][1]
        ang = math.degrees(math.acos(max(-1,min(1,(dx*nx+dy*ny)/math.hypot(dx,dy)))))
        if abs(ang-90) <= 15: n15 += 1
        if abs(ang-90) <= 30: n30 += 1
        print(s, e['rob'], w, f"{ang:.1f}")
    print(s, '±15:', n15, '±30:', n30, 'de', len(ev))
