import json, glob, os
import numpy as np
from scipy.stats import spearmanr
BASE = r"C:/Users/velas/OneDrive/Documents/tesis/fase_preliminar2/experimento_J"
P = ("lambda_cbf","lambda_entropy","n_epochs","n_steps_exp")
filas = []
for r in sorted(glob.glob(BASE + "/resultados/estudio/cfg_*/semilla_*/resultado_semilla.json")):
    d = json.load(open(r, encoding="utf-8"))
    cfgp = os.path.join(os.path.dirname(os.path.dirname(r)), "config_barridos.json")
    if not os.path.exists(cfgp):
        continue
    b = json.load(open(cfgp, encoding="utf-8"))
    pt = [p for p in d["curva"] if p["pasos"] == 200000]
    if not pt: continue
    filas.append(dict(cfg=os.path.basename(os.path.dirname(os.path.dirname(r))), cob=pt[0]["cobertura"], col=pt[0]["colisiones"], **{k: b[k] for k in P}))
print("n E/D =", len(filas), "configs", len({f['cfg'] for f in filas}))
def holm(ps):
    m=len(ps); o=np.argsort(ps); adj=np.empty(m); run=0
    for i,j in enumerate(o):
        run=max(run,(m-i)*ps[j]); adj[j]=min(1,run)
    return adj
res={}
for nom,cl in (("D","col"),("E","cob")):
    ps=[];
    for k in P:
        rho,p=spearmanr([f[k] for f in filas],[f[cl] for f in filas]); ps.append(p); res[(nom,k)]=p
        print(nom,k,round(rho,3),round(p,4))
    print(nom,"p_Holm fam4",[round(x,4) for x in holm(np.array(ps))])
# family of 20: A,B,C sin duplicado from JSON + D,E
J=json.load(open(BASE+"/resultados/analisis/correlaciones_ABC_sin_duplicado_holm.json",encoding="utf-8"))
allp=[]
for a in "ABC":
    for k in P: allp.append(J["analisis"][a]["detalle"][k]["sin_duplicado"]["p"])
allp += [res[(n,k)] for n in "DE" for k in P]
adj=holm(np.array(allp)); print("fam20 min p_Holm", round(adj.min(),4), "n", len(allp))
# rho(lambda_cbf, n_steps_exp) over 9 complete configs
import sqlite3
c=sqlite3.connect(os.environ["DBCOPIA"])
rows=c.execute("select t.trial_id,t.number from trials t where state='COMPLETE' and number!=2").fetchall()
par={}
for tid,name,val in c.execute("select trial_id,param_name,param_value from trial_params"): par.setdefault(tid,{})[name]=val
x=[par[t]['lambda_cbf'] for t,_ in rows]; y=[par[t]['n_steps_exp'] for t,_ in rows]
print("rho(lcbf,nsteps) n",len(x), spearmanr(x,y))
# E agregado por config
from collections import defaultdict
g=defaultdict(list)
for f in filas: g[f['cfg']].append(f)
xs=[g[k][0]['n_steps_exp'] for k in g]; ys=[np.mean([f['cob'] for f in g[k]]) for k in g]
print("E agregado n_steps n",len(xs), spearmanr(xs,ys))
