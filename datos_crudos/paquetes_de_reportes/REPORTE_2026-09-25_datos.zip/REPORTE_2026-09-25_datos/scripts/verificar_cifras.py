"""
verificar_cifras.py — recálculo INDEPENDIENTE de las cifras del reporte de
avance del 24–25-09-2026 (secciones 2, 3.1, 3.2, 3.3 y 4.2–4.5) a partir de
los CSV crudos de este paquete.

Qué hace
--------
Lee SOLO los archivos de ../csv/ (y ../csv/calibracion_medida.json), recalcula
cada cifra numérica del reporte y la compara, dígito a dígito y con el mismo
redondeo con que aparece en el reporte, contra el valor escrito. Imprime:

  1. Detalle de cada cálculo (listas de episodios, inicios de congelamiento
     con sus coordenadas, tablas de exposición, etc.), para poder seguirlo.
  2. Una TABLA FINAL:  n | sección | cifra | valor del reporte | recalculado |
     coincide, con estas marcas en "coincide":
        si              reproduce con la definición principal (abajo);
        por_definicion  reproduce SOLO con una definición alternativa, que se
                        declara en la nota de la fila;
        no              no reproduce (ni con las alternativas probadas);
        n/v             no verificable con el paquete (el dato no está en los
                        CSV); NO es una discrepancia.
     Debajo de la tabla, las notas de cada fila.

La salida también se escribe en ../verificacion_cifras.txt (UTF-8).

Cómo correrlo
-------------
    cd scripts
    python verificar_cifras.py            # todo, con la §3.3 si se puede
    python verificar_cifras.py --sin-33   # salta la §3.3 (diversidad)

Requiere Python ≥ 3.9, numpy y scipy. Sólo escribe ../verificacion_cifras.txt
(y ../verificacion_cifras.json con --json).

La §3.3 (diversidad de arranques) es OPCIONAL: necesita el sorteo de
referencia del proyecto (`diversidad_arranques.py`, que a su vez importa
`sesion_robotat.sortear_poses_arranque`). Se importa desde RUTA_PROYECTO (más
abajo) con sys.path y sin escribir __pycache__. Si la ruta no existe, la
sección se salta con un aviso. Sus percentiles dependen de la versión ACTUAL
de ese código (márgenes y separación del sorteo): si cambia, cambian.
Monte Carlo con la semilla fija SEMILLA_MC = 0 (la que usa
`diversidad_arranques.evaluar` por defecto), 1000 sesiones de referencia.

Definiciones operativas (las mismas en todo el script)
-------------------------------------------------------
* Arena: cuadrado de 3 × 3 m en el marco del entorno (x, y ∈ [0, 3]).
* d_pared de una fila = min(x, 3 − x, y, 3 − y) con la pose (pose_env_x,
  pose_env_y) de esa fila. "Pared más cercana" = la que da ese mínimo
  (empates: x=0, x=3, y=0, y=3, en ese orden; se cuentan y no hay ninguno).
  u = coordenada A LO LARGO de esa pared (y para las paredes x, x para las
  paredes y); c = min(u, 3 − u) = distancia, a lo largo de la pared, a la
  esquina más próxima.
* Secuencia = filas de un mismo (archivo, episodio, agente) ordenadas por
  "paso".
* Fila REPETIDA = fila cuya terna (pose_env_x, pose_env_y, pose_env_th) es
  EXACTAMENTE igual (igualdad de float; se verificó que da lo mismo que
  comparar el texto) a la de la fila anterior de la misma secuencia.
* Racha congelada = filas repetidas consecutivas. INICIO de congelamiento =
  la primera fila repetida de la racha; su pose es la de la última fila viva.
  Largo de la racha = número de filas repetidas.
* Fila VIVA = fila no repetida.
* Exposición (principal) = decisiones-agente = TODAS las filas, repetidas
  incluidas, en la franja de d_pared. Alternativa "vivas" = sólo filas vivas.
* Franjas de d_pared: [0, 0.20), [0.20, 0.35), [0.35, 0.60), [0.60, ∞).
* "Cerca de la pared" = d_pared < 0.35 m (pared más cercana).
* Aproximación (visita) a una pared, umbral δ: racha máxima de filas
  consecutivas de una secuencia (vivas y repetidas) con d_pared < δ. Tres
  variantes: (A) se corta cuando cambia la pared más cercana; (B) no se
  corta (cualquier pared); (C) por pared específica (d a ESA pared < δ; una
  esquina cuenta para las dos). "Congelada" = contiene un inicio.
* Esquina (§4.5): tercios extremos = u < 1 o u > 2 de la pared más cercana;
  tercio medio = 1 ≤ u ≤ 2. "En esquina (≤ 0.75 m)" = c ≤ 0.75. "Distancia
  al vértice" = distancia euclídea al vértice más cercano de la arena.
* Dirección de entrada (§4.5): desplazamiento entre la fila i − k y la fila
  del inicio i (k = 3, 5, 10); ángulo contra la normal SALIENTE de la pared
  más cercana: ≤ 30° perpendicular, ≤ 60° oblicua, ≤ 120° paralela, > 120°
  alejándose; "±15°" = 75–105°. Pared adyacente = la MÁS CERCANA de las dos
  paredes perpendiculares a la más cercana (la de la esquina próxima); "de
  frente" = ángulo ≤ 30° con su normal saliente.

Qué definición reproduce cada cifra (lo confirma la corrida)
-----------------------------------------------------------
* §4.2 tabla por franjas (5/1285, 7/2677, 2/6035, 0/7818): exposición =
  TODAS las filas. Pero el contraste "0/7818 vs 12/3842" y el Fisher
  p = 1.6e-6 usan filas VIVAS en el lado cercano (con todas: 12/3962,
  p = 2.1e-6). "1/5982 vs 12/3842" = vivas; "1/5992 vs 12/3962" = todas.
* §4.2 aproximación "1/85 vs 12/104", p = 0.007: variante (A). La (B) da
  1/68 vs 12/94. Rango de p entre 0.25 y 0.60 m: (A) 0.003–0.01 (lo que cita
  el reporte final); (B) 0.003–0.04. El borrador decía 0.003–0.04 con la
  definición A: era una mezcla de A y B, corregida en el reporte.
* §4.3 paredes y / x (8/2460 vs 4/1502; 24-09 6/1821 vs 3/1232): pared más
  cercana, TODAS las filas a d < 0.35.
* §4.5 esquinas 0/1403 vs 9/1560: filas VIVAS (con todas: 0/1403 vs 9/1650).
  Robot 6 0/418 vs 9/392: filas VIVAS con d < 0.35 y c ≤ 0.75. "0.35–0.72 m
  del vértice": distancia euclídea (a lo largo de la pared sería 0.26–0.70).
  Dirección 7/10, 6/10 (±15°) y 6 de 7: ventana k = 5 (con k = 3 y 10 el
  "±15°" da 5 y 7).
* §6 (extra) "12 de las 14 últimas poses vivas a 0.17–0.29 m": sólo
  redondeando d al cm (sin redondear son 11; la otra está a 0.293 m).
* §3.1 "0 colisiones en ambas": vale con colisiones_015; con colisiones_022
  el ep 12 tiene 3 en hw y 3 en cada réplica.
* §4.3 "~1 / ~49 / ~86 cm": punto MEDIO de cada pared (como
  contraste_paredes.py); por la rotación del marco, de extremo a extremo la
  pared y = 3 va de −0.3 a 2.2 cm (un extremo queda FUERA de la plataforma
  supuesta) y las x de 84 a 88 cm.
* Robot de cada agente: columna robot_a{i} del CSV de episodios (24-09); en
  los CSV de decisiones, columna "robot" (se verifica que coincidan).
* Estadística: sd muestral (ddof = 1); IC95 con t de Student; t pareado;
  Wilcoxon de rangos con signo EXACTO (enumeración de los 2^n signos,
  p bilateral = 2·min(colas), convención de scipy); potencia bilateral
  α = 0.05 con t no central; Fisher exacto (scipy); P binomial condicional =
  P(X ≥ k | n eventos, p = fracción de exposición); IC95 de la razón de
  tasas: Clopper–Pearson sobre la proporción condicional, transformado.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

# --------------------------------------------------------------------------
# Rutas (relativas al paquete) y constantes
# --------------------------------------------------------------------------
AQUI = Path(__file__).resolve().parent
PAQUETE = AQUI.parent
CSV_DIR = PAQUETE / "csv"
SALIDA = PAQUETE / "verificacion_cifras.txt"
RUTA_PROYECTO = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots"
                     r"\controllers\coordinador_enjambre")

L = 3.0                      # lado de la arena (m)
FRANJAS = [(0.0, 0.20, "<0.20"), (0.20, 0.35, "0.20-0.35"),
           (0.35, 0.60, "0.35-0.60"), (0.60, math.inf, ">=0.60")]
CERCA = 0.35                 # "cerca de la pared"
SEMILLA_MC = 0               # Monte Carlo de la §3.3
# Plataforma útil del Robotat (config_robotat.py: AREA_UTIL_X_M / _Y_M). No
# está en los CSV: se toma como dato del reporte ("4.67 × 3.45 m").
PLATAFORMA_X, PLATAFORMA_Y = 4.67, 3.45

ARCH_DEC = {
    "11-09": ["20260911_sesion-evaluacion_etapa7_decisiones.csv"],
    "22-09": ["20260922_sesion-evaluacion_etapa7_decisiones.csv",
              "20260922_sesion-evaluacion_etapa7_decisiones_02.csv"],
    "24-09": ["20260924_sesion-evaluacion_etapa7_decisiones.csv"],
}

# --------------------------------------------------------------------------
# Salida: se imprime y se guarda
# --------------------------------------------------------------------------
_LINEAS: list[str] = []


def out(*partes):
    s = " ".join(str(p) for p in partes)
    print(s)
    _LINEAS.append(s)


def titulo(t):
    out("")
    out("=" * 100)
    out(t)
    out("=" * 100)


# --------------------------------------------------------------------------
# Registro de comparaciones
# --------------------------------------------------------------------------
TABLA: list[dict] = []


def _num(s: str) -> float:
    """'−0.0317' / '+0.0296' / '1 285' / '1.6e-6' → float."""
    s = s.replace("−", "-").replace("\u202f", "").replace(" ", "").replace("+", "")
    return float(s)


def reg(sec, cifra, reporte, recalc, estado, nota=""):
    TABLA.append(dict(seccion=sec, cifra=cifra, reporte=str(reporte),
                      recalculado=str(recalc), coincide=estado, nota=nota))


def num(sec, cifra, reporte, valor, dec=None, sig=None, nota="",
        si="si", signo=False):
    """Compara un número con el MISMO redondeo del reporte.
    dec = decimales; sig = cifras significativas. `si` = estado cuando
    coincide ("si" o "por_definicion")."""
    rv = _num(reporte)
    signo = signo or reporte.strip().startswith("+")
    if dec is not None:
        fmt = f"{{:{'+' if signo else ''}.{dec}f}}"
        a, b = fmt.format(valor), fmt.format(rv)
    else:
        a, b = f"{valor:.{sig}g}", f"{rv:.{sig}g}"

    def cero(s):  # '-0.000' y '+0.000' valen lo mismo que '0.000'
        return s.lstrip("+-") if float(s) == 0 else s
    ok = cero(a) == cero(b)
    reg(sec, cifra, reporte, a, si if ok else "no", nota)
    return ok


def cuenta(sec, cifra, reporte, recalc, ok, nota="", si="si"):
    reg(sec, cifra, reporte, recalc, si if ok else "no", nota)
    return ok


def nv(sec, cifra, reporte, nota):
    reg(sec, cifra, reporte, "—", "n/v", nota)


# --------------------------------------------------------------------------
# Lectura
# --------------------------------------------------------------------------
def leer_csv(nombre):
    with open(CSV_DIR / nombre, newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def sha(nombre):
    return hashlib.sha256((CSV_DIR / nombre).read_bytes()).hexdigest()[:12]


def pared_mas_cercana(x, y):
    """(pared, d, u, empate) con la convención de las definiciones."""
    ds = [("x=0", x, y), ("x=3", L - x, y), ("y=0", y, x), ("y=3", L - y, x)]
    mejor = min(ds, key=lambda t: t[1])      # primer mínimo = orden declarado
    empate = sum(1 for t in ds if t[1] == mejor[1]) > 1
    return mejor[0], mejor[1], mejor[2], empate


def franja(d):
    for lo, hi, nom in FRANJAS:
        if lo <= d < hi:
            return nom
    raise ValueError(d)


def cargar_sesion(fecha):
    """Lista de secuencias. Cada una: dict(archivo, ep, ag, robot, filas)."""
    seqs_out, diag = [], Counter()
    for arch in ARCH_DEC[fecha]:
        seqs = defaultdict(list)
        for r in leer_csv(arch):
            seqs[(int(r["episodio"]), int(r["agente"]))].append(r)
        for (ep, ag), filas in sorted(seqs.items()):
            filas.sort(key=lambda r: int(r["paso"]))
            pasos = [int(r["paso"]) for r in filas]
            diag["saltos_de_paso"] += sum(1 for a, b in zip(pasos, pasos[1:]) if b - a != 1)
            diag["pasos_duplicados"] += len(pasos) - len(set(pasos))
            robots = {r["robot"] for r in filas}
            if len(robots) != 1:
                diag["robot_varia"] += 1
            prev_f = prev_s = None
            prev_rep = False
            recs = []
            for r in filas:
                pf = (float(r["pose_env_x"]), float(r["pose_env_y"]), float(r["pose_env_th"]))
                ps = (r["pose_env_x"], r["pose_env_y"], r["pose_env_th"])
                rep = prev_f is not None and pf == prev_f
                if prev_s is not None and rep != (ps == prev_s):
                    diag["float_distinto_de_texto"] += 1
                pared, d, u, emp = pared_mas_cercana(pf[0], pf[1])
                diag["empates_de_pared"] += int(emp)
                recs.append(dict(paso=int(r["paso"]), x=pf[0], y=pf[1], th=pf[2],
                                 rep=rep, ini=rep and not prev_rep, pared=pared,
                                 d=d, u=u, c=min(u, L - u), robot=int(r["robot"])))
                prev_f, prev_s, prev_rep = pf, ps, rep
            seqs_out.append(dict(archivo=arch, ep=ep, ag=ag, robot=int(filas[0]["robot"]),
                                 filas=recs))
    return seqs_out, diag


def inicios(seqs):
    """Inicios con su contexto: índice, largo de racha y si llega al final."""
    res = []
    for s in seqs:
        f = s["filas"]
        for i, r in enumerate(f):
            if r["ini"]:
                j = i
                while j < len(f) and f[j]["rep"]:
                    j += 1
                res.append(dict(seq=s, i=i, fila=r, largo=j - i, hasta_fin=(j == len(f))))
    return res


def filas_de(seqs):
    return [r for s in seqs for r in s["filas"]]


# --------------------------------------------------------------------------
# Utilidades estadísticas
# --------------------------------------------------------------------------
def wilcoxon_exacto(d):
    """p bilateral exacto (2·min colas, tope 1), sin ceros ni empates."""
    d = np.asarray(d, float)
    assert np.all(d != 0)
    rangos = stats.rankdata(np.abs(d))
    w_mas = rangos[d > 0].sum()
    todos = [sum(r for r, s in zip(rangos, signos) if s)
             for signos in itertools.product([0, 1], repeat=len(d))]
    todos = np.array(todos)
    p = 2 * min(np.mean(todos <= w_mas), np.mean(todos >= w_mas))
    return min(1.0, float(p)), float(w_mas)


def potencia_t(m, sd, n, alfa=0.05):
    gl, nc = n - 1, abs(m) / sd * math.sqrt(n)
    tc = stats.t.ppf(1 - alfa / 2, gl)
    return 1 - stats.nct.cdf(tc, gl, nc) + stats.nct.cdf(-tc, gl, nc)


def cola_binomial(k, n, p):
    return float(stats.binom.sf(k - 1, n, p))


def ic_razon_tasas(k1, e1, k2, e2, conf=0.95):
    """Razón de tasas (k1/e1)/(k2/e2) con IC exacto condicional."""
    n = k1 + k2
    a = 1 - conf
    lo = 0.0 if k1 == 0 else stats.beta.ppf(a / 2, k1, n - k1 + 1)
    hi = 1.0 if k1 == n else stats.beta.ppf(1 - a / 2, k1 + 1, n - k1)
    f = e2 / e1
    return (k1 / e1) / (k2 / e2), lo / (1 - lo) * f, (hi / (1 - hi) * f if hi < 1 else math.inf)


def fisher(tabla, alt="two-sided"):
    return float(stats.fisher_exact(tabla, alternative=alt)[1])


# ==========================================================================
# §0  Archivos
# ==========================================================================
def seccion_archivos():
    titulo("ARCHIVOS USADOS (sha256, 12 primeros hex)")
    for p in sorted(CSV_DIR.iterdir()):
        out(f"  {sha(p.name)}  {p.name}")
    out(f"  python {sys.version.split()[0]}  numpy {np.__version__}  scipy "
        f"{__import__('scipy').__version__}")


# ==========================================================================
# §2  La corrida del 24-09
# ==========================================================================
def seccion_2():
    titulo("§2  PUNTO DE PARTIDA: LA CORRIDA DEL 24-09 (20260924_…_episodios.csv)")
    e = leer_csv("20260924_sesion-evaluacion_etapa7_episodios.csv")
    val = [r for r in e if r["valido"] == "1"]

    def motivo(r):
        m = r["motivo"]
        if r["valido"] == "1":
            return "valido"
        if "CONGELADO" in m:
            return "congelado"
        if "antigüedad" in m:
            return "antiguedad"
        if "NO SIGUE" in m:
            return "no_sigue"
        return "otro"

    por = defaultdict(list)
    for r in e:
        por[motivo(r)].append(int(r["episodio"]))
    for k, v in por.items():
        out(f"  {k:<11} {len(v):2d}  episodios {v}")

    comp = {tuple(r[f"robot_a{i}"] for i in range(5)) for r in e}
    colo = Counter(r["colocacion"] for r in e)
    fac = Counter(r["factor"] for r in e)
    rpm = Counter(r["rpm_aborto"] for r in e)
    out(f"  composición robot_a0..a4: {comp}   colocación: {dict(colo)}   factor: {dict(fac)}   rpm_aborto: {dict(rpm)}")

    cuenta("§2", "intentos", "17", len(e), len(e) == 17)
    cuenta("§2", "válidos", "1", len(val), len(val) == 1)
    cuenta("§2", "composición", "[1, 5, 8, 6, 9]",
           "[" + ", ".join(list(comp)[0]) + "]" if len(comp) == 1 else comp,
           comp == {("1", "5", "8", "6", "9")}, "robot_a0..a4 idéntico en los 17 intentos")
    cuenta("§2", "colocación autónoma", "autónoma (17/17)", dict(colo), colo == Counter({"auto": 17}))
    cuenta("§2", "factor", "0.40", dict(fac), set(fac) == {"0.4"})
    v = val[0]
    cuenta("§2", "decisiones del válido", "500", v["decisiones"], v["decisiones"] == "500")
    cuenta("§2", "motivo: válido (ep)", "1 (ep 2)", f"{len(por['valido'])} (ep {por['valido']})",
           por["valido"] == [2])
    cuenta("§2", "motivo: marcador congelado", "10: ep 1, 3, 10–17",
           f"{len(por['congelado'])}: ep {por['congelado']}",
           por["congelado"] == [1, 3] + list(range(10, 18)))
    cuenta("§2", "motivo: antigüedad de pose", "5: ep 5–9",
           f"{len(por['antiguedad'])}: ep {por['antiguedad']}", por["antiguedad"] == [5, 6, 7, 8, 9])
    dec_ant = sorted({r["decisiones"] for r in e if motivo(r) == "antiguedad"})
    cuenta("§2", "antigüedad: a las N decisiones", "4", dec_ant, dec_ant == ["4"])
    cuenta("§2", "motivo: no sigue el comando", "1: ep 4",
           f"{len(por['no_sigue'])}: ep {por['no_sigue']}", por["no_sigue"] == [4])
    r4 = next(r for r in e if r["episodio"] == "4")
    ag = int(re.search(r"agente (\d+) NO SIGUE", r4["motivo"]).group(1))
    pct = re.search(r"recorrió el (\d+) %", r4["motivo"]).group(1)
    cuenta("§2", "ep 4: robot y %", "robot 5 al 50 %", f"robot {r4[f'robot_a{ag}']} al {pct} %",
           r4[f"robot_a{ag}"] == "5" and pct == "50", f"agente {ag} → robot_a{ag}")

    # congelamientos por robot (agente del motivo → robot_a{i})
    rob = Counter()
    for r in e:
        m = re.search(r"agente (\d+) CONGELADO", r["motivo"])
        if m:
            rob[int(r[f"robot_a{m.group(1)}"])] += 1
    out(f"  congelamientos por robot (motivo → robot_a{{i}}): {dict(sorted(rob.items()))}")
    esperado = {1: 3, 8: 3, 9: 3, 5: 1}
    cuenta("§2", "congelados por robot", "r1 ×3, r8 ×3, r9 ×3, r5 ×1, r6 ×0",
           ", ".join(f"r{k} ×{rob.get(k, 0)}" for k in (1, 8, 9, 5, 6)),
           dict(rob) == esperado)
    cuenta("§2/§10", "robots que se congelaron", "4 de 5 (1, 5, 8, 9; no el 6)",
           f"{len(rob)} de 5 ({sorted(rob)})", sorted(rob) == [1, 5, 8, 9])

    num("§2", "ep 2 semilla", "420001", float(v["semilla"]), dec=0)
    num("§2", "ep 2 cobertura", "0.2416", float(v["cobertura_aoi"]), dec=4)
    cuenta("§2", "ep 2 colisiones", "0", f"{v['colisiones_015']} (0.15 m) / {v['colisiones_022']} (0.22 m)",
           v["colisiones_015"] == "0" and v["colisiones_022"] == "0")
    num("§2", "ep 2 d_pared mín (m)", "0.2293", float(v["d_pared_min"]), dec=4)
    nv("§2", "robot 5 fuera de la red", "5.4 min",
       "los CSV no traen marcas de tiempo absolutas ni registros de red; sale de la consola/bitácora")
    return e


# ==========================================================================
# §3.1  Comparación citable del 11-09
# ==========================================================================
def seccion_31():
    titulo("§3.1  COMPARACIÓN CITABLE (11-09): hw vs réplica con capas / réplica sesgada")
    hwf = leer_csv("20260911_sesion-evaluacion_etapa7_episodios.csv")
    val = [r for r in hwf if r["valido"] == "1"]
    EPS = [int(r["episodio"]) for r in val]
    out(f"  válidos 11-09: {EPS} de {len(hwf)} filas")
    H = np.array([float(r["cobertura_aoi"]) for r in val])
    V = np.array([float(r["cobertura_replica"]) for r in val])

    on = leer_csv("20260912_sesion-replica_etapa7_capas-on.csv")
    off = leer_csv("20260912_sesion-replica_etapa7_capas-off.csv")
    on_val = [r for r in on if r["valido"] in ("1", "True")]
    out(f"  réplica con capas: {len(on)} filas, {len(on_val)} válidas")
    reps = defaultdict(list)
    for r in on_val:
        reps[int(r["episodio"])].append(float(r["cobertura_aoi"]))
    # chequeo: la columna cobertura_hw de la réplica es la del 11-09
    chk = all(abs(float(r["cobertura_hw"]) - H[EPS.index(int(r["episodio"]))]) == 0 for r in on)
    out(f"  cobertura_hw de la réplica == cobertura_aoi del 11-09: {chk}")
    M = np.array([np.mean(reps[e]) for e in EPS])
    S = np.array([np.std(reps[e], ddof=1) for e in EPS])
    D = H - M

    rep_on = {1: ("0.3600", "0.0005"), 2: ("0.3402", "0.0212"), 3: ("0.3969", "0.0008"),
              10: ("0.3084", "0.0004"), 12: ("0.2991", "0.0178")}
    rep_hw = {1: "0.3282", 2: "0.3353", 3: "0.2856", 10: "0.3101", 12: "0.3288"}
    rep_ses = {1: "0.3102", 2: "0.3253", 3: "0.2909", 10: "0.2728", 12: "0.2707"}
    rep_dif = {1: "−0.0317", 2: "−0.0050", 3: "−0.1113", 10: "+0.0017", 12: "+0.0296"}
    for k, e in enumerate(EPS):
        out(f"  ep {e:2d}: hw {H[k]:.6f}  con capas {reps[e]} → {M[k]:.6f} ± {S[k]:.6f}  "
            f"sesgada {V[k]:.6f}  hw−con {D[k]:+.6f}")
        num("§3.1", f"ep {e} hw", rep_hw[e], H[k], dec=4)
        cuenta("§3.1", f"ep {e} réplica con capas: n reps", "3", len(reps[e]), len(reps[e]) == 3)
        num("§3.1", f"ep {e} réplica con capas (media)", rep_on[e][0], M[k], dec=4)
        num("§3.1", f"ep {e} réplica con capas (sd)", rep_on[e][1], S[k], dec=4)
        num("§3.1", f"ep {e} réplica sesgada", rep_ses[e], V[k], dec=4)
        num("§3.1", f"ep {e} hw − con capas", rep_dif[e], D[k], dec=4, signo=True)

    num("§3.1", "hw media", "0.3176", H.mean(), dec=4)
    num("§3.1", "hw sd", "0.0202", H.std(ddof=1), dec=4)
    num("§3.1", "réplica con capas media", "0.3409", M.mean(), dec=4)
    num("§3.1", "réplica sesgada media", "0.2940", V.mean(), dec=4)
    num("§3.1", "hw − con capas: media", "−0.0233", D.mean(), dec=4)
    num("§3.1", "hw − con capas: sd", "0.0538", D.std(ddof=1), dec=4)

    n = len(D)
    t975 = stats.t.ppf(0.975, n - 1)
    ic = t975 * D.std(ddof=1) / math.sqrt(n)
    num("§3.1", "IC95 hw − con capas (inf)", "−0.0901", D.mean() - ic, dec=4)
    num("§3.1", "IC95 hw − con capas (sup)", "+0.0435", D.mean() + ic, dec=4)
    cuenta("§3.1", "diferencias positivas", "2/5", f"{int((D > 0).sum())}/{n}", (D > 0).sum() == 2)
    p_t = float(stats.ttest_rel(H, M).pvalue)
    p_w, w = wilcoxon_exacto(D)
    p_w_sc = float(stats.wilcoxon(H, M, method="exact").pvalue)
    out(f"  t pareado p = {p_t:.6f};  Wilcoxon exacto (propio) W+ = {w}, p = {p_w:.6f}; scipy exacto p = {p_w_sc:.6f}")
    num("§3.1", "t pareado p", "0.3872", p_t, dec=4)
    num("§3.1", "Wilcoxon exacto p", "0.4375", p_w, dec=4)
    num("§3.1", "diferencia relativa (%)", "−7", 100 * D.mean() / M.mean(), dec=0,
        nota=f"media(hw − con capas)/media(con capas) = {100 * D.mean() / M.mean():.2f} %")

    # tamaño de muestra y potencia
    m, sd = abs(D.mean()), D.std(ddof=1)
    n_ic = next(k for k in range(3, 100000) if stats.t.ppf(0.975, k - 1) * sd / math.sqrt(k) < m)
    n80 = next(k for k in range(3, 100000) if potencia_t(m, sd, k) >= 0.80)
    z, zb = stats.norm.ppf(0.975), stats.norm.ppf(0.80)
    nz_ic, nz_80 = (z * sd / m) ** 2, ((z + zb) * sd / m) ** 2
    out(f"  n para que el IC excluya 0 (t) = {n_ic};  n potencia 0.80 (t no central) = {n80};  "
        f"con z: {nz_ic:.3f} y {nz_80:.3f}")
    cuenta("§3.1", "n para que el IC excluya el 0 (t)", "23", n_ic, n_ic == 23,
           "supone la media y la sd observadas como verdaderas")
    cuenta("§3.1", "n para potencia 0.80 (t no central)", "44", n80, n80 == 44)
    num("§3.1", "n IC excluye 0 (z, sin redondear)", "20.4", nz_ic, dec=1)
    num("§3.1", "n potencia 0.80 (z, sin redondear)", "41.8", nz_80, dec=1)
    for k, r in ((5, "0.12"), (10, "0.23"), (20, "0.45")):
        num("§3.1", f"potencia con n = {k}", r, potencia_t(m, sd, k), dec=2)

    # réplica sesgada
    DS = H - V
    ics = t975 * DS.std(ddof=1) / math.sqrt(n)
    num("§3.1", "hw − sesgada: media", "+0.0236", DS.mean(), dec=4, signo=True)
    num("§3.1", "hw − sesgada: sd", "0.0246", DS.std(ddof=1), dec=4)
    num("§3.1", "IC95 hw − sesgada (inf)", "−0.0070", DS.mean() - ics, dec=4)
    num("§3.1", "IC95 hw − sesgada (sup)", "+0.0542", DS.mean() + ics, dec=4)
    num("§3.1", "hw − sesgada: t p", "0.0986", float(stats.ttest_rel(H, V).pvalue), dec=4)
    num("§3.1", "hw − sesgada: Wilcoxon p", "0.1250", wilcoxon_exacto(DS)[0], dec=4)

    # sin capas
    fuera = [r for r in off if "fuera de la arena" in r["motivo"]]
    inval = [r for r in off if r["valido"] not in ("1", "True")]
    t = np.array([float(r["duracion_s"]) for r in off])
    out(f"  sin capas: {len(off)} episodios, inválidos {len(inval)}, 'fuera de la arena' {len(fuera)}; "
        f"duraciones {sorted(np.round(t, 3))}")
    cuenta("§3.1", "sin capas: salen de la arena", "15/15", f"{len(fuera)}/{len(off)}",
           len(fuera) == 15 and len(off) == 15)
    num("§3.1", "sin capas: mediana duración (s)", "9.61", float(np.median(t)), dec=2)
    num("§3.1", "sin capas: duración mín (s)", "3.90", float(t.min()), dec=2)
    num("§3.1", "sin capas: duración máx (s)", "20.20", float(t.max()), dec=2)

    # seguridad
    def media(filas, k):
        return float(np.mean([float(r[k]) for r in filas]))
    num("§3.1", "d_pared mín hw (media, m)", "0.1126", media(val, "d_pared_min"), dec=4)
    num("§3.1", "d_pared mín réplica con capas (media 15, m)", "0.1571", media(on_val, "d_pared_min"), dec=4)
    num("§3.1", "violaciones 0.18 m hw / ep", "2.40", media(val, "viola_018"), dec=2)
    num("§3.1", "violaciones 0.18 m réplica / ep", "2.53", media(on_val, "viola_018"), dec=2)
    num("§3.1", "fracción con CBF hw", "0.412", media(val, "frac_cbf"), dec=3)
    num("§3.1", "fracción con CBF réplica", "0.490", media(on_val, "frac_cbf"), dec=3)
    c15 = (sum(int(r["colisiones_015"]) for r in val), sum(int(r["colisiones_015"]) for r in on_val))
    c22 = (sum(int(r["colisiones_022"]) for r in val), sum(int(r["colisiones_022"]) for r in on_val))
    cuenta("§3.1", "colisiones hw / réplica", "0 / 0",
           f"0.15 m: {c15[0]} / {c15[1]}; 0.22 m: {c22[0]} / {c22[1]}", c15 == (0, 0),
           si="por_definicion", nota="coincide con colisiones_015; con colisiones_022 ambas tienen 3 por episodio en el ep 12 "
           "(hw 3 en 1 ep; réplica 3 en cada una de las 3 reps)")
    return dict(H=H, V=V, val=val)


# ==========================================================================
# §3.2  El 24-09: un par incompleto
# ==========================================================================
def seccion_32(e24, r31):
    titulo("§3.2  EL 24-09 (ep 2) CONTRA LAS MEDIAS DEL 11-09")
    v = next(r for r in e24 if r["valido"] == "1")
    cob, rep = float(v["cobertura_aoi"]), float(v["cobertura_replica"])
    num("§3.2", "ep 2 cobertura", "0.2416", cob, dec=4)
    num("§3.2", "ep 2 réplica sesgada", "0.2544", rep, dec=4)
    num("§3.2", "ep 2 diferencia", "−0.0127", cob - rep, dec=4)
    num("§3.2", "ep 2 fracción con CBF", "0.065", float(v["frac_cbf"]), dec=3)
    num("§3.2", "ep 2 escapes", "0", float(v["n_escape"]), dec=0)
    num("§3.2", "ep 2 violaciones 0.18 m", "0", float(v["viola_018"]), dec=0)
    num("§3.2", "ep 2 d_pared mín (m)", "0.229", float(v["d_pared_min"]), dec=3)
    val = r31["val"]

    def media(k):
        return float(np.mean([float(r[k]) for r in val]))
    num("§3.2", "11-09 media fracción con CBF", "0.412", media("frac_cbf"), dec=3)
    num("§3.2", "11-09 media escapes", "69", media("n_escape"), dec=0)
    num("§3.2", "11-09 media violaciones", "2.4", media("viola_018"), dec=1)
    num("§3.2", "11-09 media d_pared mín (m)", "0.113", media("d_pared_min"), dec=3)
    out(f"  11-09 medias: cobertura {media('cobertura_aoi'):.6f}  réplica sesgada "
        f"{np.mean(r31['V']):.6f}  diferencia {np.mean(r31['H'] - r31['V']):+.6f}")
    # chequeos de --verificar que salen de los CSV
    cuenta("§3.2", "válidos del 24-09", "1 (ep 2) de 17",
           f"{sum(r['valido'] == '1' for r in e24)} (ep {v['episodio']}) de {len(e24)}",
           v["episodio"] == "2" and len(e24) == 17)
    cuenta("§3.2", "régimen decisiones / factor / rpm", "500 / 0.40 / 200 rpm",
           f"{v['decisiones']} / {v['factor']} / {v['rpm_aborto']}",
           (v["decisiones"], float(v["factor"]), float(v["rpm_aborto"])) == ("500", 0.4, 200.0))
    previas = sum(int(r["decisiones"]) for r in e24 if int(r["episodio"]) < 2 and r["decisiones"])
    cuenta("§3.2", "decisiones previas al ep 2 en la sesión", "390", previas, previas == 390,
           "suma de 'decisiones' de los intentos anteriores (sólo el ep 1)")
    nv("§3.2", "decisiones con rampa", "0",
       "depende del largo de la rampa definido en replica_con_capas.py (no está en el paquete)")
    nv("§3.2", "ida y vuelta de la calibración identidad", "2.22e-16",
       "es un chequeo numérico interno de replica_con_capas.py --verificar; no sale de los CSV")


# ==========================================================================
# §3.3  Precisión de la colocación (CSV) y diversidad (proyecto, opcional)
# ==========================================================================
def seccion_33_colocacion(e24):
    titulo("§3.3  PRECISIÓN DE LA COLOCACIÓN AUTÓNOMA DEL 24-09 (sólo CSV)")
    err = [float(r[f"col_err_m_a{i}"]) for r in e24 for i in range(5) if r[f"col_err_m_a{i}"] != ""]
    ts = [float(r["col_t_s"]) for r in e24]
    out(f"  col_err_m: n = {len(err)}, mediana {np.median(err):.5f} m, máx {max(err):.4f} m; "
        f"col_t_s {min(ts)}–{max(ts)} s")
    cuenta("§3.3", "n de errores de colocación", "85", len(err), len(err) == 85)
    num("§3.3", "error de posición mediano (m)", "0.028", float(np.median(err)), dec=3,
        nota="incluye al robot 5 'no avanza' de los ep 5–9 (errores de 0.44–2.03 m)")
    cuenta("§3.3", "tiempo por colocación (s)", "19–34", f"{min(ts):.1f}–{max(ts):.1f}",
           round(min(ts)) == 19 and round(max(ts)) == 34)
    v = next(r for r in e24 if r["valido"] == "1")
    e2 = [float(v[f"col_err_m_a{i}"]) for i in range(5)]
    r2 = [abs(float(v[f"col_err_rumbo_deg_a{i}"])) for i in range(5)]
    cuenta("§3.3", "ep 2 error de posición (cm)", "2.3–3.5",
           f"{100 * min(e2):.2f}–{100 * max(e2):.2f}",
           f"{100 * min(e2):.1f}" == "2.3" and f"{100 * max(e2):.1f}" == "3.5")
    cuenta("§3.3", "ep 2 error de rumbo (°)", "0.7–6.8", f"{min(r2):.1f}–{max(r2):.1f}",
           f"{min(r2):.1f}" == "0.7" and f"{max(r2):.1f}" == "6.8")


def seccion_33_diversidad(e24):
    titulo(f"§3.3  DIVERSIDAD DE ARRANQUES (diversidad_arranques del proyecto; semilla MC = {SEMILLA_MC})")
    if not RUTA_PROYECTO.exists():
        out(f"  ⚠ AVISO: no existe {RUTA_PROYECTO}; se SALTA la §3.3 (diversidad). "
            f"Las demás secciones no dependen del proyecto.")
        for fila in ("11-09 válidos", "24-09 ep 2", "24-09 17 intentos", "22-09 _03"):
            nv("§3.3", f"diversidad {fila}", "(tabla §3.3)", "sección opcional saltada: falta el proyecto")
        return
    sys.dont_write_bytecode = True          # no escribir __pycache__ en el proyecto
    sys.path.insert(0, str(RUTA_PROYECTO))
    try:
        import diversidad_arranques as da  # noqa: E402
    except Exception as exc:               # pragma: no cover
        out(f"  ⚠ AVISO: no se pudo importar diversidad_arranques ({exc!r}); se salta la §3.3")
        return
    X0 = ("x0", "y0", "th0")

    def evaluar_n(eps):
        """Como da.evaluar, pero también con 1 episodio (disp_centroide = 0
        en la sesión y en todas las simuladas → percentil 50 por empates).
        Mismo orden de consumo del generador que da.evaluar."""
        eps = [np.asarray(x, float) for x in eps]
        n_ep, n_ag = len(eps), eps[0].shape[0]
        rng = np.random.default_rng(SEMILLA_MC)
        grande = np.concatenate(da._sortear_sesion(400, n_ag, rng))
        rx, ry = grande[:, 0], grande[:, 1]
        val = da.estadisticos(eps, rx, ry)
        sims = [da.estadisticos(da._sortear_sesion(n_ep, n_ag, rng), rx, ry)
                for _ in range(da.N_REFERENCIA)]
        pct, band = {}, []
        for nombre, cola in da.ESTADISTICOS:
            dist = np.array([s[nombre] for s in sims])
            p = 100.0 * (np.mean(dist < val[nombre]) + 0.5 * np.mean(dist == val[nombre]))
            pct[nombre] = float(p)
            if ((cola == "baja" and p < 5) or (cola == "alta" and p > 95)
                    or (cola == "ambas" and (p < 2.5 or p > 97.5))):
                band.append(nombre)
        ext = [b for b in band if pct[b] < 0.5 or pct[b] > 99.5]
        if not band:
            ver = "compatible"
        elif len(band) == 1 and not ext:
            ver = "aviso (1 estadístico en la cola)"
        else:
            ver = "⚠ poco representativos"
        return val, pct, band, ver

    f11 = leer_csv("20260911_sesion-evaluacion_etapa7_episodios.csv")
    f22_3 = leer_csv("20260922_sesion-evaluacion_etapa7_episodios_03.csv")
    casos = [
        ("11-09, 5 válidos (x0)", da.episodios_desde_filas(f11, 5, X0, True),
         dict(vec="0.273", pct="0.0", cel="8/16", ksx="100", ksy="100", ver="⚠ poco representativos")),
        ("24-09, ep 2 válido (x0, n = 1)", da.episodios_desde_filas(e24, 5, X0, True),
         dict(vec="0.849", pct="85.2", cel="5/16", ksx="6.9", ksy="68.9", ver="sin banderas")),
        ("24-09, los 17 intentos (x0)", da.episodios_desde_filas(e24, 5, X0, False),
         dict(vec="0.736", pct="45.4", cel="16/16", ksx="4.3", ksy="81.4", ver="compatible")),
        ("22-09 _03, 3 intentos (x0)", da.episodios_desde_filas(f22_3, 5, X0, False),
         dict(vec="0.720", pct="40.4", cel="12/16", ksx="26.4", ksy="91.8", ver="compatible")),
    ]
    for nombre, eps, rep in casos:
        val, pct, band, ver = evaluar_n(eps)
        celdas = round(val["celdas_cubiertas"] * 16)
        out(f"  {nombre}: n = {len(eps)} episodios")
        for k, _ in da.ESTADISTICOS:
            out(f"     {k:<17} {val[k]:8.4f}  percentil {pct[k]:5.1f}")
        out(f"     banderas {band} → {ver}")
        num("§3.3", f"{nombre}: vecino medio (m)", rep["vec"], val["vecino_medio"], dec=3)
        num("§3.3", f"{nombre}: percentil vecino", rep["pct"], pct["vecino_medio"], dec=1)
        cuenta("§3.3", f"{nombre}: celdas", rep["cel"], f"{celdas}/16", f"{celdas}/16" == rep["cel"])
        num("§3.3", f"{nombre}: percentil KS x", rep["ksx"], pct["ks_x"], dec=1)
        num("§3.3", f"{nombre}: percentil KS y", rep["ksy"], pct["ks_y"], dec=1)
        # categorías: sin banderas ≡ compatible; aviso; poco representativos
        def cat(s):
            return "poco" if "poco" in s else ("aviso" if "aviso" in s else "compatible")
        cuenta("§3.3", f"{nombre}: veredicto", rep["ver"], f"{ver} (banderas {band})",
               cat(ver) == cat(rep["ver"]))
        if len(eps) == 1:
            out("     (n = 1: da.evaluar exige ≥ 2; Monte Carlo propio con las mismas funciones)")


def seccion_34_extra():
    titulo("§3.4 (extra)  BLANCOS REPETIDOS ENTRE ARCHIVOS")
    bl = []
    for nom in ("20260922_sesion-evaluacion_etapa7_episodios_02.csv",
                "20260922_sesion-evaluacion_etapa7_episodios_03.csv",
                "20260924_sesion-evaluacion_etapa7_episodios.csv"):
        for r in leer_csv(nom):
            bl.append((nom[6:8] + "-" + nom[4:6], r["episodio"],       # "22-09" / "24-09"
                       tuple(r[f"blanco_{c}_a{i}"] for i in range(5) for c in ("x", "y", "th"))))
    unicos = {b[2] for b in bl}
    out(f"  blancos: {len(bl)}, únicos: {len(unicos)}")
    cuenta("§3.4", "blancos 22-09 _02 + _03 + 24-09 (total / únicos)", "22 / 17",
           f"{len(bl)} / {len(unicos)}", (len(bl), len(unicos)) == (22, 17))
    b24 = {r[1]: r[2] for r in bl if r[0].startswith("24")}
    ok = all(b[2] == b24[b[1]] for b in bl if not b[0].startswith("24"))
    cuenta("§3.4", "22-09 _02 ep 1–2 y _03 ep 1–3 = 24-09 ep 1–3", "idénticos", str(ok), ok)


# ==========================================================================
# §4.2–4.5  Congelamientos y pared
# ==========================================================================
def seccion_4():
    S, D = {}, {}
    for f in ARCH_DEC:
        S[f], D[f] = cargar_sesion(f)
    I = {f: inicios(S[f]) for f in S}

    titulo("§4  CONGELAMIENTOS: DETECCIÓN EN LOS CSV DE DECISIONES")
    for f in S:
        filas = filas_de(S[f])
        out(f"  {f}: secuencias {len(S[f])}, filas {len(filas)}, repetidas {sum(r['rep'] for r in filas)}, "
            f"inicios {len(I[f])}, diagnóstico {dict(D[f])}")
        for it in I[f]:
            r, s = it["fila"], it["seq"]
            out(f"     {s['archivo'][9:]} ep {s['ep']:2d} ag {s['ag']} robot {s['robot']} paso {r['paso']:3d} "
                f"({r['x']:.4f}, {r['y']:.4f}) pared {r['pared']} d {r['d']:.4f} u {r['u']:.3f} "
                f"c {r['c']:.3f} racha {it['largo']} {'(hasta el final)' if it['hasta_fin'] else ''}")

    # --- robot de cada agente: CSV de decisiones vs robot_a{i} del de episodios
    e24 = leer_csv("20260924_sesion-evaluacion_etapa7_episodios.csv")
    mapa_ep = {(int(r["episodio"]), i): int(r[f"robot_a{i}"]) for r in e24 for i in range(5)}
    dif = sum(1 for s in S["24-09"] if mapa_ep[(s["ep"], s["ag"])] != s["robot"])
    out(f"  24-09: secuencias cuyo 'robot' difiere de robot_a{{i}}: {dif}")

    # ---------------- §4.2 ----------------
    titulo("§4.2  NÚMEROS CITABLES")
    n11, n22, n24 = len(I["11-09"]), len(I["22-09"]), len(I["24-09"])
    cuenta("§4.2", "congelamientos (11 / 22 / 24-09; total)", "1 / 4 / 10; 15",
           f"{n11} / {n22} / {n24}; {n11 + n22 + n24}", (n11, n22, n24) == (1, 4, 10))
    hz = []
    for nom in ("20260911_sesion-evaluacion_etapa7_episodios.csv",
                "20260922_sesion-evaluacion_etapa7_episodios.csv",
                "20260922_sesion-evaluacion_etapa7_episodios_03.csv",
                "20260924_sesion-evaluacion_etapa7_episodios.csv"):
        for r in leer_csv(nom):
            if r.get("decisiones") and int(r["decisiones"]) >= 50:
                hz.append(int(r["decisiones"]) / float(r["duracion_s"]))
    num("§4.2", "frecuencia de decisión (Hz)", "10", float(np.median(hz)), dec=0,
        nota=f"mediana de decisiones/duracion_s en {len(hz)} episodios con ≥ 50 decisiones "
             f"(rango {min(hz):.2f}–{max(hz):.2f})")
    todos_ini = I["11-09"] + I["22-09"] + I["24-09"]
    largos = Counter(it["largo"] for it in todos_ini)
    fin = sum(it["hasta_fin"] for it in todos_ini)
    cuenta("§4.2", "largo de las rachas", "todas exactamente 10 filas (cortadas por el aborto)",
           f"largos {dict(largos)}; {fin}/{len(todos_ini)} llegan al final de la secuencia",
           largos == Counter({10: 15}) and fin == 15,
           "largo = filas repetidas; con la última viva son 11 filas con la misma pose")

    F = filas_de(S["22-09"]) + filas_de(S["24-09"])
    ini2224 = I["22-09"] + I["24-09"]
    exp_t = Counter(franja(r["d"]) for r in F)
    exp_v = Counter(franja(r["d"]) for r in F if not r["rep"])
    ev = Counter(franja(it["fila"]["d"]) for it in ini2224)
    out("  22+24-09  franja     inicios  filas(todas)  filas(vivas)  ‰(todas)")
    for _, _, nom in FRANJAS:
        out(f"            {nom:<10} {ev[nom]:4d}   {exp_t[nom]:8d}     {exp_v[nom]:8d}    "
            f"{1000 * ev[nom] / exp_t[nom]:.3f}")
    rep_tab = {"<0.20": ("5 / 1 285", "3.9"), "0.20-0.35": ("7 / 2 677", "2.6"),
               "0.35-0.60": ("2 / 6 035", "0.33"), ">=0.60": ("0 / 7 818", "0")}
    for _, _, nom in FRANJAS:
        k, e = ev[nom], exp_t[nom]
        rk, re_ = [int(_num(x)) for x in rep_tab[nom][0].split("/")]
        cuenta("§4.2", f"franja {nom}: inicios / decisiones-agente", rep_tab[nom][0], f"{k} / {e}",
               (k, e) == (rk, re_), "exposición = todas las filas (repetidas incluidas)")
        dec = {"3.9": 1, "2.6": 1, "0.33": 2, "0": 0}[rep_tab[nom][1]]
        num("§4.2", f"franja {nom}: por mil", rep_tab[nom][1], 1000 * k / e, dec=dec)

    lejos_t = exp_t[">=0.60"]; lejos_v = exp_v[">=0.60"]
    cerca_t = exp_t["<0.20"] + exp_t["0.20-0.35"]
    cerca_v = exp_v["<0.20"] + exp_v["0.20-0.35"]
    k_cerca = ev["<0.20"] + ev["0.20-0.35"]
    p_v = fisher([[k_cerca, cerca_v - k_cerca], [ev[">=0.60"], lejos_v - ev[">=0.60"]]], "greater")
    p_t = fisher([[k_cerca, cerca_t - k_cerca], [ev[">=0.60"], lejos_t - ev[">=0.60"]]], "greater")
    out(f"  Fisher unilateral lejos vs cerca: vivas 0/{lejos_v} vs {k_cerca}/{cerca_v} p = {p_v:.4g}; "
        f"todas 0/{lejos_t} vs {k_cerca}/{cerca_t} p = {p_t:.4g}")
    cuenta("§4.2", "contraste lejos / cerca", "0/7818 lejos vs 12/3842 cerca",
           f"vivas: {ev['>=0.60']}/{lejos_v} vs {k_cerca}/{cerca_v}; todas: {ev['>=0.60']}/{lejos_t} vs {k_cerca}/{cerca_t}",
           (lejos_v, k_cerca, cerca_v) == (7818, 12, 3842), si="por_definicion",
           nota="3842 = filas VIVAS a d < 0.35; la tabla de franjas justo arriba usa TODAS las filas "
                "(1285 + 2677 = 3962). El reporte mezcla denominadores sin decirlo")
    num("§4.2", "Fisher unilateral p (lejos vs cerca)", "1.6e-6", p_v, sig=2, si="por_definicion",
        nota=f"con vivas (3842); con todas las filas (3962) p = {p_t:.2g}")

    # cambio entre fechas
    F11 = filas_de(S["11-09"])
    c11_t = sum(1 for r in F11 if r["d"] < CERCA)
    c11_v = sum(1 for r in F11 if r["d"] < CERCA and not r["rep"])
    k11 = sum(1 for it in I["11-09"] if it["fila"]["d"] < CERCA)
    out(f"  11-09 a d < 0.35: {k11} inicios; filas todas {c11_t}, vivas {c11_v}")
    cuenta("§4.2", "11-09 vs 22+24 a < 0.35 m (vivas)", "1/5 982 vs 12/3 842",
           f"{k11}/{c11_v} vs {k_cerca}/{cerca_v}", (k11, c11_v, k_cerca, cerca_v) == (1, 5982, 12, 3842))
    num("§4.2", "11-09 ‰ (vivas)", "0.17", 1000 * k11 / c11_v, dec=2)
    num("§4.2", "22+24 ‰ (vivas)", "3.12", 1000 * k_cerca / cerca_v, dec=2)
    rv = (k_cerca / cerca_v) / (k11 / c11_v)
    rt = (k_cerca / cerca_t) / (k11 / c11_t)
    num("§4.2", "multiplicador (vivas)", "18.7", rv, dec=1)
    cuenta("§4.2", "11-09 vs 22+24 a < 0.35 m (todas)", "1/5 992 vs 12/3 962",
           f"{k11}/{c11_t} vs {k_cerca}/{cerca_t}", (c11_t, cerca_t) == (5992, 3962))
    num("§4.2", "multiplicador (todas)", "18", rt, dec=0, nota=f"sin redondear {rt:.2f}")
    out(f"  (informativo) Fisher bilateral 11 vs 22+24 por decisión viva: "
        f"p = {fisher([[k11, c11_v - k11], [k_cerca, cerca_v - k_cerca]]):.3g}")

    # aproximaciones
    seccion_42_aproximaciones(S)

    # ---------------- §4.3 ----------------
    titulo("§4.3  PREDICCIÓN 'DIMENSIÓN CORTA'")
    ev_p = defaultdict(Counter); ex_p = defaultdict(Counter); ex_pv = defaultdict(Counter)
    for f in ("22-09", "24-09"):
        for r in filas_de(S[f]):
            if r["d"] < CERCA:
                ex_p[f][r["pared"]] += 1
                if not r["rep"]:
                    ex_pv[f][r["pared"]] += 1
        for it in I[f]:
            if it["fila"]["d"] < CERCA:
                ev_p[f][it["fila"]["pared"]] += 1
    for f in ("22-09", "24-09"):
        out(f"  {f}: " + " | ".join(f"{p}: {ev_p[f][p]}/{ex_p[f][p]} (vivas {ex_pv[f][p]})"
                                     for p in ("y=0", "y=3", "x=0", "x=3")))

    def agr(fechas, paredes, cual=ex_p):
        return (sum(ev_p[f][p] for f in fechas for p in paredes),
                sum(cual[f][p] for f in fechas for p in paredes))
    ky, ey = agr(("22-09", "24-09"), ("y=0", "y=3"))
    kx, ex = agr(("22-09", "24-09"), ("x=0", "x=3"))
    P = cola_binomial(ky, ky + kx, ey / (ey + ex))
    cuenta("§4.3", "22+24: paredes y", "8/2 460", f"{ky}/{ey}", (ky, ey) == (8, 2460),
           "exposición = todas las filas a d < 0.35 de esa pared (más cercana)")
    num("§4.3", "22+24: paredes y ‰", "3.25", 1000 * ky / ey, dec=2)
    cuenta("§4.3", "22+24: paredes x", "4/1 502", f"{kx}/{ex}", (kx, ex) == (4, 1502))
    num("§4.3", "22+24: paredes x ‰", "2.66", 1000 * kx / ex, dec=2)
    num("§4.3", "22+24: P binomial condicional", "0.50", P, dec=2,
        nota=f"P(X ≥ {ky} | n = {ky + kx}, p = {ey / (ey + ex):.4f})")
    # alternativa: vivas
    kyv, eyv = agr(("22-09", "24-09"), ("y=0", "y=3"), ex_pv)
    kxv, exv = agr(("22-09", "24-09"), ("x=0", "x=3"), ex_pv)
    out(f"  (alternativa vivas) y {kyv}/{eyv} vs x {kxv}/{exv}; P = {cola_binomial(kyv, kyv + kxv, eyv / (eyv + exv)):.3f}")

    ky4, ey4 = agr(("24-09",), ("y=0", "y=3"))
    kx4, ex4 = agr(("24-09",), ("x=0", "x=3"))
    rr, lo, hi = ic_razon_tasas(ky4, ey4, kx4, ex4)
    P4 = cola_binomial(ky4, ky4 + kx4, ey4 / (ey4 + ex4))
    cuenta("§4.3", "sólo 24-09: y vs x", "6/1 821 vs 3/1 232", f"{ky4}/{ey4} vs {kx4}/{ex4}",
           (ky4, ey4, kx4, ex4) == (6, 1821, 3, 1232))
    num("§4.3", "sólo 24-09: razón de tasas", "1.35", rr, dec=2)
    num("§4.3", "sólo 24-09: IC95 razón (inf)", "0.29", lo, dec=2,
        nota="Clopper–Pearson condicional transformado a razón de tasas")
    num("§4.3", "sólo 24-09: IC95 razón (sup)", "8.4", hi, dec=1)
    num("§4.3", "sólo 24-09: P binomial condicional", "0.47", P4, dec=2)
    # por pared 22+24 (lo pide la verificación; en el reporte sólo en la bitácora)
    for p, rep in (("y=3", "4/767"), ("y=0", "4/1 693"), ("x=0", "1/597"), ("x=3", "3/905")):
        k = ev_p["22-09"][p] + ev_p["24-09"][p]
        e = ex_p["22-09"][p] + ex_p["24-09"][p]
        rk, re_ = [int(_num(x)) for x in rep.split("/")]
        Pp = cola_binomial(k, 12, e / (ey + ex)) if k else 1.0
        cuenta("§4.3", f"por pared {p} (22+24)", rep, f"{k}/{e}", (k, e) == (rk, re_),
               f"P(≥{k} | 12, p = {e / (ey + ex):.3f}) = {Pp:.3f}")
    seccion_43_plataforma()

    # ---------------- §4.4 (apoyo) ----------------
    titulo("§4.4 (apoyo)  11-09: ESQUINAS RECORRIDAS VIVAS (cajas de 0.75 × 0.75 m)")
    cajas = Counter()
    for r in F11:
        if r["rep"]:
            continue
        cx = "izq" if r["x"] < 0.75 else ("der" if r["x"] > L - 0.75 else None)
        cy = "abajo" if r["y"] < 0.75 else ("arriba" if r["y"] > L - 0.75 else None)
        if cx and cy:
            cajas[f"{cy}-{cx}"] += 1
    out(f"  decisiones vivas por caja de esquina el 11-09: {dict(cajas)}")
    cuenta("§4.4", "11-09: pasadas vivas por las esquinas", "cientos de veces",
           f"{min(cajas.values())}–{max(cajas.values())} decisiones vivas por caja",
           min(cajas.values()) >= 100,
           "definición tomada del borrador de bitácora de 59f731bf (386 a 1 492 por caja de 0.75 m)")

    # ---------------- §4.5 ----------------
    seccion_45(S, I)


def visitas(seqs, umbral, modo):
    """(V, F): aproximaciones y aproximaciones con inicio. modo A/B/C (docstring)."""
    V = Fz = 0
    for s in seqs:
        f = s["filas"]
        if modo in ("A", "B"):
            cur = None
            for r in f:
                if r["d"] < umbral:
                    if cur is not None and (modo == "B" or cur["pared"] == r["pared"]):
                        cur["ini"] += r["ini"]
                    else:
                        if cur is not None:
                            V += 1; Fz += cur["ini"] > 0
                        cur = dict(pared=r["pared"], ini=int(r["ini"]))
                else:
                    if cur is not None:
                        V += 1; Fz += cur["ini"] > 0
                        cur = None
            if cur is not None:
                V += 1; Fz += cur["ini"] > 0
        else:  # C: por pared específica
            for p in ("x=0", "x=3", "y=0", "y=3"):
                cur = None
                for r in f:
                    dp = {"x=0": r["x"], "x=3": L - r["x"], "y=0": r["y"], "y=3": L - r["y"]}[p]
                    if dp < umbral:
                        cur = (cur or 0) + int(r["ini"])
                    elif cur is not None:
                        V += 1; Fz += cur > 0; cur = None
                if cur is not None:
                    V += 1; Fz += cur > 0
    return V, Fz


def seccion_42_aproximaciones(S):
    titulo("§4.2  APROXIMACIONES A UNA PARED (opcional: la definición no está en el reporte)")
    res = {}
    for modo, desc in (("A", "misma pared más cercana (se corta al cambiar)"),
                       ("B", "cualquier pared (no se corta)"),
                       ("C", "por pared específica")):
        ps = []
        for u in (0.25, 0.30, 0.35, 0.40, 0.50, 0.60):
            v11, f11 = visitas(S["11-09"], u, modo)
            v22, f22 = visitas(S["22-09"], u, modo)
            v24, f24 = visitas(S["24-09"], u, modo)
            V, Fz = v22 + v24, f22 + f24
            p = fisher([[f11, v11 - f11], [Fz, V - Fz]])
            ps.append(p)
            res[(modo, u)] = (f11, v11, Fz, V, p)
            out(f"  modo {modo} ({desc}) δ = {u:.2f}: 11-09 {f11}/{v11}  22+24 {Fz}/{V}  "
                f"Fisher bilateral p = {p:.4f}")
        res[(modo, "rango")] = (min(ps), max(ps))
    f11, v11, Fz, V, p = res[("A", 0.35)]
    alt = [m for m in "ABC" if res[(m, 0.35)][:4] == (1, 85, 12, 104)]
    cuenta("§4.2", "aproximaciones 11-09 vs 22+24 (δ = 0.35)", "1/85 vs 12/104",
           f"A: {f11}/{v11} vs {Fz}/{V}; B: {res[('B', 0.35)][0]}/{res[('B', 0.35)][1]} vs "
           f"{res[('B', 0.35)][2]}/{res[('B', 0.35)][3]}; C: {res[('C', 0.35)][0]}/{res[('C', 0.35)][1]} vs "
           f"{res[('C', 0.35)][2]}/{res[('C', 0.35)][3]}",
           bool(alt), si="por_definicion",
           nota=f"reproduce con la(s) definición(es) {alt or 'ninguna'}; ver definiciones del docstring")
    m = alt[0] if alt else "A"
    f11, v11, Fz, V, p = res[(m, 0.35)]
    num("§4.2", "aproximación 11-09 (%)", "1.2", 100 * f11 / v11, dec=1, si="por_definicion" if alt else "no")
    num("§4.2", "aproximación 22+24 (%)", "11.5", 100 * Fz / V, dec=1, si="por_definicion" if alt else "no")
    num("§4.2", "aproximación: Fisher p", "0.007", p, sig=1, si="por_definicion" if alt else "no",
        nota="bilateral")
    # El rango de p tiene que salir de la MISMA definición que da 1/85 vs 12/104.
    lo, hi = res[(m, "rango")]
    loB, hiB = res[("B", "rango")]
    loC, hiC = res[("C", "rango")]
    cuenta("§4.2", "aproximación: p con δ de 0.25 a 0.60", "0.003–0.01",
           f"{lo:.2g}–{hi:.2g} (modo {m})",
           f"{lo:.1g}" == "0.003" and f"{hi:.1g}" == "0.01",
           nota=f"δ ∈ {{0.25, 0.30, 0.35, 0.40, 0.50, 0.60}}. Con la definición que reproduce 1/85 vs 12/104 "
                f"(modo {m}) el rango es {lo:.2g}–{hi:.2g}; el '0.003–0.04' del borrador salía con el modo B "
                f"({loB:.2g}–{hiB:.2g}; el modo B da 1/68 vs 12/94 a 0.35) o mezclando A y B. Modo C: "
                f"{loC:.2g}–{hiC:.2g}. En todos los casos p < 0.05")


def seccion_43_plataforma():
    titulo("§4.3  DISTANCIA DE CADA PARED AL BORDE DE UNA PLATAFORMA CENTRADA (calibracion_medida.json)")
    cal = json.loads((CSV_DIR / "calibracion_medida.json").read_text(encoding="utf-8"))
    E, th = cal["escala_posicion"], cal["rotacion_marco_rad"]
    tx, ty = cal["traslacion_x_m"], cal["traslacion_y_m"]
    out(f"  calibración: escala {E:.6f}  rotación {th:.6f} rad  traslación ({tx:.6f}, {ty:.6f}) m")

    def env_a_lab(x, y):  # inversa de p_env = R(θ)·(E·p_lab) + t
        dx, dy = x - tx, y - ty
        c, s = math.cos(th), math.sin(th)
        return (c * dx + s * dy) / E, (-s * dx + c * dy) / E
    ax, ay = PLATAFORMA_X / 2, PLATAFORMA_Y / 2
    medios = {"y=3": (1.5, 3.0), "y=0": (1.5, 0.0), "x=0": (0.0, 1.5), "x=3": (3.0, 1.5)}
    d = {}
    for p, (x, y) in medios.items():
        xl, yl = env_a_lab(x, y)
        d[p] = {"y=0": yl + ay, "y=3": ay - yl, "x=0": xl + ax, "x=3": ax - xl}[p]
        out(f"  pared {p}: punto medio en lab ({xl:+.4f}, {yl:+.4f}) → a {d[p]:.4f} m del borde")
    # a lo largo de la pared la distancia cambia por la rotación: extremos
    extremos = {"y=3": ((0, 3), (3, 3)), "y=0": ((0, 0), (3, 0)),
                "x=0": ((0, 0), (0, 3)), "x=3": ((3, 0), (3, 3))}
    rango = {}
    for p, pts in extremos.items():
        vals = []
        for x, y in pts:
            xl, yl = env_a_lab(x, y)
            vals.append({"y=0": yl + ay, "y=3": ay - yl, "x=0": xl + ax, "x=3": ax - xl}[p])
        rango[p] = (min(vals), max(vals))
        out(f"  pared {p}: de extremo a extremo, {min(vals):.4f}–{max(vals):.4f} m del borde")
    cx, cy = env_a_lab(1.5, 1.5)
    out(f"  centro de la arena en lab: ({cx:+.4f}, {cy:+.4f})")
    num("§4.3", "pared y = 3 al borde (cm)", "1", 100 * d["y=3"], dec=0,
        nota=f"punto medio de la pared; plataforma {PLATAFORMA_X} × {PLATAFORMA_Y} centrada en el origen "
             f"(supuesto); calibración = calibracion_medida.json del paquete. De extremo a extremo de la "
             f"pared: y=3 {100 * rango['y=3'][0]:.1f}–{100 * rango['y=3'][1]:.1f} cm, "
             f"y=0 {100 * rango['y=0'][0]:.1f}–{100 * rango['y=0'][1]:.1f}, "
             f"x=0 {100 * rango['x=0'][0]:.1f}–{100 * rango['x=0'][1]:.1f}, "
             f"x=3 {100 * rango['x=3'][0]:.1f}–{100 * rango['x=3'][1]:.1f}")
    num("§4.3", "pared y = 0 al borde (cm)", "49", 100 * d["y=0"], dec=0)
    num("§4.3", "pared x = 0 al borde (cm)", "86", 100 * d["x=0"], dec=0)
    num("§4.3", "pared x = 3 al borde (cm)", "86", 100 * d["x=3"], dec=0)
    num("§4.1 (extra)", "arena corrida en y_lab (m)", "+0.24", cy, dec=2, signo=True)
    nv("§4.3", "plataforma 4.67 × 3.45 m", "4.67 × 3.45",
       "constante AREA_UTIL_* de config_robotat.py; no está en los CSV (se usa como dato)")


def angulo(dx, dy, pared):
    n = {"x=0": (-1, 0), "x=3": (1, 0), "y=0": (0, -1), "y=3": (0, 1)}[pared]
    nr = math.hypot(dx, dy)
    if nr < 1e-12:
        return float("nan")
    return math.degrees(math.acos(max(-1.0, min(1.0, (dx * n[0] + dy * n[1]) / nr))))


def seccion_45(S, I):
    titulo("§4.5  INDICIOS NUEVOS (24-09 salvo que se diga)")
    F24 = filas_de(S["24-09"])
    ini24 = I["24-09"]
    viv = [r for r in F24 if not r["rep"] and r["d"] < CERCA]
    todas = [r for r in F24 if r["d"] < CERCA]

    def medio(r):
        return 1.0 <= r["u"] <= 2.0
    n_med = sum(medio(r) for r in viv); n_ext = len(viv) - n_med
    k_med = sum(1 for it in ini24 if it["fila"]["d"] < CERCA and medio(it["fila"]))
    k_ext = sum(1 for it in ini24 if it["fila"]["d"] < CERCA and not medio(it["fila"]))
    p = fisher([[k_ext, n_ext - k_ext], [k_med, n_med - k_med]], "greater")
    t_med = sum(medio(r) for r in todas)
    out(f"  a d < 0.35: tercio medio {k_med}/{n_med} (vivas; todas {t_med}); extremos {k_ext}/{n_ext} "
        f"(vivas; todas {len(todas) - t_med}); Fisher unilateral p = {p:.4f}")
    cuenta("§4.5", "esquinas: tercio medio vs extremos (d < 0.35)", "0/1 403 vs 9/1 560",
           f"{k_med}/{n_med} vs {k_ext}/{n_ext}", (k_med, n_med, k_ext, n_ext) == (0, 1403, 9, 1560),
           si="por_definicion",
           nota=f"exposición = filas VIVAS (con todas las filas: {k_med}/{t_med} vs {k_ext}/{len(todas) - t_med}); "
                "tercio medio = 1 ≤ u ≤ 2 de la pared más cercana")
    num("§4.5", "esquinas: Fisher p", "0.003", p, sig=1, si="por_definicion", nota="unilateral (extremos > medio)")

    cs = [it["fila"]["c"] for it in ini24]
    dv = [min(math.hypot(it["fila"]["x"] - a, it["fila"]["y"] - b) for a in (0, L) for b in (0, L))
          for it in ini24]
    out(f"  los 10 inicios: c (a lo largo de la pared) {sorted(round(c, 3) for c in cs)}")
    out(f"                  distancia euclídea al vértice {sorted(round(x, 3) for x in dv)}")
    cuenta("§4.5", "10 inicios a X m del vértice de una esquina", "0.35–0.72",
           f"euclídea al vértice: {min(dv):.3f}–{max(dv):.3f}",
           f"{min(dv):.2f}" == "0.35" and f"{max(dv):.2f}" == "0.72",
           nota=f"distancia euclídea al vértice más cercano de la arena; a lo largo de la pared "
                f"(c = min(u, 3 − u)) sería {min(cs):.2f}–{max(cs):.2f}")

    # robot 6
    r6_cerca = sum(1 for r in F24 if r["robot"] == 6 and r["d"] < CERCA)
    r6_ini = sum(1 for it in ini24 if it["seq"]["robot"] == 6)
    cuenta("§4.5", "robot 6: inicios / decisiones a < 0.35 m", "0 / 969", f"{r6_ini} / {r6_cerca}",
           (r6_ini, r6_cerca) == (0, 969), "sin congelamientos: todas = vivas")
    zona = [r for r in F24 if not r["rep"] and r["d"] < CERCA and r["c"] <= 0.75]
    n6 = sum(1 for r in zona if r["robot"] == 6); no6 = len(zona) - n6
    k6 = sum(1 for it in ini24 if it["seq"]["robot"] == 6 and it["fila"]["d"] < CERCA and it["fila"]["c"] <= 0.75)
    ko = sum(1 for it in ini24 if it["seq"]["robot"] != 6 and it["fila"]["d"] < CERCA and it["fila"]["c"] <= 0.75)
    p6 = fisher([[k6, n6 - k6], [ko, no6 - ko]])
    por_rob = Counter(r["robot"] for r in zona)
    out(f"  zona esquina (vivas, d < 0.35, c ≤ 0.75) por robot: {dict(sorted(por_rob.items()))}")
    cuenta("§4.5", "robot 6 en esquina vs los demás", "0/418 vs 9/392", f"{k6}/{n6} vs {ko}/{no6}",
           (k6, n6, ko, no6) == (0, 418, 9, 392), si="por_definicion",
           nota="zona = filas vivas con d < 0.35 y c ≤ 0.75 (definición de 59f731bf; el reporte no la da)")
    num("§4.5", "robot 6: Fisher p", "0.0014", p6, sig=2, si="por_definicion", nota="bilateral")
    num("§4.5", "robot 6: Fisher p × 5 (Bonferroni)", "0.007", min(1, 5 * p6), sig=1, si="por_definicion")
    r6_22 = sum(1 for it in I["22-09"] if it["seq"]["robot"] == 6)
    cuenta("§4.5", "22-09: inicios del robot 6", "2 de 4", f"{r6_22} de {len(I['22-09'])}",
           (r6_22, len(I["22-09"])) == (2, 4))

    # dirección de entrada
    out("  dirección de entrada (ángulo del desplazamiento contra la normal saliente de la pared más cercana):")
    resumen = {}
    for lag in (3, 5, 10):
        paral = exact15 = 0; adyac = []
        for it in ini24:
            f = it["seq"]["filas"]; i = it["i"]; r = f[i]
            j = max(0, i - lag)
            dx, dy = r["x"] - f[j]["x"], r["y"] - f[j]["y"]
            a = angulo(dx, dy, r["pared"])
            es_par = 60 < a <= 120
            paral += es_par; exact15 += 75 <= a <= 105
            if es_par:
                # pared adyacente = la MÁS CERCANA de las dos perpendiculares a la
                # pared más cercana (la que forma la esquina próxima)
                cand = ("y=0", "y=3") if r["pared"].startswith("x") else ("x=0", "x=3")
                dist = {"x=0": r["x"], "x=3": L - r["x"], "y=0": r["y"], "y=3": L - r["y"]}
                p_ady = min(cand, key=lambda p: dist[p])
                adyac.append((angulo(dx, dy, p_ady), dist[p_ady]))
            if lag == 5:
                out(f"     ep {it['seq']['ep']:2d} robot {it['seq']['robot']} {r['pared']} ángulo {a:6.1f}°")
        de_frente = [x for x in adyac if x[0] <= 30]
        resumen[lag] = (paral, exact15, len(de_frente), de_frente)
        out(f"   ventana {lag:2d}: paralelas {paral}/10, a ±15° {exact15}/10, de frente (≤ 30°) a la "
            f"adyacente {len(de_frente)}/{paral}: ángulos "
            f"{[round(x[0], 1) for x in de_frente]}, distancias {[round(x[1], 2) for x in de_frente]}")
    p5, e5, f5, df5 = resumen[5]
    cuenta("§4.5", "entraron paralelos a la pared más cercana", "7 de 10", f"{p5} de 10 (ventana 5)",
           p5 == 7, si="por_definicion",
           nota=f"ventanas 3/5/10: {[resumen[k][0] for k in (3, 5, 10)]}; paralelo = 60–120° de la normal")
    cuenta("§4.5", "paralelos a ±15°", "6 de 10", f"{e5} de 10 (ventana 5)", e5 == 6, si="por_definicion",
           nota=f"ventanas 3/5/10: {[resumen[k][1] for k in (3, 5, 10)]}")
    cuenta("§4.5", "de esos, de frente a la pared adyacente", "6 de 7", f"{f5} de {p5} (ventana 5)",
           (f5, p5) == (6, 7), si="por_definicion",
           nota=f"ventanas 3/5/10: {[resumen[k][2] for k in (3, 5, 10)]}; adyacente = la perpendicular más "
                f"cercana (la de la esquina próxima); 'de frente' = ≤ 30° de su normal saliente")
    if df5:
        angs = [x[0] for x in df5]; ds = [x[1] for x in df5]
        cuenta("§4.5 (bitácora)", "ángulo a la adyacente / distancia", "7–18° / 0.43–0.70 m",
               f"{min(angs):.0f}–{max(angs):.0f}° / {min(ds):.2f}–{max(ds):.2f} m (ventana 5)",
               (round(min(angs)), round(max(angs))) == (7, 18) and (f"{min(ds):.2f}", f"{max(ds):.2f}") == ("0.43", "0.70"),
               si="por_definicion", nota="cifra del borrador de bitácora de 59f731bf, no del reporte")

    # 22-09: ubicación de los 4 inicios
    out("  22-09, ubicación de los inicios:")
    desc = []
    for it in I["22-09"]:
        r = it["fila"]
        dd = {"x=0": r["x"], "x=3": L - r["x"], "y=0": r["y"], "y=3": L - r["y"]}
        out(f"     ({r['x']:.3f}, {r['y']:.3f}) más cercana {r['pared']} a {r['d']:.3f} m; "
            f"u = {r['u']:.2f}; distancias {{{', '.join(f'{k}: {v:.3f}' for k, v in dd.items())}}}")
        desc.append((r["pared"], round(r["d"], 2), round(r["u"], 2)))
    n_y3 = sum(1 for p, d, u in desc if p == "y=3" and d < CERCA)
    n_x3_medio = sum(1 for p, d, u in desc if p == "x=3" and 1 <= u <= 2)
    n_x0 = [d for p, d, u in desc if p == "x=0"]
    cuenta("§4.5", "22-09: dónde fueron los 4 inicios",
           "2 junto a y = 3, 1 a media pared x = 3, 1 a 0.53 m de x = 0",
           f"{n_y3} junto a y = 3 (d < 0.35), {n_x3_medio} a media pared x = 3, "
           f"{len(n_x0)} a {n_x0[0] if n_x0 else '—'} m de x = 0",
           n_y3 == 2 and n_x3_medio == 1 and n_x0 == [0.53])

    # §6 (extra): últimas poses vivas
    d14 = sorted(it["fila"]["d"] for it in I["22-09"] + I["24-09"])
    en = sum(1 for d in d14 if 0.17 <= d <= 0.29)
    en_cm = sum(1 for d in d14 if 0.17 <= round(d, 2) <= 0.29)
    out(f"  (extra §6) d de las 14 últimas poses vivas 22+24: {[round(d, 3) for d in d14]}")
    cuenta("§6 (extra)", "últimas poses vivas a 0.17–0.29 m", "12 de 14",
           f"{en_cm} de {len(d14)} redondeando al cm ({en} sin redondear)", (en_cm, len(d14)) == (12, 14),
           si="por_definicion",
           nota="sólo con d redondeada al cm: la 12.ª está a 0.293 m (22-09 ep 3, y = 3); sin redondear son 11")
    num("§6 (extra)", "mediana de la última pose viva (m)", "0.229", float(np.median(d14)), dec=3)


# ==========================================================================
# Tabla final
# ==========================================================================
def imprimir_tabla():
    titulo("TABLA FINAL: sección | cifra | valor del reporte | recalculado | coincide")
    anchos = [4, 14, 48, 34, 44, 14]
    cab = ["n", "sección", "cifra", "reporte", "recalculado", "coincide"]
    out(" | ".join(c.ljust(a) for c, a in zip(cab, anchos)))
    out("-+-".join("-" * a for a in anchos))
    for k, f in enumerate(TABLA, 1):
        celdas = [str(k), f["seccion"], f["cifra"], f["reporte"], f["recalculado"], f["coincide"]]
        out(" | ".join(c.ljust(a) for c, a in zip(celdas, anchos)))
    out("")
    out("NOTAS POR FILA")
    for k, f in enumerate(TABLA, 1):
        if f["nota"]:
            out(f"  [{k}] {f['nota']}")
    cnt = Counter(f["coincide"] for f in TABLA)
    out("")
    out(f"RESUMEN: {len(TABLA)} filas → " + ", ".join(f"{k}: {v}" for k, v in sorted(cnt.items())))
    malas = [(k, f) for k, f in enumerate(TABLA, 1) if f["coincide"] == "no"]
    if malas:
        out("FILAS QUE NO COINCIDEN:")
        for k, f in malas:
            out(f"  [{k}] {f['seccion']} · {f['cifra']}: reporte {f['reporte']} · recalculado {f['recalculado']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--sin-33", action="store_true", help="saltar la §3.3 (diversidad)")
    ap.add_argument("--json", action="store_true", help="volcar además la tabla en JSON")
    a = ap.parse_args()
    seccion_archivos()
    e24 = seccion_2()
    r31 = seccion_31()
    seccion_32(e24, r31)
    seccion_33_colocacion(e24)
    if a.sin_33:
        out("\n(§3.3 diversidad saltada por --sin-33)")
    else:
        seccion_33_diversidad(e24)
    seccion_34_extra()
    seccion_4()
    imprimir_tabla()
    with open(SALIDA, "w", encoding="utf-8", newline="\n") as fh:   # fin de línea LF
        fh.write("\n".join(_LINEAS) + "\n")
    if a.json:
        with open(PAQUETE / "verificacion_cifras.json", "w", encoding="utf-8", newline="\n") as fh:
            json.dump(TABLA, fh, ensure_ascii=False, indent=1)
    print(f"\n(salida escrita en {SALIDA})")


if __name__ == "__main__":
    main()
