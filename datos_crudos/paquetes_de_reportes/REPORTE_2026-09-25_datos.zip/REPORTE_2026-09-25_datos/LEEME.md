# Datos crudos del reporte del 2026-09-25

Copias byte a byte de los archivos del proyecto que respaldan las cifras de `REPORTE_2026-09-25.md` (también incluido acá), más los scripts para recalcularlas. Nada de esto modifica el proyecto.

**No hay CSV de la sonda de seguimiento:** el modo de mapeo nunca se corrió en el Robotat (sólo contra el simulador).

## Cómo verificar

```bash
cd scripts
python -B verificar_cifras.py            # todas las secciones
python -B verificar_cifras.py --sin-33    # sin la §3.3 (necesita el código del proyecto)
python -B verificar_cifras.py --json      # además vuelca ../verificacion_cifras.json
```

Requiere Python ≥ 3.9, numpy y scipy. Las rutas son relativas al script. La §3.3 (diversidad de arranques) importa `diversidad_arranques` del proyecto porque necesita el sorteo de entrenamiento; si no encuentra la ruta, la salta con aviso. La salida de referencia es `verificacion_cifras.txt`: 192 cifras, 171 coinciden, 17 coinciden con la definición declarada en el docstring y 4 no son verificables con CSV (vienen de la consola o del código). La única discrepancia del borrador (rango de p de la §4.2) se corrigió en el reporte.

Integridad: compará la columna sha256 con `python -c "import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())" <archivo>`, o contra el original en el proyecto.

## Origen de cada carpeta

- `csv/`: primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/ (calibracion_medida.json: .../coordinador_enjambre/)
- `exp_J/`: fase_preliminar2/experimento_J/ (base: optuna_studies/; logs y JSON: resultados/; metricas_100eps: fase_preliminar2/modelos/tesis_v1/RESULTADO_PRIMERO/)
- `exp_P/`: fase_preliminar2/experimento_P/
- `consola/`: texto de consola de la sesión del 24-09 que pegaste en el chat (transcripción bd144444); no existe como archivo en el proyecto
- `scripts/`: generados para este reporte (verificar_cifras.py, pareado_*.py) y trazas de los verificadores (verificadores/)
- `derivados/`: salidas de scripts, no datos crudos

## Qué cifra sale de qué archivo

Ver la sección 11 del reporte. Lo esencial: las cifras de episodios (§2, §3) salen de `*_episodios.csv` y de las réplicas del 12-09; las de congelamientos y franjas (§4, §6) salen de los `*_decisiones.csv`. El 22-09 son DOS archivos: `_decisiones.csv` (va con `_episodios.csv`) y `_decisiones_02.csv` (va con `_episodios_03.csv`: 105/123/111 decisiones). `_episodios_02.csv` sólo tiene colocación.

## Manifiesto (sha256)

| archivo | bytes | tamaño | sha256 |
|---|---|---|---|
| `REPORTE_2026-09-25.md` | 45876 |  | `a7977858f34c67e5260d53dd8f9a3876a9173ea29ede82ca2adf41056071e9a1` |
| `consola/consola_20260924_pegada_en_chat.txt` | 231447 |  | `7444a699586d689f0bf65f8dd530b82cbea8b37148d78cda92a07dcc6c0081a0` |
| `csv/20260829_sesion-calibracion_etapa4_latencia-actuacion.csv` | 350 | 5 filas | `f1804b6697e13497606cd9ae8cf776a8cb6c1e688cf2e00514ba6b60910aee9e` |
| `csv/20260829_sesion-calibracion_etapa5_marcador-ocluido.csv` | 133658 | 363 filas | `5275a32df378855d2430a4a6ece5a05e774cfe935001c2d4167b2a8386561710` |
| `csv/20260829_sesion-calibracion_etapa5_marcador-ocluido_02.csv` | 134761 | 366 filas | `b7522776b18380cf7b068a03e0ff1ff431fcd665196193af48de7aca3d3b4a5c` |
| `csv/20260829_sesion-calibracion_etapa5_marcador-ocluido_03.csv` | 132951 | 366 filas | `c5344f7370363abe801c06b0c121961d37eebd48af1045a9042104e7c1dc06e6` |
| `csv/20260905_sesion-evaluacion_etapa7_decisiones.csv` | 3370984 | 25705 filas | `77268968e85d7e18d8a8b0f5d1a8b61bc18c330e2d95f99481fd7bcd8022fdc1` |
| `csv/20260905_sesion-evaluacion_etapa7_episodios.csv` | 3424 | 18 filas | `1c40f4d4a16972c8c178e93280208ede2653e1575af45ed844c7b7884d944359` |
| `csv/20260911_sesion-evaluacion_etapa7_decisiones.csv` | 2238230 | 17065 filas | `cf3a50d03fd57ce7b75d8e9cdc3d6e0066ac5fba6d1fe3e1693b2fab9788a581` |
| `csv/20260911_sesion-evaluacion_etapa7_episodios.csv` | 7977 | 19 filas | `b9459feb99fb5c641298ab3a4f4bbc64f4b27c833d571cbeaf560fc0b5b95977` |
| `csv/20260912_sesion-replica_etapa7_capas-off.csv` | 3592 | 15 filas | `7c10cd287100d49e2e82b72e7caf4c4d0a0ee72d2c5a4fe57d3d091be68ecd5b` |
| `csv/20260912_sesion-replica_etapa7_capas-on.csv` | 3176 | 15 filas | `e889c989c39c97c0d46444b3b04431e8978f916993d43fbff6781211400c7466` |
| `csv/20260922_sesion-evaluacion_etapa7_decisiones.csv` | 275073 | 2100 filas | `7aad1082b81d658728473b518112a84c11e92b18c83516526c8d787576dd6b77` |
| `csv/20260922_sesion-evaluacion_etapa7_decisiones_02.csv` | 220799 | 1695 filas | `93d8291d62d349ab84bac99c4d31337c574b290119a87cfe89792b3854973adc` |
| `csv/20260922_sesion-evaluacion_etapa7_episodios.csv` | 1672 | 2 filas | `c35a83ebfef7bb2bd07ce56d505f0c17141ee12344d8ba36d76fd1bd5452ec43` |
| `csv/20260922_sesion-evaluacion_etapa7_episodios_02.csv` | 1503 | 2 filas | `47b88afcfc4fa7a99511d05da80c177ff84c0e96de260a222d663485ad98355b` |
| `csv/20260922_sesion-evaluacion_etapa7_episodios_03.csv` | 4216 | 3 filas | `bf68354717d342995e9362845600df4f881260bc4b3bd45c6aa58e0d2b218987` |
| `csv/20260924_sesion-evaluacion_etapa7_decisiones.csv` | 1837325 | 14020 filas | `363bf3f7755c9c3cd0ab9c9e83bfebacacd47c494f07552dd7aa013cc49e9198` |
| `csv/20260924_sesion-evaluacion_etapa7_episodios.csv` | 19135 | 17 filas | `c8399b711b6f6b3ce8b77725a3803cd681a37ca0bf153840ed82a4565b7c9683` |
| `csv/calibracion_medida.json` | 12788 |  | `9d1033124c2646ffad07863dc65a12af4f530f3aaceefbdc0ac793f8ce73db66` |
| `derivados/franja_sesiones_59f731bf.json` | 29321 |  | `4fbcebcbb42756334fb26e14e5b4e1cf76eb48149b7ff458075a6a619410ed52` |
| `derivados/v45_recalc_salida.txt` | 4360 |  | `0b6f7873c3e6a13ab088db4b0a2f9aa0816c70bf889dc360af3b601afecbab86` |
| `derivados/v7_recalculo_DE_salida.txt` | 710 |  | `cc393becb98d3d63a68b09add12a15de4c92edda135fa527f7e14c871dc3b0b0` |
| `exp_J/correlaciones_ABC_sin_duplicado_holm.json` | 11367 |  | `74eb9b43fe9cffc06c65504c9a28fb21752fa1f8b31268e470c2c0bc99ac901e` |
| `exp_J/diagnostico_presupuesto_resumen.json` | 3832 |  | `73ba09173b133c0ff4e8eea592968d7748725846fe52b13ccbf836b33e21183a` |
| `exp_J/estudio_ejecucion.log` | 53351 |  | `03315dc36a3e5e244e9ca14fb98ecaa376fb4ce697a36af085877c1ac582862b` |
| `exp_J/estudio_ejecucion_prueba0.log` | 10810 |  | `bd36aebffc392a7d60b39e2a0ad77259ddaa6aaee0205a67f35cc0e38cadabf9` |
| `exp_J/experimento_J.db` | 143360 |  | `59057c367b74575f5326f14d06ac61f5c202190581990cd96141e4410a270c72` |
| `exp_J/metricas_100eps_modelo_PRIMERO.json` | 88717 |  | `be2d0326c1063aeaef50d122db73b8f99c29de3d2f039f5090ac46f265c099c7` |
| `exp_J/pruebas_experimento_J.csv` | 3010 | 22 filas | `4c72871399525d0633a1022b866a73c902024a644f89687997921656532011ee` |
| `exp_J/recalcular_ABC_sin_duplicado_holm.py` | 25382 |  | `ca16f7cd4f9956602189f4111e7d5e78c2c918c8c1be2e734d39f9dff97c9a6b` |
| `exp_J/referencia_recomputada.json` | 537 |  | `7924af3503a7f33a3f05361af0c97f500c6ba49cbc55473d0e41d150682f95b5` |
| `exp_J/resultados_estudio/estudio/cfg_0361e76f68/semilla_123/resultado_semilla.json` | 1824 |  | `f35e2895a951bb0d5c82662f1af756b2c2cce95de49f45267cf1508b5c91f60c` |
| `exp_J/resultados_estudio/estudio/cfg_0361e76f68/semilla_42/resultado_semilla.json` | 1873 |  | `b0c6b3d84f7b8d2b9204c549c4333b9149cf89fa31201451f1b378a6b15f5c41` |
| `exp_J/resultados_estudio/estudio/cfg_0361e76f68/semilla_777/resultado_semilla.json` | 1872 |  | `67a8b8a6fc5f0df94732dd4e45cc77f5e6b45704383af9e0a7b238b1dd670b1c` |
| `exp_J/resultados_estudio/estudio/cfg_06b72b7fcf/semilla_42/resultado_semilla.json` | 1828 |  | `240324b013b1bd587b8d3d425a56f151e4aa414135ee8f27af0f618f8b3475c4` |
| `exp_J/resultados_estudio/estudio/cfg_4dc3f27f85/semilla_42/resultado_semilla.json` | 1859 |  | `a1ac8a122254248522da98a09fc4ff08420a406510900c5852337c44883ab9a2` |
| `exp_J/resultados_estudio/estudio/cfg_81f82a41b4/semilla_123/resultado_semilla.json` | 1876 |  | `3ff5cd88c79217edc1f19a18a9cb9241f203230c9d518c42bf5044a0d35e9f0c` |
| `exp_J/resultados_estudio/estudio/cfg_81f82a41b4/semilla_42/resultado_semilla.json` | 1869 |  | `431a28d50ef2702c09edac0bcf1754c9b6aad73f23df97e247db7e5a5d273137` |
| `exp_J/resultados_estudio/estudio/cfg_81f82a41b4/semilla_777/resultado_semilla.json` | 1870 |  | `513a0cffb8de340fcd34db331ff97e18277ebac9cc5413be11b027c4ec1f4366` |
| `exp_J/resultados_estudio/estudio/cfg_858c0e9360/semilla_123/resultado_semilla.json` | 1874 |  | `f0249f2585acf9605aba2e5e69d91dd94510efad9167eba8de7764935def34b6` |
| `exp_J/resultados_estudio/estudio/cfg_858c0e9360/semilla_42/resultado_semilla.json` | 1859 |  | `9604af3b6429d907c589a948ba3b4c53423d619c9e2e0a283e32732b8172dc82` |
| `exp_J/resultados_estudio/estudio/cfg_858c0e9360/semilla_777/resultado_semilla.json` | 1859 |  | `ab23477196d9791deeba2ba799cfc418ad0f930483021a5f6f7143f707d2df28` |
| `exp_J/resultados_estudio/estudio/cfg_8662e37b01/semilla_123/resultado_semilla.json` | 1854 |  | `ab224995b40ce06c6e26a0a192602313ee142ae1689b248ef2cef8be02d404d0` |
| `exp_J/resultados_estudio/estudio/cfg_8662e37b01/semilla_42/resultado_semilla.json` | 1848 |  | `cbab8a04db6dfb2383ecf0754bd694c82708184a397e114ed0ecb981f7674df5` |
| `exp_J/resultados_estudio/estudio/cfg_8662e37b01/semilla_777/resultado_semilla.json` | 1830 |  | `41b3c0a7ac22bb33503a452b5f5495e9e426d4ad28af18984df53a7b761b23ae` |
| `exp_J/resultados_estudio/estudio/cfg_b54711973b/semilla_123/resultado_semilla.json` | 1827 |  | `81a20a9732796b5900a96d8cda225c6289e709ff8cda72dedc1ac29f4ded9a55` |
| `exp_J/resultados_estudio/estudio/cfg_b54711973b/semilla_42/resultado_semilla.json` | 1856 |  | `e783a2dc45012dffb9876f09dd3da24b728837225ab244e11eb03b18cb512777` |
| `exp_J/resultados_estudio/estudio/cfg_b54711973b/semilla_777/resultado_semilla.json` | 1844 |  | `32ec84c4eafe0f30bc34722332b1d8f3da99e2cd8f0b99e5dc8724125cd1eebc` |
| `exp_J/resultados_estudio/estudio/cfg_c1ea246bf8/semilla_123/resultado_semilla.json` | 1837 |  | `27f81ece9915f30c0e92a367df205e9b4da2b1aeb2146a5a1cfbcf636e33768a` |
| `exp_J/resultados_estudio/estudio/cfg_c1ea246bf8/semilla_42/resultado_semilla.json` | 1876 |  | `201dc498bbdfdd167f44ef37ccc8b1f9cfcfa4a85edbcf06e28024a7ebc45646` |
| `exp_J/resultados_estudio/estudio/cfg_c1ea246bf8/semilla_777/resultado_semilla.json` | 1859 |  | `77ba0ce720c9709e9d18c08cfabd231e49321a7bf1e2cca310c46a9a2c8cdcc5` |
| `exp_J/resultados_estudio/estudio/cfg_c4841946c7/semilla_123/resultado_semilla.json` | 1849 |  | `f192c30daee7394073c8406bf705fd7598bde9dead79c5e3e0ba7d3f3baab485` |
| `exp_J/resultados_estudio/estudio/cfg_c4841946c7/semilla_42/resultado_semilla.json` | 1873 |  | `2638010fdee3265784b61c9c452c7c36dd82b2d302a52b0198dca5dad83387dc` |
| `exp_J/resultados_estudio/estudio/cfg_c4841946c7/semilla_777/resultado_semilla.json` | 1843 |  | `4ee162f612bf216e75a14f3c1f3458695d84214886810ad4dadca14d557a6af0` |
| `exp_J/resultados_estudio/estudio/cfg_dc3474df82/semilla_123/resultado_semilla.json` | 1871 |  | `33d1b9cc2f300b42f36f871a8cd5b99cc790032ee365e9eb619df3a2204f4e88` |
| `exp_J/resultados_estudio/estudio/cfg_dc3474df82/semilla_42/resultado_semilla.json` | 1839 |  | `923c920d84069c6f4ec3bea023b8331d530d5867b368acdfeb3ac9eaedf32487` |
| `exp_J/resultados_estudio/estudio/cfg_dc3474df82/semilla_777/resultado_semilla.json` | 1856 |  | `f37ec2fa95008042605b27a5f203a96ef87cfbc9fa38f6346a7aa4c791740f00` |
| `exp_J/resultados_estudio/estudio/cfg_eb1d01e59b/semilla_123/resultado_semilla.json` | 1854 |  | `52eec8d05f15cbd7fe89478ac570d79615d884752911fbe52ae67a3bd93963bc` |
| `exp_J/resultados_estudio/estudio/cfg_eb1d01e59b/semilla_42/resultado_semilla.json` | 1872 |  | `e36f8b98a2e14c2db95ac9b1ba064a876f1dafad72c26cfaa6fba4bf6ee5635f` |
| `exp_J/resultados_estudio/estudio/cfg_eb1d01e59b/semilla_777/resultado_semilla.json` | 1872 |  | `ba1c04dd8151302dd7843aff74abbc3b9858a6333f4a9741c7d081b7336db46d` |
| `exp_P/PREREGISTRO_P.md` | 8998 |  | `8b24fa476a6600d12ce37d06e9bc588b8486e70267cb1dd9498679cb91240949` |
| `exp_P/manifiesto_P.json` | 4423 |  | `d260d9515c25b9867d4e98e48b8db6bd02520c9af8f495b64ccbf209fcec6fb4` |
| `scripts/pareado_diversidad.py` | 4253 |  | `bd787174a63c6709b377a4eae894b17e7c2022fa5cee3d9e3a9f28d5ffb897dc` |
| `scripts/pareado_recalculo.py` | 5184 |  | `9fcc0cf603d1d34a4fcb9d348c6bf3354c81a2262d8b187fc8ad7a2278c61053` |
| `scripts/verificadores/franja_sesiones_59f731bf.py` | 3563 |  | `ab9cbe104d28a0ce4e72b36fc79ca3f054e0c7354af704a2124b45911e0ce3f2` |
| `scripts/verificadores/v45_barrido.py` | 2314 |  | `f05cd2fb58e1abeb27a85e06a8b1ded1b5fb073a132eee3ec1c97e9d697382e1` |
| `scripts/verificadores/v45_bordes.py` | 5461 |  | `0eef407ade38fdcf5bb2435af6d0722ed45df42975beae0df48d1ad4413cb044` |
| `scripts/verificadores/v45_bordes2.py` | 3117 |  | `3190437455c5dfdc48de3f0802c4b18ecf7538e917e7a86a3c46464cee4dface` |
| `scripts/verificadores/v45_dir.py` | 891 |  | `ab904f707c896dce9c95cca3be99960b0a06bb2d61e5dfa2d179ece6f5dcc8a4` |
| `scripts/verificadores/v45_entre.py` | 1455 |  | `10b9760fe24f46d3914fd0c0529511ae99d8922fdc9e25eb3a36ba8e1d681539` |
| `scripts/verificadores/v45_h2.py` | 1045 |  | `bedb7cd3786a1c0db060addc407888eb64785ecdd9eab542941f7ab8659f408e` |
| `scripts/verificadores/v45_lib.py` | 2574 |  | `e6a69ff86e67655881de5d5e826d30b3149f3f4a3f0ff329715499965d3c8fc3` |
| `scripts/verificadores/v45_otros.py` | 658 |  | `5f29842c532de0408f7501e52c8d6688336463ca2d201c97be0d5360adf1addf` |
| `scripts/verificadores/v45_recalc.py` | 8486 |  | `682bf7303211d666f8ead87b6208c84ded80b3857e34619dfc4ca30a11d70ed4` |
| `scripts/verificadores/v45_visitas.py` | 1678 |  | `752b454c9ecc5cdc22c9fcd6cbe09e1647bd4a1a475b7460204401fb8dbdb960` |
| `scripts/verificadores/v7_recalculo_DE.py` | 2463 |  | `053b76e0429a99f728d674d346de8915bc1890f1ef091fc7acb7293b69f6059d` |
| `scripts/verificadores/v7_verif_resto.py` | 4584 |  | `706f3cf474a746b5b5bf306097a9a602bf3effdcecfc7ca1c9e52e0a0b70b2b0` |
| `scripts/verificar_cifras.py` | 65384 |  | `f2556669cc74d9067103d2442521709e2d3ffa568b1fee403d7a78b6ffeb2701` |
| `verificacion_cifras.txt` | 55386 |  | `77cdf65dfb9ee4ea94383e9ddce88babb7409c326e0d47e2b3a7c0a648fec7a7` |
