"""
verificar_cifras_expR_20261113.py
=================================
Verificador del REPORTE_2026-11-13_expR.md, que viaja en el paquete de datos.

1. Paquete: el sha256 de cada archivo coincide con `sha256_paquete.txt`.
2. Núcleo (`datos/expR_replica_obstaculos_moviles/verificar_cifras_R.py`): arma el
   resumen esperado desde el CSV crudo y las trazas, y lo compara texto contra
   texto con `resumen_R.txt`. Tiene que dar 0 diferencias.
3. Literales (`literales_bitacora_R.py`): la subsección de resultados de la
   bitácora, cifra por cifra.
4. El reporte, en los dos sentidos:
   - cada literal recalculado desde el crudo (las filas de la tabla con su
     veredicto, las cifras de la lectura, la corrida y la verificación) está
     tal cual en el reporte;
   - toda cifra del reporte es una de esas o una constante declarada con su
     fuente, sea en DECLARADAS del archivo de literales o en las de este archivo.

    python -B scripts/verificar_cifras_expR_20261113.py
    python -B scripts/verificar_cifras_expR_20261113.py --mutaciones

Usa sólo la biblioteca estándar; si scipy está instalado, el núcleo lo usa además
para contrastar Clopper-Pearson y McNemar a 10 decimales. Termina con 0 si todo
coincide y con 1 si no.
"""

from __future__ import annotations

import hashlib
import sys
import tempfile
from pathlib import Path
from typing import List, Tuple

RAIZ: Path = Path(__file__).resolve().parent.parent
DATOS_R: Path = RAIZ / "datos" / "expR_replica_obstaculos_moviles"
sys.path.insert(0, str(DATOS_R))

import literales_bitacora_R as LB  # noqa: E402
import verificar_cifras_R as VC  # noqa: E402

REPORTE: Path = RAIZ / "REPORTE_2026-11-13_expR.md"

#: Cifras propias del reporte (fuera de la subsección de la bitácora), con su fuente.
DECLARADAS_REPORTE = {
    "4800": "§1 del prerregistro: 12 × 400", "1200": "control bit a bit sobre semillas vistas",
    "11": "§1 del prerregistro: 11 líneas `# [R]` en correr_episodio_R",
}
DECLARADAS_HORAS_REPORTE = {
    "01:38": "línea «Fijado» de PREREGISTRO_R.md",
    "17:54": "línea «Fijada» de ADENDA_PREREGISTRO_R_20261109.md",
    "09:55": "línea «inicio» de control_bit_a_bit_R.txt (09:55:12)",
}


def verificar_paquete() -> List[str]:
    dif = []
    lista = (RAIZ / "sha256_paquete.txt").read_text(encoding="utf-8").splitlines()
    vistos = set()
    for linea in lista:
        h, _sep, rel = linea.partition(" *./")
        if len(h) != 64 or not rel:
            continue
        vistos.add(rel)
        p = RAIZ / rel
        if not p.exists():
            dif.append(f"PAQUETE: falta {rel}")
        elif hashlib.sha256(p.read_bytes()).hexdigest() != h:
            dif.append(f"PAQUETE: {rel} no coincide con su sha256")
    extra = sorted(p.relative_to(RAIZ).as_posix() for p in RAIZ.rglob("*")
                   if p.is_file() and "__pycache__" not in p.parts
                   and p.name != "sha256_paquete.txt" and p.relative_to(RAIZ).as_posix() not in vistos)
    dif += [f"PAQUETE: archivo no listado {x}" for x in extra]
    return dif


def literales_reporte() -> List[Tuple[str, str]]:
    """Cifras propias del reporte que salen del crudo: las semillas vistas de S3_sinvel con
    contacto (la salvedad sobre el §3.2 del prerregistro), desde el CSV del control."""
    d: List[str] = []
    vistos, _c = VC.cargar([VC.RUTA_CONTROL_CSV], d)
    sem = sorted(vistos["S3_sinvel"])
    con = sorted(VC.con_evento(vistos, "S3_sinvel", "contacto", sem))
    man = (DATOS_R / "resultados" / "manifiesto_R_pre_20261113_2021.txt").read_text(encoding="utf-8")
    n_man = sum(1 for x in man.splitlines() if " *./" in x)
    lit = [("manifiesto pre, archivos", f"los {n_man} archivos de la carpeta, sin los logs")]
    if len(con) != 3:
        return lit + [("contactos vistos", f"(se esperaban 3 semillas con contacto, hay {len(con)})")]
    return lit + [("contactos vistos", f"sólo S3_sinvel {con[0]} y {con[2]}; {con[1]} también tiene "
                                       f"contacto")]


def verificar_reporte(ruta: Path = REPORTE, lit=None) -> Tuple[List[str], int]:
    texto = ruta.read_bytes().decode("utf-8")
    dif = ["REPORTE: tiene CR"] if "\r" in texto else []
    if lit is None:
        lit, d = LB.literales()
        dif += d
    lit = list(lit) + literales_reporte()
    vistos = set()
    for que, esperado in lit:
        if esperado not in texto:
            dif.append(f"REPORTE: falta o difiere «{esperado}» ({que})")
        else:
            c, h = LB.tokens(esperado)
            vistos |= set(c) | set(h)
    cifras, horas = LB.tokens(texto)
    sueltas = sorted({c for c in cifras if c not in vistos and c.lstrip("+−-") not in LB.DECLARADAS
                      and c not in DECLARADAS_REPORTE})
    sueltas_h = sorted({h for h in horas if h not in vistos and h not in LB.DECLARADAS_HORAS
                        and h not in DECLARADAS_HORAS_REPORTE})
    dif += [f"REPORTE: cifra sin verificar ni declarar «{c}»" for c in sueltas]
    dif += [f"REPORTE: hora sin verificar ni declarar «{h}»" for h in sueltas_h]
    return dif, len(lit)


MUTACIONES: Tuple[Tuple[str, str, str], ...] = (
    ("veredicto invertido (H2-S3)", "b/c = 133/44; p < 0.0001 | sostenida |",
     "b/c = 133/44; p < 0.0001 | no sostenida |"),
    ("cifra cambiada (H3a)", "S3_din 20/400, S3_ctrl 1/400", "S3_din 21/400, S3_ctrl 1/400"),
    ("cifra cambiada por otra que ya aparece", "H2-S2 0.0027", "H2-S2 0.0024"),
    ("línea agregada con una cifra", "## 4. Salvedades y desviaciones\n",
     "## 4. Salvedades y desviaciones\n\n- Hubo 13 episodios repetidos.\n"),
)


def main() -> int:
    if sys.argv[1:] == ["--mutaciones"]:
        texto = REPORTE.read_text(encoding="utf-8")
        lit, _d = LB.literales()
        ok = True
        with tempfile.TemporaryDirectory() as t:
            for caso, viejo, nuevo in MUTACIONES:
                assert texto.count(viejo) == 1, viejo
                ruta = Path(t) / "reporte.md"
                ruta.write_bytes(texto.replace(viejo, nuevo).encode("utf-8"))
                dif, _ = verificar_reporte(ruta, lit)
                print(f"  {'DETECTADA' if dif else 'NO DETECTADA'}: {caso}")
                ok = ok and bool(dif)
        return 0 if ok else 1
    dif = verificar_paquete()
    d_res, cuenta = VC.verificar("resultado")
    dif += [f"NÚCLEO: {x}" for x in d_res]
    d_ent, n_ent = LB.verificar_entrada()
    dif += [f"BITÁCORA: {x}" for x in d_ent]
    d_rep, n_rep = verificar_reporte()
    dif += d_rep
    print("verificar_cifras_expR_20261113.py")
    print(f"  núcleo: {cuenta.get('lineas_resumen')} líneas de resumen_R.txt contra "
          f"{cuenta.get('lineas_esperadas')} esperadas")
    print(f"  literales: {n_ent} en la subsección de la bitácora; {n_rep} en el reporte")
    if dif:
        print(f"DIFERENCIAS: {len(dif)}")
        for x in dif:
            print("  " + x)
        return 1
    print("TODO COINCIDE: paquete íntegro, resumen y bitácora verificados, y cada cifra del reporte "
          "recalculada o declarada.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
