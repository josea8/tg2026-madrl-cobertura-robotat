# Paquete de datos del REPORTE_2026-11-13_expR.md

Son copias byte a byte de los archivos del Exp R, con la misma estructura de carpetas que en la tesis, así los scripts encuentran todo por rutas relativas. El sha256 de cada archivo está en `sha256_paquete.txt`.

- `REPORTE_2026-11-13_expR.md`: el reporte.
- `scripts/verificar_cifras_expR_20261113.py`: verifica el paquete, el resumen, la subsección de la bitácora y cada cifra del reporte. Se corre con `python -B scripts/verificar_cifras_expR_20261113.py`; con `--mutaciones` prueba que detecta cambios.
- `datos/expR_replica_obstaculos_moviles/`:
  - `PREREGISTRO_R.md` y `ADENDA_PREREGISTRO_R_20261109.md`: el diseño fijado.
  - `resultados/experimento_R_completo.csv`: el CRUDO del experimento, 4800 filas.
  - `resultados/trazas/`: las trazas por paso. `R_*` son las del experimento; `controlR_*`, las del control sobre semillas vistas.
  - `resultados/registro_R.txt` y `resultados/corrida_R_experimento_*.log`: el registro y los logs de los dos tramos de la corrida.
  - `resultados/resumen_R.txt`: el resumen del análisis prerregistrado.
  - Del control y la pasabilidad:
    - `resultados/control_bit_a_bit_R.csv`
    - `resultados/control_bit_a_bit_R.txt`
    - `resultados/pasabilidad_R.txt`
    - `resultados/comparar_ast_R.txt`
  - `resultados/manifiesto_R_pre_*.txt` y `resultados/manifiesto_sha256_R.txt`: los manifiestos pre y de cierre.
  - `figuras/`: las figuras del resumen.
  - El código:
    - `verificar_cifras_R.py`: el núcleo del verificador.
    - `literales_bitacora_R.py`: los literales de la bitácora.
    - `analizar_experimento_R.py`: el análisis prerregistrado. Necesita el código del Exp Q, que no viaja en el paquete; se incluye para leerlo.
    - `correr_experimento_R.py`, `comparar_ast_R.py` y las pruebas.
  - `ENTRADA_BITACORA_expR_pre.md` y `ENTRADA_BITACORA_expR_resultados.md`: las entradas de la bitácora.
- `datos/expQ_obstaculos_moviles/resultados/`: los dos CSV del Exp Q contra los que se comparó el control bit a bit.

Necesita Python 3 (probado con 3.13.14) y sólo la biblioteca estándar; si scipy está instalado, lo usa además para contrastar.
