"""¿Se cortan solas las conexiones con los robots? Sólo lectura: conecta al puerto
9090 y NO envía ningún dato; activa keepalive TCP (sondas sin carga, cada 2 s) para
detectar un reset del otro lado. Si una conexión cae, la reabre y lo cuenta."""
import select
import socket
import time

ROBOTS = {1: "192.168.50.101", 5: "192.168.50.105", 8: "192.168.50.108",
          2: "192.168.50.102", 9: "192.168.50.109", 4: "192.168.50.104"}
DURACION_S = 90


def abrir(ip):
    s = socket.create_connection((ip, 9090), timeout=3.0)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    s.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 2000, 1000))   # sonda a los 2 s, reintento cada 1 s
    s.setblocking(False)
    return s


conex, eventos, recibido = {}, {r: [] for r in ROBOTS}, {r: 0 for r in ROBOTS}
t0 = time.time()
for r, ip in ROBOTS.items():
    try:
        conex[r] = abrir(ip)
    except OSError as e:
        eventos[r].append((0.0, f"no abre: {type(e).__name__}"))
while time.time() - t0 < DURACION_S:
    vivos = [s for s in conex.values() if s is not None]
    listos, _, _ = select.select(vivos, [], vivos, 0.5) if vivos else ([], [], [])
    for r, s in list(conex.items()):
        if s is None or s not in listos:
            continue
        t = time.time() - t0
        try:
            datos = s.recv(4096)
            if datos:
                recibido[r] += len(datos)
                continue
            eventos[r].append((t, "el robot cerró (FIN)"))
        except (ConnectionResetError, ConnectionAbortedError, OSError) as e:
            eventos[r].append((t, f"reset ({type(e).__name__})"))
        s.close()
        try:
            conex[r] = abrir(ROBOTS[r])
            eventos[r][-1] = (t, eventos[r][-1][1] + f", reabierta en {time.time() - t0 - t:.1f} s")
        except OSError as e:
            conex[r] = None
            eventos[r][-1] = (t, eventos[r][-1][1] + f", no se pudo reabrir ({type(e).__name__})")
for s in conex.values():
    if s is not None:
        s.close()
print(f"{DURACION_S} s con las conexiones abiertas y sin enviar nada:")
for r in ROBOTS:
    ev = eventos[r]
    detalle = "; ".join(f"{t:.0f} s: {m}" for t, m in ev) if ev else "sin cortes"
    print(f"   robot {r}: {len(ev)} corte(s) — {detalle}" + (f" · recibió {recibido[r]} B" if recibido[r] else ""))
