"""Verificación de la red del laboratorio, sólo lectura: no manda órdenes a los robots."""
import socket
import statistics
import subprocess
import sys
import time

sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import config_robotat as cfg  # noqa: E402
import sesion_robotat as ses  # noqa: E402

robots = [cfg.MAPEO_AGENTES[i].id_robot for i in range(5)] + [4]
equipos = [("servidor de poses", "192.168.50.200", 1883)] + [
    (f"robot {r}", f"192.168.50.{100 + r}", 9090) for r in robots]

print("1) ping y puerto (sólo abrir y cerrar la conexión, sin mandar nada):")
for nombre, ip, puerto in equipos:
    p = subprocess.run(["ping", "-n", "3", "-w", "1000", ip], capture_output=True, text=True)
    lineas = [l for l in p.stdout.splitlines() if "Average" in l or "Media" in l or "Promedio" in l]
    perdidos = [l for l in p.stdout.splitlines() if "Lost" in l or "perdidos" in l]
    t0 = time.perf_counter()
    try:
        s = socket.create_connection((ip, puerto), timeout=2.0)
        estado = f"puerto {puerto} ABIERTO ({(time.perf_counter() - t0) * 1000:.0f} ms)"
        s.close()
    except OSError as e:
        estado = f"puerto {puerto} NO responde ({type(e).__name__})"
    print(f"   {nombre:<18} {ip:<15} {estado} | ping: {(perdidos[0].strip() if perdidos else '?')} {(lineas[0].strip() if lineas else '')}")

print("\n2) marcadores (vivo / CONGELADO / SIN RESPUESTA):")
marcadores = [cfg.MAPEO_AGENTES[i].id_marcador for i in range(5)] + [4]
try:
    c = ses.ClientePosesCrudo()
    for m in marcadores:
        congelado, _distintos, utiles = ses.stream_congelado(c, m)
        print(f"   marcador {m}: {'CONGELADO' if congelado else ('vivo' if utiles else 'SIN RESPUESTA')}")
    print("\n3) latencia del servidor de poses (200 consultas en lote de los 6 marcadores, como la sesión):")
    tiempos, fallas = [], 0
    for _ in range(200):
        _crudo, matriz, lat = c.consultar(marcadores)
        if matriz is None:
            fallas += 1
        else:
            tiempos.append(lat * 1000)
        time.sleep(0.1)
    if tiempos:
        t = sorted(tiempos)
        print(f"   p50 {statistics.median(t):.1f} ms · p95 {t[int(0.95 * len(t)) - 1]:.1f} ms · máx {t[-1]:.1f} ms · fallas {fallas}/200")
    c.cerrar()
except Exception as e:
    print(f"   no se pudo leer el servidor de poses: {type(e).__name__}: {e}")
