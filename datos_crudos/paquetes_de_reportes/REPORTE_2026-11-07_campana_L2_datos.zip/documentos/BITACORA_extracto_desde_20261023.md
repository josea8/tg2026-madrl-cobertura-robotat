### Demostración final: dos modos y panel en otro proceso (2026-10-23) — demostración, no citable

**Qué es:** la sesión de demostración de la implementación final, para el video del documento, el póster y la defensa en vivo. No es una medición: sus salidas van a `resultados_demo_final/` y **no se citan en el documento**. La campaña `L2_obstaculo_2` sigue ABIERTA y no se tocó.

**Archivos nuevos** (en `controllers/coordinador_enjambre/`, LF): `demo_final.py`, `publicador_estado.py`, `panel_demo.py`, `test_demo_final.py`, `comparar_ast_demo_final.py`, `verificar_cifras_demo_final.py` y `manifiesto_sha256_demo_final.txt`. No se modificó ningún archivo existente salvo esta bitácora.

**Los dos modos:**
- `objetivos`: la configuración de la evaluación del 30-09 (robots 1, 5, 8, 2, 9; `modelo_sanidad`; CBF y escape; factor 0.40; 500 decisiones; colocación autónoma).
- `mejorada`: lo mismo con el robot 4 como obstáculo móvil del modo L2 (F2, τ_c 0.65 s, círculo de R 0.60 alrededor de (1.5, 1.5) a 0.05 m/s), sin campaña.
- En hardware, `mejorada` exige la L0 OK del día del 4 (código 6, sin `--forzar`).

**Sólo orquesta.** Lo que no se podía importar se copió literal y está marcado con su archivo y líneas:
- `sesion_robotat.py` 1991-2000, 2013-2034 y 2062-2235;
- `demo_obstaculo_movil.py` 2653-2663 y 2692-2909 (el bucle de tomas con las reglas de parada, con `campana = None`).
- `comparar_ast_demo_final.py` comprueba que las cinco copias son idénticas a su fuente salvo **una línea marcada `[demo]`** (`sesion_robotat.py:2133`, `--colocacion actual` no pide reposicionar), y que nada redefine ni parchea un congelado. Veredicto: "SÓLO ORQUESTAN".
- La publicación, el Enter entre episodios y la hora de fin entran por la subclase del coordinador (publica DESPUÉS de `super()._decidir_y_actuar()`) y por tres envoltorios locales que llaman a las funciones congeladas.

**Publicación:** UDP, una vez por decisión. Nunca lanza: tras 20 errores seguidos se apaga y avisa una vez. Serializar y enviar va en un hilo del publicador, mientras el lazo duerme. Medido en el banco de la prueba 5, intercalado: en hilo cuesta el 58–61 % de enviar en el acto.

**Pruebas** (simulador, Python de la Store = el de la campaña): 13/13 funcionales OK.
- 1 y 2: los dos modos corren completos y los CSV tienen las columnas de la etapa 7 y de `sesion_demo`.
- 3 y 4: los mensajes llegan completos y en orden, y las fallas inyectadas no invalidan el episodio.
- 5: bit a bit contra `CoordinadorEnjambre` y `CoordinadorConObstaculo`. Con obstáculo hubo que **fijar el reloj** en la prueba: la F2 y el supervisor leen `perf_counter`, y sin eso ni la base es igual a sí misma entre dos corridas.
- 6: en `--simulador` la calibración queda en identidad.
- Las pruebas 1 a 6 corrieron **a batería**: valen como funcionales, pero sus tiempos no se citan.

**Prueba 7 (costo del panel), NO PASA en la misma laptop.**
- La primera corrida fue a batería (22 %) y no vale: el ciclo p95 sin GUI subió de ~10 a 42 ms en las tres condiciones. Quedó en `_superadas/` con su LEEME.
- Repetida **enchufada** (medias del ciclo p95, 3 × 300):

| condición | media |
|---|---|
| sin GUI | 9.99 ms |
| publica, sin panel | 9.40 ms |
| panel abierto, 10 Hz | 14.56 ms |
| panel abierto, 5 Hz | 14.44 ms |

- **Publicar no cuesta nada medible**; el panel abierto en la misma laptop suma +4.56 ms (10 Hz) y +4.45 ms (5 Hz), sobre el umbral de +2 ms.
- Como no baja con el ritmo de dibujo, no es el dibujo en sí. La causa no se aisló.
- **Recomendación:** el panel en otra laptop de la misma red (`--gui <IP>:27300`), que es la salida que ya preveía el plan. Con la misma laptop, el lazo igual cumple con holgura (~15 ms de 100), pero no el criterio de +2 ms.

**El día de la demo, lo que aprendimos hoy:** la laptop del lazo **enchufada** y en "Mejor rendimiento". A batería, el ciclo se cuadruplica.

**Congelados:** el chequeo del protocolo da "IGUAL a lo probado" antes de empezar y al terminar cada paso. El manifiesto sha256 registra los 22 archivos idénticos.

**Pendiente:** la fase 2 (espejo en Webots), sólo con OK de José; el ensayo completo en casa con el panel en la segunda laptop.

**Reporte:** `REPORTE_2026-10-23_demo_final.md` con `REPORTE_2026-10-23_demo_final_datos.zip`.

**Respaldo:** antes de esta entrada, `BITACORA_TECNICA_respaldo_20261023_preDemoFinal.md`.

### Demostración final: de dónde salen los ~4.7 ms del panel (2026-10-23, noche) — demostración, no citable

**Corrige la entrada anterior.** Allí la prueba 7 decía +4.56 ms y "no es el dibujo". Ahora la causa está acotada y la cifra vigente es la de la prueba intercalada.

**El panel se corrigió, aunque no era la causa.**
- `plt.pause()` redibujaba la figura entera en cada cuadro, además del blitting. Se reemplazó por `canvas.start_event_loop()`.
- La rejilla de AoI se redibujaba sin haber cambiado. Ahora queda guardada como capa y sólo se vuelve a dibujar cuando llega una nueva.
- La baja de prioridad del proceso **nunca había funcionado**: faltaban las firmas de `ctypes`. Ahora dice "bajo lo normal".
- Resultado: el panel pasó de 0.97 a 0.22 de un núcleo, con la misma imagen. **El costo sobre el lazo no cambió.**

**Prueba 7 intercalada** (enchufada, sin Chrome ni ChatGPT; 4 rondas, 1 × 300 por condición, orden rotado): sin GUI 7.80 ms, publica 7.75 ms, panel 12.51 ms.
- Panel − sin GUI, pareado: **+4.71 ms** (de +4.02 a +5.13). No pasa.
- Publica − sin GUI: -0.05 ms.
- Una corrida anterior con Chrome abierto dio +0.30 ms: era ruido. Está en `_superadas/` con su LEEME.

**Ingredientes separados** (`resultados_demo_final/diagnostico_panel_20261023/`, intercalados, pareados contra sin GUI):

| condición | − sin GUI |
|---|---|
| panel con ventana, recibiendo | +3.92 ms |
| panel con ventana, sin datos | +3.74 ms |
| panel sin ventana (Agg), recibiendo | +0.04 ms |
| sólo timer de 1 ms | -0.86 ms |
| ventana Tk mínima (un reloj) | +4.19 ms |
| la misma, minimizada | +3.99 ms |

- **Causa: cualquier proceso con un bucle de eventos Tk** en la misma máquina, aunque esté minimizado.
- **No es** dibujar, recibir, matplotlib, el foco ni el temporizador. El mecanismo dentro de Windows no se aisló.
- Medido en el simulador, donde el proceso del lazo tiene además los hilos del simulador. En el Robotat podría ser distinto.

**Errores del diagnóstico, declarados:**
- Una corrida A/G/H leyó el CSV viejo de A porque reutilizaba la carpeta: se descartó, se corrigió el script y se repitió.
- Una condición con el Bloc de notas se canceló antes de correr, porque al final cerraba todos los Bloc de notas. No se cerró ninguno.

**Decisión pendiente de José:** el panel en otra laptop de la misma red (recomendado), o aceptarlo en la misma laptop con el lazo en ~12.5 ms de 100.

**Reporte y zip actualizados:** `REPORTE_2026-10-23_demo_final.md`, 24/24 cifras verificadas.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261023_preCausaPanel.md`.

### Demostración final: el panel va en la misma laptop — decisión de José (2026-10-23)

**Decisión de José (23-10), textual:** "Acepto el panel en la misma laptop: el lazo queda en ~12.5 ms de 100."

- Se aparta del criterio de la prueba 7 del plan (+2 ms como máximo): con el panel abierto, el ciclo p95 sube +4.71 ms pareado (7.80 → 12.51 ms), según la adenda anterior. La prueba 7 queda **no aprobada** y se acepta así, por decisión de José.
- El periodo del lazo es de 100 ms: queda con holgura.
- Lo medido es del simulador. El día del laboratorio, mirar el ciclo p95 que muestra el panel durante el ensayo. Si se aleja de lo medido acá, la otra laptop sigue disponible (`--gui <IP>:27300`).
- No cambia nada del código.

**Respaldo:** antes de esta entrada, `BITACORA_TECNICA_respaldo_20261023_preDecisionPanel.md`.

### `L2_obstaculo_2`, sesiones del 23-10 (20:48–21:23): 10/50 incluidas

**Chequeo previo de la PC** (pegado por el operador):

```text
chequeo previo de la PC: 2026-10-23 20:32:35
  corriente: A BATERIA | ahorro de energia: apagado
  plan: 381b4222-f694-41f0-9685-ff5bb260df2e (Equilibrado) | modo enchufada: ded574b5-45a0-4f42-8737-46345c09c238 (Mejor rendimiento)
  procesos: OverlayHelper.exe [5728], SystemOptimizer.exe [5876], OmenInstallMonitor.exe [9212], OmenCommandCenterBackground.exe [6376], HP.OMEN.VirtualCamHelper.exe [2024]
CHEQUEO FALLA: no lanzar
```

- Se indicó enchufar la laptop y detener los procesos de OMEN como administrador.
- **Declaración:** no consta un `CHEQUEO OK` antes de las sesiones. La salida pegada de las sesiones empieza en el comando de la primera; el último chequeo registrado es esta FALLA, 16 min antes.

**Sesiones:**
- **`L2_20261023_204819`** (fin 21:15): se cerró a los 5 s por "timed out" al conectar con el servidor de poses del Robotat. Sin reservas.
- **`L2_20261023_204919`**: se cerró a los 11 s porque el robot 2 no respondía en la red. Sin reservas.
- **`L2_20261023_205007`** (20:50:08–21:23:37), intentos 18–25:
  - **Intento 18** (422017): sin correr. El 4 no quedó en su arranque: la guía pidió colocarlo a mano seis veces, y al final quedó a +159° de la tangente.
  - **Intento 19** (422018): válida, **INCLUIDA**; d_min obstáculo 0.347 m.
  - **Intento 20** (422019): válida, **INCLUIDA**; d_min obstáculo 0.297 m, la menor de la campaña hasta ahora (sin contacto). Hubo un reintento de colocación: el 8 "no avanza".
  - **Intento 21** (422020): válida, **INCLUIDA**; d_min obstáculo 0.346 m. Hubo un reintento: el 5 "no avanza".
  - **Intento 22** (422021): no válida, marcador 9 congelado en (0.21, 2.56), a 0.21 m de la pared, tras retroceder 2.4 s.
  - **Intento 23** (422022): no válida por antigüedad de pose. El marcador 8 se repitió en (1.56, 1.31), a unos 3 cm de la zona interior del 21-10 (x 1.456–1.548, y 1.213–1.281). Antes hubo tres reintentos de colocación: el marcador 9 congelado y, dos veces, el 5 que no avanzaba.
  - **Intento 24** (422023): parada en la colocación por **"ABORTO POR EL OBSTÁCULO: el obstáculo NO FRENA: se movió 51.1 cm durante la colocación (v medida 0.000 m/s)"**. Pausa: "s" → siguió.
    - Durante esa guía el marcador 8 estuvo un buen rato "SIN POSE", y varios robots cambiaron de lugar sin colocación en marcha: los movieron a mano.
    - Con v medida 0, lo más probable es que el 4 también se moviera a mano, o que su marcador saltara. No fue el robot andando. Falta confirmarlo con el operador.
  - **Intento 25** (422024): en la guía el 4 estaba fuera de su arranque (primero cerca del centro, después a 10–23 cm del círculo). El operador cortó con Ctrl+C a las 21:23:37: "interrumpida".
  - 0 contactos, 0 frenos de respaldo y 0 pares a < 0.15 m. Consola: 1088 ticks fuera de plazo; latencia de poses p50 3.5 ms, p95 5.5 ms y máx 94.3 ms (el 21-10, p95 16.8–17.8 ms); 345 poses rechazadas por inclinación; 0 envíos fallidos y 0 reconexiones.

**Estado de la campaña:** 25/100 intentos, **10/50 incluidas** (intentos 2, 4, 8, 9, 10, 13, 14, 19, 20 y 21), 19 corridas, 0 tomas con contacto. Sigue abierta, sin candado. Se retoma con el mismo comando, en el intento 26 (semilla 422025). Ritmo: 10/25 = 40 %.

**Para la próxima sesión:**
- `CHEQUEO OK` antes de cada lanzamiento, pegado aquí.
- Mover el 4 a mano sólo cuando la guía lo pide para el obstáculo, no durante la colocación de los agentes.
- Revisar los marcadores 8 y 9 (congelados o sin pose varias veces) y las ruedas del 5 y el 8 ("no avanza").

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261023_preSesionL2.md`.

### `L2_obstaculo_2`, sesión del 04-11 (12:07–12:41): 12/50 incluidas y caída de la red del laboratorio

**Chequeo previo de la PC:** no consta (no se pegó ninguna salida). Se declara como sesión sin `CHEQUEO OK`.

**Sesiones:**
- **`L2_20261104_120701`** (fin 13:40): se cerró a los 5 s por "timed out" al conectar con el servidor de poses. Sin reservas.
- **`L2_20261104_120744`** (12:07:44–12:41:20), intentos 26–35:
  - **Intentos 26, 27 y 28** (422025–422027): sin correr. El 4 no quedó en su arranque después de seis correcciones a mano cada uno: a 11.6 cm del círculo y 49°, a 36.5 cm, y a 27.6 cm. En el 29 se lo puso en (1.50, 0.90), mirando +x (el arranque de la L0), y entró.
  - **Intento 29** (422028): válida, **INCLUIDA**; d_min obstáculo 0.370 m. Antes hubo tres reintentos: el robot 1 "no avanza".
  - **Intento 30** (422029): no válida por antigüedad de pose. El marcador 8 se repitió en (1.46, 1.32) y (1.48, 1.33), en la zona interior del 21-10 (x 1.456–1.548, y 1.213–1.281) o a 5 cm de ella.
  - **Intento 31** (422030): no válida por antigüedad de pose (marcador 9 repetido en (0.59, 0.37)). En la guía, el marcador 8 seguía congelado en (1.49, 1.33).
  - **Intento 32** (422031): no válida, marcador 9 congelado en (0.24, 0.30). Antes, el 5 se repitió cuatro veces en (2.36–2.37, 2.70–2.72) y se recuperó.
  - **Intento 33** (422032): válida, **INCLUIDA**; d_min obstáculo 0.288 m, la menor de la campaña hasta ahora (sin contacto).
  - **Intento 34** (422033): no válida, marcador 8 congelado en (2.71, 2.51). Hubo tres reintentos de colocación: el 5 y el 9 "no avanza".
  - **Intento 35** (422034): en la colocación, todos los marcadores y el del 4 se quedaron a la vez sin pose fresca, y enseguida cayó la red (abajo). El operador cortó con Ctrl+C a las 12:41:20: "interrumpida".

**La caída de la red** (consola):
- Primero la fuente de poses se quedó sin datos frescos para los 6 marcadores a la vez. Después, entre las 12:31:59 y las 12:32:09, se cortaron los enlaces de los 6 robots (10054) y la conexión con el servidor de poses, que se perdió varias veces más.
- Los robots 5, 2, 8 y 9 y el 4 volvieron a los 234–291 s. **El robot 1 no volvió nunca** (274 intentos sin respuesta): su detención no se pudo confirmar.
- A las 12:40:24–26 se cortaron otra vez los 5 que habían vuelto, y regresaron en unos 20 s.
- Que caigan a la vez el servidor de poses y todos los robots, con 10054 (la conexión la cierra el otro extremo), y que los robots tarden unos 4 min en volver, apunta a la red del laboratorio (router o punto de acceso reiniciado o caído). No apunta al código ni a un robot. No está confirmado con el laboratorio.
- La red ya venía mal: el primer lanzamiento dio "timed out", y la latencia de poses de la sesión fue p50 3.9 ms, p95 39.8 ms y máx 741.0 ms, con 32 consultas fallidas. El 23-10 había sido p95 5.5 ms y máx 94.3 ms. Hubo 2046 ticks fuera de plazo.
- 0 contactos, 0 frenos de respaldo y 0 pares a < 0.15 m.

**Estado de la campaña:** 35/100 intentos, **12/50 incluidas** (2, 4, 8, 9, 10, 13, 14, 19, 20, 21, 29 y 33), 25 corridas, 0 tomas con contacto. Sigue abierta, sin candado. Se retoma en el intento 36 (semilla 422035). Ritmo: 12/35 = 34 %. A ese ritmo el mínimo de 30 llegaría cerca del intento 88; quedan 65 intentos para 18 incluidas (28 %).

**Para la próxima sesión:**
- Confirmar con el laboratorio el estado de la red; si vuelve a dar "timed out" o la latencia sube, no lanzar.
- Apagar y prender el robot 1, y comprobar que vuelva a la red.
- `CHEQUEO OK` y revisión de marcadores antes de cada lanzamiento, pegados aquí.
- Antes de lanzar, dejar el 4 en (1.50, 0.90) mirando +x: hoy tres intentos se gastaron sin correr porque el 4 no quedó en su arranque.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261104_preSesionL2.md`.

### `L2_obstaculo_2`, sesión del 04-11 a las 12:51: dos paradas por enlaces que se cortan, y diagnóstico de la red

**Verificación antes de lanzar (12:48, sólo lectura, desde la laptop):**
- Los 7 equipos responden al ping sin pérdidas y aceptan conexión en su puerto: el servidor de poses y los robots 1, 5, 8, 2, 9 y 4. El robot 1 volvió a la red.
- Los 6 marcadores estaban vivos.
- Latencia del servidor de poses, en 200 consultas en lote: p50 3.4 ms, p95 14.9 ms y máx 52.3 ms, sin fallas.

**Chequeo previo de la PC** (pegado por el operador):

```text
chequeo previo de la PC: 2026-11-04 12:49:56
  corriente: enchufada | ahorro de energia: apagado
  plan: 381b4222-f694-41f0-9685-ff5bb260df2e (Equilibrado) | modo enchufada: ded574b5-45a0-4f42-8737-46345c09c238 (Mejor rendimiento)
  procesos: ninguno
CHEQUEO OK
```

**Sesión `L2_20261104_125102`** (fin 13:40):
- **Intento 36** (422035): parada en la colocación por **"ABORTO POR EL OBSTÁCULO: enlace de ruedas del obstáculo (robot 4) caído antes de la colocación"**. Antes, en la colocación, los robots 5, 8, 2 y 9 "no avanza": sus enlaces se habían reseteado (10054). Pausa: "s" → siguió.
- **Intento 37** (422036): parada en la colocación por **"ENLACE DE RUEDAS CAÍDO durante la colocación: robot(s) 5"**. Otra vez los 5, 8, 2 y 9 "no avanza", y el 1 llegó solo. Pausa: "detenida" (12:58:45).
- Entre las 12:52:04 y las 12:58:13 hubo 16 resets (10054) de los enlaces de los robots, en los seis y escalonados: 4 del 2, 4 del 9, 4 del 8, 3 del 5 y 1 del 1, más 3 del 4. Casi todos se reabrieron en 0.0–0.5 s; algunos tardaron 4–22 s.
- El servidor de poses anduvo bien: 744 consultas sin fallas, p50 4.0 ms, p95 30.2 ms y máx 52.8 ms.
- 0 decisiones de toma; 0 contactos.

**Diagnóstico después de la sesión (sólo lectura):**
- En la laptop no quedó ningún proceso conectado a los robots: sólo conexiones en TIME_WAIT y el servidor de Inventor, que arrancó a las 12:59:49, después de la sesión.
- No hay conflicto de IP: en 12 vueltas (unos 40 s), cada IP de robot dio siempre la misma MAC (98-cd-ac-… y 34-ab-95-…, placas Espressif).
- La laptop tiene dos adaptadores WiFi activos: el USB TP-Link (`Wi-Fi 6`, 192.168.50.3, red del laboratorio) y el interno Realtek (`Wi-Fi`, 10.100.0.92, otra red). La ruta hacia 192.168.50.0/24 va por el TP-Link, como corresponde.
- Ping de 60 s, en paralelo y sin pérdidas:

  | Destino | p50 | p95 |
  |---|---|---|
  | router .1 | 8 ms | 40 ms |
  | servidor de poses | 4 ms | 26 ms |
  | los 6 robots | 207–215 ms | 340–348 ms |

  Los seis robots dan lo mismo.
- Conexiones abiertas con los 6 robots durante 90 s, sin enviar datos (sólo keepalive TCP cada 2 s): 0 cortes.

**Lectura:**
- Antes de la caída de la red de las 12:31:59, esta mañana no hubo ningún reset, y el 23-10 tampoco.
- Desde que la red volvió, los robots responden con latencia alta y pareja (unos 210 ms; no hay una medición anterior para comparar). Con el tráfico de la sesión, a 10 Hz, sus enlaces se resetean cada 10–60 s; en reposo, no.
- Apunta al WiFi del laboratorio, que volvió degradado después de la caída. No apunta al código, que no cambió (congelados), ni a un robot en particular.
- No está confirmado. Las paradas de seguridad actuaron como debían: detuvieron la sesión al caer los enlaces.

**Estado de la campaña:** 37/100 intentos, 12/50 incluidas, 25 corridas, 0 tomas con contacto. Sigue abierta y se retoma en el intento 38 (422037). Los intentos 36 y 37 se gastaron sin correr.

**Para seguir:**
- No lanzar con la red así: cada lanzamiento gasta intentos.
- Pedir al laboratorio que revise el router o el punto de acceso (canal, si es el mismo de antes) y reiniciar los robots para que se reconecten.
- Antes de lanzar, repetir esta verificación. Opcional: apagar el WiFi interno de la laptop durante la sesión, para no tener dos radios transmitiendo.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261104_preSesion2.md`.

### `L2_obstaculo_2`, 06-11: se alcanza el mínimo de 30 incluidas (intentos 38–73)

**Antes de lanzar:**
- Chequeo de la PC a las 19:21:17: **FALLA** por Chrome. No consta un `CHEQUEO OK` después. La app de Claude estaba abierta a las 19:35 (verificación de marcadores); no consta si se cerró antes de la sesión de las 19:38.
- Cuatro lanzamientos no arrancaron; ninguno reservó intentos:
  - `L2_20261106_192946`: "timed out" al conectar con el servidor de poses (19:29:51).
  - `L2_20261106_193200`, `L2_20261106_193221` y `L2_20261106_193330`: se cerraron en 1 s con "fin de la sesión". Es el FALLO silencioso del chequeo de marcadores (defecto conocido, demo congelada).
- Verificación de sólo lectura a las 19:34:58: el servidor de poses conecta en 24 ms, pero los 6 marcadores salen CONGELADOS (1 valor distinto en 15 lecturas) y la consulta en lote devuelve números basura (p. ej. 9.083e+223). Motive o el servidor del Robotat no estaban transmitiendo poses reales.
- A las 19:38:52 la sesión arrancó con los marcadores vivos. Qué se hizo en el laboratorio entre las 19:35 y las 19:38 no consta.

**Sesión `L2_20261106_193852`** (fin fijado 21:00; 19:38:52–20:48:09), intentos 38–73. L0 del robot 4: OK, offset a −0.3° de la tabla (362 pares).

| Intento | Semilla | Resultado | d_min obstáculo (m) | Nota |
|---|---|---|---|---|
| 38 | 422037 | sin correr | — | el 4 a +82.8 cm de su círculo, tras seis pedidos de colocación |
| 39 | 422038 | sin correr | — | el 4 a +52.4 cm de su círculo y a −49° de la tangente |
| 40 | 422039 | sin correr | — | el 4 a +11.3 cm de su círculo |
| 41 | 422040 | sin correr | — | colocación de agentes: el 8 a 186 cm y el 2 a 19 cm de su blanco ("no avanza") |
| 42 | 422041 | no válida | 0.457 | marcador 1 congelado en (0.27, 2.81) tras retroceder 2.2 s |
| 43 | 422042 | no válida | 0.289 | antigüedad de pose (10 y 20 ticks) mientras el 9 retrocedía desde (0.29, 0.46); antes el 8 se recuperó dos veces en (0.22, 1.83) |
| 44 | 422043 | **INCLUIDA** | 0.333 | |
| 45 | 422044 | no válida | 0.374 | marcador 1 congelado en (0.20, 2.83); antes se recuperó en (0.95, 2.82) |
| 46 | 422045 | **INCLUIDA** | 0.339 | dos reintentos de colocación: el 5 "no avanza" |
| 47 | 422046 | **INCLUIDA** | 0.314 | el 9 se recuperó en (0.96, 2.82) |
| 48 | 422047 | **INCLUIDA** | 0.299 | el 1 se recuperó dos veces en (1.67, 1.07); el 8 retrocedía en (0.89, 2.76) al terminar (decisión 496 de 500) |
| 49 | 422048 | no válida | 0.317 | marcador 1 congelado en (0.94, 2.79) |
| 50 | 422049 | no válida | 0.298 | marcador 9 congelado en (0.97, 2.82) |
| 51 | 422050 | no válida | 0.396 | agente 0 (robot 1) NO SIGUE el comando (0 % en 50 pasos); 8 s después se cayó su enlace |
| 52 | 422051 | **INCLUIDA** | 0.310 | en la guía, enlace del 1 caído a las 20:09:01 (10054) y reabierto a los 84.4 s; el 8 se recuperó en (1.62, 1.14) |
| 53 | 422052 | **INCLUIDA** | 0.336 | |
| 54 | 422053 | **INCLUIDA** | 0.296 | |
| 55 | 422054 | no válida | 0.394 | marcador 8 congelado en (2.86, 2.71); antes el 2 se recuperó dos veces en (0.94, 2.79) |
| 56 | 422055 | **INCLUIDA** | 0.293 | |
| 57 | 422056 | no válida | 0.409 | marcador 9 congelado en (0.25, 2.41) |
| 58 | 422057 | **INCLUIDA** | 0.292 | |
| 59 | 422058 | **INCLUIDA** | 0.330 | |
| 60 | 422059 | no válida | 0.420 | marcador 9 congelado en (0.84, 2.73) |
| 61 | 422060 | **INCLUIDA** | 0.342 | |
| 62 | 422061 | no válida | 0.431 | marcador 9 congelado en (1.42, 2.82) |
| 63 | 422062 | no válida | 0.341 | marcador 2 congelado en (0.92, 2.78) |
| 64 | 422063 | **INCLUIDA** | 0.301 | el 9 se recuperó en (0.96, 2.82) |
| 65 | 422064 | **INCLUIDA** | 0.307 | |
| 66 | 422065 | **INCLUIDA** | 0.422 | el 9 se recuperó en (1.68, 1.08) |
| 67 | 422066 | no válida | 0.330 | marcador 9 congelado en (0.45, 2.82) |
| 68 | 422067 | **INCLUIDA** | 0.328 | |
| 69 | 422068 | **INCLUIDA** | 0.316 | |
| 70 | 422069 | no válida | 0.550 | marcador 9 congelado en (0.20, 2.77) |
| 71 | 422070 | **INCLUIDA** | 0.265 | la menor de la campaña, sin contacto |
| 72 | 422071 | **INCLUIDA** | 0.320 | el 9 se recuperó en (0.96, 2.82) |
| 73 | 422072 | interrumpida | — | Ctrl+C en la guía a las 20:48:09, con el marcador 9 congelado en (0.80, 2.77) |

Coordenadas en el marco del env (m), tomadas de la consola. Todas las paradas por marcador congelado fueron después de retroceder 1.9–2.4 s sin recuperar la captura.

**Resumen de la sesión:**
- 36 intentos: **18 incluidas**; 13 corridas no válidas (11 por marcador congelado, 1 por antigüedad de pose, 1 porque el robot 1 no seguía el comando); 4 sin correr (3 por la colocación del obstáculo y 1 por la de los agentes); 1 interrumpida. Ritmo 18/36 = 50 %.
- 0 contactos, 0 frenos de respaldo y 0 pares a < 0.15 m. d_min al obstáculo entre 0.265 y 0.550 m.
- Consola: 27007 consultas de poses, 0 fallidas, p50 3.3 ms, p95 5.2 ms y máx 34.0 ms; 170 poses rechazadas por inclinación; 1 envío fallido y 1 reconexión (robot 1); 1 frenado por pose vencida; 12841 decisiones; **9890 ticks fuera de plazo**, la cifra más alta por sesión en la campaña (antes 506–3041), en la sesión más larga.
- La red se comportó: un solo reset de enlace en 70 min (el del robot 1), frente a los 16 en 6 min del 04-11. La latencia de poses volvió a la del 23-10 (p95 5.5 ms).

**Congelamientos de marcador (de la consola):**
- Los 11 que pararon tomas fueron en la franja alta del env: 10 con y entre 2.71 y 2.83 (pared +y) y 1 en (0.25, 2.41).
- Un punto se repite: **cerca de (0.95, 2.80)**, 9 veces con 3 robots distintos (1, 9 y 2), dentro de ±3 cm. 3 pararon la toma (49, 50 y 63) y 6 se recuperaron con el retroceso. Apunta a un punto ciego de las cámaras en ese lugar; no está confirmado.
- 4 congelamientos interiores, todos recuperados en 0.2–0.9 s: (1.67, 1.07) dos veces, (1.62, 1.14) y (1.68, 1.08), con los robots 1, 8 y 9. Quedan a unos 10–20 cm de la zona interior del 21-10 (x 1.42–1.55, y 1.21–1.28).

**Declaraciones:**
- No consta un `CHEQUEO OK` antes de esta sesión. Sigue sin haber incluidas que salgan de una sesión con chequeo propio.
- El aviso "NO SE PUDO CONFIRMAR LA DETENCIÓN" del robot 1 (20:09) salió en la guía de la toma 52. Su última orden había sido la detención del fin de la toma 51. Después estuvo un rato SIN POSE y reapareció en otra posición: probablemente lo movieron a mano. Falta confirmarlo con el operador.

**Estado de la campaña:** 73/100 intentos, **30/50 incluidas → veredicto MÍNIMO alcanzado**: intentos 2, 4, 8, 9, 10, 13, 14, 19, 20, 21, 29, 33, 44, 46, 47, 48, 52, 53, 54, 56, 58, 59, 61, 64, 65, 66, 68, 69, 71 y 72. 56 corridas, 0 tomas con contacto. Sigue **abierta**, sin candado; si se sigue, se retoma en el intento 74 (semilla 422073). Ritmo de la campaña: 30/73 = 41 %.

**Para decidir (José):**
- Quedan 27 intentos hasta el tope. Para llegar a la meta de 50 hacen falta 20 de 27 (74 %). Con el ritmo de la campaña (41 %) se esperan unas 11 incluidas más (≈ 41 al tope); con el de hoy (50 %), 13–14 (≈ 43–44). Salvo un ritmo muy superior, el veredicto queda en MÍNIMO por cualquiera de los dos caminos; seguir sólo suma incluidas.
- Hoy se hicieron 36 intentos en 69 min, unos 1.9 min cada uno: agotar el tope es una sesión más de alrededor de 1 h.
- Cerrar ahora es `--cerrar-campana "motivo"` y no tiene vuelta atrás. Después vienen la réplica (PC limpia, `CHEQUEO OK` por lanzamiento, nunca en paralelo con el hardware), el análisis, el verificador y el reporte con el zip. La cobertura sigue sin mirarse hasta el cierre.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261106_preSesionL2.md`.

### `L2_obstaculo_2`, 07-11: respuesta del operador sobre el robot 1 y correcciones a la adenda del 06-11

La adenda anterior se revisó afirmación por afirmación contra la consola pegada, el libro y esta bitácora. Seis revisores, uno por sección; cada discrepancia pasó por tres escépticos y quedó si la sostuvieron al menos dos. Los conteos de reintentos y de congelamientos en las guías los rehíce aparte sobre la consola. Nada de esto cambia el estado de la campaña: 73/100 intentos, 30/50 incluidas (MÍNIMO), 56 corridas, 0 contactos.

**Robot 1 a las 20:09 (respuesta del operador):** "se fue la batería no fue intervención". Reemplaza "probablemente lo movieron a mano. Falta confirmarlo con el operador".
- Con eso, el "NO SIGUE el comando" del intento 51 (0 % de lo comandado en 50 pasos) es la batería: el propio aviso la lista entre las causas posibles. El único 10054 de la sesión (20:09:01) también.
- Lo que muestra la consola:
  - Su orden vigente era la detención: la del fin de la toma 51 y el latido de la guía, que manda parar cada 1 s.
  - No se movió de (2.26, 1.85) hasta 8 refrescos después del corte.
  - Después estuvo 30 refrescos SIN POSE.
  - Su pose reapareció en (2.01, 1.98), (2.33, 1.07) y (2.13, 1.33), y quedó en (2.10, 1.36). Todo eso pasó con el enlace todavía caído: se reabrió a los 84.4 s, tras 41 intentos sin respuesta.
- La consola no explica cómo pasó de (2.26, 1.85) a (2.10, 1.36) sin enlace. Queda como dato.
- La colocación automática de la toma 52 arrancó desde ahí, y la toma fue válida.

**Correcciones a la adenda del 06-11:**

1. **L0 del robot 4.** Es la del 21-10 a las 13:09 (`20261021_130948_L0_resumen.csv`), con la que se creó la campaña. El 06-11 no se corrió L0: la línea "[campaña] L0 del robot 4: L0 OK" es el lanzamiento leyendo esa L0 guardada.
2. **Intento 43.**
   - El aviso de 10 ticks salió en la misma decisión en que el 9 empezó a retroceder desde (0.29, 0.46). El de 20 ticks salió en la siguiente, y terminó en el frenado del 9 por pose vencida: el único de la sesión.
   - Por cómo funcionan los dos avisos, el 9 se quedó sin poses válidas; no fue un marcador que Motive mantuviera congelado, porque ese sigue mandando filas válidas. En la guía de la toma 44 el 9 aparece SIN POSE.
   - Las dos recuperaciones del 8 fueron en (0.22, 1.83) y (0.22, 1.84), a los 1.7 y 1.6 s.
3. **Intento 48.**
   - Las recuperaciones del 1 fueron en (1.67, 1.07) y (1.67, 1.06).
   - El 8 no se recuperó: terminó la toma congelado en (0.89, 2.76) y siguió así en la guía de la 49, donde frenó dos veces la colocación. La segunda vez, junto con el 9 congelado en (2.81, 2.32).
4. **Intento 51.** La causa es la batería del robot 1 (ver arriba).
5. **Reintentos de colocación.** Las notas de la tabla sólo los anotaron en el 41 y el 46. No gastan el intento. En total hubo 20 en 14 tomas:

   | Toma | 41 | 43 | 44 | 46 | 48 | 49 | 50 | 51 | 56 | 61 | 63 | 65 | 72 | 73 |
   |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
   | Reintentos | 1 | 1 | 1 | 2 | 1 | 2 | 1 | 1 | 1 | 1 | 1 | 3 | 3 | 1 |

   - Causas: robots que "no avanza" en la colocación automática (30 avisos, de los cinco robots); marcadores congelados o sin pose (44, 48, 49 y 73); y distancias mínimas al obstáculo o a una pared.
   - **Por qué se gastó el intento 41:** los pedidos de colocar al 4 a mano consumen vueltas del mismo ciclo de 6 que los reintentos de los agentes (el bucle de `REINTENTOS_COLOCACION` en `demo_obstaculo_movil.py`).
     - En el 41 hubo 4 pedidos del obstáculo, así que el primer reintento de los agentes ya salió como "reintento 5/5" y el siguiente fallo gastó el intento.
     - En el 38, el 39 y el 40 los 6 pedidos fueron del obstáculo.
     - Para el operador: dejar bien al 4 en el primer pedido le conserva los reintentos a los agentes.
6. **Ticks fuera de plazo.**
   - "(antes 506–3041)" está mal: el 506 es de la campaña descartada `L2_obstaculo` (16-10). En `L2_obstaculo_2` las cifras anteriores son 1540, 3041, 1088 y 2046, así que el rango es 1088–3041. Que los 9890 del 06-11 sean el total más alto sigue siendo cierto.
   - Por decisión no lo es: 9890/12841 = 0.77 el 06-11, contra 1540/1703 = 0.90 y 3041/3752 = 0.81 en las dos sesiones del 21-10 (sus consolas están en el zip del reporte del 22-10). Del 23-10 y del 04-11 no hay conteo de decisiones registrado.
   - El total alto viene de la duración de la sesión, no de un lazo peor.
7. **Red.**
   - "un solo reset de enlace en 70 min (el del robot 1)" pasa a: **ningún reset atribuible a la red en 69 min**. El único 10054 fue la batería del 1.
   - La comparación con el 04-11 tiene que contar los seis robots: allí hubo **19** resets en 6 min (16 de los agentes y 3 del robot 4), no 16.
8. **Congelamientos.**
   - **Retrocesos.** En las tomas 42–72 hubo 25:
     - 11 terminaron en parada por marcador congelado;
     - 12 se recuperaron;
     - 2 quedaron sin resolver: el del 9 en (0.29, 0.46), que acabó en la parada por antigüedad de la 43, y el del 8 en (0.89, 2.76), cortado por el fin de la 48.
     - De los recuperados, la adenda no listó los dos del 8 en la 43, junto a la pared −x.
   - **Hay un segundo punto que se repite:** la esquina −x+y, con x entre 0.20 y 0.27 e y entre 2.77 y 2.83.
     - Ahí pararon 3 tomas: la 42 y la 45 con el robot 1, y la 70 con el 9.
     - Además hubo 2 congelamientos que sólo se vieron en las guías: el 9 en (0.27, 2.80) antes de la 48 y el 1 en (0.21, 2.83) antes de la 64.
     - "Un punto se repite" pasa a "**se repiten dos puntos**".
   - **Punto de (0.95, 2.80).** A los 9 de las tomas se suma el 1 congelado en (0.95, 2.82) en la guía de la 53, donde había terminado la 52: son 10 con las guías.
   - **Guías.** La sección contó sólo lo que pasó durante las tomas y el congelamiento de la 73. En las guías, los congelamientos nuevos fueron 7; el resto repite el marcador y la posición que habían parado la toma anterior:

     | Antes de la toma | 41 | 44 | 48 | 49 | 53 | 64 | 73 |
     |---|---|---|---|---|---|---|---|
     | Robot | 1 | 8 | 9 | 9 | 1 | 1 | 9 |
     | Posición | (0.60, 1.72) | (0.33, 2.06) | (0.27, 2.80) | (2.81, 2.32) | (0.95, 2.82) | (0.21, 2.83) | (0.80, 2.77) |

9. **Se revisó y queda igual:** "Sigue sin haber incluidas que salgan de una sesión con chequeo propio". Es el criterio del reporte del 22-10 (§9): la 2 y la 4 salen de la sesión de las 13:34 del 21-10, que tuvo el `CHEQUEO OK` de las 13:32:16 compartido, no uno propio.

**Sigue pendiente del operador:**
- qué se hizo en el laboratorio entre las 19:35 y las 19:38 del 06-11, cuando los marcadores volvieron;
- si hubo un `CHEQUEO OK` antes de la sesión de las 19:38.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261107_preCorreccion.md`.

### `L2_obstaculo_2`, 07-11: respuestas del operador sobre el arranque del 06-11

**Qué se hizo entre las 19:35 y las 19:38:** "solo corrí el motive".
- Motive no estaba corriendo. Mientras tanto, el servidor del Robotat aceptaba la conexión (24 ms) y devolvía los 6 marcadores congelados con valores basura, como mostró la verificación de las 19:34:58.
- Con Motive corriendo, la sesión de las 19:38:52 arrancó con los marcadores vivos.
- **Lección:** sin Motive, el servidor no da ningún aviso. En modo campaña el lanzamiento se cierra en unos 1 s con "fin de la sesión" (el FALLO silencioso), y no gasta intentos. Antes de lanzar hay que comprobar que Motive esté abierto y transmitiendo.

**Chequeo de la PC antes de la sesión de las 19:38:** "si", dio `CHEQUEO OK`.
- La salida no se pegó, así que no consta la hora ni la lista de procesos.
- Esto corrige "No consta un `CHEQUEO OK` antes de esta sesión" de la adenda del 06-11, y cierra el pendiente de la adenda anterior. El último pendiente también queda resuelto con la respuesta sobre Motive.

**Efecto en la declaración de chequeos.** Las 30 incluidas quedan así:
- **18** (intentos 44–72, del 06-11): de una sesión con `CHEQUEO OK` declarado por el operador, sin la salida pegada.
- **2** (intentos 2 y 4, del 21-10): de la sesión de las 13:34, con el OK de las 13:32:16 compartido.
- **10** (intentos 8, 9, 10, 13, 14, 19, 20, 21, 29 y 33): de sesiones sin chequeo registrado.

"Sigue sin haber incluidas que salgan de una sesión con chequeo propio" sólo vale contando las salidas pegadas, que es el criterio del reporte del 22-10. Con la declaración del operador, 18 sí lo tienen. Cómo contarlas en el reporte lo decide José.

**Para las próximas sesiones:** pegar aquí la salida del chequeo, como pide el protocolo.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261107_preRespuestas.md`.

### `L2_obstaculo_2`, 07-11: respuestas del operador a las preguntas del reporte del 07-11

Las preguntas salieron de `tesis/REPORTE_2026-11-07_campana_L2.md` (§9.5). Respuestas textuales del operador:

- **El "timed out" del primer lanzamiento del 06-11 (19:29:46):** "era que no estaba conectado al robotat". La laptop todavía no estaba conectada al Robotat. Del "timed out" del primer lanzamiento del 23-10 y del 04-11 no se preguntó; tienen la misma firma, pero no está confirmado.
- **Intento 24 (23-10), "ABORTO POR EL OBSTÁCULO: el obstáculo NO FRENA":** "si": el operador movió el 4 a mano durante la colocación. Confirma lo probable de la adenda del 23-10. El aborto lo causó la mano, no el robot.
- **04-11, robot 1 sin detención confirmada durante el corte:** "si, se lo quite, pero lo que pasó es que el server estaba fallando". El operador le cortó la alimentación al robot 1. Según él, lo que fallaba era el servidor. Queda como su lectura; la adenda del 04-11 apuntaba a la red del laboratorio, y ninguna de las dos está confirmada con el laboratorio.
- **06-11, robot 1 a las 20:09:** "le cambié la batería, fué cuando se quedó sin ella". Se le acabó la batería, y el operador se la cambió.
  - Eso explica el cambio de pose con el enlace caído: el robot se levantó para cambiarle la batería.
  - También explica que después anduviera hasta el final.
  - La respuesta anterior, "no fue intervención", se refería a la causa del corte (la batería), no a lo que pasó después.
  - Con esto queda resuelta la contradicción que anotaron la primera adenda del 07-11 y el reporte del 07-11.
- **06-11, `CHEQUEO OK` y app de Claude:** a la pregunta "¿a qué hora te dio el `CHEQUEO OK`, y cerraste la app de Claude antes de lanzar a las 19:38?", el operador contestó "si".
  - Se lee como que cerró la app de Claude antes de lanzar.
  - La hora del `CHEQUEO OK` sigue sin constar.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261107_preRespuestas2.md`.

### `L2_obstaculo_2`, 09-11: revisión del reporte del 07-11

- **La pose (2.10, 1.36) del robot 1 el 06-11 sí se leyó con el enlace caído**, como dice la primera adenda del 07-11.
  - La versión del 07-11 de `tesis/REPORTE_2026-11-07_campana_L2.md` la daba como leída después de la reconexión, y lo declaraba como corrección a esa adenda. La corrección se retira; la adenda estaba bien.
  - En la consola, la tabla con (2.10, 1.36) sale justo después de "RECONECTADO (reconexión n.º 1) a los 84.4 s".
  - Pero en cada refresco de la guía (`latir`, dentro de `_esperar_reposicionamiento` en `sesion_robotat.py`) el orden es: se leen las poses; `detener_todo` frena a los robots, y ahí `_reconectar` reabrió el enlace e imprimió "RECONECTADO"; recién entonces se imprime la tabla con las poses leídas antes.
  - **Para leer las guías en la consola:** la tabla que sigue a un "RECONECTADO" es de antes de la reconexión.
- El resto de la revisión quedó en la versión del 09-11 del reporte: el corte del 04-11 frente a "el server estaba fallando" (los enlaces de los robots no pasan por el servidor de poses), cuándo pudo correrse el `CHEQUEO OK` del 06-11, la laptop conectada a la red del Robotat en la lista de antes de lanzar, y Python 3.13 para el verificador.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261109_preRevision.md`.

### `L2_obstaculo_2`, 13-11: tercera revisión del reporte de la campaña (versión 13-11) y la primera corrida de `verificar_red.py` del 06-11

La versión 09-11 de `tesis/REPORTE_2026-11-07_campana_L2.md` pasó por una tercera ronda: 8 revisores, 24 hallazgos distintos, los 24 sostenidos por al menos 2 de 3 escépticos. Se aplicaron en la versión 13-11 del reporte, de su verificador y de su zip.

**Lo que cambia sobre lo que decía esta bitácora o el reporte anterior:**
- **La primera corrida de `verificar_red.py` del 06-11 sí dejó salida.** El reporte decía que no.
  - Su archivo de salida se creó a las 19:22:44 y se escribió por última vez a las 19:23:26 (1014 bytes). Ni el servidor de poses ni ninguno de los 6 robots abrió conexión (TimeoutError); el servidor y los robots 1, 5 y 8 perdieron el 100 % de los paquetes del ping; la lectura de marcadores falló.
  - Es coherente con la respuesta del operador del 07-11 ("era que no estaba conectado al robotat"): a esa hora la laptop no alcanzaba la red del Robotat. No consta hasta cuándo.
  - Va en el paquete como `derivados/verificar_red_20261106_1922_salida.txt`, copia literal. En `diagnostico_solo_lectura_20261106.txt` esa corrida figura a las 19:33:47 porque ahí está la hora en que quedó registrada como llamada interrumpida, no la de su lanzamiento.
- **La app de Claude el 06-11.** Se había cerrado para el chequeo de las 19:21:17; después se volvió a usar (el operador le pegó la salida de ese chequeo, y de ella salió la corrida de `verificar_red.py`). Los resultados de comandos del derivado van de las 19:33:47 (el aviso de la llamada cortada porque la sesión de la app terminó) a las 19:34:58; son horas de resultados, no de abrir y cerrar la app. El operador contestó "si" a la pregunta doble de si dio el `CHEQUEO OK` y cerró la app antes de lanzar; no dio ninguna de las dos horas.
- **El `CHEQUEO OK` declarado del 06-11 sólo cubriría la sesión de las 19:38:52 si se corrió después de cerrar la app por última vez.** Un OK anterior a ese cierre no cubre el uso de la app, porque el chequeo detecta el servidor de Inventor de la app. Si fue antes de las 19:33:31, quedó compartido con uno a cuatro lanzamientos que no arrancaron, entre 321 y 1055 s antes de abrir la sesión. Esto corrige "Con la declaración del operador, 18 sí lo tienen" (chequeo propio) de la segunda adenda del 07-11, y la ventana que daba la versión 09-11 del reporte.
- **Las "14 pérdidas seguidas" de la conexión con el servidor de poses del 04-11** (12:40) son 14 líneas "[poses] conexión perdida" seguidas, sin hora: consultas fallidas sobre la conexión perdida en el primer corte, que la sesión no reabre (un solo "[poses] conectado", al arrancar). No son caídas nuevas del servidor. La consola trae 21 de esas líneas en toda la sesión.
- **La pausa del intento 24 (23-10):** si vale la respuesta del operador (movió el 4 a mano), la causa del aborto era conocida; el desvío de pausa con causa sin resolver es sólo el del 36. Lo que se declara del 24 es el movimiento del 4 durante la colocación.
- **Protocolo del paquete:** es el que regía las sesiones del período. El 09-11 a las 01:36, ya armado el primer zip, se agregaron al chequeo de la PC los procesos del Exp R.

**Pendiente con el operador** (consta en el §10 del reporte): la hora del `CHEQUEO OK` del 06-11 y si lo corrió después de cerrar la app de Claude; y si el "timed out" del primer lanzamiento del 23-10 y del 04-11 también fue la laptop sin conectar al Robotat (no se le preguntó).

**Verificador:** 338 cifras (316 en la versión anterior). Sólo corre con Python 3.13 y escribe su salida en UTF-8.

**Respaldo:** antes de esta adenda, `BITACORA_TECNICA_respaldo_20261113_preRonda3.md`.
