"""Comprobación de sólo lectura: ¿la réplica de L2_obstaculo_2 está completa? (misma lógica que el script)."""
import json, sys
from pathlib import Path
COORD = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
sys.dont_write_bytecode = True; sys.path.insert(0, str(COORD))
import replica_con_obstaculo as R
salida = R.DIR_DEMO / "replica_campana" / "L2_obstaculo_2"
tomas = R.cargar_campana(R.DIR_DEMO, "L2_obstaculo_2", None)
hechas = R.claves_hechas(salida)
normales, supl = R.completitud(tomas, hechas, R.CONDICIONES_ORDEN)
print("tomas de la campaña:", len(tomas), "| condiciones:", len(R.CONDICIONES_ORDEN), "| corridas hechas:", len(hechas))
print("grupos con la pasada normal incompleta:", len(normales), "| grupos con 0 válidas sin suplementaria:", len(supl))
print("→ exit code que da _informar_completitud:", 3 if (normales or supl) else 0)
sha_ahora, _ = R.sha256_de_pila()
pila = json.loads(next(salida.glob("*_replica_pila.json")).read_text(encoding="utf-8"))
print("sha256 de la pila: la de la réplica == la de hoy:", pila["sha256_pila"] == sha_ahora, "|", sha_ahora[:16] + "…")
try:
    R.validar_hechas(hechas, tomas, sha_ahora); print("validar_hechas: OK")
except Exception as e:
    print("validar_hechas:", type(e).__name__, e)
