"""
verificar_cifras_cierre_campana_l2_20261114.py
==============================================
Recalcula desde los crudos del paquete, o coteja contra el archivo de donde
sale, las cifras del reporte `REPORTE_2026-11-14_cierre_campana_L2.md`, y
comprueba que el texto las diga IGUAL: cada cifra se busca literal en el
reporte y se compara con lo recalculado. Lo que no cubre está en el §13 del
reporte. Una línea por cifra (SÍ / NO); código 1 si alguna no coincide.

    python scripts/verificar_cifras_cierre_campana_l2_20261114.py <raíz del paquete> <reporte.md>

No importa código del proyecto ni paquetes externos (csv, json, hashlib, ast,
re, math, statistics). Los cuantiles t del IC95 son los de la distribución t de
Student con 11, 18, 25, 29 y 49 grados de libertad, fijos en el script. Los p
de Wilcoxon y de la t, y el bootstrap, no se recalculan acá: se cotejan contra
`analisis.json`, que recalcula `verificar_campana_l2.py` (independiente).

Hace falta Python 3.13: la huella sin calibración de `config_robotat.py` es un
sha256 de `ast.dump`, que cambió en 3.13 (ya no escribe las listas vacías). Con
3.12 daría otra huella sin que el archivo haya cambiado, y 3.14 y posteriores
no se probaron (`ast.dump` puede volver a cambiar): el script sólo corre con
3.13 y con otra versión se niega. La salida se escribe en UTF-8.

Autor: José — Tesis Mecatrónica UVG.
"""

from __future__ import annotations

import ast
import csv
import hashlib
import json
import math
import re
import statistics as st
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

CIFRAS: List[Tuple[str, str, str, bool]] = []   # (descripción, reportado, calculado, en el texto)
TEXTO = ""
RAIZ = Path(".")
TCRIT = {11: 2.200985160, 18: 2.100922040, 25: 2.059538553, 29: 2.045229642, 49: 2.009575237}
Z = 1.959963985
ANALISIS = "L2_obstaculo_2_20261114_101647"


# ── utilidades ───────────────────────────────────────────────────────────
def leer(ruta: Path) -> List[Dict[str, str]]:
    with open(ruta, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def texto_de(ruta: Path) -> str:
    return ruta.read_bytes().decode("utf-8")


def sg(x: float, d: int = 4) -> str:
    """Con el signo, y el menos tipográfico del reporte."""
    return f"{x:+.{d}f}".replace("-", "−")


def mn(x: float, d: int = 4) -> str:
    return f"{x:.{d}f}".replace("-", "−")


def cifra(desc: str, reportado: str, calculado: Any, en_texto: bool = True) -> None:
    CIFRAS.append((desc, reportado, str(calculado), en_texto))


def fila(desc: str, esperado: str) -> None:
    """Una línea completa del reporte, igual a `esperado`."""
    ok = any(l.strip() == esperado for l in TEXTO.splitlines())
    CIFRAS.append((desc, esperado, esperado if ok else "FILA AUSENTE O DISTINTA", False))


def todas(desc: str, patron: str, esperado: str) -> None:
    """Todas las apariciones de `patron` en el reporte tienen que ser `esperado`."""
    hall = re.findall(patron, TEXTO)
    ok = bool(hall) and all(h == esperado for h in hall)
    CIFRAS.append((desc + f" ({len(hall)} apariciones)", esperado, esperado if ok else str(hall), False))


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest() if ruta.is_file() else "FALTA"


def ic_t(v: Sequence[float]) -> Dict[str, Any]:
    n = len(v)
    m = st.mean(v)
    sd = st.stdev(v)
    sa = TCRIT[n - 1] * sd / math.sqrt(n)
    return {"n": n, "m": m, "sd": sd, "lo": m - sa, "hi": m + sa, "sa": sa, "med": st.median(v),
            "pos": sum(x > 0 for x in v), "neg": sum(x < 0 for x in v)}


def cp0(n: int) -> float:
    """Límite superior del IC95 de Clopper–Pearson con 0 eventos en n."""
    return 1 - 0.025 ** (1 / n)


def wilson(k: int, n: int) -> Tuple[float, float]:
    p = k / n
    c = (p + Z * Z / (2 * n)) / (1 + Z * Z / n)
    h = Z * math.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / (1 + Z * Z / n)
    return c - h, c + h


def num(x: Any) -> Any:
    try:
        return float(x) if x not in ("", None) else None
    except ValueError:
        return None


# ── datos ────────────────────────────────────────────────────────────────
class D:
    pass


def cargar() -> None:
    coord = RAIZ / "primerafase_webots" / "controllers" / "coordinador_enjambre"
    res = coord / "resultados_demo_obstaculo"
    D.coord, D.res = coord, res
    D.lib_dir = res / "campanas" / "L2_obstaculo_2"
    D.anal_dir = res / "analisis_campana" / ANALISIS
    D.rep_dir = res / "replica_campana" / "L2_obstaculo_2"
    D.filas = leer(D.lib_dir / "libro.csv")
    D.cab = json.loads(texto_de(D.lib_dir / "campana.json"))
    D.resultados = sorted((f for f in D.filas if f["tipo"] == "resultado"), key=lambda f: int(f["intento"]))
    D.incl = [f for f in D.resultados if f["incluida"] == "1"]
    D.corr = [f for f in D.resultados if f["estado"] == "corrida"]
    D.js = json.loads(texto_de(D.anal_dir / "analisis.json"))
    D.hw = {}
    for ruta in sorted(res.glob("*_L2_tomas.csv")):
        if ruta.stat().st_size:
            for f in leer(ruta):
                if f.get("intento_campana"):
                    D.hw[(f["id_sesion"], int(f["intento_campana"]))] = f
    D.rep = leer(next(D.rep_dir.glob("*_replica_tomas.csv")))
    D.w = texto_de(RAIZ / "derivados" / "condiciones_replica_windows_20261114.txt")


def hw_de(f: Dict[str, str]) -> Dict[str, str]:
    return D.hw[(f["id_sesion"], int(f["intento"]))]


def grupo(k: int, cond: str, tau: float) -> List[Dict[str, str]]:
    return [r for r in D.rep if int(r["intento_campana"]) == k and r["condicion"] == cond
            and abs(float(r["tau_s"]) - tau) < 1e-9 and r["valido"] == "1"]


def media_rep(k: int, cond: str, tau: float, col: str) -> Any:
    v = [float(r[col]) for r in grupo(k, cond, tau) if r[col] not in ("", None)]
    return st.mean(v) if v else None


def min_rep(k: int, cond: str, tau: float, col: str) -> Any:
    v = [float(r[col]) for r in grupo(k, cond, tau) if r[col] not in ("", None)]
    return min(v) if v else None


# ── 1. libro y resumen ───────────────────────────────────────────────────
def libro() -> None:
    k = len(D.resultados)
    incl, corr = len(D.incl), len(D.corr)
    cifra("intentos, corridas, incluidas", "73 de 100 intentos, 56 corridas y 30 de 50 incluidas",
          f"{k} de {D.cab['tope_intentos']} intentos, {corr} corridas y {incl} de {D.cab['meta']} incluidas")
    lo, hi = wilson(incl, k)
    cifra("ritmo y Wilson", "30/73 = 41 %, con IC95 de Wilson [0.305, 0.526]",
          f"{incl}/{k} = {100 * incl / k:.0f} %, con IC95 de Wilson [{lo:.3f}, {hi:.3f}]")
    for dia, (a, b) in {"21-10": (1, 17), "23-10": (18, 25), "04-11": (26, 37), "06-11": (38, 73)}.items():
        rr = [f for f in D.resultados if a <= int(f["intento"]) <= b]
        fila(f"por día {dia}", f"| {dia} | {a}–{b} | {sum(f['estado'] == 'corrida' for f in rr)} | "
             f"{sum(f['incluida'] == '1' for f in rr)} | {100 * sum(f['incluida'] == '1' for f in rr) / len(rr):.0f} % |")
    fila("por día: campaña", f"| **campaña** | **1–{k}** | **{corr}** | **{incl}** | **{100 * incl / k:.0f} %** |")
    cierre = next(f for f in D.filas if f["tipo"] == "cierre_campana")
    t = datetime.fromisoformat(cierre["fecha"])
    cifra("cierre: fecha", "Cerrada el 14-11 a las 00:14:20", f"Cerrada el {t:%d-%m} a las {t:%H:%M:%S}")
    cifra("cierre: motivo", "Fin del tiempo disponible: no hay más turnos en el Robotat desde el 09-11. 73/100 intentos, 30 incluidas (MÍNIMO).",
          cierre["motivo"])
    cifra("libro: filas", "El libro quedó con 187 filas, una `cierre_campana` nueva, y las 73 reservas y los 73 resultados intactos",
          f"El libro quedó con {len(D.filas)} filas, una `cierre_campana` nueva, y las {sum(f['tipo'] == 'reserva' for f in D.filas)} reservas "
          f"y los {len(D.resultados)} resultados intactos")
    ap, ci = sum(f["tipo"] == "apertura" for f in D.filas), sum(f["tipo"] == "cierre_sesion" for f in D.filas)
    cifra("libro: sesiones", "(17 aperturas y 17 cierres)", f"({ap} aperturas y {ci} cierres)")
    no = Counter("no válida" if f["estado"] == "corrida" else {"sin_correr": "sin correr", "interrumpida": "interrumpida",
                 "parada_colocacion": "parada en la colocación"}[f["estado"]] for f in D.resultados if f["incluida"] != "1")
    cifra("no incluidos", "26 no válidas, 8 sin correr, 5 interrumpidas y 4 paradas en la colocación",
          f"{no['no válida']} no válidas, {no['sin correr']} sin correr, {no['interrumpida']} interrumpidas y {no['parada en la colocación']} paradas en la colocación")
    cifra("meta de 50", "Llegar a 50 habría pedido 20 de los 27 intentos que quedaban",
          f"Llegar a 50 habría pedido {D.cab['meta'] - incl} de los {D.cab['tope_intentos'] - k} intentos que quedaban")
    cont = sum(f["contacto"] == "1" for f in D.corr)
    fr = sum(int(float(f["frenos"] or 0)) > 0 for f in D.corr)
    cifra("contactos (resumen)", "0 tomas con contacto (< 0.15 m) en las 56 corridas, IC95 de Clopper–Pearson [0.000, 0.064]",
          f"{cont} tomas con contacto (< 0.15 m) en las {corr} corridas, IC95 de Clopper–Pearson [0.000, {cp0(corr):.3f}]" if cont == 0 else "HAY CONTACTOS")
    todas("frenos de respaldo en las corridas", r"\d+ frenos de respaldo en las \d+ corridas", f"{fr} frenos de respaldo en las {corr} corridas")
    cifra("criterio de seguridad", "0 tomas corridas con contacto (< 0.15 m, con el obstáculo o entre agentes)",
          f"{D.js['criterio_de_cierre']['n_tomas_con_contacto']} tomas corridas con contacto (< 0.15 m, con el obstáculo o entre agentes)")
    # d_min de las corridas.
    dm = [(float(hw_de(f)["d_min_obst_medida"]), int(f["intento"])) for f in D.corr if hw_de(f)["d_min_obst_medida"] not in ("", None)]
    dmin = min(dm)
    D.dmstats = (dmin[0], st.median(x for x, _ in dm), max(dm)[0])
    cifra("d_min hw", "mínimo 0.2648 m (intento 71), mediana 0.3329 m, máximo 0.6415 m",
          f"mínimo {dmin[0]:.4f} m (intento {dmin[1]}), mediana {st.median(x for x, _ in dm):.4f} m, máximo {max(dm)[0]:.4f} m")


# ── 2. principal, sensibilidades, seguridad, costo ───────────────────────
def principal() -> None:
    ks = [int(f["intento"]) for f in D.incl]
    hw = {int(f["intento"]): float(hw_de(f)["cobertura_aoi"]) for f in D.incl}
    rc = {k: media_rep(k, "con_obstaculo", 0.0, "cobertura_aoi") for k in ks}
    rs = {k: media_rep(k, "sin_obstaculo", 0.0, "cobertura_aoi") for k in ks}
    r45 = {k: media_rep(k, "con_obstaculo", 0.45, "cobertura_aoi") for k in ks}
    assert all(v is not None for v in rc.values()) and all(v is not None for v in rs.values())
    d = {k: hw[k] - rc[k] for k in ks}
    H, Rr, Dd = ic_t([hw[k] for k in ks]), ic_t([rc[k] for k in ks]), ic_t(list(d.values()))
    D.d, D.hw_cob, D.rc, D.rs, D.ks = d, hw, rc, rs, ks
    D.H, D.Rr, D.Dd = H, Rr, Dd
    fila("principal: hw", f"| hw | {H['n']} | {H['m']:.4f} | {H['sd']:.4f} | [{H['lo']:.4f}, {H['hi']:.4f}] |")
    fila("principal: réplica", f"| réplica (con obstáculo, τ = 0) | {Rr['n']} | {Rr['m']:.4f} | {Rr['sd']:.4f} | [{Rr['lo']:.4f}, {Rr['hi']:.4f}] |")
    fila("principal: d", f"| **d = hw − réplica** | {Dd['n']} | **{mn(Dd['m'])}** | {Dd['sd']:.4f} | **[{mn(Dd['lo'])}, {sg(Dd['hi'])}]** |")
    todas("conclusión del principal", r"hw − réplica = [−+]\d\.\d{4}, IC95 \[[^\]]+\] \(n = \d+\)",
          f"hw − réplica = {mn(Dd['m'])}, IC95 [{mn(Dd['lo'])}, {sg(Dd['hi'])}] (n = {Dd['n']})")
    cotas = re.findall(r"brecha\\?\| ≤ (\d\.\d{4})", TEXTO)
    esp_cota = f"{max(abs(Dd['lo']), abs(Dd['hi'])):.4f}"
    cifra(f"cota de la brecha en todo el texto ({len(cotas)} apariciones)", f"todas {esp_cota}",
          f"todas {esp_cota}" if cotas and all(c == esp_cota for c in cotas) else f"distintas: {cotas}", False)
    cifra("medias (resumen)", "La media del hw (0.3348) queda por debajo de la de la réplica (0.3479); 20 de 30 diferencias son negativas",
          f"La media del hw ({H['m']:.4f}) queda por debajo de la de la réplica ({Rr['m']:.4f}); {Dd['neg']} de {Dd['n']} diferencias son negativas"
          if H["m"] < Rr["m"] else "HW NO ES MENOR")
    cifra("mediana y signos", "Mediana de d: −0.0104. Positivas 10, negativas 20",
          f"Mediana de d: {mn(Dd['med'])}. Positivas {Dd['pos']}, negativas {Dd['neg']}")
    p = D.js["principal"]
    cifra("referencias que no deciden", "Wilcoxon de rangos con signo p = 0.0368; bootstrap percentil de la media [−0.0284, +0.0023]; p de la t, 0.1047",
          f"Wilcoxon de rangos con signo p = {p['wilcoxon_p']:.4f}; bootstrap percentil de la media [{mn(p['bootstrap_ic95'][0])}, {sg(p['bootstrap_ic95'][1])}]; p de la t, {p['t_p']:.4f}")
    cifra("referencias (resumen)", "el Wilcoxon da p = 0.0368 y el bootstrap, [−0.0284, +0.0023]. El IC t contiene el 0 (p = 0.1047)",
          f"el Wilcoxon da p = {p['wilcoxon_p']:.4f} y el bootstrap, [{mn(p['bootstrap_ic95'][0])}, {sg(p['bootstrap_ic95'][1])}]. El IC t contiene el 0 (p = {p['t_p']:.4f})"
          if Dd["lo"] < 0 < Dd["hi"] else "EL IC NO CONTIENE EL 0")
    cifra("semiancho", "Semiancho observado ±0.0161, contra ±0.016 esperado en el plan con n = 30", f"Semiancho observado ±{Dd['sa']:.4f}, contra ±0.016 esperado en el plan con n = {Dd['n']}")
    sd_rep = [st.stdev([float(r["cobertura_aoi"]) for r in grupo(k, "con_obstaculo", 0.0)]) for k in ks if len(grupo(k, "con_obstaculo", 0.0)) >= 2]
    cifra("ruido entre repeticiones", "mediana 0.0011, máximo 0.0331", f"mediana {st.median(sd_rep):.4f}, máximo {max(sd_rep):.4f}")
    # El análisis y el recálculo coinciden en lo básico.
    cifra("análisis = recálculo (d)", "igual", "igual" if abs(p["media"] - Dd["m"]) < 1e-9 and abs(p["sd"] - Dd["sd"]) < 1e-9 else f"{p['media']} vs {Dd['m']}", False)
    # Sensibilidades.
    exc_B = {int(f["intento"]) for f in D.incl if hw_de(f)["retrocesos_detalle"].strip()}
    exc_C = {int(f["intento"]) for f in D.incl if float(hw_de(f)["frenos"] or 0) > 0}
    exc_D = {int(f["intento"]) for f in D.incl if num(hw_de(f)["decisiones_previas"]) is not None and num(hw_de(f)["decisiones_previas"]) < 50}
    pares = leer(D.anal_dir / "pares.csv")
    exc_A = {int(f["intento"]) for f in pares if f["fuera_de_soporte"].strip().lower() in ("1", "true")}
    sens = D.js["sensibilidades"]
    for etiqueta, clave, exc in (("A. sin arranques fuera del soporte", "A_sin_fuera_de_soporte", exc_A), ("B. sin tomas con retroceso", "B_sin_retroceso", exc_B),
                                 ("C. sin tomas con freno de respaldo", "C_sin_freno", exc_C), ("D. sin tomas con rampa", "D_sin_rampa", exc_D)):
        S = ic_t([d[k] for k in ks if k not in exc])
        fila(f"sensibilidad {clave}", f"| {etiqueta} | {S['n']} | {mn(S['m'])} | [{mn(S['lo'])}, {sg(S['hi'])}] | {sens[clave]['wilcoxon_p']:.4f} |")
    E = ic_t([hw[k] - r45[k] for k in ks])
    fila("sensibilidad E", f"| E. réplica con τ = 0.45 s | {E['n']} | {mn(E['m'])} | [{mn(E['lo'])}, {sg(E['hi'])}] | {sens['E_replica_tau_045']['wilcoxon_p']:.4f} |")
    cifra("tomas con retroceso y con rampa", "B quita las 11 tomas con retroceso; D quita las 4 con rampa (intentos 2, 8, 19 y 29)",
          f"B quita las {len(exc_B)} tomas con retroceso; D quita las {len(exc_D)} con rampa (intentos {', '.join(map(str, sorted(exc_D)[:-1]))} y {max(exc_D)})")
    cifra("A y C como el principal", "A y C dan lo mismo que el principal: ninguna incluida tiene arranque fuera del soporte ni freno de respaldo",
          "A y C dan lo mismo que el principal: ninguna incluida tiene arranque fuera del soporte ni freno de respaldo" if not exc_A and not exc_C else "A O C QUITAN TOMAS")
    cifra("ninguna sensibilidad cambia", "todos los IC95 contienen el 0",
          "todos los IC95 contienen el 0" if all(ic_t([d[k] for k in ks if k not in e])["lo"] < 0 < ic_t([d[k] for k in ks if k not in e])["hi"] for e in (exc_A, exc_B, exc_C, exc_D))
          and E["lo"] < 0 < E["hi"] else "ALGUNO NO CONTIENE EL 0")
    # Seguridad pareada.
    dh = {int(f["intento"]): float(hw_de(f)["d_min_obst_medida"]) for f in D.incl}
    dm_med = {k: media_rep(k, "con_obstaculo", 0.0, "d_min_obst_medida") for k in ks}
    dm_min = {k: min_rep(k, "con_obstaculo", 0.0, "d_min_obst_medida") for k in ks}
    A1 = ic_t([dh[k] - dm_med[k] for k in ks]); A2 = ic_t([dh[k] - dm_min[k] for k in ks])
    D.A1 = A1
    p1, p2 = D.js["seguridad"]["d_min_hw_menos_replica_media"], D.js["seguridad"]["d_min_hw_menos_replica_minimo"]
    cifra("d_min pareada: media de reps", "−0.0069 m, IC95 [−0.0240, +0.0103], mediana +0.0001, positivas 15 de 30, Wilcoxon p = 0.7971",
          f"{mn(A1['m'])} m, IC95 [{mn(A1['lo'])}, {sg(A1['hi'])}], mediana {sg(A1['med'])}, positivas {A1['pos']} de {A1['n']}, Wilcoxon p = {p1['wilcoxon_p']:.4f}")
    cifra("d_min pareada: mínimo de reps", "−0.0037 m, IC95 [−0.0214, +0.0139], mediana +0.0010, positivas 16 de 30, p = 0.7343",
          f"{mn(A2['m'])} m, IC95 [{mn(A2['lo'])}, {sg(A2['hi'])}], mediana {sg(A2['med'])}, positivas {A2['pos']} de {A2['n']}, p = {p2['wilcoxon_p']:.4f}")
    cifra("réplica bajo 0.15 m", "0 de 30 por la media y 0 de 30 por el mínimo, IC95 [0.000, 0.116]",
          f"{sum(v < 0.15 for v in dm_med.values())} de {len(ks)} por la media y {sum(v < 0.15 for v in dm_min.values())} de {len(ks)} por el mínimo, IC95 [0.000, {cp0(len(ks)):.3f}]")
    fs = sum(float(r["frenos_sombra"] or 0) for r in D.rep)
    cifra("frenos en sombra de la réplica", "frenos en sombra de la réplica: 0", f"frenos en sombra de la réplica: {fs:.0f}")
    ev = sum(float(hw_de(f)["frenos"] or 0) for f in D.corr); dec = sum(float(hw_de(f)["decisiones_freno"] or 0) for f in D.corr)
    cifra("frenos: eventos y decisiones", "tomas con freno de respaldo: 0 de 56, IC95 [0.000, 0.064], con 0 eventos y 0 decisiones en freno",
          f"tomas con freno de respaldo: {sum(float(hw_de(f)['frenos'] or 0) > 0 for f in D.corr)} de {len(D.corr)}, IC95 [0.000, {cp0(len(D.corr)):.3f}], con {ev:.0f} eventos y {dec:.0f} decisiones en freno")
    cifra("contacto: ninguna en las no incluidas", "tomas con contacto (< 0.15 m): 0 de 56, IC95 de Clopper–Pearson [0.000, 0.064]; ninguna en las no incluidas",
          f"tomas con contacto (< 0.15 m): {sum(f['contacto'] == '1' for f in D.corr)} de {len(D.corr)}, IC95 de Clopper–Pearson [0.000, {cp0(len(D.corr)):.3f}]; "
          f"{'ninguna' if not D.js['seguridad']['contactos_no_incluidas'] else 'HAY'} en las no incluidas")
    # Pared.
    wh = {int(f["intento"]): float(hw_de(f)["d_pared_min"]) for f in D.incl}
    wm = {k: media_rep(k, "con_obstaculo", 0.0, "d_pared_min") for k in ks}
    wn = {k: min_rep(k, "con_obstaculo", 0.0, "d_pared_min") for k in ks}
    W1 = ic_t([wh[k] - wm[k] for k in ks]); W2 = ic_t([wh[k] - wn[k] for k in ks])
    D.W1 = W1
    pw = D.js["seguridad"]["d_pared_hw_menos_replica_media"]
    cifra("pared pareada", "−0.0302 m**, IC95 [−0.0354, −0.0251] (n = 30), mediana −0.0283, negativas 30 de 30, Wilcoxon p < 0.0001",
          f"{mn(W1['m'])} m**, IC95 [{mn(W1['lo'])}, {mn(W1['hi'])}] (n = {W1['n']}), mediana {mn(W1['med'])}, negativas {W1['neg']} de {W1['n']}, Wilcoxon p < 0.0001"
          if pw["wilcoxon_p"] < 1e-4 else "p NO ES < 0.0001")
    cifra("pared: mínimo de reps", "Con el mínimo de las repeticiones: −0.0291 m, IC95 [−0.0344, −0.0239], mediana −0.0278",
          f"Con el mínimo de las repeticiones: {mn(W2['m'])} m, IC95 [{mn(W2['lo'])}, {mn(W2['hi'])}], mediana {mn(W2['med'])}")
    allw = st.mean(float(hw_de(f)["d_pared_min"]) for f in D.corr if hw_de(f)["d_pared_min"] not in ("", None))
    cifra("pared: medias", "0.1367 m en las incluidas del hw, 0.1669 m en su réplica y 0.1569 m en las 56 corridas del hw",
          f"{st.mean(wh.values()):.4f} m en las incluidas del hw, {st.mean(wm.values()):.4f} m en su réplica y {allw:.4f} m en las {len(D.corr)} corridas del hw")
    cifra("viola_018", "1.87 en el hw y 1.93 en la réplica",
          f"{st.mean(float(hw_de(f)['viola_018']) for f in D.incl):.2f} en el hw y {st.mean(media_rep(k, 'con_obstaculo', 0.0, 'viola_018') for k in ks):.2f} en la réplica")
    cifra("colisiones", "`colisiones_015` y `colisiones_022`, 0 en el hw y en la réplica",
          "`colisiones_015` y `colisiones_022`, 0 en el hw y en la réplica" if sum(float(hw_de(f)[c] or 0) for f in D.corr for c in ("colisiones_015", "colisiones_022")) == 0
          and sum(float(r[c] or 0) for r in D.rep for c in ("colisiones_015", "colisiones_022")) == 0 else "HAY COLISIONES")
    cifra("frac_cbf", "`frac_cbf` medio: 0.3073 en el hw y 0.3553 en la réplica",
          f"`frac_cbf` medio: {st.mean(float(hw_de(f)['frac_cbf']) for f in D.incl):.4f} en el hw y {st.mean(media_rep(k, 'con_obstaculo', 0.0, 'frac_cbf') for k in ks):.4f} en la réplica")
    cifra("n_escape", "`n_escape` medio: 39.97 y 32.88 en las pareadas, y 32.125 en las 56 corridas del hw",
          f"`n_escape` medio: {st.mean(float(hw_de(f)['n_escape']) for f in D.incl):.2f} y {st.mean(media_rep(k, 'con_obstaculo', 0.0, 'n_escape') for k in ks):.2f} en las pareadas, "
          f"y {st.mean(float(hw_de(f)['n_escape']) for f in D.corr):.3f} en las {len(D.corr)} corridas del hw")
    cifra("n_escape (6a)", "El `n_escape` medio fue 32.125 por corrida en el hw", f"El `n_escape` medio fue {st.mean(float(hw_de(f)['n_escape']) for f in D.corr):.3f} por corrida en el hw")
    # Costo del obstáculo.
    c = {k: rc[k] - rs[k] for k in ks}
    C = ic_t(list(c.values()))
    D.C = C
    pc = D.js["costo"]
    cifra("costo", "**c = +0.0077**, IC95 [−0.0001, +0.0155] (n = 30, 29 gl), mediana +0.0045, positivas 21 de 30. p de la t = 0.0520; Wilcoxon p = 0.0387",
          f"**c = {sg(C['m'])}**, IC95 [{mn(C['lo'])}, {sg(C['hi'])}] (n = {C['n']}, {C['n'] - 1} gl), mediana {sg(C['med'])}, positivas {C['pos']} de {C['n']}. "
          f"p de la t = {pc['t_p']:.4f}; Wilcoxon p = {pc['wilcoxon_p']:.4f}")
    dp = st.mean(wm[k] for k in ks) - st.mean(media_rep(k, "sin_obstaculo", 0.0, "d_pared_min") for k in ks)
    fc = st.mean(media_rep(k, "con_obstaculo", 0.0, "frac_cbf") - media_rep(k, "sin_obstaculo", 0.0, "frac_cbf") for k in ks)
    hs = st.mean(hw[k] - rs[k] for k in ks)
    cifra("costo: descriptivos", "`d_pared_min` con − sin = −0.0005 m; `frac_cbf` con − sin = +0.0437; hw − réplica sin obstáculo = −0.0054",
          f"`d_pared_min` con − sin = {mn(dp)} m; `frac_cbf` con − sin = {sg(fc)}; hw − réplica sin obstáculo = {mn(hs)}")
    # Resumen §1.
    cifra("resumen: pared", "El hw pasa 0.0302 m más cerca de la pared que su réplica (IC95 [−0.0354, −0.0251])",
          f"El hw pasa {abs(W1['m']):.4f} m más cerca de la pared que su réplica (IC95 [{mn(W1['lo'])}, {mn(W1['hi'])}])")
    cifra("resumen: distancia al obstáculo", "La distancia mínima al obstáculo fue 0.2648 m, con mediana 0.3329 m",
          f"La distancia mínima al obstáculo fue {min(float(hw_de(f)['d_min_obst_medida']) for f in D.corr if hw_de(f)['d_min_obst_medida']):.4f} m, "
          f"con mediana {st.median(float(hw_de(f)['d_min_obst_medida']) for f in D.corr if hw_de(f)['d_min_obst_medida']):.4f} m")
    cifra("resumen: costo", "con − sin obstáculo = +0.0077, IC95 [−0.0001, +0.0155]",
          f"con − sin obstáculo = {sg(C['m'])}, IC95 [{mn(C['lo'])}, {sg(C['hi'])}]")


# ── 3. comparación con el 30-09 y cierre (a3) ────────────────────────────
def comparacion() -> None:
    c = D.js["comparacion_3009"]
    ch, bp, be, dpw = c["cobertura_hw"], c["brecha_por_pares"], c["brecha_por_escenario"], c["d_pared_hw_menos_replica"]
    p = D.js["principal"]
    D.bp, D.be = bp, be
    fila("30-09: cobertura", f"| cobertura del hw | {ch['media']:.4f} ± {ch['sd']:.4f} (n = {ch['n']}) | {p['hw']['media']:.4f} ± {p['hw']['sd']:.4f} (n = {p['hw']['n']}) |")
    fila("30-09: por pares", f"| brecha hw − réplica, por pares | {sg(bp['media'])}, IC95 [{mn(bp['ic95'][0])}, {sg(bp['ic95'][1])}] (n = {bp['n']}) | "
         f"{mn(p['media'])}, IC95 [{mn(p['ic95'][0])}, {sg(p['ic95'][1])}] (n = {p['n']}) |")
    fila("30-09: por escenario", f"| brecha hw − réplica, por escenario | {sg(be['media'])}, IC95 [{mn(be['ic95'][0])}, {sg(be['ic95'][1])}] (n = {be['n']}) | igual que por pares (una toma por escenario) |")
    pw = D.js["seguridad"]["d_pared_hw_menos_replica_media"]
    fila("30-09: pared", f"| `d_pared_min` hw − réplica | {mn(dpw['media'])} m, IC95 [{mn(dpw['ic95'][0])}, {mn(dpw['ic95'][1])}] (n = {dpw['n']}) | "
         f"{mn(pw['media'])} m, IC95 [{mn(pw['ic95'][0])}, {mn(pw['ic95'][1])}] (n = {pw['n']}) |")
    cifra("30-09: resumen", "la brecha por pares fue +0.0077 y por escenario +0.0123, con IC95 que contienen el 0; la de esta campaña es −0.0131",
          f"la brecha por pares fue {sg(bp['media'])} y por escenario {sg(be['media'])}, con IC95 que contienen el 0; la de esta campaña es {mn(p['media'])}"
          if bp["ic95"][0] < 0 < bp["ic95"][1] and be["ic95"][0] < 0 < be["ic95"][1] else "ALGÚN IC NO CONTIENE EL 0")
    # a3.
    a3 = json.loads(texto_de(D.rep_dir.parent / "cierre_a3_20261010_b" / "cierre_a3_20261010_091454.json"))
    D.a3 = a3
    cifra("a3: resultado", "media de Δ = −0.00252, **IC95 [−0.01052, +0.00549]**. El margen aprobado es ±0.00827",
          f"media de Δ = {a3['media']:.5f}, **IC95 [{a3['ic95'][0]:.5f}, {sg(a3['ic95'][1], 5)}]**. El margen aprobado es ±{a3['delta_umbral']:.5f}".replace("-", "−") if a3["pasa"] is False else "EL a3 NO ES NO PASA")
    cifra("a3: resumen", "(media de Δ = −0.00252, IC95 [−0.01052, +0.00549], margen ±0.00827)",
          f"(media de Δ = {a3['media']:.5f}, IC95 [{a3['ic95'][0]:.5f}, {sg(a3['ic95'][1], 5)}], margen ±{a3['delta_umbral']:.5f})".replace("-", "−"))
    nv = sum(f["n_nuevas"] for f in a3["tabla"])
    cifra("a3: episodios y repeticiones", "12 episodios válidos del 30-09 corridos sin obstáculo con τ = 0 y 3 repeticiones (36/36 válidas, una sola pila)",
          f"{a3['E']} episodios válidos del 30-09 corridos sin obstáculo con τ = 0 y 3 repeticiones ({nv}/{3 * a3['E']} válidas, una sola pila)")
    ep = {(f["sesion"], f["episodio"]): f["delta"] for f in a3["tabla"]}
    cifra("a3: los dos episodios", "la bifurcación nueva de s05 ep 2 (Δ = −0.040) y la corrida baja del 30-09 en s05 ep 8 (Δ = +0.013)",
          f"la bifurcación nueva de s05 ep 2 (Δ = {mn(ep[('_05', 2)], 3)}) y la corrida baja del 30-09 en s05 ep 8 (Δ = {sg(ep[('_05', 8)], 3)})")
    diag = texto_de(D.rep_dir.parent / "cierre_a3_20261010_b" / "diagnostico_20261010" / "ruido_y_tiempos_a3_salida.txt")
    m = re.search(r"P\(PASA \| intercambiables\) = ([\d.]+)", diag)
    cifra("a3: probabilidad", "la probabilidad de que pase es 0.615", f"la probabilidad de que pase es {m.group(1)}")
    pilas = a3["sha256_pila"] if isinstance(a3["sha256_pila"], list) else [a3["sha256_pila"]]
    cifra("a3: pila", "una sola pila", "una sola pila" if len(set(pilas)) == 1 else "VARIAS", False)


# ── 4. réplica: completitud, condiciones, post hoc ───────────────────────
def replica() -> None:
    ini = sorted(r["inicio"] for r in D.rep)
    cifra("réplica: 270 corridas", "270 corridas: 30 tomas incluidas × 3 condiciones", f"{len(D.rep)} corridas: {len(D.incl)} tomas incluidas × {len({(r['condicion'], r['tau_s']) for r in D.rep})} condiciones")
    cifra("réplica: inicio y fin", "La primera corrida empezó a las 00:31:57 y la última, a las 04:30:41",
          f"La primera corrida empezó a las {ini[0][11:19]} y la última, a las {ini[-1][11:19]}")
    cierre = next(f for f in D.filas if f["tipo"] == "cierre_campana")["fecha"]
    antes = sum(r["inicio"].replace(" ", "T") < cierre for r in D.rep)
    cifra("réplica: después del cierre", "(0 corridas antes del cierre)", f"({antes} corridas antes del cierre)")
    cifra("réplica: pasadas", "Sin pasadas suplementarias", "Sin pasadas suplementarias" if {r["pasada"] for r in D.rep} == {"normal"} else "HAY SUPLEMENTARIAS")
    pila = json.loads(texto_de(next(D.rep_dir.glob("*_replica_pila.json"))))
    sha = hashlib.sha256(json.dumps(pila["huellas"], sort_keys=True).encode("utf-8")).hexdigest()
    cifra("pila: sha256", "`63b4078b13d1d875588998deaa982f83c08aa7d17c078b27942a126799c71562`",
          f"`{pila['sha256_pila']}`" if sha == pila["sha256_pila"] == D.js["declaraciones"]["replica_sha256_pila"][0] else "NO COINCIDE")
    # Completitud (del archivo derivado).
    comp = texto_de(RAIZ / "derivados" / "completitud_replica_20261114.txt")
    cifra("completitud", "270 corridas hechas, 0 grupos con la pasada normal incompleta, 0 grupos con 0 válidas sin pasada suplementaria, `validar_hechas` OK",
          "270 corridas hechas, 0 grupos con la pasada normal incompleta, 0 grupos con 0 válidas sin pasada suplementaria, `validar_hechas` OK"
          if "corridas hechas: 270" in comp and "pasada normal incompleta: 0" in comp and "sin suplementaria: 0" in comp and "validar_hechas: OK" in comp else "NO")
    # La corrida no válida.
    inv = [r for r in D.rep if r["valido"] != "1"]
    r0 = inv[0]
    cifra("corrida no válida", "Intento 20, con obstáculo, τ = 0.0, repetición 1: \"antigüedad de pose sobre el umbral\". Empezó a las 00:52:12 y duró 779.8 s",
          f"Intento {r0['intento_campana']}, {'con obstáculo' if r0['condicion'] == 'con_obstaculo' else r0['condicion']}, τ = {float(r0['tau_s'])}, repetición {r0['rep']}: "
          f"\"{r0['motivo']}\". Empezó a las {r0['inicio'][11:19]} y duró {float(r0['duracion_s']):.1f} s" if len(inv) == 1 else f"{len(inv)} NO VÁLIDAS")
    cifra("corridas no válidas: 1 de 270", "Corridas no válidas: 1 de 270", f"Corridas no válidas: {len(inv)} de {len(D.rep)}")
    # Windows.
    w = D.w
    m105 = re.search(r"(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)  id 105  Power source change", w)
    corte = datetime.fromisoformat(m105.group(1).replace(" ", "T"))
    cifra("Windows: cambio de corriente", "El evento Kernel-Power 105 de las 01:05:10", f"El evento Kernel-Power 105 de las {corte:%H:%M:%S}")
    bit = texto_de(RAIZ / "documentos" / "BITACORA_extracto_desde_20261023.md")
    cifra("lecturas de las 00:14 y las 04:57", "a batería (40 %) a las 00:14:55 y enchufada, al 100 %, a las 04:57",
          "a batería (40 %) a las 00:14:55 y enchufada, al 100 %, a las 04:57"
          if all(x in bit for x in ("A batería (40 %)", "A las 04:57 estaba enchufada, al 100 %", "00:14:55")) else "NO ESTÁN EN EL EXTRACTO")
    cifra("python de las 04:55:53", "los `python` que empezaron a las 04:55:53, después de la réplica",
          "los `python` que empezaron a las 04:55:53, después de la réplica" if len(re.findall(r"python3?\.?\d*\.?exe?\s+x1\s+más antiguo 2026-11-14 04:55:53", w)) == 2 else "NO")
    cifra("Windows: batería crítica y suspensión",
          "A las 00:52:47 hubo un \"Critical Battery Trigger\", a las 00:52:49 la laptop entró a suspensión y a las 00:52:50 reanudó; a las 01:05:11–12, un Modern Standby breve",
          "A las 00:52:47 hubo un \"Critical Battery Trigger\", a las 00:52:49 la laptop entró a suspensión y a las 00:52:50 reanudó; a las 01:05:11–12, un Modern Standby breve"
          if all(s in w for s in ("00:52:47  id 524  Critical Battery Trigger Met", "00:52:49  id 42  The system is entering sleep", "00:52:50  id 107  The system has resumed from sleep",
                                  "01:05:11  id 506  The system is entering Modern Standby", "01:05:12  id 507  The system is exiting Modern Standby")) else "NO")
    om = re.search(r"OmenCommandCenterBackground\.exe\s+x\d+\s+más antiguo (\d{4})-(\d\d)-(\d\d) (\d\d:\d\d:\d\d)", w)
    ch = re.search(r"chrome\.exe\s+x\d+\s+más antiguo (\d{4})-(\d\d)-(\d\d) (\d\d:\d\d:\d\d)", w)
    cifra("Windows: procesos", "Chrome (el proceso más antiguo, desde el 13-11 a las 18:16:35) y `OmenCommandCenterBackground.exe` (desde el 13-11 a las 18:02:21)",
          f"Chrome (el proceso más antiguo, desde el {ch.group(3)}-{ch.group(2)} a las {ch.group(4)}) y `OmenCommandCenterBackground.exe` (desde el {om.group(3)}-{om.group(2)} a las {om.group(4)})")
    # Batería vs enchufada y post hoc.
    t = lambda s: datetime.fromisoformat(s.replace(" ", "T"))
    bat = [r for r in D.rep if t(r["inicio"]) < corte]; ac = [r for r in D.rep if t(r["inicio"]) >= corte]
    cifra("25 y 245", "25 de las 270 corridas empezaron antes de las 01:05:10 y 245, después",
          f"{len(bat)} de las {len(D.rep)} corridas empezaron antes de las {corte:%H:%M:%S} y {len(ac)}, después")
    p95 = lambda g: [float(r["ciclo_p95_ms"]) for r in g if float(r["decisiones"] or 0) > 0 and r["ciclo_p95_ms"] != ""]
    cifra("p95 por fuente", "en las 25 corridas que empezaron a batería, el ciclo p95 medio fue 35.0 ms (máximo 46.7); en las 245 que empezaron enchufadas, 8.6 ms (máximo 18.7)",
          f"en las {len(bat)} corridas que empezaron a batería, el ciclo p95 medio fue {st.mean(p95(bat)):.1f} ms (máximo {max(p95(bat)):.1f}); "
          f"en las {len(ac)} que empezaron enchufadas, {st.mean(p95(ac)):.1f} ms (máximo {max(p95(ac)):.1f})")
    sob = [sum(int(float(r["ciclos_sobre_100ms"] or 0)) > 0 for r in g) for g in (bat, ac)]
    cifra("ciclos > 100 ms", "La única corrida con algún ciclo de más de 100 ms fue una de las de batería",
          "La única corrida con algún ciclo de más de 100 ms fue una de las de batería" if sob == [1, 0] else f"{sob}")
    for cond, tau, etiqueta in (("con_obstaculo", 0.0, "con obstáculo, τ = 0"), ("sin_obstaculo", 0.0, "sin obstáculo, τ = 0"), ("con_obstaculo", 0.45, "con obstáculo, τ = 0.45")):
        g = [r for r in D.rep if r["condicion"] == cond and abs(float(r["tau_s"]) - tau) < 1e-9]
        v = p95(g)
        fila(f"p95 {etiqueta}", f"| {etiqueta} | {st.mean(v):.2f} | {max(v):.2f} |")
    cifra("p95: 90 corridas por condición", "(`ciclo_p95_ms` de las 90 corridas de cada condición, válidas o no)",
          f"(`ciclo_p95_ms` de las {Counter((r['condicion'], r['tau_s']) for r in D.rep).most_common(1)[0][1]} corridas de cada condición, válidas o no)")
    cifra("resumen: p95", "11.64 ms (con obstáculo, τ = 0), 11.31 ms (con obstáculo, τ = 0.45) y 10.28 ms (sin obstáculo) de media",
          "{:.2f} ms (con obstáculo, τ = 0), {:.2f} ms (con obstáculo, τ = 0.45) y {:.2f} ms (sin obstáculo) de media".format(
              *(st.mean(p95([r for r in D.rep if r["condicion"] == c and abs(float(r["tau_s"]) - tt) < 1e-9])) for c, tt in
                (("con_obstaculo", 0.0), ("con_obstaculo", 0.45), ("sin_obstaculo", 0.0)))))
    # Desvío entre repeticiones, sin obstáculo.
    g = defaultdict(list)
    for r in D.rep:
        if r["condicion"] == "sin_obstaculo" and r["valido"] == "1":
            g[int(r["intento_campana"])].append(float(r["cobertura_aoi"]))
    dos = {k: v for k, v in g.items() if len(v) >= 2}
    d1 = sum(st.stdev(v) > 0.01 for v in dos.values()); d0 = sum(st.pstdev(v) > 0.01 for v in dos.values())
    cifra("desvío entre reps", f"de las 30 tomas (todas con ≥ 2 repeticiones válidas), **8 tienen un desvío mayor que 0.01** (ddof = 1), contra 6 de 50 en la réplica del 30-09. Con ddof = 0 son 6 de 30",
          f"de las {len(dos)} tomas (todas con ≥ 2 repeticiones válidas), **{d1} tienen un desvío mayor que 0.01** (ddof = 1), contra 6 de 50 en la réplica del 30-09. Con ddof = 0 son {d0} de {len(dos)}"
          if len(dos) == 30 else "NO SON 30")
    pc0 = p95([r for r in D.rep if r["condicion"] == "con_obstaculo" and abs(float(r["tau_s"])) < 1e-9])
    D.p95con, D.d1, D.dos_n = (st.mean(pc0), max(pc0)), d1, len(dos)
    cifra("resumen: desvío", "8 de 30 tomas tienen un desvío entre repeticiones mayor que 0.01 (ddof = 1), contra 6 de 50 el 30-09",
          f"{d1} de {len(dos)} tomas tienen un desvío entre repeticiones mayor que 0.01 (ddof = 1), contra 6 de 50 el 30-09")


# ── 5. congelados, pila, declaraciones ───────────────────────────────────
def huella(ruta: Path) -> str:
    nombres_dia = {"ESCALA_POSICION", "ESCALA_NO_VERIFICADA", "ROTACION_MARCO_RAD", "TRASLACION_X_M", "TRASLACION_Y_M", "MARCO_NO_VERIFICADO", "OFFSET_HEADING_RAD",
                   "HEADING_NO_VERIFICADO", "MAPEO_NO_VERIFICADO", "OFFSETS_RUMBO_POR_ROBOT", "OFFSETS_RUMBO_MEDIDOS", "ORIGEN_OFFSET_RUMBO"}
    partes = []
    for nodo in ast.parse(ruta.read_bytes().decode("utf-8")).body:
        if isinstance(nodo, ast.Expr) and isinstance(nodo.value, ast.Constant):
            continue
        if isinstance(nodo, (ast.Assign, ast.AnnAssign)):
            blancos = nodo.targets if isinstance(nodo, ast.Assign) else [nodo.target]
            if all(isinstance(b, ast.Name) and b.id in nombres_dia for b in blancos):
                continue
        partes.append(ast.dump(nodo, include_attributes=False))
    return hashlib.sha256("\n".join(partes).encode("utf-8")).hexdigest()


def hash_de(nombre: str) -> str:
    if nombre.endswith("#sin_calibracion"):
        return huella(D.coord / nombre.split("#")[0])
    if nombre.startswith("TESIS/"):
        return sha256(RAIZ / nombre[len("TESIS/"):])
    return sha256(D.coord / nombre)


def declaraciones() -> None:
    cab = D.cab["archivos_congelados"]
    ig = sum(hash_de(n) == h for n, h in cab.items())
    cifra("congelados", "iguales a los de la cabecera de la campaña (22/22)", f"iguales a los de la cabecera de la campaña ({ig}/{len(cab)})")
    pila = json.loads(texto_de(next(D.rep_dir.glob("*_replica_pila.json"))))["huellas"]
    igp = sum(hash_de(n) == h for n, h in pila.items())
    cifra("pila: huellas", "las 25 huellas de archivos de la pila", f"las {len(pila)} huellas de archivos de la pila" if igp == len(pila) else f"SÓLO {igp}/{len(pila)} IGUALES")
    d = D.js["declaraciones"]
    cs = d["configuracion_por_sesion"]
    offs = {json.dumps(c["offsets_deg"], sort_keys=True) for c in cs}
    shas = {json.dumps(c["sha256"], sort_keys=True) for c in cs}
    o = cs[0]["offsets_deg"]
    cifra("configuración por sesión", "fueron los mismos en las 17 sesiones: offsets en grados de los robots 1, 5, 8, 2, 9 y 4: 92.1293, 88.8106, 95.01, 89.7361, 94.2587 y 81.9006",
          f"fueron los mismos en las {len(cs)} sesiones: offsets en grados de los robots 1, 5, 8, 2, 9 y 4: "
          f"{o['1']}, {o['5']}, {o['8']}, {o['2']}, {o['9']} y {o['4']}" if len(offs) == 1 and len(shas) == 1 else "CAMBIA ENTRE SESIONES")
    sh = cs[0]["sha256"]
    cifra("sha256 de config y calibración", f"`config_robotat.py` con sha256 `{sh['config_robotat.py']}` y `calibracion_medida.json` con `{sh['calibracion_medida.json']}`",
          f"`config_robotat.py` con sha256 `{sh['config_robotat.py']}` y `calibracion_medida.json` con `{sha256(D.coord / 'calibracion_medida.json')}`"
          if sha256(D.coord / "calibracion_medida.json") == sh["calibracion_medida.json"] else "LA CALIBRACIÓN NO COINCIDE")
    cifra("rampa", "intentos 2, 8, 19 y 29", f"intentos {', '.join(map(str, d['tomas_con_rampa'][:-1]))} y {d['tomas_con_rampa'][-1]}")
    cifra("col_obst_origen", "ninguna; las 30 incluidas son \"proyección\"", f"ninguna; las {d['col_obst_origen_incluidas']['proyeccion']} incluidas son \"proyección\"" if not d["tomas_obstaculo_no_proyeccion"] else "HAY")
    cifra("correcciones y candados", "No hubo correcciones del libro (`--corregir-campana`), ni candados liberados, ni filas ilegibles",
          "No hubo correcciones del libro (`--corregir-campana`), ni candados liberados, ni filas ilegibles"
          if not d["correcciones"] and not d["candados_liberados"] and not d["filas_descartadas_del_libro"] else "HAY")
    cifra("pausas: cantidad", "pausas de seguridad (5):", f"pausas de seguridad ({len(d['pausas_de_seguridad'])}):")
    kw = {7: ("CONTACTO durante la colocación: robots 1 y 2 a 0.150 m", "CONTACTO durante la colocación: robots 1 y 2 a 0.150 m"),
          15: ("marcador del obstáculo CONGELADO", "ABORTO POR EL OBSTÁCULO: marcador del obstáculo CONGELADO en (1.58, 0.92)"),
          24: ("el obstáculo NO FRENA: se movió 51.1 cm durante la colocación (v medida 0.000 m/s)", "ABORTO POR EL OBSTÁCULO: el obstáculo NO FRENA, se movió 51.1 cm durante la colocación (v medida 0.000 m/s)"),
          36: ("enlace de ruedas del obstáculo (robot 4) caído antes de la colocación", "ABORTO POR EL OBSTÁCULO: enlace de ruedas del obstáculo (robot 4) caído antes de la colocación"),
          37: ("robot(s) 5", "ENLACE DE RUEDAS CAÍDO durante la colocación: robot 5")}
    for pz in d["pausas_de_seguridad"]:
        k = pz["intento"]
        clave, texto = kw[k]
        fl = f"| {k} | {texto} | {pz['respuesta']} |"
        ok = clave in pz["regla"] and ("(1.58, 0.92)" in pz["regla"] if k == 15 else True)
        cifra(f"pausa del {k}", fl, fl if ok else "NO", False)
        fila(f"pausa del {k} (fila)", fl)
    # Chequeo de la PC por sesión.
    sid = {int(f["intento"]): f["id_sesion"] for f in D.resultados}
    por = defaultdict(list)
    for f in D.incl:
        por[f["id_sesion"]].append(int(f["intento"]))
    def inc(s: str) -> str:
        v = por.get(s)
        if not v:
            return "—"
        if len(v) > 5 and v == list(range(v[0], v[-1] + 1)) or (len(v) > 5):
            return f"las {len(v)} del {min(v)} al {max(v)}"
        return ", ".join(map(str, v[:-1])) + " y " + str(v[-1]) if len(v) > 1 else str(v[0])
    filas = [("21-10, 13:26", f"| 21-10, 13:26 (intento 1) | sí, pegado (13:25:56) | {inc('L2_20261021_132617')} |"),
             ("21-10, 13:34", f"| 21-10, 13:34 (intentos 2–7) | compartido: el OK de las 13:32:16 | {inc('L2_20261021_133444')} |"),
             ("21-10, 13:48", f"| 21-10, 13:48 (intentos 8–17) | no: el último OK, 963 s antes, era de otra sesión | {inc('L2_20261021_134819')} |"),
             ("23-10, 20:50", f"| 23-10, 20:50 (intentos 18–25) | no: el último chequeo, a las 20:32:35, dio FALLA | {inc('L2_20261023_205007')} |"),
             ("04-11, 12:07", f"| 04-11, 12:07 (intentos 26–35) | no consta | {inc('L2_20261104_120744')} |"),
             ("04-11, 12:51", f"| 04-11, 12:51 (intentos 36–37) | sí, pegado (12:49:56) | {inc('L2_20261104_125102')} |"),
             ("06-11, 19:38", "| 06-11, 19:38 (intentos 38–73) | sí según el operador, sin la salida pegada; el último pegado, a las 19:21:17, dio FALLA | "
                              f"{inc('L2_20261106_193852')} |")]
    for desc, fl in filas:
        fila(f"chequeo: {desc}", fl)
    fila("chequeo: réplica", "| **réplica, 14-11, 00:31 (lanzamiento único)** | el operador lo corrió y no guardó la salida: no consta el resultado | — |")
    c = Counter("declarado" if s == "L2_20261106_193852" else ("compartido" if s == "L2_20261021_133444" else "sin") for f in D.incl for s in [f["id_sesion"]])
    cifra("clasificación", "18 con `CHEQUEO OK` declarado sin salida y sin hora, 2 con el OK compartido y 10 sin `CHEQUEO OK` propio",
          f"{c['declarado']} con `CHEQUEO OK` declarado sin salida y sin hora, {c['compartido']} con el OK compartido y {c['sin']} sin `CHEQUEO OK` propio")
    # Interrumpidas y aperturas sin tomas.
    interr = [int(f["intento"]) for f in D.resultados if f["estado"] == "interrumpida"]
    cifra("interrumpidas", "intentos 1, 17, 25, 35 y 73 (5)", f"intentos {', '.join(map(str, interr[:-1]))} y {interr[-1]} ({len(interr)})")
    seg = leer(D.anal_dir / "seguridad_tomas.csv")
    cifra("recuento físico de interrumpidas", "(recuento físico del análisis: 0)",
          f"(recuento físico del análisis: {sum(f['marcada_interrumpida'] == '1' for f in seg)})"
          if D.js["seguridad"]["corridas_marcadas_interrumpidas"] == 0 else "NO")
    con_res = {f["id_sesion"] for f in D.filas if f["tipo"] == "resultado"}
    sin = [f for f in D.filas if f["tipo"] == "apertura" and f["id_sesion"] not in con_res]
    por_dia = Counter(f["fecha"][:10] for f in sin)
    cifra("aperturas sin tomas", "10 cerraron sin ningún intento (3 del 21-10, 2 del 23-10, 1 del 04-11 y 4 del 06-11)",
          f"{len(sin)} cerraron sin ningún intento ({por_dia['2026-10-21']} del 21-10, {por_dia['2026-10-23']} del 23-10, {por_dia['2026-11-04']} del 04-11 y {por_dia['2026-11-06']} del 06-11)")
    # Ruido entre repeticiones del a3.
    a3 = D.a3
    r22 = texto_de(RAIZ / "documentos" / "REPORTE_2026-10-22_campana_L2.md")
    m1 = re.search(r"Desvío mediano por episodio: ([\d.]+) en las nuevas y ([\d.]+) en las del 30-09", r22)
    m2 = re.search(r"El máximo nuevo \(([\d.]+), s05 ep 2\) supera al del 30-09 en esos episodios \(([\d.]+), s05 ep 8\)", r22)
    cifra("a3: ruido entre repeticiones",
          "el desvío mediano por episodio es 0.0013 en las nuevas contra 0.0015 en las del 30-09, pero el máximo nuevo (0.0287, s05 ep 2) supera al del 30-09 (0.0175, s05 ep 8)",
          f"el desvío mediano por episodio es {a3['sd_nueva_mediana']:.4f} en las nuevas contra {m1.group(2)} en las del 30-09, pero el máximo nuevo ({a3['sd_nueva_max']:.4f}, s05 ep 2) "
          f"supera al del 30-09 ({m2.group(2)}, s05 ep 8)" if m1 and m2 and m1.group(1) == f"{a3['sd_nueva_mediana']:.4f}" and m2.group(1) == f"{a3['sd_nueva_max']:.4f}" else "NO COINCIDE")
    # Pilas del a3 y de la réplica.
    pa3 = json.loads(texto_de(next((D.rep_dir.parent / "cierre_a3_20261010_b").glob("*_replica_pila.json"))))
    prp = json.loads(texto_de(next(D.rep_dir.glob("*_replica_pila.json"))))
    difieren = sorted(k for k in set(pa3["huellas"]) | set(prp["huellas"]) if pa3["huellas"].get(k) != prp["huellas"].get(k))
    esperados = ["TESIS/PLAN_ANALISIS_campana_L2.md", "analizar_campana_l2.py", "calibracion_medida.json", "campana_obstaculo.py",
                 "config_robotat.py#sin_calibracion", "demo_obstaculo_movil.py"]
    iguales = len(prp["huellas"]) - len(difieren)
    texto_pilas = ("El a3 corrió con la pila `b5a289046f966592…` y la réplica de la campaña, con `63b4078b13d1d875…`. Difieren 6 de los 25 archivos: "
                   "`config_robotat.py` (la huella sin calibración), `calibracion_medida.json`, `campana_obstaculo.py`, `demo_obstaculo_movil.py`, "
                   "`analizar_campana_l2.py` y el plan. Los otros 19 son iguales")
    ok_pilas = (difieren == esperados and iguales == 19 and pa3["sha256_pila"].startswith("b5a289046f966592") and prp["sha256_pila"].startswith("63b4078b13d1d875")
                and all(pa3["huellas"].get(k) == prp["huellas"].get(k) for k in ("replica_con_obstaculo.py", "simulador_robotat.py", "sesion_robotat.py", "lib/filtro_cbf.py")))
    cifra("pila del a3 contra la de la réplica", texto_pilas, texto_pilas if ok_pilas else f"difieren {difieren}, iguales {iguales}")
    # Cierre (b).
    con = [r for r in D.rep if r["condicion"] == "con_obstaculo"]
    errm = max(float(r["cierre_b_err_max_m"]) for r in con)
    errth = max(float(r["cierre_b_err_th_rad"]) for r in con)
    ok_b = all(r["cierre_b_ok"] == "1" and r["cierre_b_desfase"] == "0" and r["cierre_b_mandos_iguales"] == "1" for r in con)
    cifra("cierre (b)", "pasó en las 180 corridas con obstáculo (error máximo 0.0 m, sin desfase, mandos iguales, rumbo dentro de 4.4e−16 rad)",
          f"pasó en las {len(con)} corridas con obstáculo (error máximo {errm:.1f} m, sin desfase, mandos iguales, rumbo dentro de {errth:.1e} rad)".replace("e-", "e−")
          if ok_b else "FALLA EL CIERRE (b)")
    # Tabla del chequeo contra la del reporte del 13-11.
    r13 = texto_de(RAIZ / "documentos" / "REPORTE_2026-11-07_campana_L2.md")
    en13 = {l.strip() for l in r13.splitlines()}
    for desc, fl in filas:
        cifra(f"chequeo {desc}: igual en el reporte del 13-11", "igual", "igual" if fl in en13 else "DISTINTA DE LA DEL 13-11", False)
    # Frases fijas y prohibidas.
    fijas = ["No se afirma equivalencia", "Con el freno en sombra, la separación la sostuvo el filtro con su rescate, y el freno habría actuado como capa redundante",
             "pero no en las condiciones del protocolo", "no corrió con la PC limpia", "no guardó la salida", "dio **NO PASA**", "sin afirmar equivalencia"]
    falta = [x for x in fijas if x not in TEXTO]
    cifra("frases fijas del reporte", "todas presentes", "todas presentes" if not falta else f"FALTAN: {falta}", False)
    prohibidas = ["evitó el choque", "evitó la colisión", "evitó el contacto", "evitaron el choque", "Hay equivalencia", "son equivalentes", "es equivalente", "equivalencia demostrada"]
    hay = [x for x in prohibidas if x in TEXTO]
    cifra("frases prohibidas", "ninguna", "ninguna" if not hay else f"HAY: {hay}", False)
    # Citas.
    b = texto_de(RAIZ / "documentos" / "BITACORA_extracto_desde_20261023.md")
    cuerpo = TEXTO.split("\n## 13. Datos y verificación")[0]
    cifra("el título del §13 aparece una vez", "1", str(TEXTO.count("\n## 13. Datos y verificación")), False)
    for desc, cita in (("declaración de las 18", "Según el operador, la app de Claude se cerró antes de lanzar a las 19:38:52; la hora del cierre no consta"),
                       ("declaración de las 18 (OK)", "`CHEQUEO OK` declarado por el operador, sin salida pegada y sin hora"),
                       ("chequeo de la réplica", "no guardó la salida")):
        cifra(f"cita: {desc}", "está en el extracto y en el reporte", "está en el extracto y en el reporte" if cita in b and cita in cuerpo else "NO ESTÁ", False)
    cifra("cierre en la bitácora", "está en el extracto", "está en el extracto" if "14-11: CIERRE de la campaña (MÍNIMO)" in b and "14-11: la réplica de las tomas (completa)" in b else "NO ESTÁ", False)


def tesis() -> None:
    k, corr, incl = len(D.resultados), len(D.corr), len(D.incl)
    H, Rr, Dd, C, A1, W1, a3 = D.H, D.Rr, D.Dd, D.C, D.A1, D.W1, D.a3
    cp = f"{cp0(corr):.3f}"
    filas = [
        f"| Intentos / corridas / incluidas | {k} / {corr} / {incl} | intentos, corridas y tomas incluidas |",
        f"| Cobertura final del hw, incluidas | {H['m']:.4f} ± {H['sd']:.4f} (n = {H['n']}) |",
        f"| Cobertura final de la réplica con obstáculo, τ = 0 | {Rr['m']:.4f} ± {Rr['sd']:.4f} (n = {Rr['n']}) |",
        f"| **Brecha hw − réplica (principal)** | **{mn(Dd['m'])}, IC95 [{mn(Dd['lo'])}, {sg(Dd['hi'])}]** |",
        f"| Costo del obstáculo (con − sin, réplica) | {sg(C['m'])}, IC95 [{mn(C['lo'])}, {sg(C['hi'])}] |",
        f"| Contactos (< 0.15 m al obstáculo) | {sum(f['contacto'] == '1' for f in D.corr)} de {corr} corridas, IC95 [0.000, {cp}] |",
        f"| Frenos de respaldo | {sum(float(hw_de(f)['frenos'] or 0) > 0 for f in D.corr)} de {corr} corridas, IC95 [0.000, {cp}] |",
        f"| Distancia mínima al obstáculo ({corr} corridas) | mín {D.dmstats[0]:.4f}, mediana {D.dmstats[1]:.4f}, máx {D.dmstats[2]:.4f} |",
        f"| `d_min` hw − réplica (media de repeticiones) | {mn(A1['m'])}, IC95 [{mn(A1['lo'])}, {sg(A1['hi'])}] |",
        f"| `d_pared_min` hw − réplica (media de repeticiones) | {mn(W1['m'])}, IC95 [{mn(W1['lo'])}, {mn(W1['hi'])}] |",
        f"| Brecha hw − réplica del 30-09 (por pares / por escenario) | {sg(D.bp['media'])} [{mn(D.bp['ic95'][0])}, {sg(D.bp['ic95'][1])}] / "
        f"{sg(D.be['media'])} [{mn(D.be['ic95'][0])}, {sg(D.be['ic95'][1])}] |",
        f"| Cierre (a3) | NO PASA: media de Δ {a3['media']:.5f}, IC95 [{a3['ic95'][0]:.5f}, {sg(a3['ic95'][1], 5)}], margen ±{a3['delta_umbral']:.5f} |".replace("Δ -", "Δ −").replace("[-", "[−"),
        f"| Ciclo p95 de la réplica (con obstáculo, τ = 0) | {D.p95con[0]:.2f} media, {D.p95con[1]:.2f} máx (post hoc) |",
        f"| Tomas con desvío entre repeticiones > 0.01 (sin obstáculo, ddof = 1) | {D.d1} de {D.dos_n} (30-09: 6 de 50) (post hoc) |",
    ]
    for i, f in enumerate(filas):
        cifra(f"Para la tesis, fila {i + 1}", f, f if f in TEXTO else "FILA AUSENTE O DISTINTA", False)


def main() -> int:
    global TEXTO, RAIZ
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    if sys.version_info[:2] != (3, 13):
        print("Hace falta Python 3.13: la huella sin calibración de config_robotat.py es un sha256 de "
              "ast.dump, que cambió en 3.13 y no se probó con 3.14 ni posteriores.")
        return 2
    RAIZ = Path(sys.argv[1])
    TEXTO = Path(sys.argv[2]).read_bytes().decode("utf-8")
    cargar()
    libro()
    principal()
    comparacion()
    replica()
    tesis()
    declaraciones()
    malas = 0
    for desc, rep, calc, en_texto in CIFRAS:
        ok = (rep == calc) and (not en_texto or rep in TEXTO)
        malas += not ok
        print(f"{'SÍ' if ok else 'NO'}  {desc}: reportado «{rep}» · calculado «{calc}»"
              + ("" if not en_texto or rep in TEXTO else " · NO ESTÁ EN EL TEXTO"))
    print(f"\n{len(CIFRAS) - malas}/{len(CIFRAS)} cifras coinciden")
    return 1 if malas else 0


if __name__ == "__main__":
    sys.exit(main())
