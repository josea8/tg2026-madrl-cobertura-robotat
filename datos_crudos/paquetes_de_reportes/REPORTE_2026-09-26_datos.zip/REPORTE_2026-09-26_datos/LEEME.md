# Datos crudos del reporte del 2026-09-26

Copias byte a byte de los archivos del proyecto que respaldan `REPORTE_2026-09-26.md` (incluido acá), más los scripts de cada cifra. Nada de esto modifica el proyecto.

## Cómo reproducir la comparación sim/real

```bash
cd scripts
python -B pareo_0926.py      # usa ../csv; imprime principal, sensibilidades, 11-09 y combinado
```

Requiere Python ≥ 3.9, numpy y scipy. La salida de referencia está en `derivados/pareo_0926_salida.txt` y coincide con `analizar_replicas.py --sesion 20260926_…` del proyecto.

Los scripts `a26_*` (congelamientos, enlaces, supervivencia) son las trazas de los análisis; apuntan a las rutas del proyecto y del scratchpad donde se corrieron, y sus salidas están en `derivados/`. Leen los mismos CSV que están en `csv/`.

## Origen

- `csv/`: `primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/` (la calibración, de `coordinador_enjambre/`). La réplica `20260926_sesion-replica_etapa7_capas-on_de-20260926.csv` se generó hoy con `replica_con_capas.py --capas on --reps 3`.
- `consola/consola_20260926.txt`: la consola de la sesión que pegaste en el chat (no existe como archivo en el proyecto).
- `replica_hashes_pila.txt`: sha256 de la pila con la que corrió la réplica (`replica_con_capas`, `sesion_robotat`, `simulador_robotat`, `adaptadores_robotat`, `coordinador_enjambre`, `protocolo_robotat`, `config_robotat`, `retroceso_congelamiento`, `colocacion_autonoma`, `calibracion_medida.json`).
- `derivados/`: salidas de scripts, no datos crudos. `figuras/`: mapa de congelamientos.

**No hay CSV de la sonda:** el mapeo todavía no se corrió en el laboratorio. El diagnóstico de poses estaba apagado (sin `.jsonl`).

## Manifiesto (sha256)

| archivo | bytes | tamaño | sha256 |
|---|---|---|---|
| `REPORTE_2026-09-26.md` | 17871 |  | `38379ec96e9cad1c9ddbc359f134fb4743cbb2341551aa5509f2653a4781eb9f` |
| `consola/consola_20260926.txt` | 290670 |  | `8a9bb06977c8d21b1b0c46bec3150a747fff9eed765427b3b113852b90874619` |
| `csv/20260911_sesion-evaluacion_etapa7_decisiones.csv` | 2238230 | 17065 filas | `cf3a50d03fd57ce7b75d8e9cdc3d6e0066ac5fba6d1fe3e1693b2fab9788a581` |
| `csv/20260911_sesion-evaluacion_etapa7_episodios.csv` | 7977 | 19 filas | `b9459feb99fb5c641298ab3a4f4bbc64f4b27c833d571cbeaf560fc0b5b95977` |
| `csv/20260912_sesion-replica_etapa7_capas-on.csv` | 3176 | 15 filas | `e889c989c39c97c0d46444b3b04431e8978f916993d43fbff6781211400c7466` |
| `csv/20260922_sesion-evaluacion_etapa7_decisiones.csv` | 275073 | 2100 filas | `7aad1082b81d658728473b518112a84c11e92b18c83516526c8d787576dd6b77` |
| `csv/20260922_sesion-evaluacion_etapa7_decisiones_02.csv` | 220799 | 1695 filas | `93d8291d62d349ab84bac99c4d31337c574b290119a87cfe89792b3854973adc` |
| `csv/20260924_sesion-evaluacion_etapa7_decisiones.csv` | 1837325 | 14020 filas | `363bf3f7755c9c3cd0ab9c9e83bfebacacd47c494f07552dd7aa013cc49e9198` |
| `csv/20260924_sesion-evaluacion_etapa7_episodios.csv` | 19135 | 17 filas | `c8399b711b6f6b3ce8b77725a3803cd681a37ca0bf153840ed82a4565b7c9683` |
| `csv/20260926_sesion-evaluacion_etapa7_decisiones.csv` | 4567596 | 34260 filas | `7f47dc62623b8466adf3e768dc0c911ac0808e8d5e2a229cfd6039515253b89d` |
| `csv/20260926_sesion-evaluacion_etapa7_episodios.csv` | 23676 | 19 filas | `c3c07ab50ac0a1910aa1333539b9c92c3d979f36d3e80e2f78bf1f2c8bbfafb7` |
| `csv/20260926_sesion-replica_etapa7_capas-on_de-20260926.csv` | 8364 | 30 filas | `7f0daf9deabc3106fabd842001aac69b92f019bc565b344f0b3653c80d580601` |
| `csv/calibracion_medida.json` | 12788 |  | `9d1033124c2646ffad07863dc65a12af4f530f3aaceefbdc0ac793f8ce73db66` |
| `derivados/a26_congel_analisis_salida.txt` | 41063 |  | `6b3c0fd6d0f433cd896530132ffcecca062a0cce04d3cc1f157622f59923699f` |
| `derivados/a26_congel_analisis_salida2.txt` | 41063 |  | `6b3c0fd6d0f433cd896530132ffcecca062a0cce04d3cc1f157622f59923699f` |
| `derivados/a26_congel_consola_salida.txt` | 32942 |  | `a833dbdefc409c68c9f40dc1a39d03bc1994782e90077456ae0ee0217619133f` |
| `derivados/a26_congel_eventos_salida.txt` | 7993 |  | `1aaafb90e922d8113cc5ed8e817827f6a1e0a8ad319a87701790b643ecbc7296` |
| `derivados/a26_congel_rumbos_salida.txt` | 4249 |  | `c8764e4c28b6bfd7713e94a4ab65562f5aae1cba4af27489875ad45488e5300d` |
| `derivados/a26_congel_zona_salida.txt` | 18384 |  | `2cf6593cf07e1a25599982ec27150229425d7ac9dbc2a2fcaf23b219c4f0a683` |
| `derivados/a26_congel_zona_salida2.txt` | 18384 |  | `2cf6593cf07e1a25599982ec27150229425d7ac9dbc2a2fcaf23b219c4f0a683` |
| `derivados/a26_superv_1_salida.txt` | 6179 |  | `ec335912afd4c961927636945378474bd5ad881a242261779403d75ce917ed24` |
| `derivados/a26_superv_2_salida.txt` | 14247 |  | `775b4dd8bad84a1c944ef8b9d3ac536686c97ba874784c9fc6f79648b0df4b86` |
| `derivados/a26_superv_3_salida.txt` | 12239 |  | `aedbbf4d918fcad1f587120e69b8b874b05bbbbbf9f22b5ad456f4bbe4f19ae5` |
| `derivados/a26_superv_4_salida.txt` | 10802 |  | `fdef6cbae5c32c1345a352349dfc94d32d8752fc103bd4da3773290c19ce9de5` |
| `derivados/a26_superv_5_salida.txt` | 1578 |  | `116c7be3d472447b0d796b5c53e0c84976beec3695a8ab3104a225c431f0903e` |
| `derivados/a26_superv_rachas.csv` | 1526 | 12 filas | `7e89553cf34f7bb255df9562a6aaa38a3b26da4e87805ee622c193c3c0a3f6d5` |
| `derivados/a26_superv_tabla.csv` | 4230 | 19 filas | `717f00c97db1f1c82cc1adfa37c9b3590ed2f436fb5447c723dbe1ba55b07ab6` |
| `derivados/pareo_0926_salida.txt` | 3635 |  | `9e4d529d6aa1ecf0323b93223b1051675ec0ef6acbcabac6fd625d060a70526e` |
| `derivados/replica_0926_log.txt` | 8161 |  | `92e14206835d677963361a5e57b01dbe49f8779fd34bb863c1ff8ebacfd04eba` |
| `figuras/a26_congel_mapa.png` | 393157 |  | `610924fe5c3d2291ee3343c404be2c699cbf43d427d9f77dfa4b13002882a177` |
| `replica_hashes_pila.txt` | 880 |  | `a1dd1d73fdf8d74ba64fea67cd7515743bd7403abe23c90e5ce47559e2e2e95a` |
| `scripts/a26_congel_analisis.py` | 14281 |  | `8a8c7fa82d22590ced50237d6cfcf01148505ca919b2420719ea560f5b7e8372` |
| `scripts/a26_congel_consola.py` | 2607 |  | `3f56242cc5a7873c5b7006047cff57050beffe85458635fec23b4d1dd159b7f4` |
| `scripts/a26_congel_eventos.py` | 10295 |  | `d108b85b22172be0a4bd3f460d466e36b92292e4c043c690d3a2bd4613aa77b4` |
| `scripts/a26_congel_mapa.py` | 6221 |  | `a31fc2003a2f0744ad00a311649e443e55a874ffb41836f03633b8084027d80a` |
| `scripts/a26_congel_rumbos.py` | 2309 |  | `55520a7fbac4d7149032dff3612293b1827e3de581576ce8217556a87a85bf9e` |
| `scripts/a26_congel_zona.py` | 7034 |  | `b2da008d97be4efbdf0f0b4e874cd5cd57911aed5cc4d92bea779bb19bb113cb` |
| `scripts/a26_enlaces_arranques.py` | 2348 |  | `2736c16c3d244f46e212d166a4dfb58d9949e4b7346c54a45d8a7e1ef2602ec2` |
| `scripts/a26_enlaces_condensar.py` | 1061 |  | `b8705a2741d63f1c99321f4937eb843c54c96addd837e8381304dda740540497` |
| `scripts/a26_enlaces_corte_r9.py` | 1240 |  | `9a8ad2ca31e8203787eac765a386fee56da38a4e15360f9835239d038cce446e` |
| `scripts/a26_enlaces_decisiones.py` | 5730 |  | `ebf3346d0c081432858c17b45543477d2c36e0e594d8b445657471beb27d2aef` |
| `scripts/a26_enlaces_episodios.py` | 687 |  | `6c75e1f3700a2a5e5c290221c76e0d033d99b7c6d11777f0cc6dffa8e6284a0c` |
| `scripts/a26_enlaces_lab.py` | 1080 |  | `27215d55f00024f5407794f0fda201ce59f990b5418dae507d6660a9664f2064` |
| `scripts/a26_enlaces_linea_tiempo.py` | 3373 |  | `7939a40051897a9893c4f254983d43c891370f7a15bb1008d408e657cc69ad90` |
| `scripts/a26_enlaces_noavanza_0924.py` | 693 |  | `bf19e5fd7921202bcba2a53a56c8b3fdbd18bb9b7b5fafd505c62bcde31f4847` |
| `scripts/a26_enlaces_nosigue.py` | 1558 |  | `6d571071a86e4a1a3499d39d5a0d0594832279e9462a1c1ac1c12c7b8f5f741a` |
| `scripts/a26_enlaces_pivote.py` | 2904 |  | `3b0bd04b53b6da2b7b1314bb4d66e1e3a4be31b838d309197ae585322ed2795a` |
| `scripts/a26_enlaces_sesiones_previas.py` | 1728 |  | `ab5aa180f32be8b57b98e284c9fd9ccf440ca8023ced45c3d2476cecf83c0ba1` |
| `scripts/a26_enlaces_verificaciones.py` | 3661 |  | `0286e2d6c3ff57e28b2c96370049c05f024ac53a6722f3e3e107d56a9a3a5df0` |
| `scripts/a26_superv_1_tabla.py` | 6054 |  | `f993c49212e88286fe4a00be4d851f7f05b92e84b0d904b78ec3bf04e53d11b7` |
| `scripts/a26_superv_2_sesgo.py` | 10732 |  | `153d9fa0ee052e70ccb513b38046e276278be5906be86f96cfeaf6bf5b48573b` |
| `scripts/a26_superv_3_diversidad.py` | 4459 |  | `68e06b0845c093c85fe1298c7b3df4577fd80bed8511feb2abb6e1b2268da2b6` |
| `scripts/a26_superv_4_seguridad_semillas.py` | 11499 |  | `09867e5c6f235467e2a7bcf0ef0e8301174f38d81d9a5f1702bb8f7c6b320906` |
| `scripts/a26_superv_5_extras.py` | 4083 |  | `1c704281a3cd94dd0c64e50d8205b7218e6d403b6c5969b37e38486e91edd532` |
| `scripts/a26_superv_comun.py` | 3095 |  | `f52bc1b9b74dbdc3031ce2dca2fbeb2367a645301677a197dc73b4ee1fc91ce4` |
| `scripts/pareo_0926.py` | 5677 |  | `70f0ebdd3be3cc6078975266a034ca2a667dcfa5795d9c56c26118cfc8881cc4` |
