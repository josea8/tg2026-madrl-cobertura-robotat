# Evolución del seguimiento dentro de los episodios con NO SIGUE (ventanas de 50 decisiones).
import csv, math
import numpy as np
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_decisiones.csv"
rows = list(csv.DictReader(open(D, encoding="utf-8")))
def serie(e, a):
    rs = sorted([r for r in rows if r["episodio"] == str(e) and r["agente"] == str(a)], key=lambda r: int(r["paso"]))
    xy = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in rs])
    th = np.unwrap([float(r["pose_env_th"]) for r in rs])
    v = np.array([float(r["v_ejecutada"]) for r in rs]) * 0.40
    w = np.array([float(r["w_ejecutada"]) for r in rs]) * 0.40
    return xy, th, v, w
for e, a, rob in [(2, 0, 1), (3, 4, 9), (14, 3, 6)]:
    xy, th, v, w = serie(e, a)
    av = np.r_[0, np.linalg.norm(np.diff(xy, axis=0), axis=1)]
    com = np.abs(v) * 0.1
    dth = np.r_[0, np.diff(th)] / 0.1
    print(f"ep {e} robot {rob}: {len(v)} decisiones")
    for k in range(0, len(v), 50):
        s = slice(k, min(k + 50, len(v)))
        cc = np.corrcoef(dth[s][1:], w[s][1:])[0, 1] if np.std(dth[s][1:]) > 0 and np.std(w[s][1:]) > 0 else float('nan')
        print(f"   dec {k:3d}-{min(k+50,len(v))-1:3d}: recorrido/comandado {av[s].sum()*100:6.1f}/{com[s].sum()*100:6.1f} cm = {av[s].sum()/com[s].sum()*100:5.1f} %"
              f"   giro medido {np.degrees(np.mean(dth[s])):7.1f} °/s  ω cmd {np.degrees(np.mean(w[s])):7.1f} °/s  corr(ω_med, ω_cmd)={cc:5.2f}")
