# Seguimiento real/comandado por (episodio, agente) y detalle de los episodios con robots problemáticos.
import csv, math
from collections import defaultdict
import numpy as np
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_decisiones.csv"
E = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_episodios.csv"
FACTOR, DT = 0.40, 0.1
rows = list(csv.DictReader(open(D, encoding="utf-8")))
eps = {int(r["episodio"]): r for r in csv.DictReader(open(E, encoding="utf-8"))}
g = defaultdict(list)
for r in rows:
    g[(int(r["episodio"]), int(r["agente"]))].append(r)
for k in g:
    g[k].sort(key=lambda r: int(r["paso"]))
# decisión global para la rampa (primeras 50 decisiones de la sesión: factor 0.25)
orden_eps = sorted({k[0] for k in g})
print("decisiones por episodio en el CSV:", {e: len(g[(e, 0)]) for e in orden_eps})

def serie(e, a):
    rs = g[(e, a)]
    xy = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in rs])
    th = np.array([float(r["pose_env_th"]) for r in rs])
    v = np.array([float(r["v_ejecutada"]) for r in rs])
    w = np.array([float(r["w_ejecutada"]) for r in rs])
    ret = np.array([int(r["en_retroceso"]) for r in rs])
    paso = np.array([int(r["paso"]) for r in rs])
    return xy, th, v, w, ret, paso

def ratio(e, a, ultimos=None):
    xy, th, v, w, ret, paso = serie(e, a)
    fac = np.full(len(v), FACTOR)
    if e == 1:
        fac[:50] = FACTOR * 0.25
    com = np.abs(v) * fac * DT
    com[ret == 1] = 0.0
    av = np.r_[0.0, np.linalg.norm(np.diff(xy, axis=0), axis=1)]
    # congelado: fila idéntica (x,y,th) a la anterior
    rep = np.r_[False, np.all(np.diff(np.c_[xy, th], axis=0) == 0, axis=1)]
    if ultimos:
        com, av, rep = com[-ultimos:], av[-ultimos:], rep[-ultimos:]
    # el detector usa avance del paso k contra comandado del paso k
    return av.sum(), com.sum(), (av.sum() / com.sum() if com.sum() > 0 else float("nan")), int(rep.sum())

robot_de = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
print("\nSEGUIMIENTO recorrido/comandado por episodio y robot (episodio completo; comandado = |v_ejecutada|·0.40·0.1 s, sin retroceso)")
print("ep  " + "  ".join(f"r{robot_de[a]:>2}     " for a in range(5)) + "  valido")
tabla = {}
for e in orden_eps:
    fila = []
    for a in range(5):
        rec, com, rt, nrep = ratio(e, a)
        tabla[(e, a)] = rt
        fila.append(f"{rt:5.2f}({nrep:2d})")
    print(f"{e:2d}  " + "  ".join(fila) + f"   {eps[e]['valido']}")
print("(entre paréntesis: filas con pose idéntica a la anterior)")
print("\nMediana por robot, episodios 1-8 vs 9-19 (sólo episodios con ≥100 decisiones):")
for a in range(5):
    t1 = [tabla[(e, a)] for e in orden_eps if e <= 8 and len(g[(e, a)]) >= 100]
    t2 = [tabla[(e, a)] for e in orden_eps if e >= 9 and len(g[(e, a)]) >= 100]
    print(f"  robot {robot_de[a]}: 1-8 {np.median(t1):.3f} (n={len(t1)})   9-19 {np.median(t2):.3f} (n={len(t2)})  todos: " +
          " ".join(f"{e}:{tabla[(e, a)]:.2f}" for e in orden_eps if len(g[(e, a)]) >= 100))

print("\nNO SIGUE — ventana de los últimos 50 pasos:")
for e, a in [(2, 0), (3, 4), (14, 3)]:
    rec, com, rt, nrep = ratio(e, a, ultimos=50)
    xy, th, v, w, ret, paso = serie(e, a)
    net = np.linalg.norm(xy[-1] - xy[0])
    dth = np.sum(np.abs(np.diff(np.unwrap(th))))
    print(f"  ep {e} robot {robot_de[a]}: recorrido {rec*100:.1f} cm / comandado {com*100:.1f} cm = {rt*100:.1f} %  ·  filas repetidas {nrep}"
          f"  ·  episodio: {len(paso)} decisiones, desplazamiento neto {net*100:.1f} cm, giro acumulado {math.degrees(dth):.0f}°"
          f"  ·  |v| medio {np.mean(np.abs(v)):.3f}  |w| medio {np.mean(np.abs(w)):.3f}")
    # comparación: los otros 4 robots en la misma ventana
    otros = []
    for b in range(5):
        if b == a: continue
        r2 = ratio(e, b, ultimos=50)
        otros.append(f"r{robot_de[b]} {r2[2]*100:.0f}%")
    print("      otros robots misma ventana: " + ", ".join(otros))

print("\nROBOT 6 (agente 3) en episodios 6, 7, 8, 14 (arrancó 'no avanza'):")
def circulo(xy):
    # ajuste algebraico (Kasa) de circunferencia
    x, y = xy[:, 0], xy[:, 1]
    A = np.c_[2 * x, 2 * y, np.ones_like(x)]
    b = x ** 2 + y ** 2
    c, *_ = np.linalg.lstsq(A, b, rcond=None)
    cx, cy = c[0], c[1]
    r = math.sqrt(c[2] + cx ** 2 + cy ** 2)
    res = np.abs(np.hypot(x - cx, y - cy) - r)
    return cx, cy, r, float(np.median(res))
for e in [6, 7, 8, 14]:
    xy, th, v, w, ret, paso = serie(e, 3)
    rec, com, rt, nrep = ratio(e, 3)
    net = np.linalg.norm(xy[-1] - xy[0])
    dth = np.unwrap(th)
    cx, cy, r, res = circulo(xy)
    ext = xy.max(axis=0) - xy.min(axis=0)
    print(f"  ep {e}: {len(paso)} dec · inicio ({xy[0,0]:.3f},{xy[0,1]:.3f}) fin ({xy[-1,0]:.3f},{xy[-1,1]:.3f}) · neto {net*100:.1f} cm · camino {rec*100:.1f} cm "
          f"· comandado {com*100:.1f} cm · seguimiento {rt*100:.1f} % · extensión x {ext[0]*100:.1f} cm y {ext[1]*100:.1f} cm "
          f"· giro neto {math.degrees(dth[-1]-dth[0]):.0f}° · círculo ajustado r={r*100:.1f} cm (residuo mediano {res*100:.1f} cm) · filas repetidas {nrep}")
    # progreso por tramos de 100 decisiones
    tr = []
    for k in range(0, len(paso), 100):
        s = slice(k, min(k + 100, len(paso)))
        r_ = ratio  # noqa
        xyk = xy[s]
        cam = np.sum(np.linalg.norm(np.diff(xyk, axis=0), axis=1))
        vk = np.abs(v[s]) * FACTOR * DT
        tr.append(f"{k}-{min(k+100,len(paso))-1}: {cam*100:.0f}/{vk.sum()*100:.0f} cm")
    print("        tramos camino/comandado: " + " · ".join(tr))
