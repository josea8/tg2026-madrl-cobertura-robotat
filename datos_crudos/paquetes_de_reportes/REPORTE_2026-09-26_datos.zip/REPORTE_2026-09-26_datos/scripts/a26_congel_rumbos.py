# -*- coding: utf-8 -*-
"""a26_congel_rumbos.py — pasos vivos por los puntos de pérdida del 26-09 y su dirección (sólo lectura)."""
import math, sys, io, importlib.util
spec = importlib.util.spec_from_file_location('A', r'C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_congel_analisis.py')
_old = sys.stdout; sys.stdout = io.StringIO()
A = importlib.util.module_from_spec(spec); spec.loader.exec_module(A)
sys.stdout = _old; sys.stdout.reconfigure(encoding='utf-8')
S, I = A.S, A.I
PUNTOS = {'A (2.541,2.19)': (2.541, 2.190), 'B (2.817,2.49)': (2.817, 2.490), 'C (2.52,2.80)': (2.52, 2.80), 'E (0.428,2.480)': (0.428, 2.480)}
R = 0.04
for fecha in ['11-09', '24-09', '26-09']:
    print('=' * 100); print(fecha)
    for nom, (cx, cy) in PUNTOS.items():
        pasos = []
        for s in S[fecha]:
            f = s['f']; dentro = False
            for k, r in enumerate(f):
                a = math.hypot(r['x'] - cx, r['y'] - cy) < R
                if a and not dentro:
                    k0 = k
                if dentro and not a:
                    seg = f[k0:k]
                    # rumbo de paso: desde fila k0-2 a k+1
                    p0 = f[max(0, k0 - 2)]; p1 = f[min(len(f) - 1, k + 1)]
                    rumbo = math.degrees(math.atan2(p1['y'] - p0['y'], p1['x'] - p0['x']))
                    cong = any(x['ini'] for x in f[k0:k + 1])
                    pasos.append((s['ep'], s['robot'], seg[0]['paso'], len(seg), round(rumbo), cong, sum(not x['rep'] for x in seg)))
                dentro = a
            if dentro:
                seg = f[k0:]
                cong = any(x['ini'] for x in seg)
                p0 = f[max(0, k0 - 2)]; p1 = f[-1]
                rumbo = math.degrees(math.atan2(p1['y'] - p0['y'], p1['x'] - p0['x']))
                pasos.append((s['ep'], s['robot'], seg[0]['paso'], len(seg), round(rumbo), cong, sum(not x['rep'] for x in seg)))
        print(f'  {nom}: {len(pasos)} pasos a < {R*100:.0f} cm; con inicio {sum(p[5] for p in pasos)}')
        for p in pasos:
            print(f'     ep{p[0]:2d} r{p[1]} desde paso {p[2]:3d} filas {p[3]:2d} (vivas {p[6]:2d}) rumbo del paso {p[4]:+4d}°  {"<<< CONGELA" if p[5] else ""}')
