# -*- coding: utf-8 -*-
"""a26_congel_mapa.py — mapa (marco del entorno) de los eventos de pose repetida
del 26-09 con las sesiones anteriores y las referencias 29-08 / 09-09. Sólo lectura.
Salida: a26_congel_mapa.png en el scratchpad."""
import math, sys, io, importlib.util
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
spec = importlib.util.spec_from_file_location('A', r'C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_congel_analisis.py')
_old = sys.stdout; sys.stdout = io.StringIO()
A = importlib.util.module_from_spec(spec); spec.loader.exec_module(A)
sys.stdout = _old; sys.stdout.reconfigure(encoding='utf-8')
S, I = A.S, A.I
OUT = r'C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_congel_mapa.png'

SURF, TXT, TXT2, GRID = '#fcfcfb', '#0b0b0b', '#52514e', '#d9d8d4'
C_REC, C_FAIL, C_CENS = '#2a78d6', '#eb6834', '#1baf7a'   # slots 1-3 (all-pairs OK)
C_PREV = '#8a8984'

res = {(1, 245): 'r', (4, 233): 'r', (5, 20): 'f', (6, 167): 'f', (7, 55): 'r', (7, 111): 'f', (10, 25): 'f',
       (11, 426): 'f', (13, 378): 'f', (17, 467): 'R', (17, 497): 'c', (19, 94): 'r'}
fuera26 = [(2.47, 2.41), (2.36, 2.23), (2.10, 2.42), (2.71, 2.09), (1.31, 0.56)]
fuera24 = [(2.37, 2.45), (0.40, 2.44), (1.79, 0.25)]
refs = {'29-08 quieto': A.lab2env(1.361, 1.215), '09-09 MATLAB': A.lab2env(1.479, 1.041)}

vx = [r['x'] for s in S['26-09'] for r in s['f'] if not r['rep']]
vy = [r['y'] for s in S['26-09'] for r in s['f'] if not r['rep']]

fig, axes = plt.subplots(1, 2, figsize=(13.5, 6.6), facecolor=SURF)
for k, ax in enumerate(axes):
    ax.set_facecolor(SURF)
    ax.scatter(vx, vy, s=0.6 if k == 0 else 2.0, c=GRID, linewidths=0, zorder=1, rasterized=True)
    ax.add_patch(Rectangle((0, 0), 3, 3, fill=False, ec=TXT2, lw=1.2, zorder=2))
    # previos
    prev = [(it['r']['x'], it['r']['y']) for f in ['11-09', '22-09', '24-09'] for it in I[f]]
    ax.scatter(*zip(*prev), marker='^', s=46, facecolors='none', edgecolors=C_PREV, linewidths=1.3, zorder=3)
    ax.scatter(*zip(*fuera24), marker='^', s=46, facecolors='none', edgecolors=C_PREV, linewidths=1.0, linestyle=':', zorder=3)
    # fuera de episodio 26-09
    ax.scatter(*zip(*fuera26), marker='D', s=44, facecolors='none', edgecolors=TXT, linewidths=1.2, zorder=4)
    # 26-09 en episodio
    for it in I['26-09']:
        key = (it['s']['ep'], it['r']['paso']); t = res[key]
        col = {'r': C_REC, 'R': C_REC, 'f': C_FAIL, 'c': C_CENS}[t]
        mk = {'r': 'o', 'R': 'P', 'f': 'X', 'c': 's'}[t]
        if t == 'c':
            ax.scatter(it['r']['x'], it['r']['y'], marker=mk, s=80 if k == 0 else 190, facecolors='none', edgecolors=col, linewidths=2.0, zorder=5)
        else:
            ax.scatter(it['r']['x'], it['r']['y'], marker=mk, s=80 if k == 0 else 130, c=col, edgecolors=SURF, linewidths=1.5, zorder=7 if t == 'R' else 5)
        if k == 1 and key not in [(5, 20), (7, 111), (10, 25), (17, 467), (17, 497), (4, 233), (11, 426)]:
            dx, dy = {(17, 497): (0.012, -0.03), (17, 467): (-0.075, -0.035), (10, 25): (0.012, -0.012), (5, 20): (0.012, 0.012),
                      (7, 111): (0.012, 0.008), (6, 167): (-0.085, 0.01), (13, 378): (0.012, -0.02)}.get(key, (0.012, 0.01))
            ax.annotate(f"ep{key[0]} r{it['s']['robot']}", (it['r']['x'] + dx, it['r']['y'] + dy), fontsize=8, color=TXT2, zorder=6)
    for nom, (x, y) in refs.items():
        ax.scatter(x, y, marker='*', s=190, c=TXT, edgecolors=SURF, linewidths=1.0, zorder=6)
        if k == 1:
            ax.annotate(nom, (x, y), xytext=(-78, 8) if nom.startswith('29') else (-80, -14), textcoords='offset points', fontsize=8.5, color=TXT)
    ax.set_aspect('equal')
    ax.tick_params(colors=TXT2, labelsize=8.5)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_xlabel('x del entorno [m]', color=TXT2, fontsize=9)
    ax.set_ylabel('y del entorno [m]', color=TXT2, fontsize=9)
axes[0].set_xlim(-0.08, 3.08); axes[0].set_ylim(-0.08, 3.08)
axes[0].add_patch(Rectangle((2.30, 2.02), 0.72, 0.90, fill=False, ec=TXT2, lw=0.8, ls='--', zorder=2))
axes[0].set_title('Arena 3 × 3 m (gris claro: filas vivas del 26-09)', color=TXT, fontsize=10.5, loc='left')
axes[1].set_xlim(2.30, 3.02); axes[1].set_ylim(2.02, 2.92)
axes[1].set_title('Esquina +x+y (recuadro)', color=TXT, fontsize=10.5, loc='left')
for nom, (x, y, txt) in {'A': (2.32, 2.245, 'A  lab (+1.03, +0.92), d_pared 0.44–0.47\nep5 r6 · ep7 r9 · ep10 r6 · ep17 r8 (×2)'),
                         'B': (2.86, 2.40, 'B  lab (+1.30, +1.20)\nd 0.18–0.19'),
                         'C': (2.32, 2.845, 'C  lab (+1.01, +1.50), d 0.19–0.24\nep4 r6 · ep11 r5 · ep19 r5')}.items():
    axes[1].annotate(txt, (x, y), fontsize=8.5, color=TXT, fontweight='bold' if False else 'normal')
# leyenda
from matplotlib.lines import Line2D
h = [Line2D([], [], marker='o', ls='', color=C_REC, ms=8, label='26-09 recuperada ≤ 0.3 s (pasó de largo)'),
     Line2D([], [], marker='P', ls='', color=C_REC, ms=9, label='26-09 recuperada por el retroceso (2.0 s)'),
     Line2D([], [], marker='X', ls='', color=C_FAIL, ms=9, label='26-09 sigue congelada → aborto'),
     Line2D([], [], marker='s', ls='', mfc='none', mec=C_CENS, mew=2, ms=9, label='26-09 re-entrada, cortada por fin de episodio'),
     Line2D([], [], marker='D', ls='', mfc='none', mec=TXT, ms=7, label='26-09 fuera de episodio (consola)'),
     Line2D([], [], marker='^', ls='', mfc='none', mec=C_PREV, ms=8, label='11, 22 y 24-09 (CSV y consola 24-09)'),
     Line2D([], [], marker='*', ls='', color=TXT, ms=12, label='referencias lab 29-08 y 09-09')]
fig.legend(handles=h, loc='lower center', ncol=4, frameon=False, fontsize=8.5, labelcolor=TXT)
fig.suptitle('Poses congeladas (última pose viva) — evaluación del 26-09 contra sesiones anteriores', color=TXT, fontsize=12, x=0.01, ha='left')
fig.tight_layout(rect=(0, 0.07, 1, 0.95))
fig.savefig(OUT, dpi=150, facecolor=SURF)
print('guardado', OUT)
