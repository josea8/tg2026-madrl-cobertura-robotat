"""Utilidades comunes (solo lectura) para el análisis del 26-09: supervivencia,
diversidad y seguridad. Prefijo a26_superv_."""
import csv
import numpy as np
import pandas as pd

RS = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
      r"\coordinador_enjambre\resultados_sesion")
COORD = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
         r"\coordinador_enjambre")

ARENA = 3.0
ZX, ZY = 2.35, 2.0          # zona esquina +x+y (marco env): x >= 2.35 y y >= 2.0
PARED = 0.35


def leer_ep(nombre):
    with open(f"{RS}\\{nombre}", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def leer_dec(nombre):
    d = pd.read_csv(f"{RS}\\{nombre}")
    d = d.sort_values(["episodio", "agente", "paso"]).reset_index(drop=True)
    x, y = d["pose_env_x"].to_numpy(), d["pose_env_y"].to_numpy()
    d["d_pared"] = np.minimum.reduce([x, ARENA - x, y, ARENA - y])
    d["zona"] = (x >= ZX) & (y >= ZY)
    d["cerca"] = d["d_pared"] < PARED
    # fila repetida: (x, y, θ) EXACTAMENTE igual a la fila anterior del mismo
    # (episodio, agente)
    g = d.groupby(["episodio", "agente"])
    rep = ((d["pose_env_x"] == g["pose_env_x"].shift(1))
           & (d["pose_env_y"] == g["pose_env_y"].shift(1))
           & (d["pose_env_th"] == g["pose_env_th"].shift(1)))
    d["repetida"] = rep.fillna(False).astype(bool)
    prev_rep = g["repetida"].shift(1).fillna(False).astype(bool)
    d["inicio_cong"] = d["repetida"] & ~prev_rep
    d["viva"] = ~d["repetida"]
    return d


def rachas(d):
    """Rachas de filas repetidas: (ep, agente, paso_inicio, largo, x, y, d_pared)."""
    out = []
    for (ep, ag), s in d.groupby(["episodio", "agente"]):
        s = s.sort_values("paso")
        rp = s["repetida"].to_numpy()
        pasos = s["paso"].to_numpy()
        i = 0
        while i < len(rp):
            if rp[i]:
                j = i
                while j + 1 < len(rp) and rp[j + 1]:
                    j += 1
                fila = s.iloc[i]
                out.append(dict(episodio=int(ep), agente=int(ag),
                                paso_ini=int(pasos[i]), largo=int(j - i + 1),
                                x=float(fila.pose_env_x), y=float(fila.pose_env_y),
                                d_pared=float(fila.d_pared),
                                zona=bool(fila.zona),
                                llega_al_final=bool(j == len(rp) - 1)))
                i = j + 1
            else:
                i += 1
    return pd.DataFrame(out)


def env_a_lab(xe, ye, escala=1.0166876, rot=0.0084726,
              tras=(1.5061547, 1.2563353)):
    """Inverso de env = R·(escala·lab) + tras."""
    vx, vy = xe - tras[0], ye - tras[1]
    c, s = np.cos(-rot), np.sin(-rot)
    return (c * vx - s * vy) / escala, (s * vx + c * vy) / escala


def lab_a_env(xl, yl, escala=1.0166876, rot=0.0084726,
              tras=(1.5061547, 1.2563353)):
    c, s = np.cos(rot), np.sin(rot)
    return (c * escala * xl - s * escala * yl + tras[0],
            s * escala * xl + c * escala * yl + tras[1])
