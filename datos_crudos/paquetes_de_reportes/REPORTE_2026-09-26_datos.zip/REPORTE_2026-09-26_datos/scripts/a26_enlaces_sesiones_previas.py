# Motivos de invalidez de sesiones anteriores, clasificados (robot/enlace vs seguimiento de marcador).
import csv, glob, os, re
from collections import Counter
base = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"
for f in ["20260911_sesion-evaluacion_etapa7_episodios.csv", "20260922_sesion-evaluacion_etapa7_episodios.csv",
          "20260922_sesion-evaluacion_etapa7_episodios_02.csv", "20260922_sesion-evaluacion_etapa7_episodios_03.csv",
          "20260924_sesion-evaluacion_etapa7_episodios.csv", "20260926_sesion-evaluacion_etapa7_episodios.csv"]:
    rows = list(csv.DictReader(open(os.path.join(base, f), encoding="utf-8")))
    c = Counter()
    det = []
    for r in rows:
        m = r.get("motivo", "") or ""
        if r.get("valido") in ("1", "True", "true"):
            c["válido"] += 1; continue
        if "NO SIGUE" in m: k = "no sigue"
        elif "enlace" in m.lower(): k = "enlace"
        elif "CONGELADO" in m or "congelad" in m: k = "marcador congelado"
        elif "antigüedad" in m or "vieja" in m: k = "antigüedad pose"
        elif "rpm" in m.lower(): k = "rpm"
        elif "pared" in m or "separad" in m or "arena" in m: k = "chequeo arranque"
        else: k = "otro"
        c[k] += 1
        if k in ("no sigue", "enlace", "antigüedad pose", "otro"):
            det.append(f"ep{r.get('episodio')}: {m[:110]}")
    extra = ""
    if "col_estado_a0" in rows[0]:
        noav = sum(1 for r in rows for a in range(5) if r.get(f"col_estado_a{a}") == "no avanza")
        extra = f" · col_estado 'no avanza' en arranques: {noav}"
    print(f"{f}: {len(rows)} filas · {dict(c)}{extra}")
    for d in det: print("     ", d)
