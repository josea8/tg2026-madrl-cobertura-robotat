import csv, math, json
import numpy as np
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_decisiones.csv"
E = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_episodios.csv"
CAL = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\calibracion_medida.json"
rows = list(csv.DictReader(open(D, encoding="utf-8")))
def serie(e, a):
    return sorted([r for r in rows if r["episodio"] == str(e) and r["agente"] == str(a)], key=lambda r: int(r["paso"]))
# 1) ep 4, agente 3, pasos 228-238
print("ep 4 agente 3 (robot 6), pasos 228-238:")
rs = serie(4, 3)
for r in rs[228:239]:
    print(f"  paso {r['paso']}: x={float(r['pose_env_x']):.6f} y={float(r['pose_env_y']):.6f} th={float(r['pose_env_th']):.6f} en_retroceso={r['en_retroceso']}")
# otras filas repetidas en el ep 4 (cualquier agente)
for a in range(5):
    s = serie(4, a)
    rep = [int(s[k]['paso']) for k in range(1, len(s)) if (s[k]['pose_env_x'], s[k]['pose_env_y'], s[k]['pose_env_th']) == (s[k-1]['pose_env_x'], s[k-1]['pose_env_y'], s[k-1]['pose_env_th'])]
    if rep: print(f"  ep 4 agente {a}: pasos con pose idéntica a la anterior: {rep}")
# tick del aviso: ticks acumulados con (decisiones+1)*10 por episodio
ep = {int(r["episodio"]): r for r in csv.DictReader(open(E, encoding="utf-8"))}
acum = sum((int(ep[k]["decisiones"]) + 1) * 10 for k in (1, 2, 3))
print(f"ticks acumulados antes del ep 4 (modelo (decisiones+1)·10): {acum} → tick 12640 = decisión {(12640 - acum) / 10:.0f} del ep 4;"
      f" con decisiones·10: {(12640 - sum(int(ep[k]['decisiones']) * 10 for k in (1,2,3))) / 10:.0f}")
# 2) mínimo del seguimiento en ventana deslizante de 50 para agente 3 en ep 6 y 7
for e in (6, 7):
    s = serie(e, 3)
    xy = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in s])
    v = np.array([abs(float(r["v_ejecutada"])) for r in s]) * 0.4 * 0.1
    av = np.r_[0, np.linalg.norm(np.diff(xy, axis=0), axis=1)]
    rat = [av[k-49:k+1].sum() / v[k-49:k+1].sum() for k in range(50, len(s))]
    w = np.array([float(r["w_ejecutada"]) for r in s]) * 0.4
    th = np.unwrap([float(r["pose_env_th"]) for r in s])
    dth = np.diff(th) / 0.1
    cc = np.corrcoef(dth, w[1:])[0, 1]
    frac_signo = np.mean(np.sign(dth) != np.sign(w[1:]))
    print(f"ep {e} robot 6: seguimiento en ventanas de 50 → mín {min(rat)*100:.1f} %, máx {max(rat)*100:.1f} % (umbral 50 %);"
          f" corr(ω medido, ω comandado) = {cc:.2f}; decisiones con signo de giro opuesto al comandado: {frac_signo*100:.0f} %")
# 3) cobertura sin el ep 8
cov = {k: float(r["cobertura_aoi"]) for k, r in ep.items() if r["valido"] == "1"}
v = np.array(list(cov.values()))
v8 = np.array([c for k, c in cov.items() if k != 8])
print(f"cobertura válidos n={len(v)}: media {v.mean():.4f} sd {v.std(ddof=1):.4f}; sin ep 8 n={len(v8)}: media {v8.mean():.4f} sd {v8.std(ddof=1):.4f}")
# error de colocación normal (sin los abandonos)
errs = []
for k, r in ep.items():
    for a in range(5):
        if r[f"col_estado_a{a}"] == "listo":
            errs.append(math.hypot(float(r[f"x0_a{a}"]) - float(r[f"blanco_x_a{a}"]), float(r[f"y0_a{a}"]) - float(r[f"blanco_y_a{a}"])))
errs = np.array(errs)
print(f"|x0-blanco| de robots 'listo': n={len(errs)} mediana {np.median(errs):.3f} m, máx {errs.max():.3f} m")
# 4) posiciones congeladas de los rechazos → marco lab
cal = json.load(open(CAL, encoding="utf-8"))
print("claves calibración:", [k for k in cal.keys()][:20])
