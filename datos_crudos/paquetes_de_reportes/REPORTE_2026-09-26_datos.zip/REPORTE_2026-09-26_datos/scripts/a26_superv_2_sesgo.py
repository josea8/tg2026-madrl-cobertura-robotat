"""2) Sesgo de supervivencia 26-09: exposición a pared / zona +x+y a igualdad
de tiempo transcurrido, válidos contra inválidos por congelamiento."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import numpy as np
import pandas as pd
from scipy import stats
from a26_superv_comun import leer_ep, leer_dec, rachas, ZX, ZY

E = leer_ep("20260926_sesion-evaluacion_etapa7_episodios.csv")
D = leer_dec("20260926_sesion-evaluacion_etapa7_decisiones.csv")
R = rachas(D)
val = [int(r["episodio"]) for r in E if r["valido"] == "1"]
cong = [int(r["episodio"]) for r in E if "CONGELADO" in r["motivo"]]
nosig = [int(r["episodio"]) for r in E if "NO SIGUE" in r["motivo"]]
dec = {int(r["episodio"]): int(r["decisiones"]) for r in E}
cob = {int(r["episodio"]): float(r["cobertura_aoi"]) for r in E}
print("válidos", val, "\ncongelados", cong, "\nno sigue", nosig)

# inicio de la racha FATAL de cada congelado (la que llega al final)
onset = {}
for ep in cong:
    rr = R[(R.episodio == ep) & (R.llega_al_final)]
    onset[ep] = int(rr.paso_ini.iloc[0])
print("inicio de la racha fatal:", onset)


def expo(ep, lo, hi, solo_vivas=False, cual="cerca"):
    s = D[(D.episodio == ep) & (D.paso >= lo) & (D.paso < hi)]
    if solo_vivas:
        s = s[s.viva]
    return float(s[cual].mean()) if len(s) else np.nan


def comparar(ventana_de, etiqueta, solo_vivas=False):
    print(f"\n--- {etiqueta} ---")
    print(" ep_inv  ventana      métrica   inv    válidos: media  min    max   "
          "#válidos<inv  #empates  pct_inv")
    us = {"cerca": [], "zona": [], "d020": []}
    for ep in cong:
        lo, hi = ventana_de(ep)
        if hi <= lo:
            print(f"  {ep}: ventana vacía")
            continue
        for cual in ("cerca", "zona"):
            vi = expo(ep, lo, hi, solo_vivas, cual)
            vv = np.array([expo(j, lo, hi, solo_vivas, cual) for j in val])
            menos = int((vv < vi).sum())
            emp = int((vv == vi).sum())
            u = (menos + 0.5 * emp) / len(vv)
            us[cual].append(u)
            print(f"  {ep:5d}  [{lo:3d},{hi:3d})  {cual:6s}  {vi:.4f}   "
                  f"{vv.mean():.4f}  {vv.min():.4f} {vv.max():.4f}   "
                  f"{menos:2d}/10      {emp:2d}     {100*u:5.1f}")
    # combinación aproximada: media de percentiles, nulo = rangos uniformes
    # INDEPENDIENTES entre episodios (aproximación: los válidos se comparten)
    rng = np.random.default_rng(0)
    for cual in ("cerca", "zona"):
        u = np.array(us[cual])
        if not len(u):
            continue
        # nulo: rango del inválido entre 11 uniforme → u ∈ {0,0.1,...,1.0}
        sim = rng.integers(0, 11, size=(200000, len(u))) / 10.0
        m = sim.mean(axis=1)
        p_hi = float(np.mean(m >= u.mean()))
        p_lo = float(np.mean(m <= u.mean()))
        print(f"  {cual}: percentil medio de los inválidos entre los válidos = "
              f"{100*u.mean():.1f} (nulo 50); P(≥)={p_hi:.3f}, P(≤)={p_lo:.3f} "
              f"[aprox., rangos independientes]")


# A) ventana [0, inicio de la racha fatal): sólo antes del congelamiento
comparar(lambda ep: (0, onset[ep]), "A) primeras decisiones HASTA el inicio del congelamiento fatal (todas las filas)")
# B) literal: N = decisiones del inválido (incluye la cola congelada)
comparar(lambda ep: (0, dec[ep]), "B) primeras N = decisiones del inválido (incluye la cola congelada, pose retenida)")
comparar(lambda ep: (0, dec[ep]), "B') primeras N = decisiones del inválido, sólo filas vivas", solo_vivas=True)
# C) sin la aproximación final: [0, inicio − 20) (2 s antes)
comparar(lambda ep: (0, max(onset[ep] - 20, 0)), "C) [0, inicio − 20): excluye los 2 s de entrada al punto ciego")

# E3) horizontes comunes: todos los intentos que llegan a N
print("\n=== Exposición en las primeras N decisiones, por grupo (sólo intentos con dec >= N) ===")
print("  N    grupo        n   f_cerca(media)  f_zona(media)   f_zona vivas")
for N in (45, 100, 135, 191, 300, 402, 451, 500):
    for gname, eps in (("válidos", val), ("congelados", cong), ("no_sigue", nosig),
                       ("TODOS", val + cong + nosig)):
        ee = [e for e in eps if dec[e] >= N]
        if not ee:
            continue
        fc = np.mean([expo(e, 0, N, False, "cerca") for e in ee])
        fz = np.mean([expo(e, 0, N, False, "zona") for e in ee])
        fzv = np.mean([expo(e, 0, N, True, "zona") for e in ee])
        print(f"  {N:3d}  {gname:10s} {len(ee):3d}   {fc:.4f}          {fz:.4f}          {fzv:.4f}")

# Mann-Whitney en la ventana común de 45 decisiones (todos los 19 la tienen)
print("\n=== Primeras 45 decisiones (los 19 intentos): Mann-Whitney válidos vs congelados ===")
for cual in ("cerca", "zona"):
    for vivas in (False, True):
        a = [expo(e, 0, 45, vivas, cual) for e in val]
        b = [expo(e, 0, 45, vivas, cual) for e in cong]
        U = stats.mannwhitneyu(b, a, alternative="two-sided", method="exact")
        print(f"  {cual} {'vivas' if vivas else 'todas'}: congelados {np.round(b,4)} "
              f"vs válidos media {np.mean(a):.4f} [{min(a):.4f},{max(a):.4f}] · U={U.statistic:.1f} p={U.pvalue:.3f}")

# ── arranques cerca de la zona ────────────────────────────────────────────
print("\n=== Arranques (x0 medida y blanco) respecto de la zona +x+y y del bolsillo (2.54, 2.20) ===")
P1 = np.array([2.54, 2.20])
filas = []
for r in E:
    ep = int(r["episodio"])
    x0 = np.array([[float(r[f"x0_a{i}"]), float(r[f"y0_a{i}"])] for i in range(5)])
    bl = np.array([[float(r[f"blanco_x_a{i}"]), float(r[f"blanco_y_a{i}"])] for i in range(5)])
    enz0 = int(((x0[:, 0] >= ZX) & (x0[:, 1] >= ZY)).sum())
    enzb = int(((bl[:, 0] >= ZX) & (bl[:, 1] >= ZY)).sum())
    dP1_0 = np.linalg.norm(x0 - P1, axis=1).min()
    dP1_b = np.linalg.norm(bl - P1, axis=1).min()
    grp = "válido" if ep in val else ("congelado" if ep in cong else "no_sigue")
    extra = ""
    if ep in cong:
        ag = int(r["motivo"].split("agente ")[1].split(" ")[0])
        extra = (f" · congelado a{ag}: x0 ({x0[ag,0]:.2f},{x0[ag,1]:.2f}) "
                 f"d(x0,P1)={np.linalg.norm(x0[ag]-P1):.2f} · inicio {onset[ep]}")
    filas.append(dict(ep=ep, grp=grp, enz0=enz0, enzb=enzb, dP1_0=dP1_0, dP1_b=dP1_b))
    print(f"  ep {ep:2d} {grp:9s} agentes en zona al arrancar x0={enz0} blanco={enzb} · "
          f"agente más cercano a P1: x0 {dP1_0:.2f} m, blanco {dP1_b:.2f} m{extra}")
F = pd.DataFrame(filas)
print(F.groupby("grp")[["enz0", "enzb", "dP1_0", "dP1_b"]].mean().to_string(float_format=lambda v: f"{v:.3f}"))
a = F[F.grp == "válido"].dP1_b
b = F[F.grp == "congelado"].dP1_b
print(f"  d(blanco más cercano, P1): válidos {np.round(sorted(a),2)} · congelados {np.round(sorted(b),2)} · "
      f"MW exacto p={stats.mannwhitneyu(b, a, method='exact').pvalue:.3f}")

# ── cobertura vs exposición entre los válidos ─────────────────────────────
print("\n=== Válidos (n=10): cobertura vs exposición (Spearman) ===")
T = pd.read_csv(r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_superv_tabla.csv")
V = T[T.valido == 1]
for c in ("f_cerca", "f_zona", "f_d020", "cbf", "esc", "dpmin"):
    rho, p = stats.spearmanr(V.cob, V[c])
    r_, pr = stats.pearsonr(V.cob, V[c])
    print(f"  cob vs {c:8s}: Spearman rho={rho:+.3f} p={p:.3f} · Pearson r={r_:+.3f} p={pr:.3f}")

# ── cobertura parcial de los inválidos largos ─────────────────────────────
print("\n=== Cobertura al abortar (no comparable: AoI envejece; sólo descriptiva) ===")
for ep in sorted(cong + nosig):
    print(f"  ep {ep:2d} dec {dec[ep]:3d} cobertura {cob[ep]:.4f}")
vv = np.array([cob[e] for e in val])
print(f"  válidos (500): media {vv.mean():.4f} sd {vv.std(ddof=1):.4f} min {vv.min():.4f} max {vv.max():.4f}")
largos = [e for e in cong + nosig if dec[e] >= 400]
print(f"  inválidos con >=400 decisiones: {largos} → coberturas {[round(cob[e],4) for e in largos]}")
print(f"  media válidos + largos (n={len(val)+len(largos)}): {np.mean(list(vv)+[cob[e] for e in largos]):.4f}")

# ── seguridad a igualdad de tiempo: tasas por 1000 decisiones-agente ──────
print("\n=== Tasas de seguridad por decisión-agente (todas las filas) ===")
for gname, eps in (("válidos", val), ("congelados", cong), ("no_sigue", nosig)):
    s = D[D.episodio.isin(eps)]
    print(f"  {gname:10s} n_filas {len(s):6d} · CBF {s.cbf_intervino.mean():.4f} · "
          f"escape por 1000 {1000*s.en_escape.mean():.1f} · d<0.18 por 1000 {1000*(s.d_pared<0.18).mean():.1f}")
print("  ventana A (hasta el inicio fatal) — CBF y escape, inválido vs válidos en la misma ventana:")
for ep in cong:
    hi = onset[ep]
    si = D[(D.episodio == ep) & (D.paso < hi)]
    sv = D[(D.episodio.isin(val)) & (D.paso < hi)]
    print(f"    ep {ep:2d} [0,{hi:3d}): CBF {si.cbf_intervino.mean():.4f} vs {sv.cbf_intervino.mean():.4f} · "
          f"escape/1000 {1000*si.en_escape.mean():.1f} vs {1000*sv.en_escape.mean():.1f}")

# ── tasa de congelamiento por zona y por banda de pared (filas vivas) ─────
print("\n=== Inicios de racha repetida por 1000 decisiones-agente VIVAS (26-09, 19 intentos) ===")
viva = D[D.viva]
ini = D[D.inicio_cong]
for nombre, m_v, m_i in (
        ("zona +x+y", viva.zona, ini.zona),
        ("fuera de zona", ~viva.zona, ~ini.zona),
        ("d<0.20", viva.d_pared < 0.20, ini.d_pared < 0.20),
        ("0.20-0.35", (viva.d_pared >= 0.20) & (viva.d_pared < 0.35), (ini.d_pared >= 0.20) & (ini.d_pared < 0.35)),
        ("0.35-0.60", (viva.d_pared >= 0.35) & (viva.d_pared < 0.60), (ini.d_pared >= 0.35) & (ini.d_pared < 0.60)),
        (">=0.60", viva.d_pared >= 0.60, ini.d_pared >= 0.60),
        ("zona y d<0.35", viva.zona & (viva.d_pared < 0.35), ini.zona & (ini.d_pared < 0.35)),
        ("zona y d>=0.35", viva.zona & (viva.d_pared >= 0.35), ini.zona & (ini.d_pared >= 0.35)),
        ("fuera zona y d<0.35", ~viva.zona & (viva.d_pared < 0.35), ~ini.zona & (ini.d_pared < 0.35))):
    nv, ni = int(m_v.sum()), int(m_i.sum())
    print(f"  {nombre:20s}: {ni:2d} / {nv:6d} = {1000*ni/max(nv,1):6.2f} ‰")
a = int(ini.zona.sum()); b = int(viva.zona.sum()); c = int((~ini.zona).sum()); d = int((~viva.zona).sum())
OR, p = stats.fisher_exact([[a, b - a], [c, d - c]])
print(f"  Fisher zona vs fuera: OR={OR:.1f} p={p:.2e}")
