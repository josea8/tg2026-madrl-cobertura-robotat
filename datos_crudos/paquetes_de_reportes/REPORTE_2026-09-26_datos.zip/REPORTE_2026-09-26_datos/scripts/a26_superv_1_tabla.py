"""1) Tabla por episodio del 26-09 (19 intentos) + verificación de métricas
recalculadas desde el CSV de decisiones + rachas de pose repetida."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import numpy as np
import pandas as pd
from a26_superv_comun import leer_ep, leer_dec, rachas, env_a_lab, lab_a_env, ZX, ZY

pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 40)
pd.set_option("display.max_rows", 200)

E = leer_ep("20260926_sesion-evaluacion_etapa7_episodios.csv")
D = leer_dec("20260926_sesion-evaluacion_etapa7_decisiones.csv")


def corto(m):
    if not m:
        return "válido"
    if "CONGELADO" in m:
        ag = m.split("agente ")[1].split(" ")[0]
        rob = m.split("(robot ")[1].split(")")[0]
        return f"congel. a{ag}/r{rob}"
    if "NO SIGUE" in m:
        ag = m.split("agente ")[1].split(" ")[0]
        pct = m.split("recorrió el ")[1].split(" %")[0]
        return f"no sigue a{ag} ({pct}%)"
    return m[:30]


filas = []
for r in E:
    ep = int(r["episodio"])
    s = D[D.episodio == ep]
    n = len(s)
    viva = s[s.viva]
    # verificación
    dpmin_ag = s.groupby("agente")["d_pared"].min()
    cbf = s["cbf_intervino"].mean()
    esc = int(s["en_escape"].sum())
    # colisiones: pares distintos con d<0.15 / 0.22 en alguna decisión
    c15, c22 = set(), set()
    for paso, t in s.groupby("paso"):
        p = t.sort_values("agente")[["pose_env_x", "pose_env_y"]].to_numpy()
        ags = t.sort_values("agente")["agente"].to_numpy()
        for i in range(len(p)):
            for j in range(i + 1, len(p)):
                dd = np.linalg.norm(p[i] - p[j])
                if dd < 0.15:
                    c15.add((ags[i], ags[j]))
                if dd < 0.22:
                    c22.add((ags[i], ags[j]))
    # distancia mínima entre pares (m) en el episodio
    dmin_par = np.inf
    for paso, t in s.groupby("paso"):
        p = t[["pose_env_x", "pose_env_y"]].to_numpy()
        dd = np.linalg.norm(p[:, None] - p[None], axis=2)
        np.fill_diagonal(dd, np.inf)
        dmin_par = min(dmin_par, dd.min())
    # robot 6 (agente 3) lejos de su blanco al arrancar
    err_a3 = float(r["col_err_m_a3"])
    filas.append(dict(
        ep=ep, valido=int(r["valido"]), motivo=corto(r["motivo"]),
        semilla=int(r["semilla"]), dec=int(r["decisiones"]),
        cob=float(r["cobertura_aoi"]),
        dpmin=float(r["d_pared_min"]), viola=int(r["viola_018"]),
        cbf=float(r["frac_cbf"]), esc=int(r["n_escape"]),
        c15=int(r["colisiones_015"]), c22=int(r["colisiones_022"]),
        f_cerca=s["cerca"].mean(), f_zona=s["zona"].mean(),
        f_cerca_v=viva["cerca"].mean(), f_zona_v=viva["zona"].mean(),
        f_d020=(s["d_pared"] < 0.20).mean(),
        n_rep=int(s["repetida"].sum()),
        dmin_par=dmin_par,
        err_col_r6=err_a3,
        # verificaciones
        ok_dp=abs(dpmin_ag.min() - float(r["d_pared_min"])) < 1e-9,
        ok_vi=int((dpmin_ag < 0.18).sum()) == int(r["viola_018"]),
        ok_cbf=abs(cbf - float(r["frac_cbf"])) < 1e-9,
        ok_esc=esc == int(r["n_escape"]),
        ok_c=(len(c15) == int(r["colisiones_015"]) and len(c22) == int(r["colisiones_022"])),
        ok_n=(n == 5 * int(r["decisiones"])),
    ))
T = pd.DataFrame(filas)
print("=== TABLA POR EPISODIO 26-09 (19 intentos) ===")
print("f_cerca = fracción de decisiones-agente con d_pared < 0.35 m (todas las filas)")
print("f_zona  = fracción de decisiones-agente en x>=2.35, y>=2.0 (marco env)")
print("_v = sólo filas vivas (fuera de rachas repetidas)")
cols = ["ep", "valido", "motivo", "dec", "cob", "dpmin", "viola", "cbf", "esc",
        "c15", "c22", "f_cerca", "f_zona", "f_cerca_v", "f_zona_v", "f_d020",
        "n_rep", "dmin_par", "err_col_r6"]
print(T[cols].to_string(index=False, float_format=lambda v: f"{v:.4f}"))
print()
print("verificaciones (todas deben ser True):")
print(T[["ep", "ok_dp", "ok_vi", "ok_cbf", "ok_esc", "ok_c", "ok_n"]].all().to_string())

# resumen por grupo
T["grupo"] = np.where(T.valido == 1, "válido",
                      np.where(T.motivo.str.startswith("congel"), "congelado", "no_sigue"))
print()
print("=== resumen por grupo (media de episodios; exposición hasta el final) ===")
print(T.groupby("grupo")[["dec", "f_cerca", "f_zona", "f_cerca_v", "f_zona_v"]]
      .agg(["mean", "count"]).to_string(float_format=lambda v: f"{v:.4f}"))
# ponderado por decisiones-agente
print()
for gname, gsub in T.groupby("grupo"):
    eps = gsub.ep.tolist()
    s = D[D.episodio.isin(eps)]
    print(f"  {gname:10s} eps {eps}: {len(s)} decisiones-agente · cerca {s.cerca.sum()} "
          f"({s.cerca.mean():.4f}) · zona {s.zona.sum()} ({s.zona.mean():.4f})")

print()
print("=== RACHAS DE POSE REPETIDA (inicio = primera fila igual a la anterior) ===")
R = rachas(D)
R["robot"] = R.agente.map({0: 1, 1: 5, 2: 8, 3: 6, 4: 9})
R["valido_ep"] = R.episodio.map(dict(zip(T.ep, T.valido)))
lab = [env_a_lab(x, y) for x, y in zip(R.x, R.y)]
R["x_lab"] = [l[0] for l in lab]
R["y_lab"] = [l[1] for l in lab]
print(R.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
print(f"rachas: {len(R)}; en zona +x+y: {int(R.zona.sum())}; d_pared<0.35: {int((R.d_pared<0.35).sum())}")

print()
print("referencias en lab → env:")
for nombre, (xl, yl) in {"29-08 marcador quieto": (1.361, 1.215),
                         "09-09 MATLAB pérdida": (1.479, 1.041)}.items():
    xe, ye = lab_a_env(xl, yl)
    print(f"  {nombre}: lab ({xl:+.3f},{yl:+.3f}) → env ({xe:.3f},{ye:.3f}); "
          f"en zona: {xe >= ZX and ye >= ZY}")

T.to_csv(r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_superv_tabla.csv", index=False)
R.to_csv(r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_superv_rachas.csv", index=False)
