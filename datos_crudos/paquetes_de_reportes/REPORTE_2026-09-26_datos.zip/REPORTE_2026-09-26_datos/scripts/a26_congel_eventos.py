# -*- coding: utf-8 -*-
"""
a26_congel_eventos.py — tabla unificada de eventos de pose repetida (en y fuera
de episodio) con marco lab, d_pared, vértice y distancias a las referencias
del 29-08 y 09-09; estadísticas NE / esquinas; modelo del retroceso. Sólo lectura.

Fuera de episodio: poses tomadas de la consola (guía, 2 decimales) — del
26-09 (consola_20260926.txt) y del 24-09 (datos_reporte_20260925/consola).
Las rachas de la guía que son continuación de un congelamiento DENTRO del
episodio anterior se marcan "arrastre" y no se cuentan como eventos nuevos.
"""
import math, sys, io, importlib.util
from collections import Counter
from scipy import stats
spec = importlib.util.spec_from_file_location('A', r'C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_congel_analisis.py')
_old = sys.stdout; sys.stdout = io.StringIO()
A = importlib.util.module_from_spec(spec); spec.loader.exec_module(A)
sys.stdout = _old; sys.stdout.reconfigure(encoding='utf-8')
S, I = A.S, A.I

REF = {'29-08': (1.361, 1.215), '09-09': (1.479, 1.041)}

eventos = []  # dict(fuente, fecha, ep, robot, x, y, estado, nota)
res26 = {  # resultado del retroceso (retrocesos_detalle)
    (1, 245): 'recuperada 0.3 s', (4, 233): 'recuperada 0.1 s', (5, 20): 'sigue_congelada 2.4 s',
    (6, 167): 'sigue_congelada 2.3 s', (7, 55): 'recuperada 0.1 s', (7, 111): 'sigue_congelada 2.3 s',
    (10, 25): 'sigue_congelada 2.3 s', (11, 426): 'sigue_congelada 2.4 s', (13, 378): 'sigue_congelada 2.3 s',
    (17, 467): 'recuperada 2.0 s', (17, 497): 'fin_del_episodio 0.2 s', (19, 94): 'recuperada 0.1 s'}
for it in I['26-09']:
    s, r = it['s'], it['r']
    eventos.append(dict(fuente='CSV', fecha='26-09', ep=s['ep'], robot=s['robot'], paso=r['paso'], x=r['x'], y=r['y'],
                        estado=res26[(s['ep'], r['paso'])], nota=''))
# fuera de episodio 26-09 (consola; ver a26_congel_consola_salida.txt)
fuera26 = [
    ('26-09', 'antes ep2 (colocación autónoma)', 6, 2.47, 2.41, 'colocación: se movía hacia -x desde (2.57, 2.42); x57+x13 refrescos; operador'),
    ('26-09', 'antes ep2 (tras manipulación)', 6, 2.36, 2.23, 'tras SIN POSE (levantado): 1 lectura viva y congelado x8+x14; posible oclusión por la mano'),
    ('26-09', 'antes ep3 (colocación, enlace 10054)', 1, 2.10, 2.42, 'robot 1 sin control fiable (10054); x42; primera viva después (2.80, 2.52)'),
    ('26-09', 'antes ep4 (enlace 10054, "mantiene última orden")', 9, 2.71, 2.09, 'se movió solo desde (1.73, 1.81); x36; primera viva (2.42, 2.14)'),
    ('26-09', 'antes ep15 (operador moviéndolo a mano)', 6, 1.31, 0.56, 'enlace caído; saltos de 36 cm/s = a mano; x4; probable oclusión por la mano'),
]
for fecha, cuando, rob, x, y, nota in fuera26:
    eventos.append(dict(fuente='consola', fecha=fecha, ep=cuando, robot=rob, paso='-', x=x, y=y, estado='fuera de episodio', nota=nota))
for fecha in ['11-09', '22-09', '24-09']:
    for it in I[fecha]:
        s, r = it['s'], it['r']
        eventos.append(dict(fuente='CSV', fecha=fecha, ep=s['ep'], robot=s['robot'], paso=r['paso'], x=r['x'], y=r['y'],
                            estado='aborto 10 filas', nota=s['arch'][-12:]))
for rob, x, y in [(1, 2.37, 2.45), (5, 0.40, 2.44), (5, 1.79, 0.25)]:
    eventos.append(dict(fuente='consola', fecha='24-09', ep='fuera', robot=rob, paso='-', x=x, y=y, estado='fuera de episodio', nota='consola 24-09'))

print('| fecha | fuente | ep | robot | paso | env (x, y) | lab (x, y) | d_pared [pared] | vértice (dist) | a 29-08 | a 09-09 | resultado |')
print('|---|---|---|---|---|---|---|---|---|---|---|---|')
for e in eventos:
    xl, yl = A.env2lab(e['x'], e['y'])
    pw, d, u = A.pared(e['x'], e['y'])
    dv, vn = A.vertice(e['x'], e['y'])
    d29 = math.hypot(xl - REF['29-08'][0], yl - REF['29-08'][1])
    d09 = math.hypot(xl - REF['09-09'][0], yl - REF['09-09'][1])
    e.update(xl=xl, yl=yl, d=d, pw=pw, dv=dv, vn=vn, d29=d29, d09=d09)
    print(f"| {e['fecha']} | {e['fuente']} | {e['ep']} | {e['robot']} | {e['paso']} | ({e['x']:.3f}, {e['y']:.3f}) | ({xl:+.3f}, {yl:+.3f}) | {d:.3f} [{pw}] | {vn} {dv:.2f} | {100*d29:.0f} cm | {100*d09:.0f} cm | {e['estado']} |")

# grupos del 26-09 (en episodio)
print()
print('Grupos 26-09 (en episodio): dispersión y distancias')
grupos = {'A (interior, entra hacia +x)': [(5, 20), (7, 111), (10, 25), (17, 467), (17, 497)],
          'B (x=3, entra hacia +y)': [(6, 167), (13, 378)],
          'C (y=3, entra hacia -x)': [(4, 233), (11, 426), (19, 94)]}
ev26 = {(e['ep'], e['paso']): e for e in eventos if e['fecha'] == '26-09' and e['fuente'] == 'CSV'}
for g, claves in grupos.items():
    pts = [ev26[k] for k in claves]
    cx = sum(p['x'] for p in pts) / len(pts); cy = sum(p['y'] for p in pts) / len(pts)
    dmax = max(math.hypot(p['x'] - q['x'], p['y'] - q['y']) for p in pts for q in pts)
    cxl, cyl = A.env2lab(cx, cy)
    print(f"  {g}: n={len(pts)} robots {sorted(set(p['robot'] for p in pts))} centro env ({cx:.3f}, {cy:.3f}) lab ({cxl:+.3f}, {cyl:+.3f}) "
          f"diámetro {100*dmax:.1f} cm; d_pared {min(p['d'] for p in pts):.3f}–{max(p['d'] for p in pts):.3f}; "
          f"a 29-08 {100*math.hypot(cxl-1.361, cyl-1.215):.0f} cm; a 09-09 {100*math.hypot(cxl-1.479, cyl-1.041):.0f} cm")
# distancias entre centros
print('  distancias entre centros A-B, A-C, B-C:')
cent = {}
for g, claves in grupos.items():
    pts = [ev26[k] for k in claves]
    cent[g[0]] = (sum(p['x'] for p in pts) / len(pts), sum(p['y'] for p in pts) / len(pts))
for a, b in [('A', 'B'), ('A', 'C'), ('B', 'C')]:
    print(f'    {a}-{b}: {100*math.hypot(cent[a][0]-cent[b][0], cent[a][1]-cent[b][1]):.0f} cm')

# vecinos más cercanos de sesiones previas a cada grupo
print('  evento previo más cercano a cada centro (22/24-09 CSV y consola 24-09, 11-09):')
prev = [e for e in eventos if e['fecha'] in ('11-09', '22-09', '24-09')]
for g, (cx, cy) in cent.items():
    m = min(prev, key=lambda e: math.hypot(e['x'] - cx, e['y'] - cy))
    print(f"    {g}: {m['fecha']} {m['fuente']} ep{m['ep']} r{m['robot']} ({m['x']:.3f}, {m['y']:.3f}) a {100*math.hypot(m['x']-cx, m['y']-cy):.0f} cm")
e1 = ev26[(1, 245)]
m = min(prev, key=lambda e: math.hypot(e['x'] - e1['x'], e['y'] - e1['y']))
print(f"    E (ep1 r5 (0.428, 2.480)): {m['fecha']} {m['fuente']} ep{m['ep']} r{m['robot']} ({m['x']:.3f}, {m['y']:.3f}) a {100*math.hypot(m['x']-e1['x'], m['y']-e1['y']):.0f} cm")

# ---------------------------------------------------------------- estadística espacial por fecha
print()
print('Tasas por región (todas las filas) y Fisher 24-09 vs 26-09')
def reg_ne(r): return r['x'] > 2.0 and r['y'] > 2.0
for nom, pred in [('NE (x>2, y>2)', reg_ne), ('resto', lambda r: not reg_ne(r))]:
    fila = []
    tab = {}
    for f in ['11-09', '22-09', '24-09', '26-09']:
        e = sum(1 for s in S[f] for r in s['f'] if pred(r))
        k = sum(1 for it in I[f] if pred(it['r']))
        tab[f] = (k, e)
        fila.append(f'{f} {k}/{e} ({1000*k/max(e,1):.2f} ‰)')
    k1, e1_ = tab['24-09']; k2, e2 = tab['26-09']
    p = stats.fisher_exact([[k1, e1_ - k1], [k2, e2 - k2]])[1]
    print(f'  {nom}: ' + '  '.join(fila) + f'   Fisher 24 vs 26 p = {p:.2g}')
for vn in ['(0,0)', '(3,0)', '(0,3)', '(3,3)']:
    tab = {}
    for f in ['24-09', '26-09']:
        e = sum(1 for s in S[f] for r in s['f'] if A.vertice(r['x'], r['y'])[1] == vn and A.vertice(r['x'], r['y'])[0] < 0.75)
        k = sum(1 for it in I[f] if A.vertice(it['r']['x'], it['r']['y'])[1] == vn and A.vertice(it['r']['x'], it['r']['y'])[0] < 0.75)
        tab[f] = (k, e)
    p = stats.fisher_exact([[tab['24-09'][0], tab['24-09'][1] - tab['24-09'][0]], [tab['26-09'][0], tab['26-09'][1] - tab['26-09'][0]]])[1]
    print(f"  esquina {vn} (vértice < 0.75 m): 24-09 {tab['24-09'][0]}/{tab['24-09'][1]}  26-09 {tab['26-09'][0]}/{tab['26-09'][1]}  Fisher p = {p:.2g}")

print()
print('Franjas de d_pared 26-09 dentro y fuera del cuadrante NE (todas las filas)')
for nom, pred in [('NE', reg_ne), ('resto', lambda r: not reg_ne(r))]:
    et = Counter(A.franja(r['d']) for s in S['26-09'] for r in s['f'] if pred(r))
    ev = Counter(A.franja(it['r']['d']) for it in I['26-09'] if pred(it['r']))
    print(f'  {nom}: ' + '  '.join(f"{fr} {ev[fr]}/{et[fr]} ({1000*ev[fr]/max(et[fr],1):.2f} ‰)" for _, _, fr in A.FRANJAS))

# Fisher de pasos por A hacia +x
print()
print('Pasos por A (r 4 cm) con rumbo hacia +x (|rumbo| < 50°): 24-09 2 vivos / 0 congelan; 26-09 5 / 5 congelan')
print(f"  Fisher bilateral p = {stats.fisher_exact([[0, 2], [5, 0]])[1]:.3f}")
print('Pasos por B (r 4 cm) hacia +y: 11-09 3 + 24-09 1 vivos (0/4); 26-09 2/8 congelan')
print(f"  Fisher bilateral p = {stats.fisher_exact([[0, 4], [2, 6]])[1]:.3f}")

# ---------------------------------------------------------------- modelo del retroceso (ep 17)
print()
print('Modelo de retardo puro del plan (ep 17, inicio 467): v_in, k, camino, fin nominal detrás de la última viva')
f = [s for s in S['26-09'] if s['ep'] == 17 and s['ag'] == 2][0]['f']
idx = {r['paso']: r for r in f}
desp = [math.hypot(idx[p]['x'] - idx[p-1]['x'], idx[p]['y'] - idx[p-1]['y']) for p in range(460, 466)]
v_in = sum(desp) / len(desp) / 0.1
print(f'  v_in medida (pasos 459–465) = {100*v_in:.1f} cm/s; comandada 0.124 m/s (0.31·0.40)')
v, w = 0.31 * 0.40, -1.95 * 0.40
ell = 0.048
rueda = max(abs(v + w * ell), abs(v - w * ell))
k = max(0.5, 0.07 / rueda)
W, M = 0.65, 0.4
print(f'  rueda más rápida {100*rueda:.1f} cm/s → k = {k:.3f}; deshacer {100*v*W:.1f} cm en {W/k:.2f} s; margen {100*M*k*v:.1f} cm en {M:.1f} s; total {100*(v*W + M*k*v):.1f} cm (consola: 10.5 cm)')
for tau in (0.30, 0.45, 0.60):
    # posición relativa a la última viva (t_det - 0.1); + = detrás
    atras_fin = v * (W - (0.1 + tau)) + M * k * v
    t_fin = tau + W / k + M
    print(f'  τ = {tau:.2f} s: fin del retroceso a {100*atras_fin:+.1f} cm detrás de la última viva, a los {t_fin:.2f} s de la detección (aborto a {W/k + M + 0.6:.2f} s)')
p0 = idx[466]; p1 = idx[487]
print(f"  observado: reaparece en paso 487 (2.0 s) a {100*math.hypot(p1['x']-p0['x'], p1['y']-p0['y']):.1f} cm detrás de la última viva (paso 466); resolución a 10 Hz y {100*k*v:.1f} cm/s de retroceso: ±{100*k*v*0.1:.1f} cm")
