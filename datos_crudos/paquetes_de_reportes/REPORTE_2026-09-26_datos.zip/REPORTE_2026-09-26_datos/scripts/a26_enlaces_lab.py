import json, math
import numpy as np
cal = json.load(open(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\calibracion_medida.json", encoding="utf-8"))
s, r, tx, ty = cal["escala_posicion"], cal["rotacion_marco_rad"], cal["traslacion_x_m"], cal["traslacion_y_m"]
print(s, r, tx, ty)
R = np.array([[math.cos(r), -math.sin(r)], [math.sin(r), math.cos(r)]])
for nombre, p in [("ep2 rechazo r6", (2.47, 2.41)), ("ep2 rechazo r6", (2.36, 2.23)), ("ep3 rechazo r1", (2.10, 2.42)), ("ep4 rechazo r9", (2.71, 2.09))]:
    lab = R.T @ (np.array(p) - np.array([tx, ty])) / s
    print(f"{nombre}: env {p} → lab ({lab[0]:+.3f}, {lab[1]:+.3f})")
cov = [0.36425459384918213, 0.38799452781677246, 0.2948719263076782, 0.2697807550430298, 0.35052669048309326, 0.38086605072021484, 0.3819398283958435, 0.37998104095458984, 0.3024955987930298, 0.3648613691329956]
v = np.array(cov); v8 = np.delete(v, 2)
print(f"con ep8: {v.mean():.4f} ± {v.std():.4f} (ddof 0); sin ep8: {v8.mean():.4f} ± {v8.std():.4f} (ddof 0), ± {v8.std(ddof=1):.4f} (ddof 1)")
