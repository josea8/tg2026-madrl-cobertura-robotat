# -*- coding: utf-8 -*-
"""
a26_congel_analisis.py — congelamientos y retroceso del 26-09 (sólo lectura).

Definiciones (las del REPORTE_2026-09-25 y de verificar_cifras.py):
* Secuencia = filas de un (archivo, episodio, agente), ordenadas por paso.
* Fila REPETIDA = (pose_env_x, pose_env_y, pose_env_th) EXACTAMENTE igual a
  la fila anterior de la secuencia. INICIO = primera fila repetida de una racha
  (rep and not prev_rep); su pose = la de la última fila viva.
* d_pared = min(x, 3-x, y, 3-y) en el marco del entorno; pared más cercana con
  el orden de desempate x=0, x=3, y=0, y=3.
* Exposición principal = TODAS las filas de la franja (repetidas incluidas);
  alternativa = filas vivas.
* Marco lab: env = R(rot)·(escala·lab) + tras  ⇒  lab = R(-rot)·(env - tras)/escala.
"""
import csv, math, sys, io, json
from collections import defaultdict, Counter
from pathlib import Path
import numpy as np
from scipy import stats

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
D = Path(r'C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion')
CAL = json.load(open(D.parent / 'calibracion_medida.json', encoding='utf-8'))
ESC, ROT = CAL['escala_posicion'], CAL['rotacion_marco_rad']
TX, TY = CAL['traslacion_x_m'], CAL['traslacion_y_m']
L = 3.0
FRANJAS = [(0.0, 0.20, '<0.20'), (0.20, 0.35, '0.20-0.35'), (0.35, 0.60, '0.35-0.60'), (0.60, math.inf, '>=0.60')]
ARCH = {
    '11-09': ['20260911_sesion-evaluacion_etapa7_decisiones.csv'],
    '22-09': ['20260922_sesion-evaluacion_etapa7_decisiones.csv', '20260922_sesion-evaluacion_etapa7_decisiones_02.csv'],
    '24-09': ['20260924_sesion-evaluacion_etapa7_decisiones.csv'],
    '26-09': ['20260926_sesion-evaluacion_etapa7_decisiones.csv'],
}
DT = 0.1


def env2lab(x, y):
    dx, dy = x - TX, y - TY
    c, s = math.cos(ROT), math.sin(ROT)
    return (c * dx + s * dy) / ESC, (-s * dx + c * dy) / ESC


def lab2env(xl, yl):
    c, s = math.cos(ROT), math.sin(ROT)
    return c * ESC * xl - s * ESC * yl + TX, s * ESC * xl + c * ESC * yl + TY


def pared(x, y):
    ds = [('x=0', x, y), ('x=3', L - x, y), ('y=0', y, x), ('y=3', L - y, x)]
    m = min(ds, key=lambda t: t[1])
    return m[0], m[1], m[2]


def vertice(x, y):
    vs = [(0, 0), (3, 0), (0, 3), (3, 3)]
    d = [(math.hypot(x - a, y - b), f'({a},{b})') for a, b in vs]
    return min(d)


def franja(d):
    for lo, hi, n in FRANJAS:
        if lo <= d < hi:
            return n


def cargar(fecha):
    seqs = []
    for arch in ARCH[fecha]:
        g = defaultdict(list)
        with open(D / arch, newline='', encoding='utf-8-sig') as fh:
            for r in csv.DictReader(fh):
                g[(int(r['episodio']), int(r['agente']))].append(r)
        for (ep, ag), filas in sorted(g.items()):
            filas.sort(key=lambda r: int(r['paso']))
            prev = None; prev_rep = False; recs = []
            for r in filas:
                pf = (float(r['pose_env_x']), float(r['pose_env_y']), float(r['pose_env_th']))
                rep = prev is not None and pf == prev
                pw, d, u = pared(pf[0], pf[1])
                recs.append(dict(paso=int(r['paso']), x=pf[0], y=pf[1], th=pf[2], rep=rep,
                                 ini=rep and not prev_rep, pared=pw, d=d, u=u,
                                 retro=int(r.get('en_retroceso', '0') or 0),
                                 v=float(r['v_ejecutada']), w=float(r['w_ejecutada']),
                                 robot=int(r['robot'])))
                prev, prev_rep = pf, rep
            seqs.append(dict(arch=arch, ep=ep, ag=ag, robot=int(filas[0]['robot']), f=recs))
    return seqs


def inicios(seqs):
    res = []
    for s in seqs:
        f = s['f']
        for i, r in enumerate(f):
            if r['ini']:
                j = i
                while j < len(f) and f[j]['rep']:
                    j += 1
                res.append(dict(s=s, i=i, r=r, largo=j - i, hasta_fin=(j == len(f)), j=j))
    return res


S = {k: cargar(k) for k in ARCH}
I = {k: inicios(v) for k, v in S.items()}

# ----------------------------------------------------------------------------
print('=' * 110)
print('CALIBRACIÓN  escala', ESC, 'rot', ROT, 'tras', TX, TY)
for nom, (xl, yl) in [('29-08 congelado quieto', (1.361, 1.215)), ('09-09 pérdida MATLAB', (1.479, 1.041))]:
    xe, ye = lab2env(xl, yl)
    pw, d, u = pared(xe, ye)
    print(f'  {nom}: lab ({xl:+.3f}, {yl:+.3f}) -> env ({xe:.3f}, {ye:.3f})  d_pared {d:.3f} ({pw})')
print('  control ida y vuelta:', env2lab(*lab2env(1.361, 1.215)))

# ----------------------------------------------------------------------------
print('=' * 110)
print('1) INICIOS 26-09 (CSV de decisiones)')
ep_csv = {int(r['episodio']): r for r in csv.DictReader(open(D / '20260926_sesion-evaluacion_etapa7_episodios.csv', encoding='utf-8-sig'))}
filas26 = []
for it in I['26-09']:
    s, i, r = it['s'], it['i'], it['r']
    f = s['f']
    prev = f[i - 1]  # última viva = pose congelada
    xl, yl = env2lab(r['x'], r['y'])
    dv, vn = vertice(r['x'], r['y'])
    # corrida en_retroceso que contiene/sigue al inicio
    k0 = i
    while k0 < len(f) and not f[k0]['retro'] and k0 < i + 3:
        k0 += 1
    k1 = k0
    while k1 < len(f) and f[k1]['retro']:
        k1 += 1
    n_retro = k1 - k0 if k0 < len(f) and f[k0]['retro'] else 0
    # primera viva después de la racha
    j = it['j']
    if j < len(f):
        nv = f[j]
        dist = math.hypot(nv['x'] - r['x'], nv['y'] - r['y'])
        dth = math.degrees((nv['th'] - r['th'] + math.pi) % (2 * math.pi) - math.pi)
        reap = f"viva en paso {nv['paso']} ({nv['x']:.3f}, {nv['y']:.3f}) a {dist*100:.1f} cm, dθ {dth:+.1f}°, d_pared {nv['d']:.3f}"
    else:
        reap = 'no reaparece (fin de secuencia)'
    # dirección de entrada: desplazamiento últimas 5 decisiones
    k = max(0, i - 6)
    ddx, ddy = f[i - 1]['x'] - f[k]['x'], f[i - 1]['y'] - f[k]['y']
    rumbo_mov = math.degrees(math.atan2(ddy, ddx))
    v_ent = math.hypot(ddx, ddy) / ((i - 1 - k) * DT) if i - 1 > k else float('nan')
    valido = ep_csv[s['ep']]['valido']
    filas26.append(dict(ep=s['ep'], ag=s['ag'], robot=s['robot'], paso=r['paso'], x=r['x'], y=r['y'], th=r['th'],
                        xl=xl, yl=yl, d=r['d'], pared=r['pared'], u=r['u'], dv=dv, vn=vn, largo=it['largo'],
                        fin=it['hasta_fin'], n_retro=n_retro, retro_ini=f[k0]['paso'] if n_retro else None,
                        reap=reap, valido=valido, rumbo=rumbo_mov, v_ent=v_ent))
    print(f"ep{s['ep']:2d} (válido={valido}) a{s['ag']}/r{s['robot']} inicio paso {r['paso']:3d}  env ({r['x']:.3f}, {r['y']:.3f}) θ {math.degrees(r['th']):+.1f}°"
          f"  lab ({xl:+.3f}, {yl:+.3f})  d_pared {r['d']:.3f} [{r['pared']}, u={r['u']:.2f}]  vértice {vn} a {dv:.3f} m")
    print(f"      racha {it['largo']} filas ({it['largo']*DT:.1f} s) hasta_fin={it['hasta_fin']}  en_retroceso: {n_retro} filas desde paso {f[k0]['paso'] if n_retro else '-'}"
          f"  | entrada: rumbo del desplazamiento {rumbo_mov:+.0f}°, {v_ent*100:.1f} cm/s (últimas {i-1-k} decisiones)")
    print(f"      {reap}")
    print(f"      detalle CSV episodios: {ep_csv[s['ep']]['retrocesos_detalle']}")

# chequeo: filas en_retroceso fuera de rachas y rachas sin retroceso
print('-' * 110)
tot_retro = sum(r['retro'] for s in S['26-09'] for r in s['f'])
tot_rep = sum(r['rep'] for s in S['26-09'] for r in s['f'])
retro_no_rep = sum(1 for s in S['26-09'] for r in s['f'] if r['retro'] and not r['rep'])
rep_no_retro = sum(1 for s in S['26-09'] for r in s['f'] if r['rep'] and not r['retro'])
print(f'26-09 filas: {sum(len(s["f"]) for s in S["26-09"])}  repetidas {tot_rep}  en_retroceso {tot_retro}  retro&!rep {retro_no_rep}  rep&!retro {rep_no_retro}')

# Detalle fila a fila de cada racha (pose, retro, v/w) +- 8 filas
print('=' * 110)
print('DETALLE FILA A FILA de cada evento (±)')
for it in I['26-09']:
    s, i = it['s'], it['i']
    f = s['f']
    a, b = max(0, i - 8), min(len(f), it['j'] + 6)
    print(f"--- ep{s['ep']} a{s['ag']} r{s['robot']} inicio paso {f[i]['paso']}")
    for k in range(a, b):
        r = f[k]
        print(f"   paso {r['paso']:3d} ({r['x']:.4f}, {r['y']:.4f}, {math.degrees(r['th']):+7.2f}°) rep={int(r['rep'])} retro={r['retro']} v={r['v']:+.4f} w={r['w']:+.3f} d={r['d']:.3f}")

# ----------------------------------------------------------------------------
print('=' * 110)
print('2) INICIOS DE SESIONES ANTERIORES (11, 22, 24-09)')
todos = []
for fecha in ['11-09', '22-09', '24-09']:
    for it in I[fecha]:
        s, r = it['s'], it['r']
        xl, yl = env2lab(r['x'], r['y'])
        dv, vn = vertice(r['x'], r['y'])
        todos.append((fecha, s['ep'], s['ag'], s['robot'], r['paso'], r['x'], r['y'], xl, yl, r['d'], r['pared'], dv, vn, it['largo']))
        print(f"{fecha} {s['arch'][-12:]} ep{s['ep']:2d} a{s['ag']} r{s['robot']} paso {r['paso']:3d} env ({r['x']:.3f}, {r['y']:.3f}) lab ({xl:+.3f}, {yl:+.3f}) d {r['d']:.3f} [{r['pared']}] vért {vn} {dv:.3f} racha {it['largo']}")

# ----------------------------------------------------------------------------
print('=' * 110)
print('3) TASAS por franja de d_pared (inicios / decisiones-agente, ‰)')
def tabla(fechas):
    F = [r for f_ in fechas for s in S[f_] for r in s['f']]
    exp_t = Counter(franja(r['d']) for r in F)
    exp_v = Counter(franja(r['d']) for r in F if not r['rep'])
    ev = Counter(franja(it['r']['d']) for f_ in fechas for it in I[f_])
    return exp_t, exp_v, ev
res_tab = {}
for nom, fechas in [('11-09', ['11-09']), ('22+24-09', ['22-09', '24-09']), ('26-09', ['26-09']), ('22-09', ['22-09']), ('24-09', ['24-09'])]:
    et, evv, ev = tabla(fechas)
    res_tab[nom] = (et, evv, ev)
    print(f'-- {nom}')
    for _, _, fr in FRANJAS:
        k, e, v = ev[fr], et[fr], evv[fr]
        print(f'   {fr:10s} {k:3d} / {e:6d} = {1000*k/e if e else float("nan"):6.2f} ‰  (vivas {k}/{v} = {1000*k/v if v else float("nan"):.2f} ‰)')
    kc = ev['<0.20'] + ev['0.20-0.35']; ec = et['<0.20'] + et['0.20-0.35']; vc = evv['<0.20'] + evv['0.20-0.35']
    print(f'   <0.35      {kc:3d} / {ec:6d} = {1000*kc/ec:.2f} ‰  (vivas {kc}/{vc} = {1000*kc/vc:.2f} ‰)   total filas {sum(et.values())}, inicios {sum(ev.values())}')

# contrastes 26-09 vs 22+24 por franja (razón de tasas, IC exacto condicional)
def ic_razon(k1, e1, k2, e2, conf=0.95):
    n = k1 + k2; a = 1 - conf
    lo = 0.0 if k1 == 0 else stats.beta.ppf(a / 2, k1, n - k1 + 1)
    hi = 1.0 if k1 == n else stats.beta.ppf(1 - a / 2, k1 + 1, n - k1)
    f = e2 / e1
    return (k1 / e1) / (k2 / e2) if k2 else math.inf, lo / (1 - lo) * f, (hi / (1 - hi) * f if hi < 1 else math.inf)
print('-- razón de tasas 26-09 / 22+24-09 (todas las filas) y p (binomial condicional bilateral)')
et6, _, ev6 = res_tab['26-09']; et2, _, ev2 = res_tab['22+24-09']
for grupo in [['<0.20'], ['0.20-0.35'], ['<0.20', '0.20-0.35'], ['0.35-0.60'], ['>=0.60'], ['0.35-0.60', '>=0.60']]:
    k1 = sum(ev6[g] for g in grupo); e1 = sum(et6[g] for g in grupo)
    k2 = sum(ev2[g] for g in grupo); e2 = sum(et2[g] for g in grupo)
    rr, lo, hi = ic_razon(k1, e1, k2, e2)
    p = stats.binomtest(k1, k1 + k2, e1 / (e1 + e2)).pvalue if k1 + k2 else float('nan')
    print(f'   {"+".join(grupo):22s} 26-09 {k1}/{e1}  vs  22+24 {k2}/{e2}   RR {rr:.2f} [{lo:.2f}, {hi:.2f}]  p {p:.3g}')

# ----------------------------------------------------------------------------
print('=' * 110)
print('4) OCUPACIÓN VIVA alrededor de los puntos (radio r, filas vivas por sesión)')
centros = {
    'A interior (2.54,2.20)': (2.54, 2.20),
    'B borde x=3 (2.815,2.49)': (2.815, 2.49),
    'C borde y=3 (2.52,2.79)': (2.52, 2.79),
    'D 29-08 env': lab2env(1.361, 1.215),
    'E ep1 (0.43,2.48)': (0.43, 2.48),
    'F colocación r6 (2.47,2.41)': (2.47, 2.41),
    'G colocación r6 (2.36,2.23)': (2.36, 2.23),
    'H colocación r1 (2.10,2.42)': (2.10, 2.42),
}
for nom, (cx, cy) in centros.items():
    linea = []
    for fecha in ['11-09', '22-09', '24-09', '26-09']:
        for rad in (0.05, 0.10):
            n = sum(1 for s in S[fecha] for r in s['f'] if not r['rep'] and math.hypot(r['x'] - cx, r['y'] - cy) < rad)
            linea.append(f'{fecha} r{int(rad*100)}:{n}')
        # visitas (entradas al disco de 10 cm)
        vis = 0; vis_cong = 0
        for s in S[fecha]:
            dentro = False; cong = False
            for r in s['f']:
                aden = math.hypot(r['x'] - cx, r['y'] - cy) < 0.10
                if aden and not dentro:
                    vis += 1; cong = False
                if aden and r['ini']:
                    cong = True
                if dentro and not aden:
                    vis_cong += int(cong)
                dentro = aden
            if dentro:
                vis_cong += int(cong)
        linea.append(f'visitas10:{vis}(cong {vis_cong})')
    print(f'  {nom:30s} ' + '  '.join(linea))

# ----------------------------------------------------------------------------
print('=' * 110)
print('5) DECISIONES-AGENTE EN RETROCESO por episodio (CSV de decisiones vs CSV de episodios)')
por_ep = defaultdict(lambda: [0, 0, 0])
for s in S['26-09']:
    for r in s['f']:
        por_ep[s['ep']][0] += r['retro']; por_ep[s['ep']][1] += 1; por_ep[s['ep']][2] += r['rep']
for ep in sorted(por_ep):
    rr, n, rp = por_ep[ep]
    e = ep_csv[ep]
    print(f"  ep{ep:2d} válido={e['valido']} filas {n:5d}  en_retroceso {rr:3d} ({100*rr/n:.2f} %)  repetidas {rp:3d} ({100*rp/n:.2f} %)"
          f"  | CSV ep: decisiones_retroceso {e['decisiones_retroceso']} frac {float(e['frac_decisiones_retroceso']):.4f}  cobertura {float(e['cobertura_aoi']):.4f}")
val = [ep for ep in por_ep if ep_csv[ep]['valido'] == '1']
tr = sum(por_ep[ep][0] for ep in val); tn = sum(por_ep[ep][1] for ep in val); tp = sum(por_ep[ep][2] for ep in val)
print(f'  VÁLIDOS ({len(val)}): en_retroceso {tr}/{tn} = {100*tr/tn:.3f} %  repetidas {tp}/{tn} = {100*tp/tn:.3f} %')
