"""5) Cifras complementarias: cotas de la selección sobre la media de
cobertura, válidos con/sin racha, contrastes de zona entre fechas."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import numpy as np
import pandas as pd
from scipy import stats
from a26_superv_comun import leer_ep, leer_dec, rachas

E = leer_ep("20260926_sesion-evaluacion_etapa7_episodios.csv")
cob = {int(r["episodio"]): float(r["cobertura_aoi"]) for r in E}
val = [int(r["episodio"]) for r in E if r["valido"] == "1"]
inv = [int(r["episodio"]) for r in E if r["valido"] != "1"]
cong = [int(r["episodio"]) for r in E if "CONGELADO" in r["motivo"]]
v = np.array([cob[e] for e in val])

print("=== cotas ingenuas: si los inválidos hubieran terminado dentro del rango de los válidos ===")
for nombre, grupo in (("9 inválidos", inv), ("6 congelados", cong)):
    n = len(grupo)
    lo = (v.sum() + n * v.min()) / (len(v) + n)
    hi = (v.sum() + n * v.max()) / (len(v) + n)
    print(f"  {nombre}: media de {len(v)+n} en [{lo:.4f}, {hi:.4f}] (válidos solos {v.mean():.4f}) → "
          f"desplazamiento [{lo-v.mean():+.4f}, {hi-v.mean():+.4f}]")
# con los largos a su cobertura parcial y el resto en el rango
largos = [3, 11, 13]
cortos = [e for e in inv if e not in largos]
base = v.sum() + sum(cob[e] for e in largos)
nn = len(v) + len(largos) + len(cortos)
print(f"  largos (3, 11, 13) a su cobertura parcial y los 6 cortos en [mín, máx] de válidos: "
      f"[{(base + len(cortos)*v.min())/nn:.4f}, {(base + len(cortos)*v.max())/nn:.4f}]")

print("\n=== válidos con racha repetida (1, 4, 17, 19) vs sin racha ===")
con = [1, 4, 17, 19]
a = [cob[e] for e in con]; b = [cob[e] for e in val if e not in con]
print(f"  con: {np.round(a,4).tolist()} media {np.mean(a):.4f} · sin: {np.round(b,4).tolist()} media {np.mean(b):.4f} · "
      f"MW exacto p={stats.mannwhitneyu(a, b, method='exact').pvalue:.3f} (post hoc)")

print("\n=== arranque con un agente en la zona: congelados 2/6 (ep 5, 10) vs válidos 1/10 (ep 19) ===")
print(f"  Fisher bilateral p={stats.fisher_exact([[2, 4], [1, 9]])[1]:.3f}")

print("\n=== zona +x+y entre fechas: inicios de racha / filas vivas en la zona ===")
res = {}
for nombre in ("20260911_sesion-evaluacion_etapa7_decisiones.csv",
               "20260922_sesion-evaluacion_etapa7_decisiones.csv",
               "20260922_sesion-evaluacion_etapa7_decisiones_02.csv",
               "20260924_sesion-evaluacion_etapa7_decisiones.csv",
               "20260926_sesion-evaluacion_etapa7_decisiones.csv"):
    D = leer_dec(nombre)
    viva = D[D.viva]; ini = D[D.inicio_cong]
    res[nombre[:8] + nombre[-7:-4]] = (int(ini.zona.sum()), int(viva.zona.sum()),
                                      int((~ini.zona).sum()), int((~viva.zona).sum()))
for k, (iz, vz, io, vo) in res.items():
    print(f"  {k}: zona {iz}/{vz} ({1000*iz/max(vz,1):.2f} ‰) · fuera {io}/{vo} ({1000*io/max(vo,1):.3f} ‰)")
z11 = res["20260911nes"]; z26 = res["20260926nes"]
z2224 = [sum(x) for x in zip(res["20260922nes"], res["20260922_02"], res["20260924nes"])]
print(f"  22+24-09: zona {z2224[0]}/{z2224[1]} · fuera {z2224[2]}/{z2224[3]}")
p = stats.fisher_exact([[z11[0], z11[1] - z11[0]], [z26[0], z26[1] - z26[0]]])[1]
print(f"  zona 11-09 vs 26-09: Fisher bilateral p={p:.2e}")
p = stats.fisher_exact([[z2224[0], z2224[1] - z2224[0]], [z26[0], z26[1] - z26[0]]])[1]
print(f"  zona 22+24-09 vs 26-09: Fisher bilateral p={p:.3f}")
p = stats.fisher_exact([[z2224[2], z2224[3] - z2224[2]], [z26[2], z26[3] - z26[2]]])[1]
print(f"  FUERA de zona 22+24-09 vs 26-09: Fisher bilateral p={p:.2e}")

print("\n=== inicios de racha por robot (26-09) ===")
D26 = leer_dec("20260926_sesion-evaluacion_etapa7_decisiones.csv")
R = rachas(D26)
R["robot"] = R.agente.map({0: 1, 1: 5, 2: 8, 3: 6, 4: 9})
R["fatal"] = R.llega_al_final & R.episodio.isin(cong)
print(R.groupby("robot").agg(rachas=("paso_ini", "size"), fatales=("fatal", "sum")).to_string())
