# Parte 2: arranques con un robot fuera de su blanco (colocación lo dejó "no avanza").
import csv, math
E = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_episodios.csv"
rows = list(csv.DictReader(open(E, encoding="utf-8")))
robot_de = {0: 1, 1: 5, 2: 8, 3: 6, 4: 9}
print("Estados de colocación distintos de 'listo' (todas las filas, todos los agentes):")
for r in rows:
    for a in range(5):
        est = r[f"col_estado_a{a}"]
        if est != "listo":
            x0, y0 = r.get(f"x0_a{a}", ""), r.get(f"y0_a{a}", "")
            bx, by = float(r[f"blanco_x_a{a}"]), float(r[f"blanco_y_a{a}"])
            d = math.hypot(float(x0) - bx, float(y0) - by) if x0 not in ("", None) else float("nan")
            print(f"  ep {r['episodio']:>2} agente {a} (robot {robot_de[a]}): col_estado='{est}'  col_err_m={r[f'col_err_m_a{a}']}  "
                  f"col_err_rumbo={r[f'col_err_rumbo_deg_a{a}']}°  x0=({float(x0):.4f},{float(y0):.4f})  blanco=({bx:.4f},{by:.4f})  "
                  f"|x0-blanco|={d:.4f} m  th0={float(r[f'th0_a{a}']):.3f} blanco_th={r[f'blanco_th_a{a}']}  valido={r['valido']}  cobertura={float(r['cobertura_aoi']):.4f}  réplica={r['cobertura_replica']}")
print()
print("Error de colocación |x0 - blanco| (m) por episodio y agente (x0 = pose medida al arrancar):")
print("ep   " + "  ".join(f"r{robot_de[a]:<6}" for a in range(5)) + "  valido  col_motivo")
for r in rows:
    ds = []
    for a in range(5):
        x0 = r.get(f"x0_a{a}", "")
        bx, by = float(r[f"blanco_x_a{a}"]), float(r[f"blanco_y_a{a}"])
        ds.append(math.hypot(float(x0) - bx, float(y0 := r[f"y0_a{a}"]) - by) if x0 else float("nan"))
    print(f"{r['episodio']:>2}   " + "  ".join(f"{d:6.3f} " for d in ds) + f"  {r['valido']}      {r['col_motivo']}")
# distancia del robot 6 al vecino más cercano y a la pared en los arranques afectados
print()
for e in ["6", "7", "8", "14"]:
    r = next(x for x in rows if x["episodio"] == e)
    p = {a: (float(r[f"x0_a{a}"]), float(r[f"y0_a{a}"])) for a in range(5)}
    x, y = p[3]
    dp = min(x, 3 - x, y, 3 - y)
    dv = min(math.hypot(x - p[b][0], y - p[b][1]) for b in range(5) if b != 3)
    print(f"ep {e}: robot 6 en ({x:.3f},{y:.3f}) d_pared={dp:.3f} m  vecino más cercano {dv:.3f} m")
