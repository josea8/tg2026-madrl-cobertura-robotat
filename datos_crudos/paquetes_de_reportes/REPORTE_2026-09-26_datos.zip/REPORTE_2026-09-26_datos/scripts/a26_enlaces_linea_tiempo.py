# Línea de tiempo aproximada de la consola del 26-09 (v2: interpola dentro de la colocación).
# Modelo: refresco de guía = 1 s; colocación = segundos impresos "[colocación N s]" / "en X s";
# episodio = duracion_s del CSV. Anclas: las 5 horas de caída de enlace (interpolación lineal).
import re, csv
from datetime import datetime, timedelta
SC = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad"
F = SC + r"\consola_20260926.txt"
P = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_episodios.csv"
dur = {int(r["episodio"]): float(r["duracion_s"]) for r in csv.DictReader(open(P, encoding="utf-8"))}
L = open(F, encoding="utf-8").read().splitlines()
guia_r1 = re.compile(r"^\s+[✔✘]?\s*robot 1:? (está|SIN POSE|marcador)")
t = 0.0; ep = 0; t_col0 = None; en_ep = False
T = {}
eventos = []
for n, l in enumerate(L, 1):
    m = re.match(r"^EPISODIO (\d+)\s+\(", l)
    if m:
        ep = int(m.group(1)); eventos.append((n, t, ep, f"inicio bloque ep {ep}"))
    elif guia_r1.match(l):
        t += 1.0
    else:
        m = re.match(r"^\s+\[colocación\s+(\d+) s\]", l)
        if m:
            if int(m.group(1)) == 0 or t_col0 is None:
                t_col0 = t
            t = t_col0 + float(m.group(1))
        m2 = re.match(r"^\s+colocación: .* en (\d+) s", l)
        if m2 and t_col0 is not None:
            t = t_col0 + float(m2.group(1)); t_col0 = None
            eventos.append((n, t, ep, "fin colocación: " + l.strip()[12:70]))
        if "sin teletransporte" in l or ("detención enviada" in l and L[n-2].strip().startswith("colocación:")):
            pass
        if ">>> EPISODIO" in l:
            t += dur.get(ep, 0.0)
            eventos.append((n, t, ep, "fin episodio: " + l.strip()[4:60]))
    T[n] = t
    if re.search(r"fallo enviando|RECONECTADO|no avanza\) —|NO SIGUE|no se gasta el intento|pose vieja|⛔ marcador", l):
        eventos.append((n, t, ep, l.strip()[:120]))
anclas = []
caidas = [n for n, l in enumerate(L, 1) if "fallo enviando" in l]
reconex = [(n, re.search(r"a los ([\d.]+) s de la caída \(caída (\d\d:\d\d:\d\d)", l)) for n, l in enumerate(L, 1) if "RECONECTADO" in l]
for c, (rn, m) in zip(caidas, reconex):
    anclas.append((T[c], datetime.strptime("2026-09-26 " + m.group(2), "%Y-%m-%d %H:%M:%S")))
for (t1, h1), (t2, h2) in zip(anclas, anclas[1:]):
    print(f"entre anclas: modelo {t2-t1:6.1f} s · real {(h2-h1).total_seconds():6.1f} s · factor {(h2-h1).total_seconds()/(t2-t1):.3f}")
fac_medio = (anclas[-1][1] - anclas[0][1]).total_seconds() / (anclas[-1][0] - anclas[0][0])
print(f"factor medio real/modelo: {fac_medio:.3f}")
def hora(tt):
    if tt <= anclas[0][0]:
        return anclas[0][1] - timedelta(seconds=(anclas[0][0] - tt) * fac_medio)
    for (t1, h1), (t2, h2) in zip(anclas, anclas[1:]):
        if t1 <= tt <= t2:
            return h1 + (h2 - h1) * ((tt - t1) / (t2 - t1))
    return anclas[-1][1] + timedelta(seconds=(tt - anclas[-1][0]) * fac_medio)
with open(SC + r"\a26_enlaces_linea_tiempo.txt", "w", encoding="utf-8", newline="\n") as fo:
    for (n, tt, e, x) in eventos:
        s = f"{n:5d} ep{e:2d} t_mod={tt:7.1f} ~{hora(tt).strftime('%H:%M:%S')} {x}"
        print(s); fo.write(s + "\n")
