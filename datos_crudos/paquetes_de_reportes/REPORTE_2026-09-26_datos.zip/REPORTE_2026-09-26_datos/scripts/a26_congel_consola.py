# -*- coding: utf-8 -*-
"""a26_congel: reconstruye desde la consola del 26-09 la secuencia de estados de
la guía de colocación por robot (está / CONGELADO / SIN POSE), con los
marcadores de episodio y los eventos de retroceso. Sólo lectura."""
import re, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
RUTA = r'C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\consola_20260926.txt'
L = open(RUTA, encoding='utf-8').read().splitlines()

re_esta = re.compile(r'robot (\d+): está \(([-\d.]+), ([-\d.]+)\)')
re_cong = re.compile(r'robot (\d+): marcador CONGELADO \(pose repetida en ([-\d.]+), ([-\d.]+)\)')
re_sin = re.compile(r'robot (\d+): SIN POSE')
re_ep = re.compile(r'^EPISODIO (\d+) ')
re_evt = re.compile(r'(↩|▶|⛔|>>> EPISODIO|colocación: |⚠ colocación|RECONECTADO|10054|Enter para seguir|✘ no se arranca|\[colocación)')

eventos = []  # (linea, tipo, robot, x, y, texto)
ep = 0
for i, s in enumerate(L, 1):
    m = re_ep.search(s)
    if m:
        ep = int(m.group(1)); eventos.append((i, 'EP', None, None, None, s.strip())); continue
    m = re_esta.search(s)
    if m:
        eventos.append((i, 'esta', int(m.group(1)), float(m.group(2)), float(m.group(3)), '')); continue
    m = re_cong.search(s)
    if m:
        eventos.append((i, 'CONG', int(m.group(1)), float(m.group(2)), float(m.group(3)), '')); continue
    m = re_sin.search(s)
    if m:
        eventos.append((i, 'SIN', int(m.group(1)), None, None, '')); continue
    if re_evt.search(s):
        eventos.append((i, 'evt', None, None, None, s.strip()[:170]))

# Compresión por robot: secuencia de estados (tipo, pose) con rango de líneas
for rob in [1, 5, 8, 6, 9]:
    print('=' * 100)
    print('ROBOT', rob)
    prev = None; ini = None; n = 0
    seq = []
    for (i, t, r, x, y, txt) in eventos:
        if r != rob:
            continue
        clave = (t, x, y)
        if clave != prev:
            if prev is not None:
                seq.append((ini, fin, prev, n))
            prev = clave; ini = i; n = 0
        fin = i; n += 1
    seq.append((ini, fin, prev, n))
    for (a, b, (t, x, y), n) in seq:
        # episodio que contiene la línea a
        e = max([int(re_ep.search(L[j-1]).group(1)) for (j, tt, *_ ) in eventos if tt == 'EP' and j <= a] or [0])
        print(f'  L{a:5d}-{b:5d} ep{e:2d} {t:5s} ({x},{y}) x{n}')

print('=' * 100)
print('EVENTOS')
for (i, t, r, x, y, txt) in eventos:
    if t in ('EP', 'evt') and not txt.startswith('[colocación'):
        print(f'L{i:5d} {txt}')
