# Momento exacto en que el robot 9 deja de moverse en el ep 3, y el robot 1 en el ep 2.
import csv
import numpy as np
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_decisiones.csv"
rows = list(csv.DictReader(open(D, encoding="utf-8")))
for e, a in [(3, 4), (2, 0)]:
    rs = sorted([r for r in rows if r["episodio"] == str(e) and r["agente"] == str(a)], key=lambda r: int(r["paso"]))
    xy = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in rs])
    av = np.r_[0, np.linalg.norm(np.diff(xy, axis=0), axis=1)]
    v = np.array([float(r["v_ejecutada"]) for r in rs]) * 0.4
    ini = 420 if e == 3 else 0
    print(f"ep {e} agente {a}: avance por decisión (mm) desde {ini}:")
    print("  " + " ".join(f"{int(rs[k]['paso'])}:{av[k]*1000:.1f}" for k in range(ini, len(rs))))
    # último paso con avance > 3 mm
    mov = np.where(av > 0.003)[0]
    print(f"  último paso con avance > 3 mm: {int(rs[mov[-1]]['paso']) if len(mov) else None}; pose final ({xy[-1,0]:.3f},{xy[-1,1]:.3f}); v cmd final {v[-1]:.3f}")
    d_pared = min(xy[-1,0], 3-xy[-1,0], xy[-1,1], 3-xy[-1,1])
    print(f"  d_pared final {d_pared:.3f} m")
