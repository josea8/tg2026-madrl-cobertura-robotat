import csv, math
f = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260924_sesion-evaluacion_etapa7_episodios.csv"
for r in csv.DictReader(open(f, encoding="utf-8")):
    for a in range(5):
        if r.get(f"col_estado_a{a}") not in ("listo", None, ""):
            x0 = r.get(f"x0_a{a}", "")
            d = (math.hypot(float(x0) - float(r[f"blanco_x_a{a}"]), float(r[f"y0_a{a}"]) - float(r[f"blanco_y_a{a}"])) if x0 else float("nan"))
            print(f"24-09 ep {r['episodio']} agente {a} robot {r.get(f'robot_a{a}')}: estado={r[f'col_estado_a{a}']} |x0-blanco|={d:.3f} m valido={r['valido']} motivo={r['motivo'][:70]}")
