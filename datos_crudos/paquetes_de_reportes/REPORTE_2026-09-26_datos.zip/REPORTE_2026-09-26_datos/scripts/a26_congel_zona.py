# -*- coding: utf-8 -*-
"""a26_congel_zona.py — extensión de las zonas ciegas del 26-09 (sólo lectura).
Usa las mismas definiciones que a26_congel_analisis.py (se importa)."""
import math, sys, io
from collections import Counter, defaultdict
sys.argv = ['x']
import importlib.util
spec = importlib.util.spec_from_file_location('A', r'C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\a26_congel_analisis.py')
_buf = io.StringIO(); _old = sys.stdout
A = importlib.util.module_from_spec(spec)
sys.stdout = _buf
spec.loader.exec_module(A)
sys.stdout = _old; sys.stdout.reconfigure(encoding='utf-8') if hasattr(_old,'buffer') else _old
S, I = A.S, A.I

# ---------------------------------------------------------------- near-repeat previo al inicio
print('=' * 100)
print('Paso previo al inicio: desplazamiento (fila i-1 vs i-2) contra el típico (mediana de las 5 anteriores)')
for fecha in ['11-09', '22-09', '24-09', '26-09']:
    for it in I[fecha]:
        s, i = it['s'], it['i']; f = s['f']
        if i < 7:
            continue
        d_prev = math.hypot(f[i-1]['x'] - f[i-2]['x'], f[i-1]['y'] - f[i-2]['y'])
        dth_prev = abs(math.degrees((f[i-1]['th'] - f[i-2]['th'] + math.pi) % (2*math.pi) - math.pi))
        tip = sorted(math.hypot(f[k]['x'] - f[k-1]['x'], f[k]['y'] - f[k-1]['y']) for k in range(i-6, i-1))[2]
        saltos = [(f[k]['paso'], round(100*math.hypot(f[k]['x'] - f[k-1]['x'], f[k]['y'] - f[k-1]['y']), 1),
                   round(abs(math.degrees((f[k]['th'] - f[k-1]['th'] + math.pi) % (2*math.pi) - math.pi)), 1))
                  for k in range(i-10, i)]
        glitch = [x for x in saltos if x[1] > 2.2 or x[2] > 25]
        print(f"{fecha} ep{s['ep']:2d} a{s['ag']} r{s['robot']} ini {f[i]['paso']:3d}: Δ(i-1,i-2) {d_prev*1000:7.2f} mm {dth_prev:6.3f}°  típico {tip*1000:6.1f} mm  "
              f"{'<<< CASI-REPETIDA' if d_prev < 0.1*tip else ''}  saltos>2.2cm/25° en 10 previas: {glitch}")

# ---------------------------------------------------------------- mapa fino zona A
def mapa(fecha, x0, x1, y0, y1, paso=0.03):
    nx, ny = int(round((x1-x0)/paso)), int(round((y1-y0)/paso))
    viv = Counter(); ini = Counter(); ult = Counter()
    for s in S[fecha]:
        for k, r in enumerate(s['f']):
            if not (x0 <= r['x'] < x1 and y0 <= r['y'] < y1):
                continue
            c = (int((r['x']-x0)/paso), int((r['y']-y0)/paso))
            if not r['rep']:
                viv[c] += 1
            if r['ini']:
                ini[c] += 1
    print(f'   {fecha}: celdas {paso*100:.0f} cm, x {x0}-{x1} (columnas), y {y1}->{y0} (filas); número = filas vivas, * = inicio')
    print('         ' + ''.join(f'{x0+ix*paso:5.2f}' for ix in range(nx)))
    for iy in range(ny-1, -1, -1):
        fila = ''
        for ix in range(nx):
            v = viv[(ix, iy)]; k = ini[(ix, iy)]
            fila += f"{(str(v) if v else '.') + ('*'*k):>5s}"
        print(f'   {y0+iy*paso:5.2f} ' + fila)

for nom, caja in [('ZONA A (interior, 2.54, 2.20)', (2.40, 2.82, 2.05, 2.35)),
                  ('ZONA B/C (esquina +x+y)', (2.36, 2.96, 2.35, 2.95))]:
    print('=' * 100)
    print(nom)
    for fecha in ['11-09', '24-09', '26-09']:
        mapa(fecha, *caja)

# ---------------------------------------------------------------- filas vivas al "frente" de la pérdida
print('=' * 100)
print('Filas vivas del 26-09 más allá del punto de pérdida en la dirección de entrada (semiplano adelante, a < 15 cm lateral)')
for it in I['26-09']:
    s, i = it['s'], it['i']; f = s['f']
    k = max(0, i - 6)
    ux, uy = f[i-1]['x'] - f[k]['x'], f[i-1]['y'] - f[k]['y']
    n = math.hypot(ux, uy); ux, uy = ux/n, uy/n
    px, py = f[i]['x'], f[i]['y']
    adelante = []
    for s2 in S['26-09']:
        for r in s2['f']:
            if r['rep']:
                continue
            dx, dy = r['x']-px, r['y']-py
            a = dx*ux + dy*uy; lat = -dx*uy + dy*ux
            if 0.01 < a < 0.15 and abs(lat) < 0.03:
                adelante.append((round(a*100), s2['ep'], s2['robot']))
    cnt = Counter(round(a/3)*3 for a, _, _ in adelante)
    print(f"ep{s['ep']:2d} r{s['robot']} ini {f[i]['paso']} ({px:.3f},{py:.3f}) rumbo {math.degrees(math.atan2(uy,ux)):+.0f}°: filas vivas en el corredor ±3 cm, 1–15 cm adelante: {len(adelante)}  por distancia(cm): {dict(sorted(cnt.items()))}  episodios/robots: {sorted(set((e,r) for _,e,r in adelante))[:12]}")

# ---------------------------------------------------------------- reaparición: adelante o atrás
print('=' * 100)
print('Reaparición respecto de la dirección de entrada (proyección del salto sobre el rumbo de entrada)')
for it in I['26-09']:
    s, i, j = it['s'], it['i'], it['j']; f = s['f']
    if j >= len(f):
        continue
    k = max(0, i - 6)
    ux, uy = f[i-1]['x'] - f[k]['x'], f[i-1]['y'] - f[k]['y']
    n = math.hypot(ux, uy); ux, uy = ux/n, uy/n
    dx, dy = f[j]['x'] - f[i]['x'], f[j]['y'] - f[i]['y']
    print(f"ep{s['ep']:2d} r{s['robot']} ini {f[i]['paso']}: reaparece tras {it['largo']} filas; a lo largo {100*(dx*ux+dy*uy):+.1f} cm, lateral {100*(-dx*uy+dy*ux):+.1f} cm")

# ---------------------------------------------------------------- exposición por esquina (vértice a < 0.75 m) por sesión
print('=' * 100)
print('Exposición por esquina: filas (todas) con distancia euclídea al vértice < 0.75 m, inicios y filas a <0.35 de pared')
for fecha in ['11-09', '22-09', '24-09', '26-09']:
    ex = Counter(); ic = Counter(); exc = Counter()
    for s in S[fecha]:
        for r in s['f']:
            dv, vn = A.vertice(r['x'], r['y'])
            if dv < 0.75:
                ex[vn] += 1
                if r['d'] < 0.35:
                    exc[vn] += 1
                if r['ini']:
                    ic[vn] += 1
    print(f'  {fecha}: ' + '  '.join(f'{v}: {ic[v]}/{ex[v]} (d<0.35: {exc[v]})' for v in ['(0,0)', '(3,0)', '(0,3)', '(3,3)']))

# cuadrante +x+y (x>1.5, y>1.5) vs resto
print('Cuadrante NE (x>2.0 y y>2.0) vs resto, todas las filas:')
for fecha in ['11-09', '22-09', '24-09', '26-09']:
    e_ne = sum(1 for s in S[fecha] for r in s['f'] if r['x'] > 2.0 and r['y'] > 2.0)
    e_r = sum(1 for s in S[fecha] for r in s['f']) - e_ne
    k_ne = sum(1 for it in I[fecha] if it['r']['x'] > 2.0 and it['r']['y'] > 2.0)
    k_r = len(I[fecha]) - k_ne
    print(f'  {fecha}: NE {k_ne}/{e_ne} = {1000*k_ne/max(e_ne,1):.2f} ‰   resto {k_r}/{e_r} = {1000*k_r/max(e_r,1):.2f} ‰')
from scipy import stats
e_ne = sum(1 for s in S['26-09'] for r in s['f'] if r['x'] > 2.0 and r['y'] > 2.0)
e_tot = sum(len(s['f']) for s in S['26-09'])
k_ne = sum(1 for it in I['26-09'] if it['r']['x'] > 2.0 and it['r']['y'] > 2.0)
print(f'  26-09: P(≥{k_ne} de {len(I["26-09"])} en NE | fracción de exposición {e_ne/e_tot:.3f}) = {stats.binom.sf(k_ne-1, len(I["26-09"]), e_ne/e_tot):.2e}')
