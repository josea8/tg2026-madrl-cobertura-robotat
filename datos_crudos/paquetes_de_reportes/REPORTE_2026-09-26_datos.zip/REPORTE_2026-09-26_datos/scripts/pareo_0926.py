"""
Pareo sim/real del 26-09 contra la réplica CON capas, con el análisis fijado antes de
ver el resultado:

  principal : los 10 episodios válidos del protocolo (1, 4, 8, 9, 12, 15, 16, 17, 18, 19)
  sens. A   : sin el ep 17 (retroceso de 20 filas recuperado + re-entrada censurada al final)
  sens. B   : sin el ep 8 (robot 6 arrancó a 1.07 m de su blanco: 'no avanza' no bloqueó)
  sens. C   : sin ningún episodio con pose repetida (1, 4, 17, 19)
  combinado : 11-09 (n=5, arranques compactos, [1,2,3,6,9]) + 26-09 (n=10) — DECLARADO,
              cambian composición, arranque, protocolo y código.

Estadísticos (mismos que analizar_replicas.py): diferencia pareada hw − media de las 3 reps,
IC95 t, t pareado, Wilcoxon exacto, n para que el IC excluya 0 y para potencia 0.80
(t no central), potencia a n = 10/20/30. Desvíos con ddof = 1. Solo lectura.
"""
import csv, math, sys
from pathlib import Path
import numpy as np
from scipy import stats

# Carpeta de CSV: argumento, o ../csv junto al script (paquete), o la del proyecto.
_PAQUETE = Path(__file__).resolve().parent.parent / "csv"
RS = (Path(sys.argv[1]) if len(sys.argv) > 1 else
      _PAQUETE if _PAQUETE.is_dir() else
      Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion"))


def replica(archivo, origen=None):
    por_ep = {}
    for r in csv.DictReader(open(archivo, encoding="utf-8")):
        if origen and r.get("fuente_episodios") and origen not in r["fuente_episodios"]:
            continue
        if str(r.get("valido", "1")) not in ("1", "True", "true"):
            print(f"  ⚠ réplica inválida: ep {r['episodio']} rep {r['rep']}: {r.get('motivo')}")
            continue
        por_ep.setdefault(int(r["episodio"]), []).append(float(r["cobertura_aoi"]))
    return por_ep


def hw(archivo):
    return {int(r["episodio"]): float(r["cobertura_aoi"])
            for r in csv.DictReader(open(archivo, encoding="utf-8")) if r["valido"] in ("1", "True")}


def n_para(m, sd, potencia=None):
    for n in range(2, 5000):
        t = stats.t.ppf(0.975, n - 1)
        if potencia is None:
            if abs(m) - t * sd / math.sqrt(n) > 0:
                return n
        else:
            nc = abs(m) / (sd / math.sqrt(n))
            p = 1 - stats.nct.cdf(t, n - 1, nc) + stats.nct.cdf(-t, n - 1, nc)
            if p >= potencia:
                return n
    return None


def potencia(m, sd, n):
    t = stats.t.ppf(0.975, n - 1)
    nc = abs(m) / (sd / math.sqrt(n))
    return 1 - stats.nct.cdf(t, n - 1, nc) + stats.nct.cdf(-t, n - 1, nc)


def informe(nombre, pares):
    eps = sorted(pares)
    d = np.array([pares[e][0] - pares[e][1] for e in eps])
    h = np.array([pares[e][0] for e in eps]); s = np.array([pares[e][1] for e in eps])
    n = len(d); m = d.mean(); sd = d.std(ddof=1)
    t = stats.t.ppf(0.975, n - 1); ic = (m - t * sd / math.sqrt(n), m + t * sd / math.sqrt(n))
    pt = stats.ttest_1samp(d, 0).pvalue
    pw = stats.wilcoxon(d, method="exact").pvalue if n >= 2 else float("nan")
    print(f"\n== {nombre}  (n = {n}; ep {eps})")
    print(f"   hw {h.mean():.4f} ± {h.std(ddof=1):.4f}   réplica con capas {s.mean():.4f} ± {s.std(ddof=1):.4f}")
    print(f"   hw − réplica = {m:+.4f} ± {sd:.4f}   IC95 [{ic[0]:+.4f}, {ic[1]:+.4f}]   "
          f"positivas {int((d > 0).sum())}/{n}   t p = {pt:.4f}   Wilcoxon p = {pw:.4f}   "
          f"relativo {100 * m / s.mean():+.1f} %")
    print(f"   n para IC sin 0: {n_para(m, sd)}   n para potencia 0.80: {n_para(m, sd, 0.80)}   "
          f"potencia n=10/20/30: {potencia(m, sd, 10):.2f}/{potencia(m, sd, 20):.2f}/{potencia(m, sd, 30):.2f}")
    return d


if __name__ == "__main__":
    rep26 = sorted(RS.glob("*_sesion-replica_etapa7_capas-on_de-20260926*.csv"))
    if not rep26:
        sys.exit("no está la réplica del 26-09 todavía")
    print("réplica 26-09:", rep26[-1].name)
    r26 = replica(rep26[-1]); h26 = hw(RS / "20260926_sesion-evaluacion_etapa7_episodios.csv")
    print("reps por episodio:", {e: len(v) for e, v in sorted(r26.items())})
    for e in sorted(r26):
        v = r26[e]
        print(f"   ep {e:2d}: hw {h26[e]:.4f}  réplica {np.mean(v):.4f} (reps {', '.join(f'{x:.4f}' for x in v)}; "
              f"sd {np.std(v, ddof=1) if len(v) > 1 else 0:.4f})  dif {h26[e] - np.mean(v):+.4f}")
    ruido = [np.std(v, ddof=1) for v in r26.values() if len(v) > 1]
    print(f"   ruido entre reps: mediana {np.median(ruido):.4f}, máx {np.max(ruido):.4f}")
    p26 = {e: (h26[e], float(np.mean(r26[e]))) for e in r26 if e in h26}
    informe("PRINCIPAL 26-09: los 10 válidos", p26)
    informe("SENS. A: sin ep 17", {e: v for e, v in p26.items() if e != 17})
    informe("SENS. B: sin ep 8", {e: v for e, v in p26.items() if e != 8})
    informe("SENS. C: sin episodios con pose repetida (1, 4, 17, 19)", {e: v for e, v in p26.items() if e not in (1, 4, 17, 19)})
    r11 = replica(RS / "20260912_sesion-replica_etapa7_capas-on.csv"); h11 = hw(RS / "20260911_sesion-evaluacion_etapa7_episodios.csv")
    p11 = {e: (h11[e], float(np.mean(r11[e]))) for e in r11 if e in h11}
    informe("11-09 (referencia, ya publicada)", p11)
    comb = {("11", e): v for e, v in p11.items()}; comb.update({("26", e): v for e, v in p26.items()})
    informe("COMBINADO 11-09 + 26-09 (declarado: otra composición, arranque y protocolo)", comb)
    d11 = np.array([a - b for a, b in p11.values()]); d26 = np.array([a - b for a, b in p26.values()])
    w = stats.ttest_ind(d11, d26, equal_var=False)
    print(f"\n¿difieren las brechas entre sesiones? Welch sobre las diferencias: t = {w.statistic:.3f}, p = {w.pvalue:.4f}")
