"""3) Diversidad de arranques del 26-09 con diversidad_arranques.py (sin
modificarlo): válidos (x0), blancos de los 19 intentos y variantes."""
import sys
sys.dont_write_bytecode = True
COORD = (r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
         r"\coordinador_enjambre")
sys.path.insert(0, COORD)
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import copy
import numpy as np
import diversidad_arranques as da
from a26_superv_comun import leer_ep

E26 = leer_ep("20260926_sesion-evaluacion_etapa7_episodios.csv")
E11 = leer_ep("20260911_sesion-evaluacion_etapa7_episodios.csv")
E24 = leer_ep("20260924_sesion-evaluacion_etapa7_episodios.csv")

print("=== informe() tal cual lo corre la sesión (26-09) ===")
res = da.informe(E26, 5)
print()


def corre(nombre, eps):
    r = da.evaluar(eps)
    v, p = r["valores"], r["percentiles"]
    print(f"--- {nombre} (n_ep={len(eps)}) ---")
    for ln in r["lineas"]:
        print(ln)
    return r


out = {}
X0v = da.episodios_desde_filas(E26, 5)
out["26_validos_x0"] = corre("26-09 válidos, x0 medida", X0v)
BL19 = da.episodios_desde_filas(E26, 5, ("blanco_x", "blanco_y", "blanco_th"), solo_validos=False)
out["26_blancos_19"] = corre("26-09 blancos de los 19 intentos", BL19)
BLv = da.episodios_desde_filas(E26, 5, ("blanco_x", "blanco_y", "blanco_th"), solo_validos=True)
out["26_blancos_val"] = corre("26-09 blancos de los 10 válidos", BLv)
inv = [f for f in E26 if f["valido"] != "1"]
BLi = da.episodios_desde_filas(inv, 5, ("blanco_x", "blanco_y", "blanco_th"), solo_validos=False)
out["26_blancos_inv"] = corre("26-09 blancos de los 9 inválidos", BLi)
X019 = da.episodios_desde_filas(E26, 5, solo_validos=False)
out["26_x0_19"] = corre("26-09 x0 medida de los 19 intentos", X019)

# sin el ep 8 (robot 6 arrancó a 1.07 m de su blanco)
sin8 = [f for f in E26 if f["episodio"] != "8"]
out["26_val_sin8"] = corre("26-09 válidos SIN el ep 8 (x0)", da.episodios_desde_filas(sin8, 5))
# ep 8 con el agente 3 en su blanco (x, y; θ medida)
E26b = copy.deepcopy(E26)
for f in E26b:
    if f["episodio"] == "8":
        f["x0_a3"], f["y0_a3"] = f["blanco_x_a3"], f["blanco_y_a3"]
out["26_val_ep8blanco"] = corre("26-09 válidos con el agente 3 del ep 8 en su blanco", da.episodios_desde_filas(E26b, 5))

# robot 6 fuera de su blanco al arrancar
print("\n=== robot 6 (agente 3) al arrancar vs su blanco ===")
for f in E26:
    e = float(f["col_err_m_a3"])
    if e > 0.12:
        x0 = (float(f["x0_a3"]), float(f["y0_a3"]))
        bl = (float(f["blanco_x_a3"]), float(f["blanco_y_a3"]))
        d = np.hypot(x0[0] - bl[0], x0[1] - bl[1])
        # vecino más cercano del agente 3 al arrancar
        P = np.array([[float(f[f"x0_a{i}"]), float(f[f"y0_a{i}"])] for i in range(5)])
        dd = np.linalg.norm(P - P[3], axis=1); dd[3] = np.inf
        print(f"  ep {f['episodio']:>2} válido={f['valido']} col_err {e:.4f} · x0 ({x0[0]:.3f},{x0[1]:.3f}) "
              f"blanco ({bl[0]:.3f},{bl[1]:.3f}) |x0−blanco|={d:.4f} · vecino más cercano {dd.min():.3f} m · "
              f"estado {f['col_estado_a3']}")

# vecino medio por episodio (válidos 26-09)
print("\n=== vecino medio por episodio (x0), válidos 26-09 ===")
for f, m in zip([f for f in E26 if f["valido"] == "1"], X0v):
    p = m[:, :2]
    d = np.linalg.norm(p[:, None] - p[None], axis=2); np.fill_diagonal(d, np.inf)
    print(f"  ep {f['episodio']:>2}: vecino medio {d.min(axis=1).mean():.3f} m, mínimo {d.min():.3f} m")

# 11-09 válidos (x0) — referencia
print()
X011 = da.episodios_desde_filas(E11, 5)
out["11_validos_x0"] = corre("11-09 válidos, x0 medida", X011)
X011t = da.episodios_desde_filas(E11, 5, solo_validos=False)
out["11_x0_todos"] = corre("11-09 intentos con x0", X011t)
# 24-09 (para contexto)
out["24_blancos_17"] = corre("24-09 blancos de los 17", da.episodios_desde_filas(E24, 5, ("blanco_x", "blanco_y", "blanco_th"), solo_validos=False))
out["24_x0_17"] = corre("24-09 x0 de los 17", da.episodios_desde_filas(E24, 5, solo_validos=False))

print("\n=== RESUMEN (valor · percentil) ===")
cols = [n for n, _ in da.ESTADISTICOS]
print(f"{'conjunto':22s} " + " ".join(f"{c:>20s}" for c in cols) + "  banderas")
for k, r in out.items():
    print(f"{k:22s} " + " ".join(f"{r['valores'][c]:8.3f} ({r['percentiles'][c]:5.1f})    " for c in cols)
          + f"  {r['banderas']}")
