# ¿Robot 6 pivotaba sobre una rueda con órdenes distintas (episodio, colocación, guía con (0,0))?
import csv, math, re
import numpy as np
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_decisiones.csv"
C = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\consola_20260926.txt"
R, L = 0.016, 0.048
rows = [r for r in csv.DictReader(open(D, encoding="utf-8")) if r["agente"] == "3" and r["episodio"] in ("6", "7", "8")]
def rpm(v, w):
    wl = (v - w * L) / R * 60 / (2 * math.pi)
    wr = (v + w * L) / R * 60 / (2 * math.pi)
    return wl, wr
for e in ("6", "7", "8"):
    rs = sorted([r for r in rows if r["episodio"] == e], key=lambda r: int(r["paso"]))
    th = np.unwrap([float(r["pose_env_th"]) for r in rs])
    xy = np.array([[float(r["pose_env_x"]), float(r["pose_env_y"])] for r in rs])
    v = np.array([float(r["v_ejecutada"]) for r in rs]) * 0.40
    w = np.array([float(r["w_ejecutada"]) for r in rs]) * 0.40
    dth = np.degrees(np.diff(th)) / 0.1    # °/s
    # tasa de giro medida por tramos de 20 decisiones, contra el ω comandado medio
    print(f"ep {e}: {len(rs)} decisiones")
    for k in range(0, len(rs) - 1, 20):
        s = slice(k, min(k + 20, len(rs) - 1))
        wl, wr = rpm(v[s], w[s])
        print(f"   dec {k:3d}-{min(k+20,len(rs)-1):3d}: giro medido {np.mean(dth[s]):7.1f} °/s   ω comandado medio {np.degrees(np.mean(w[s])):7.1f} °/s   "
              f"v cmd medio {np.mean(v[s]):.3f} m/s   rpm cmd izq {np.mean(wl):6.1f} der {np.mean(wr):6.1f}   "
              f"avance medido {np.sum(np.linalg.norm(np.diff(xy[k:min(k+21,len(rs))],axis=0),axis=1))*100:5.1f} cm")
    if e == "8":
        break
# Guía (consola) del ep 7 y 8: poses del robot 6 cada latido (~1 s)
lines = open(C, encoding="utf-8").read().splitlines()
def guia(a, b):
    pts = []
    for n in range(a, b):
        m = re.match(r"^\s+robot 6: está \(([\d.]+), ([\d.]+)\)", lines[n - 1])
        if m:
            pts.append((n, float(m.group(1)), float(m.group(2))))
    return pts
for nombre, (a, b) in {"guía ep 7 (líneas 2121-2313)": (2121, 2313), "guía ep 8 (líneas 2354-2558)": (2354, 2558)}.items():
    pts = guia(a, b)
    xy = np.array([[p[1], p[2]] for p in pts])
    A = np.c_[2 * xy[:, 0], 2 * xy[:, 1], np.ones(len(xy))]
    c, *_ = np.linalg.lstsq(A, (xy ** 2).sum(1), rcond=None)
    cx, cy = c[0], c[1]; r = math.sqrt(c[2] + cx ** 2 + cy ** 2)
    ang = np.degrees(np.arctan2(xy[:, 1] - cy, xy[:, 0] - cx))
    paso = (np.diff(ang) + 360) % 360
    print(f"{nombre}: {len(pts)} lecturas · centro ({cx:.3f},{cy:.3f}) r={r*100:.1f} cm · "
          f"paso angular entre lecturas: mediana {np.median(paso):.0f}°, p10 {np.percentile(paso,10):.0f}°, p90 {np.percentile(paso,90):.0f}°")
