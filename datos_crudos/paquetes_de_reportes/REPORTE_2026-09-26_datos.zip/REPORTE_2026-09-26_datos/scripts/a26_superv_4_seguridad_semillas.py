"""4) Seguridad hw 26-09 (válidos) vs 11-09 y 24-09 ep 2; 5) semillas
repetidas entre sesiones; 6) cobertura 26-09 vs 11-09 (Welch)."""
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad")
import numpy as np
import pandas as pd
from scipy import stats
from a26_superv_comun import leer_ep, leer_dec, rachas, ZX, ZY

E26 = leer_ep("20260926_sesion-evaluacion_etapa7_episodios.csv")
E11 = leer_ep("20260911_sesion-evaluacion_etapa7_episodios.csv")
E24 = leer_ep("20260924_sesion-evaluacion_etapa7_episodios.csv")
E22a = leer_ep("20260922_sesion-evaluacion_etapa7_episodios.csv")
E22b = leer_ep("20260922_sesion-evaluacion_etapa7_episodios_02.csv")
E22c = leer_ep("20260922_sesion-evaluacion_etapa7_episodios_03.csv")
D26 = leer_dec("20260926_sesion-evaluacion_etapa7_decisiones.csv")
D11 = leer_dec("20260911_sesion-evaluacion_etapa7_decisiones.csv")

M = ["cobertura_aoi", "d_pared_min", "viola_018", "frac_cbf", "n_escape",
     "colisiones_015", "colisiones_022"]


def val(E):
    return [r for r in E if r["valido"] == "1"]


def arr(E, k):
    return np.array([float(r[k]) for r in E])


V26, V11 = val(E26), val(E11)
print(f"válidos 26-09: {[r['episodio'] for r in V26]} · 11-09: {[r['episodio'] for r in V11]}")
print("\n=== 4) SEGURIDAD (válidos) — media ± sd(ddof=1) [sd ddof=0] · mín · máx ===")
for nombre, V in (("26-09", V26), ("11-09", V11)):
    print(f" {nombre} (n={len(V)})")
    for k in M:
        a = arr(V, k)
        print(f"   {k:15s} {a.mean():.4f} ± {a.std(ddof=1):.4f} [{a.std():.4f}] · mín {a.min():.4f} · "
              f"máx {a.max():.4f} · mediana {np.median(a):.4f} · valores {np.round(a,4).tolist()}")
e2 = [r for r in E24 if r["episodio"] == "2"][0]
print(" 24-09 ep 2: " + " · ".join(f"{k} {float(e2[k]):.4f}" for k in M))

esc = arr(V26, "n_escape")
print(f"\n escapes 26-09: total {esc.sum():.0f}; ep 15 = {esc.max():.0f} ({100*esc.max()/esc.sum():.1f} % del total); "
      f"episodios con 0: {(esc==0).sum()}/10; sin el ep 15: media {np.delete(esc, esc.argmax()).mean():.2f}")
esc11 = arr(V11, "n_escape")
print(f" escapes 11-09: {esc11.tolist()} (0 episodios con 0)")
print(f" MW exacto escapes 26 vs 11: p={stats.mannwhitneyu(esc, esc11, method='exact').pvalue:.4f}")

# verificación de n_escape en 11-09 = suma de en_escape
ok = all(int(D11[D11.episodio == int(r['episodio'])].en_escape.sum()) == int(r['n_escape']) for r in V11)
print(f" 11-09: n_escape == suma de en_escape por episodio: {ok}")
# rachas de escape (activaciones = transiciones 0→1) para ambas sesiones
for nombre, D, V in (("26-09", D26, V26), ("11-09", D11, V11)):
    acts = []
    for r in V:
        s = D[D.episodio == int(r["episodio"])].sort_values(["agente", "paso"])
        a = 0
        for ag, t in s.groupby("agente"):
            e = t.en_escape.to_numpy()
            a += int(((e[1:] == 1) & (e[:-1] == 0)).sum() + (e[0] == 1))
        acts.append(a)
    print(f" {nombre} activaciones de escape (transiciones 0→1) por episodio: {acts} · media {np.mean(acts):.2f}")

print("\n tasas por decisión-agente (válidos): exposición y seguridad")
for nombre, D, V in (("26-09", D26, V26), ("11-09", D11, V11)):
    s = D[D.episodio.isin([int(r["episodio"]) for r in V])]
    print(f"   {nombre}: filas {len(s)} · d<0.35 {s.cerca.mean():.4f} · d<0.20 {(s.d_pared<0.20).mean():.4f} · "
          f"d<0.18 {(s.d_pared<0.18).mean():.4f} · zona {s.zona.mean():.4f} · CBF {s.cbf_intervino.mean():.4f} · "
          f"escape {s.en_escape.mean():.4f}")
    per = s.groupby("episodio").agg(cerca=("cerca", "mean"), zona=("zona", "mean"))
    print(f"      por episodio d<0.35: {np.round(per.cerca.values,4).tolist()}")

print("\n comparaciones 26-09 (n=10) vs 11-09 (n=5): Welch y Mann-Whitney exacto")
for k in ("d_pared_min", "viola_018", "frac_cbf", "n_escape"):
    a, b = arr(V26, k), arr(V11, k)
    w = stats.ttest_ind(a, b, equal_var=False)
    ci = w.confidence_interval(0.95)
    mw = stats.mannwhitneyu(a, b, method="exact")
    print(f"   {k:12s} dif {a.mean()-b.mean():+.4f} IC95 Welch [{ci.low:+.4f}, {ci.high:+.4f}] p={w.pvalue:.4f} · MW p={mw.pvalue:.4f}")

# ─────────────────────────────────────────────────────────────────────────
print("\n=== 5) SEMILLAS REPETIDAS ENTRE SESIONES ===")
sesiones = {"11-09": E11, "22-09": E22a, "22-09_02": E22b, "22-09_03": E22c, "24-09": E24, "26-09": E26}
filas = []
for s, E in sesiones.items():
    for r in E:
        ep = int(r["episodio"])
        sem = r.get("semilla") or ""
        filas.append(dict(sesion=s, ep=ep, semilla=int(sem) if sem else None,
                          sem_esperada=420000 + ep - 1, valido=int(r["valido"]),
                          dec=int(r["decisiones"]) if r.get("decisiones") else None,
                          cob=float(r["cobertura_aoi"]) if r.get("cobertura_aoi") else None))
S = pd.DataFrame(filas)
chk = S.dropna(subset=["semilla"])
print(f" semilla == 420000 + ep − 1 en todas las filas con semilla: {(chk.semilla == chk.sem_esperada).all()} "
      f"({len(chk)} filas)")
# blancos idénticos para la misma semilla (26-09 vs 24-09 / 22-09_02 / 22-09_03)
def blancos(r):
    return np.array([[float(r[f"blanco_{c}_a{i}"]) for c in ("x", "y", "th")] for i in range(5)])
for s, E in (("24-09", E24), ("22-09_02", E22b), ("22-09_03", E22c)):
    iguales, total, maxdif = 0, 0, 0.0
    for r in E:
        ep = int(r["episodio"])
        r26 = [q for q in E26 if int(q["episodio"]) == ep]
        if not r26 or not r.get("blanco_x_a0"):
            continue
        d = np.abs(blancos(r) - blancos(r26[0])).max()
        total += 1; iguales += int(d < 1e-9); maxdif = max(maxdif, d)
    print(f" blancos 26-09 vs {s}: {iguales}/{total} episodios idénticos (máx |dif| {maxdif:.2e})")

print("\n pares misma semilla, AMBOS válidos (26-09 contra cualquier otra sesión):")
s26 = S[S.sesion == "26-09"]
for _, a in s26.iterrows():
    otros = S[(S.sesion != "26-09") & (S.sem_esperada == a.sem_esperada)]
    for _, b in otros.iterrows():
        marca = "AMBOS VÁLIDOS" if (a.valido and b.valido) else ""
        if a.valido or b.valido:
            print(f"   semilla {a.sem_esperada}: 26-09 ep {a.ep} (válido={a.valido}, dec {a.dec}, cob {a.cob}) · "
                  f"{b.sesion} ep {b.ep} (válido={b.valido}, dec {b.dec}, cob {b.cob}) {marca}")

print("\n detalle de los pares 26-09 vs 11-09 con ambos válidos:")
for ep in (1, 12):
    a = [r for r in E26 if int(r["episodio"]) == ep][0]
    b = [r for r in E11 if int(r["episodio"]) == ep][0]
    def vec(r):
        P = np.array([[float(r[f"x0_a{i}"]), float(r[f"y0_a{i}"])] for i in range(5)])
        d = np.linalg.norm(P[:, None] - P[None], axis=2); np.fill_diagonal(d, np.inf)
        return d.min(axis=1).mean(), P.mean(axis=0)
    va, ca = vec(a); vb, cb = vec(b)
    print(f"   ep {ep} semilla {a['semilla']}={b['semilla']}: cobertura 26-09 {float(a['cobertura_aoi']):.4f} vs 11-09 "
          f"{float(b['cobertura_aoi']):.4f} (dif {float(a['cobertura_aoi'])-float(b['cobertura_aoi']):+.4f}) · "
          f"vecino medio x0 {va:.3f} vs {vb:.3f} m · centroide x0 ({ca[0]:.2f},{ca[1]:.2f}) vs ({cb[0]:.2f},{cb[1]:.2f})")
    for k in ("d_pared_min", "viola_018", "frac_cbf", "n_escape", "colisiones_022"):
        print(f"      {k:14s} {float(a[k]):.4f} vs {float(b[k]):.4f}")
    print(f"      réplica sesgada (sin capas, NO citar): {float(a['cobertura_replica']):.4f} vs {float(b['cobertura_replica']):.4f}")

# ─────────────────────────────────────────────────────────────────────────
print("\n=== 6) COBERTURA hw 26-09 (n=10) vs 11-09 (n=5) ===")
a, b = arr(V26, "cobertura_aoi"), arr(V11, "cobertura_aoi")
print(f" 26-09: media {a.mean():.4f} sd(ddof=1) {a.std(ddof=1):.4f} [ddof=0 {a.std():.4f}] · 11-09: media {b.mean():.4f} "
      f"sd(ddof=1) {b.std(ddof=1):.4f} [ddof=0 {b.std():.4f}]")
w = stats.ttest_ind(a, b, equal_var=False)
ci = w.confidence_interval(0.95)
va_, vb_ = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
gl = (va_ + vb_) ** 2 / (va_ ** 2 / (len(a) - 1) + vb_ ** 2 / (len(b) - 1))
print(f" diferencia {a.mean()-b.mean():+.4f} · EE {np.sqrt(va_+vb_):.4f} · gl Welch {gl:.2f} · t {w.statistic:.3f} · "
      f"IC95 [{ci.low:+.4f}, {ci.high:+.4f}] · p {w.pvalue:.4f}")
mw = stats.mannwhitneyu(a, b, method="exact")
print(f" Mann-Whitney exacto: U={mw.statistic:.0f} p={mw.pvalue:.4f}")
# Hedges g
sp = np.sqrt(((len(a)-1)*a.var(ddof=1) + (len(b)-1)*b.var(ddof=1)) / (len(a)+len(b)-2))
print(f" d de Cohen (sd combinada) {(a.mean()-b.mean())/sp:.2f}")
# bootstrap percentil
rng = np.random.default_rng(0)
bs = [rng.choice(a, len(a)).mean() - rng.choice(b, len(b)).mean() for _ in range(20000)]
print(f" IC95 bootstrap (percentil, 20000) [{np.percentile(bs,2.5):+.4f}, {np.percentile(bs,97.5):+.4f}]")

def variante(nombre, excl):
    aa = np.array([float(r["cobertura_aoi"]) for r in V26 if int(r["episodio"]) not in excl])
    w = stats.ttest_ind(aa, b, equal_var=False); ci = w.confidence_interval(0.95)
    print(f"   {nombre:38s} n={len(aa):2d} media {aa.mean():.4f} dif {aa.mean()-b.mean():+.4f} "
          f"IC95 [{ci.low:+.4f}, {ci.high:+.4f}] p {w.pvalue:.4f}")
print(" sensibilidad:")
variante("26-09 sin ep 8 (robot 6 fuera de blanco)", {8})
variante("26-09 sin episodios con rachas repetidas", {1, 4, 17, 19})
variante("26-09 sin ep 1 y 12 (semillas del 11-09)", {1, 12})
variante("26-09 sólo semillas no compartidas c/11-09", {1, 12})

# ─────────────────────────────────────────────────────────────────────────
print("\n=== contexto: ¿dónde arrancaron las rachas del 22+24-09? (zona +x+y) ===")
for nombre in ("20260922_sesion-evaluacion_etapa7_decisiones.csv",
               "20260922_sesion-evaluacion_etapa7_decisiones_02.csv",
               "20260924_sesion-evaluacion_etapa7_decisiones.csv",
               "20260911_sesion-evaluacion_etapa7_decisiones.csv"):
    D = leer_dec(nombre)
    R = rachas(D)
    viva = D[D.viva]
    nz = int(R.zona.sum()) if len(R) else 0
    print(f" {nombre[:8]}{nombre[-8:-4]}: rachas {len(R)}, en zona {nz}; filas vivas en zona {int(viva.zona.sum())} "
          f"de {len(viva)} ({viva.zona.mean():.4f})")
    if len(R):
        print("   " + "; ".join(f"ep{int(q.episodio)} a{int(q.agente)} ({q.x:.2f},{q.y:.2f})" for q in R.itertuples()))

# ─────────────────────────────────────────────────────────────────────────
print("\n=== robot 6 (agente 3) en ep 6, 7, 8, 14: ¿se movió en el episodio? ===")
for ep in (5, 6, 7, 8, 14):
    s = D26[(D26.episodio == ep) & (D26.agente == 3)].sort_values("paso")
    p = s[["pose_env_x", "pose_env_y"]].to_numpy()
    rec = np.linalg.norm(np.diff(p, axis=0), axis=1).sum()
    print(f"   ep {ep:2d}: inicio ({p[0,0]:.3f},{p[0,1]:.3f}) fin ({p[-1,0]:.3f},{p[-1,1]:.3f}) recorrido {rec:.3f} m "
          f"en {len(p)} decisiones")
