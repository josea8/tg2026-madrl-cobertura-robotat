import re, sys
F = r"C:\Users\velas\AppData\Local\Temp\claude\C--Users-velas-OneDrive-Documents-tesis\bd144444-ab27-4353-9d36-c6c2c73e1595\scratchpad\consola_20260926.txt"
OUT = F.replace("consola_20260926.txt", "a26_enlaces_consola_condensada.txt")
lines = open(F, encoding="utf-8").read().splitlines()
out = []
prev = None
guia = re.compile(r"^\s+[✔✘]?\s*robot (\d):? (está|SIN POSE|marcador)")
ultimo = {}
for i, l in enumerate(lines, 1):
    if not l.strip():
        continue
    m = guia.match(l)
    key = re.sub(r"\s+", " ", l.strip())
    if m:
        r = m.group(1)
        # normalizar decimales de 'mover' para evitar ruido 0.1 cm
        k2 = re.sub(r"mover\s+[\d.]+ cm", "mover", key)
        if ultimo.get(r) == k2:
            continue
        ultimo[r] = k2
        out.append(f"{i:5d}| G {l}")
        continue
    if key == prev:
        continue
    prev = key
    if "BLANCOS DE ESTE" in l:
        ultimo = {}
    out.append(f"{i:5d}| {l}")
open(OUT, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
print(len(out))
