import csv, math
P = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_sesion\20260926_sesion-evaluacion_etapa7_episodios.csv"
rows = list(csv.DictReader(open(P, encoding="utf-8")))
print(len(rows))
cols = ["episodio","valido","decisiones","duracion_s","cobertura_aoi","col_t_s","col_motivo","col_listos","colocacion",
        "poses_consultas","poses_fallidas","poses_rechazadas","poses_rechazos_motivo","poses_bytes_descartados","poses_consultas_con_descarte","ciclos_sobre_100ms","ciclo_p95_ms"]
for r in rows:
    print(" | ".join(f"{c}={r[c]}" for c in cols))
print()
for r in rows:
    print(r["episodio"], r["motivo"][:140])
