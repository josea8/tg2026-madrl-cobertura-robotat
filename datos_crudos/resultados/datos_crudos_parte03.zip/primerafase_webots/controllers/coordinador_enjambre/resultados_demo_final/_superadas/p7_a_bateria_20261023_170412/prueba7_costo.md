# Prueba 7: costo del panel sobre el lazo (demostración, no citable)

2026-10-23 17:18, simulador local, 3 × 300 decisiones por condición, colocación automática. El panel corre en otro proceso con prioridad bajo lo normal.

| condición | ciclo_p95_ms ep 1 | ep 2 | ep 3 | media |
|---|---|---|---|---|
| sin GUI | 37.74 | 42.12 | 46.52 | 42.13 |
| publica, sin panel | 40.02 | 45.39 | 41.64 | 42.35 |
| panel abierto | 42.09 | 46.67 | 46.98 | 45.24 |

Diferencia de medias: +3.12 ms (umbral +2 ms).

Panel: (sin salida)
