# Prueba 7: costo del panel sobre el lazo (demostración, no citable)

2026-10-23 18:27, simulador local, 3 × 300 decisiones por condición, colocación automática. El panel corre en otro proceso con prioridad bajo lo normal.

| condición | ciclo_p95_ms ep 1 | ep 2 | ep 3 | media |
|---|---|---|---|---|
| sin GUI | 13.41 | 7.84 | 8.73 | 9.99 |
| publica, sin panel | 9.27 | 9.03 | 9.88 | 9.40 |
| panel abierto | 14.18 | 13.75 | 15.75 | 14.56 |

Diferencia de medias: +4.56 ms (umbral +2 ms).

Panel: (sin salida)
