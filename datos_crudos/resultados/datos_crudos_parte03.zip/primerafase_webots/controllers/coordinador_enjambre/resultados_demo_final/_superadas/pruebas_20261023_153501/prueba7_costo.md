# Prueba 7: costo del panel sobre el lazo (demostración, no citable)

2026-10-23 15:41, simulador local, 3 × 300 decisiones por condición, colocación automática.

| condición | ciclo_p95_ms ep 1 | ep 2 | ep 3 | media |
|---|---|---|---|---|
| sin GUI | 11.66 | 11.34 | 12.38 | 11.79 |
| panel abierto | 13.73 | 14.01 | 14.09 | 13.94 |

Diferencia de medias: +2.15 ms (umbral +2 ms).

Panel: (sin salida)
