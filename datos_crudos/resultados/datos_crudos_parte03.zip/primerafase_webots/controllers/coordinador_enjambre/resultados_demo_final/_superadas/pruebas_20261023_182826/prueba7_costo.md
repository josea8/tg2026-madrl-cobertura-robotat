# Prueba 7: costo del panel sobre el lazo (demostración, no citable)

2026-10-23 18:31, simulador local, 3 × 300 decisiones por condición, colocación automática. El panel corre en otro proceso con prioridad bajo lo normal, a 5 Hz.

| condición | ciclo_p95_ms ep 1 | ep 2 | ep 3 | media |
|---|---|---|---|---|
| sin GUI (de la corrida anterior) | — | — | — | 9.99 |
| publica, sin panel | — | — | — | — |
| panel abierto | 14.84 | 13.30 | 15.19 | 14.44 |

Diferencia de medias: +4.45 ms (umbral +2 ms).

Panel: (sin salida)
