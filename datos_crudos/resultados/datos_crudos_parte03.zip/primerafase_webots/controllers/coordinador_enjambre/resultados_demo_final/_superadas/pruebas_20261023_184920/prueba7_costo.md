# Prueba 7: costo del panel sobre el lazo (demostración, no citable)

2026-10-23 18:58, simulador local, 3 × 300 decisiones por condición, colocación automática. El panel corre en otro proceso con prioridad bajo lo normal, a 10 Hz.

| condición | ciclo_p95_ms ep 1 | ep 2 | ep 3 | media |
|---|---|---|---|---|
| sin GUI | 10.22 | 21.70 | 21.56 | 17.83 |
| publica, sin panel | 22.27 | 20.10 | 23.39 | 21.92 |
| panel abierto | 17.55 | 17.30 | 19.53 | 18.13 |

Diferencia de medias: +0.30 ms (umbral +2 ms).

Panel: (sin salida)
