# Prueba 7: costo del panel sobre el lazo (demostración, no citable)

2026-10-23 15:51, simulador local, 3 × 300 decisiones por condición, colocación automática. El panel corre en otro proceso con prioridad bajo lo normal.

| condición | ciclo_p95_ms ep 1 | ep 2 | ep 3 | media |
|---|---|---|---|---|
| sin GUI | 11.64 | 11.03 | 12.31 | 11.66 |
| publica, sin panel | 12.22 | 12.42 | 12.80 | 12.48 |
| panel abierto | 13.98 | 13.39 | 9.53 | 12.30 |

Diferencia de medias: +0.64 ms (umbral +2 ms).

Panel: (sin salida)
