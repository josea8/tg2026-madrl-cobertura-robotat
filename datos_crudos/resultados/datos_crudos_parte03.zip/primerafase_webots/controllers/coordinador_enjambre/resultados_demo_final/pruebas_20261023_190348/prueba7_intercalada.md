# Prueba 7 intercalada: costo del panel sobre el lazo (demostración, no citable)

2026-10-23 19:10, simulador local, 4 rondas; en cada una, 1 episodio × 300 decisiones por condición, orden rotado ronda a ronda. Panel en otro proceso, 10 Hz, prioridad bajo lo normal.

| ronda | orden | sin GUI | publica, sin panel | panel abierto | panel − sin GUI | publica − sin GUI |
|---|---|---|---|---|---|---|
| 1 | sin_gui → publica_sin_panel → con_panel | 7.84 | 7.70 | 12.70 | +4.86 | -0.13 |
| 2 | publica_sin_panel → con_panel → sin_gui | 7.79 | 8.20 | 12.62 | +4.83 | +0.41 |
| 3 | con_panel → sin_gui → publica_sin_panel | 7.90 | 7.51 | 11.92 | +4.02 | -0.39 |
| 4 | sin_gui → publica_sin_panel → con_panel | 7.67 | 7.60 | 12.80 | +5.13 | -0.07 |

Medias: sin GUI 7.80 ms, publica 7.75 ms, panel 12.51 ms.
Diferencia pareada panel − sin GUI: media +4.71 ms (de +4.02 a +5.13); umbral +2 ms.
Diferencia pareada publica − sin GUI: media -0.05 ms (de -0.39 a +0.41).
