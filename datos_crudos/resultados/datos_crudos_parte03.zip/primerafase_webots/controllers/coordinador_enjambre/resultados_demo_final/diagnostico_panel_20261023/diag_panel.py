"""
Diagnóstico (scratchpad, no del proyecto): ¿de dónde salen los ~4.5 ms que
suma el panel abierto en la misma laptop al ciclo p95 de la decisión?

Una condición por invocación:
    python diag_panel.py <condicion> <puerto_sim> <salida.json>
Condiciones:
    sin          sin publicar, sin panel
    panel        panel normal (ventana, 10 Hz) recibiendo
    agg          panel SIN ventana (Agg), dibujando igual, recibiendo
    ventana_ociosa  panel con ventana escuchando OTRO puerto (dibuja reloj, sin datos)
    carga        un proceso Python que quema ~la misma CPU que el panel, prioridad baja
Mide por decisión: latencia de la consulta de poses (la que suma
`_correr_episodio`) y cómputo de `_decidir_y_actuar` (sin publicar), más la
CPU que usó el proceso auxiliar.
"""
import contextlib
import ctypes
import io
import json
import os
import statistics
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

CARPETA = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
sys.path.insert(0, str(CARPETA))
os.chdir(CARPETA)

import demo_final as D  # noqa: E402

cond, puerto_sim, salida = sys.argv[1], int(sys.argv[2]), Path(sys.argv[3])

# ── instrumentación: sólo sobre la clase PROPIA de la demo ─────────────────
muestras = {"lat_ms": [], "computo_ms": []}
base = D.CoordinadorEnjambre._decidir_y_actuar


def medido(self):
    lat = self.fuente._latencias[-1] if self.fuente._latencias else 0.0
    t0 = time.perf_counter()
    fin = base(self)
    muestras["computo_ms"].append(1000 * (time.perf_counter() - t0))
    muestras["lat_ms"].append(1000 * lat)
    return fin


D.CoordinadorDemo._decidir_y_actuar = medido   # sin publicar: aísla el lazo


def tiempos_cpu(handle):
    k = ctypes.windll.kernel32
    c, e, kt, ut = (wintypes.FILETIME() for _ in range(4))
    k.GetProcessTimes(int(handle), ctypes.byref(c), ctypes.byref(e),
                      ctypes.byref(kt), ctypes.byref(ut))
    f = lambda t: (t.dwHighDateTime << 32 | t.dwLowDateTime) / 1e7
    return f(kt) + f(ut)


QUEMAR = r"""
import ctypes, time, sys
ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x4000)
frac = float(sys.argv[1])
while True:
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < 0.1 * frac:
        pass
    time.sleep(0.1 * (1 - frac))
"""

aux = None
py = sys.executable
panel = [py, str(CARPETA / "panel_demo.py")]
if cond == "panel":
    aux = subprocess.Popen(panel + ["--puerto", "27310"])
elif cond == "agg":
    aux = subprocess.Popen(panel + ["--puerto", "27310", "--sin-ventana"])
elif cond == "ventana_ociosa":
    aux = subprocess.Popen(panel + ["--puerto", "27399"])
elif cond == "carga":
    aux = subprocess.Popen([py, "-c", QUEMAR, os.environ.get("FRAC", "0.4")])
time.sleep(4.0)

argv = ["--modo", "objetivos", "--simulador", "--puerto-simulador", str(puerto_sim),
        "--episodios", "1", "--decisiones", "300", "--colocacion", "actual",
        "--salida", str(salida.parent / f"diag_{cond}"), "--sin-gui"]
cpu0 = tiempos_cpu(aux._handle) if aux else 0.0
t0 = time.perf_counter()
with contextlib.redirect_stdout(io.StringIO()):
    codigo = D.main(argv, preguntar=lambda _m: "")
dur = time.perf_counter() - t0
cpu_aux = (tiempos_cpu(aux._handle) - cpu0) if aux else 0.0
if aux:
    aux.terminate()
    aux.wait(10)


def p(v, q):
    v = sorted(v)
    return v[min(len(v) - 1, int(q * len(v)))]


r = {"cond": cond, "codigo": codigo, "n": len(muestras["computo_ms"]),
     "aux_cpu_frac_de_un_nucleo": round(cpu_aux / dur, 3) if aux else 0.0}
for k, v in muestras.items():
    r[k] = {"p50": round(p(v, .5), 3), "p95": round(p(v, .95), 3), "media": round(statistics.mean(v), 3)}
ciclo = [a + b for a, b in zip(muestras["lat_ms"], muestras["computo_ms"])]
r["ciclo_ms"] = {"p50": round(p(ciclo, .5), 3), "p95": round(p(ciclo, .95), 3)}
salida.write_text(json.dumps(r, indent=1), encoding="utf-8")
print(json.dumps(r))
