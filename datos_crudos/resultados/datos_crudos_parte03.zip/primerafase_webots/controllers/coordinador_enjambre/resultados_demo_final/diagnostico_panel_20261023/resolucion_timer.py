"""Resolución ACTUAL del temporizador de Windows, sin panel / con panel /
con un proceso que sólo pide 1 ms (timeBeginPeriod). Scratchpad."""
import ctypes
import subprocess
import sys
import time
from ctypes import wintypes

PANEL = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\panel_demo.py"


def resolucion_ms():
    mn, mx, act = wintypes.ULONG(), wintypes.ULONG(), wintypes.ULONG()
    ctypes.windll.ntdll.NtQueryTimerResolution(ctypes.byref(mn), ctypes.byref(mx), ctypes.byref(act))
    return act.value / 1e4


PIDE_1MS = "import ctypes,time; ctypes.windll.winmm.timeBeginPeriod(1); time.sleep(3600)"
print(f"sin nada           : {resolucion_ms():.3f} ms")
for nombre, cmd in (("panel (ventana)", [sys.executable, PANEL, "--puerto", "27396"]),
                    ("panel sin ventana", [sys.executable, PANEL, "--puerto", "27396", "--sin-ventana"]),
                    ("timeBeginPeriod(1)", [sys.executable, "-c", PIDE_1MS])):
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(5)
    print(f"{nombre:19s}: {resolucion_ms():.3f} ms")
    p.terminate()
    p.wait(10)
    time.sleep(2)
    print(f"  después de cerrar : {resolucion_ms():.3f} ms")
