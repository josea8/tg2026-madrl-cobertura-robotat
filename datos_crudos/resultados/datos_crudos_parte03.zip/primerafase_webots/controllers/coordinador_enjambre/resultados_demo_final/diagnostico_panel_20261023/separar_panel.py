"""
¿Qué ingrediente del panel suma ~4.7 ms al ciclo p95? Intercalado.
    python separar_panel.py <rondas> <salida.json>
Condiciones (cada una: 1 episodio × 300, colocación 'actual', simulador nuevo):
  A sin GUI · B panel ventana recibiendo · C panel ventana SIN datos ·
  D panel Agg (sin ventana) recibiendo · E proceso que sólo pide 1 ms de timer
Scratchpad (no del proyecto).
"""
import contextlib
import csv
import io
import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path

CARPETA = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
sys.path.insert(0, str(CARPETA))
os.chdir(CARPETA)
import config_robotat as cfg  # noqa: E402
import demo_final as D  # noqa: E402

rondas, salida = int(sys.argv[1]), Path(sys.argv[2])
py = sys.executable
PANEL = [py, str(CARPETA / "panel_demo.py")]
TK_MINIMA = str(Path(__file__).with_name("tk_minima.py"))
PIDE_1MS = "import ctypes,time; ctypes.windll.winmm.timeBeginPeriod(1); time.sleep(3600)"
COND = {
    "A_sin_gui": (None, ["--sin-gui"]),
    "B_panel_recibe": (PANEL + ["--puerto", "27310"], ["--gui", "127.0.0.1:27310"]),
    "C_ventana_sin_datos": (PANEL + ["--puerto", "27399"], ["--sin-gui"]),
    "D_agg_recibe": (PANEL + ["--puerto", "27310", "--sin-ventana"], ["--gui", "127.0.0.1:27310"]),
    "E_timer_1ms": ([py, "-c", PIDE_1MS], ["--sin-gui"]),
    "G_tk_minima": ([py, TK_MINIMA, "normal"], ["--sin-gui"]),
    "H_tk_minimizada": ([py, TK_MINIMA, "iconic"], ["--sin-gui"]),
    "N_bloc_de_notas": (["notepad.exe"], ["--sin-gui"]),
}
if len(sys.argv) > 3:
    COND = {k: v for k, v in COND.items() if k[0] in sys.argv[3]}
nombres = list(COND)
res = {c: [] for c in nombres}
guardado = {k: getattr(cfg, k) for k in ("ESCALA_POSICION", "ROTACION_MARCO_RAD", "TRASLACION_X_M",
                                         "TRASLACION_Y_M", "OFFSET_HEADING_RAD", "offset_rumbo_de_robot")}
puerto = 29000
base = Path(salida).parent / f"separar_{time.strftime('%Y%m%d_%H%M%S')}"   # nueva en cada corrida
assert not base.exists()
for r in range(rondas):
    orden = nombres[r % len(nombres):] + nombres[:r % len(nombres)]
    for c in orden:
        puerto += 20
        aux_cmd, extra = COND[c]
        aux = subprocess.Popen(aux_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) if aux_cmd else None
        if aux:
            time.sleep(4)
        carpeta = base / f"r{r + 1}_{c}"
        argv = ["--modo", "objetivos", "--simulador", "--puerto-simulador", str(puerto),
                "--episodios", "1", "--decisiones", "300", "--colocacion", "actual",
                "--salida", str(carpeta)] + extra
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                codigo = D.main(argv, preguntar=lambda _m: "")
        finally:
            if aux:
                aux.terminate()
                aux.wait(10)
            for k, v in guardado.items():
                setattr(cfg, k, v)
        ep = list(csv.DictReader(open(next(carpeta.glob("*episodios.csv")), encoding="utf-8")))
        v = float(ep[0]["ciclo_p95_ms"])
        res[c].append(v)
        print(f"ronda {r + 1} {c:20s} válido {ep[0]['valido']} ciclo p95 {v:.2f}", flush=True)
print()
for c in nombres:
    d = [x - a for x, a in zip(res[c], res["A_sin_gui"])]
    print(f"{c:20s} media {statistics.mean(res[c]):6.2f} ms   − A pareado: media {statistics.mean(d):+.2f} "
          f"(de {min(d):+.2f} a {max(d):+.2f})")
salida.write_text(json.dumps(res, indent=1), encoding="utf-8")
