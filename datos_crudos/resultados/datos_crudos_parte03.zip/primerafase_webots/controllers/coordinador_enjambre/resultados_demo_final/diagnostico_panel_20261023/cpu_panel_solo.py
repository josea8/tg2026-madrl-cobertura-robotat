"""CPU del panel SOLO (sin la demo), con ventana, a distintos Hz. Scratchpad."""
import ctypes
import subprocess
import sys
import time
from ctypes import wintypes

PANEL = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\panel_demo.py"


def cpu(h):
    c, e, k, u = (wintypes.FILETIME() for _ in range(4))
    ctypes.windll.kernel32.GetProcessTimes(int(h), *(ctypes.byref(x) for x in (c, e, k, u)))
    f = lambda t: (t.dwHighDateTime << 32 | t.dwLowDateTime) / 1e7
    return f(k) + f(u)


for extra in sys.argv[1:]:
    args = extra.split()
    p = subprocess.Popen([sys.executable, PANEL, "--puerto", "27398"] + args,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    time.sleep(5)                       # arranque
    c0, t0 = cpu(p._handle), time.perf_counter()
    time.sleep(10)
    frac = (cpu(p._handle) - c0) / (time.perf_counter() - t0)
    p.terminate()
    p.wait(10)
    print(f"{extra:30s} CPU {frac:.2f} de un núcleo")
