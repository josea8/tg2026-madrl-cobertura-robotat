"""Ventana Tk mínima con un reloj a 10 Hz. `iconic` la abre minimizada."""
import sys
import time
import tkinter as tk

r = tk.Tk()
r.geometry("900x600")
etiqueta = tk.Label(r, text="", font=("Arial", 40))
etiqueta.pack(expand=True)
if len(sys.argv) > 1 and sys.argv[1] == "iconic":
    r.iconify()


def tic():
    etiqueta.config(text=time.strftime("%H:%M:%S") + f".{int(time.time() * 10) % 10}")
    r.after(100, tic)


tic()
r.mainloop()
