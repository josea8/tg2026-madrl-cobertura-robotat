"""Costo de un cuadro del panel CON ventana, por partes. Scratchpad.
    python cuadro_por_partes.py [dpi]"""
import base64
import json
import socket
import statistics
import sys
import time

import numpy as np

sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import panel_demo as PD  # noqa: E402

dpi = float(sys.argv[1]) if len(sys.argv) > 1 else None
PUERTO = 27397
rec = PD.Receptor(PUERTO)
panel = PD.Panel(rec, 10.0, None)
if dpi:
    panel.fig.set_dpi(dpi)
plt = panel.plt
plt.show(block=False)
panel.fig.canvas.draw()
print("tamaño del lienzo (px):", panel.fig.canvas.get_width_height())

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
rng = np.random.default_rng(0)
g = (rng.random((64, 64)) * 255).astype(np.uint8)


def enviar(k):
    s.sendto(json.dumps({"tipo": "paso", "secuencia": k + 1, "t": time.time(),
                         "modo": "objetivos", "episodio": 1, "paso": k, "decisiones": 500,
                         "agentes": [{"i": i, "robot": i, "x": 0.5 + 0.4 * i + 0.01 * k, "y": 1.0, "th": 0.1 * k,
                                      "cbf": k % 2, "escape": 0, "retroceso": 0} for i in range(5)],
                         "objetivos": [{"x": 1.0, "y": 2.0, "sigma": 0.2}] * 3, "cobertura": 0.1,
                         "acumulados": {"frac_cbf": 0.1, "escapes": 0, "retrocesos": 0, "pares_015": 0,
                                        "d_pared_min": 0.3, "ciclo_p95_ms": 9.0, "lat_poses_p95_ms": 1.0},
                         "eventos": [], "rejilla": {"forma": [64, 64], "b64": base64.b64encode(g).decode()}}
                        ).encode(), ("127.0.0.1", PUERTO))


partes = {"actualizar": [], "draw_artist": [], "blit": [], "flush_events": [], "total": []}
canvas = panel.fig.canvas
for k in range(60):
    enviar(k)
    time.sleep(0.02)
    t0 = time.perf_counter()
    panel._actualizar(rec.instantanea())
    t1 = time.perf_counter()
    if panel._fondo is None:
        canvas.draw()
    else:
        canvas.restore_region(panel._fondo)
        panel._dibujar_animados()
    t2 = time.perf_counter()
    canvas.blit(panel.fig.bbox)
    t3 = time.perf_counter()
    canvas.flush_events()
    t4 = time.perf_counter()
    if k >= 10:
        for n, v in zip(partes, (t1 - t0, t2 - t1, t3 - t2, t4 - t3, t4 - t0)):
            partes[n].append(1000 * v)
    plt.pause(0.05)
rec.detener()
for n, v in partes.items():
    print(f"{n:13s} media {statistics.mean(v):6.1f} ms   p95 {sorted(v)[int(.95 * len(v))]:6.1f} ms")

# ── por artista ──
from collections import defaultdict
costo = defaultdict(list)
for k in range(20):
    enviar(100 + k); time.sleep(0.02)
    panel._actualizar(rec.instantanea())
    canvas.restore_region(panel._fondo)
    for a in panel.animados:
        t0 = time.perf_counter(); panel.fig.draw_artist(a)
        costo[type(a).__name__ + (" (rejilla)" if a is panel.img else "")].append(1000 * (time.perf_counter() - t0))
for n, v in sorted(costo.items(), key=lambda x: -sum(x[1])):
    print(f"  {n:22s} {sum(v)/20:6.2f} ms por cuadro ({len(v)//20} artistas)")
