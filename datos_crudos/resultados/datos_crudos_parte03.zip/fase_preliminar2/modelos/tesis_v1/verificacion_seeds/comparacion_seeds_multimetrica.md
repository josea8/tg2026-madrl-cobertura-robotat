# Comparación multi-métrica — 3 seeds del Trial 13

*Generado: 2026-04-17 21:29:07*

## Hipótesis

Las 3 seeds tuvieron rewards dispares (-10 a -59) pero cobertura AoI similar (0.45–0.55). ¿Están aprendiendo cobertura comparable y difieren solo en tasa de colisión? Esta evaluación mide cuatro ejes independientes sobre 30 episodios deterministas por seed.

## Configuración

- **n_episodios por seed:** 30
- **max_steps por episodio:** 500
- **domain_rand:** False (eval determinista)
- **Modelos evaluados:** `modelos/tesis_v1/verificacion_seeds/seed_{42,123,777}/modelo_final.zip`

## Tabla comparativa

| Métrica | seed=42 (μ±σ) | seed=123 (μ±σ) | seed=777 (μ±σ) |
|---------|---------------:|----------------:|----------------:|
| Cobertura AoI final | 0.698±0.018 | 0.679±0.022 | 0.532±0.048 |
| Pares en colisión | 0.5±0.7 | 1.3±1.0 | 1.3±1.1 |
| Distancia recorrida [m] | 15.34±0.04 | 15.41±0.03 | 14.01±0.31 |
| Step al cruzar cob. 0.5 | 153±14 | 161±21 | 271±110 |

### Rango (min – max) por métrica y seed

| Métrica | seed=42 | seed=123 | seed=777 |
|---------|--------:|---------:|---------:|
| Cobertura AoI final | 0.66 – 0.72 | 0.62 – 0.71 | 0.40 – 0.61 |
| Pares en colisión | 0.00 – 3.00 | 0.00 – 4.00 | 0.00 – 4.00 |
| Distancia recorrida [m] | 15.21 – 15.42 | 15.30 – 15.47 | 12.76 – 14.32 |
| Step al cruzar cob. 0.5 | 133.00 – 190.00 | 138.00 – 225.00 | 145.00 – 500.00 |

## Análisis entre seeds

**Medias de cobertura por seed:** ['0.698', '0.679', '0.532']
- Media de las medias: **0.636**
- Desv. std entre seeds: **0.074**
- ¿Todas > 0.6? **False**
- ¿Consistente (std < 0.1)? **True**

## Criterio de decisión

| Categoría | Condición | Acción |
|-----------|-----------|--------|
| 🟢 REPORTABLE            | todas las medias > 0.6 AND std < 0.1 | Proceder a 5M con mejor seed |
| 🟡 CONSISTENTE_PERO_BAJA | std < 0.1 pero alguna media ≤ 0.6 | Ajuste manual de pesos + relanzar 100k |
| 🔴 INCONSISTENTE         | std ≥ 0.1 | tesis_v2 con espacio reducido |

### Resultado: **CONSISTENTE_PERO_BAJA**

Cobertura consistente entre seeds (std=0.074) pero insuficiente (media=0.636 < 0.6). **Ajustar pesos manualmente antes de Optuna:**
  - Subir `λ_entropy` de 1.140 → 1.80 (más presión por explorar AoI).
  - Bajar `λ_cbf` de 2.966 → 1.50 (menos miedo a proximidad).
  - Mantener `λ_gradient` y `λ_ibrm`.
  - Relanzar `verificar_reproducibilidad_trial13.py` con estos pesos modificados y re-evaluar este script.

## Figura

![Comparación boxplots](comparacion_seeds_multimetrica.png)