# Comparación A/B de λ_cbf — seed=42, 200k steps

*Generado: 2026-04-18 08:19:03*

## Motivación

La seed 42 del test de reproducibilidad alcanzó cobertura 0.698 pero con 0.5 pares-colisión por episodio — demasiado para la demo física en Pololus. ¿Conviene subir λ_cbf a 5.0 antes del 5M o confiar en que 5M reducirá colisiones por mayor experiencia?

## Variantes

| Variante | λ_cbf | Descripción |
|----------|------:|-------------|
| A | 2.9655 | Hiperparámetros Trial 13 exactos |
| B | 5.0000 | Trial 13 + λ_cbf elevado |

Resto de hiperparámetros idénticos (Trial 13): lr=6.86e-05, γ=0.9845, n_steps=128, λ_grad=0.562, λ_ent=1.140, λ_ibrm=0.484.

- **Seed:** 42
- **Steps entrenamiento:** 200,000
- **Eval:** 30 episodios deterministas sin domain_rand

## Tabla comparativa

| Métrica | Variante A (μ±σ) | Variante B (μ±σ) | Δ (B − A) |
|---------|-----------------:|-----------------:|----------:|
| Cobertura AoI final | 0.680±0.021 | 0.591±0.033 | -0.089 |
| Pares en colisión | 0.20±0.48 | 0.43±0.56 | +0.233 |
| Distancia recorrida [m] | 15.22±0.08 | 14.83±0.13 | -0.397 |
| Step al cruzar cob. 0.5 | 167±17 | 211±61 | +44.0 |

### Rangos (min – max)

| Métrica | Variante A | Variante B |
|---------|-----------:|-----------:|
| Cobertura AoI final | 0.62 – 0.72 | 0.50 – 0.64 |
| Pares en colisión | 0.00 – 2.00 | 0.00 – 2.00 |
| Distancia recorrida [m] | 15.05 – 15.37 | 14.53 – 15.09 |
| Step al cruzar cob. 0.5 | 131.00 – 209.00 | 152.00 – 488.00 |

## Criterio de decisión

| Caso | Condición | Variante 5M |
|------|-----------|:----------:|
| 🟢 B_GANA         | cob_B > 0.6 AND col_B < 0.2 | B (λ_cbf=5.0) |
| 🔴 B_COLAPSA      | cob_B < 0.5 | A + filtrar demo |
| 🟡 SIMILARES      | Δcob < 0.05 AND Δcol < 0.5 | A (simplicidad) |
| 🟡 B_MEJORA_MARGINAL | Δcol > 0.3 AND Δcob < 0.10 AND cob_B > 0.6 | B (trade-off favorable) |

### Resultado: **SIN_DECISION_CLARA** → Variante **A** (λ_cbf = 2.9655)

Trade-off ambiguo: cob_A=0.680 col_A=0.20 vs cob_B=0.591 col_B=0.43. Default a A por ser el óptimo de Optuna; revisar datos a mano.

## Comando para el 5M

```powershell
python train.py --modo entrenar --nombre_estudio tesis_v1 --n_pasos 5000000 --n_agentes 5 --max_steps_ep 500 --n_envs 4 --seed 42
```

(Usa `mejores_hiperparametros.json` que tiene λ_cbf=2.97 del Trial 13.)

## Figura

![Comparación boxplots](comparacion.png)