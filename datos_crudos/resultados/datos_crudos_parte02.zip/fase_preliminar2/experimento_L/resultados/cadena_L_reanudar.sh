#!/bin/bash
cd "/c/Users/velas/OneDrive/Documents/tesis/fase_preliminar2/experimento_L"
VENV="/c/Users/velas/venv_lab4/Scripts/python.exe"
echo "INICIO reanudar $(date)"
echo "== R2 referencia ==";      python  regimen2_inferencia.py    --condicion referencia  --dispositivo cpu  > resultados/r2_referencia.log 2>&1;  echo "fin R2 referencia $(date) rc=$?"
echo "== R1 cpu_control rep2 =="; "$VENV" regimen1_entrenamiento.py --condicion cpu_control --dispositivo cpu  --sufijo rep2 > resultados/r1_cpu_control_rep2.log 2>&1; echo "fin R1 cpu_control rep2 $(date) rc=$?"
echo "== R1 gpu rep2 ==";         "$VENV" regimen1_entrenamiento.py --condicion gpu         --dispositivo cuda --sufijo rep2 > resultados/r1_gpu_rep2.log 2>&1;         echo "fin R1 gpu rep2 $(date) rc=$?"
echo "FIN reanudar $(date)"
