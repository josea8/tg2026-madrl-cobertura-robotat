#!/bin/bash
# Repetición del régimen 1 (GPU y control) para acotar la varianza por carga ajena.
cd "/c/Users/velas/OneDrive/Documents/tesis/fase_preliminar2/experimento_L"
VENV="/c/Users/velas/venv_lab4/Scripts/python.exe"
echo "INICIO rep2 $(date)"
echo "== R1 cpu_control rep2 =="; "$VENV" regimen1_entrenamiento.py --condicion cpu_control --dispositivo cpu  --sufijo rep2 > resultados/r1_cpu_control_rep2.log 2>&1; echo "fin R1 cpu_control rep2 $(date) rc=$?"
echo "== R1 gpu rep2 ==";         "$VENV" regimen1_entrenamiento.py --condicion gpu         --dispositivo cuda --sufijo rep2 > resultados/r1_gpu_rep2.log 2>&1;         echo "fin R1 gpu rep2 $(date) rc=$?"
echo "FIN rep2 $(date)"
