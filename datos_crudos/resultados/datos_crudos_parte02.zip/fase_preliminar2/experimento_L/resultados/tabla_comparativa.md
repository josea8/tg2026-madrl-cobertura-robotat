# Experimento L — costo computacional, CPU frente a GPU

## Hardware declarado

- CPU: 13th Gen Intel(R) Core(TM) i5-13420H, 8 núcleos físicos / 12 lógicos; RAM 16.0 GiB; Windows 11 (10.0.26200).
- GPU: NVIDIA GeForce RTX 4050 Laptop GPU, 6141 MiB (torch: 6140.5 MiB), driver 592.82, CUDA runtime de la rueda 12.8, cuDNN 91900, capacidad de cómputo 8.9.
- Hilos de torch en el proceso principal: 8 (OMP_NUM_THREADS=12).
- La máquina NO estaba aislada: corrían otras aplicaciones del autor. La ocupación de CPU del sistema se muestreó durante cada corrida y se reporta al lado de cada cifra.

## Condiciones

- **gpu**: GPU (torch 2.11+cu128, cuda)
- **cpu_control**: CPU control (torch 2.11+cu128, cpu)
- **referencia**: Referencia (torch 2.10+cpu, cpu)

### Régimen 1 — entrenamiento (Trial 13, semilla 42, 200 000 pasos, 4 envs = 20 flujos)

Una corrida = 79 iteraciones PPO; cada iteración = rollout de 2560 transiciones (128 pasos × 20 flujos) + actualización de 520 minibatches de 64 (13 épocas × 40). `entorno` = `step_async`+`step_wait` del VecEnv (4 procesos, incluye IPC); `inferencia` = `collect_rollouts` − entorno (forward de la política + buffer); `actualización` = `train()`; `red` = inferencia + actualización.

**Tabla 1a — totales crudos de la corrida 1** (segundos de pared; cobertura AoI final media ± σ sobre 100 episodios deterministas del protocolo, semillas 42·10000+i, reflexión, n = 5, sobre el modelo entrenado en la condición):

| Condición | learn total | entorno | inferencia | actualización | red | pasos/s | cobertura (100 eps) | colisiones <0.15 m |
|---|---|---|---|---|---|---|---|---|
| GPU (torch 2.11+cu128, cuda) | 1175.6 | 185.0 (15.7 %) | 69.8 (5.9 %) | 920.7 (78.3 %) | 990.5 (84.3 %) | 172 | 0.675563 ± 0.021555 | 1.070 |
| CPU control (torch 2.11+cu128, cpu) | 257.2 | 68.1 (26.5 %) | 11.8 (4.6 %) | 177.3 (68.9 %) | 189.2 (73.5 %) | 786 | 0.681291 ± 0.020097 | 0.210 |
| Referencia (torch 2.10+cpu, cpu) | 283.6 | 75.6 (26.7 %) | 12.5 (4.4 %) | 195.5 (68.9 %) | 208.0 (73.3 %) | 713 | 0.681291 ± 0.020097 | 0.210 |

**Tabla 1b — todas las corridas, por iteración PPO** (mediana y mínimo sobre las 79 iteraciones; ms/minibatch = actualización/520; carga = ocupación media de CPU de todo el sistema durante la corrida, % de 12 hilos lógicos; `propio` = núcleos medios del proceso principal, sin los 4 trabajadores):

| Corrida | learn total [s] | entorno/iter med (mín) [s] | inferencia/iter med (mín) [s] | actualización/iter med (mín) [s] | ms/minibatch med (mín) | carga % | propio núcleos | cobertura 100 eps | colisiones |
|---|---|---|---|---|---|---|---|---|---|
| gpu | 1175.6 | 2.27 (0.49) | 0.785 (0.273) | 9.88 (3.30) | 19.00 (6.35) | 46.0 | 0.77 | 0.675563 | 1.070 |
| gpu_rep2 | 307.4 | 0.47 (0.39) | 0.265 (0.204) | 3.13 (2.67) | 6.02 (5.14) | 21.9 | 0.82 | 0.675563 | 1.070 |
| cpu_control | 257.2 | 0.85 (0.75) | 0.146 (0.124) | 2.21 (2.05) | 4.24 (3.94) | 81.9 | 7.11 | 0.681291 | 0.210 |
| cpu_control_rep2 | 515.6 | 1.25 (0.73) | 0.171 (0.103) | 2.95 (1.47) | 5.68 (2.82) | 74.9 | 5.71 | 0.681291 | 0.210 |
| referencia | 283.6 | 0.94 (0.84) | 0.149 (0.137) | 2.33 (2.06) | 4.48 (3.97) | 80.3 | 7.13 | 0.681291 | 0.210 |

**Contraste con Amdahl** (f y s_red MEDIDOS; control = misma rueda cu128 en CPU):

| Base de cálculo | f_red (control) | techo 1/(1−f) | s_red GPU/CPU | s_inferencia | s_actualización | s_entorno | S_pred Amdahl | S_obs |
|---|---|---|---|---|---|---|---|---|
| totales crudos, corrida 1 | 0.735 | 3.78× | 0.191× | 0.169× | 0.193× | 0.368× | 0.243× | 0.219× |
| medianas por iteración, 2+2 corridas | 0.727 | 3.66× | 0.656× | 0.500× | 0.669× | 1.784× | 0.724× | 0.793× |
| mínimos por iteración (sin contención) | 0.684 | 3.16× | 0.546× | 0.504× | 0.549× | 1.852× | 0.638× | 0.703× |

- Exp J suponía f = 0.17 (techo 1.20×). La f medida dentro de la corrida es mucho mayor porque los cuatro trabajadores simulan el entorno EN PARALELO y el proceso principal sólo espera; el perfilador del Exp J midió el entorno en serie.
- S_pred y S_obs coinciden por construcción cuando s_entorno ≈ 1; la diferencia entre ambos mide cuánto cambió el tiempo de entorno entre condiciones (contención, no dispositivo).
- Efecto de la VERSIÓN de torch (referencia 2.10 → control 2.11, ambas CPU, medianas): 0.967× total, 0.965× en la fracción de red.

**Verificación de equivalencia** (cobertura del modelo entrenado en cada corrida, 100 eps del protocolo):

- gpu: 0.67556251 (IC95 [0.6713, 0.6798]), colisiones 1.070; Δ vs oficial -0.00572849 → dentro de la banda entre semillas [0.532, 0.698].
- gpu_rep2: 0.67556251 (IC95 [0.6713, 0.6798]), colisiones 1.070; Δ vs oficial -0.00572849 → dentro de la banda entre semillas [0.532, 0.698].
- cpu_control: 0.68129082 (IC95 [0.6774, 0.6852]), colisiones 0.210; Δ vs oficial -0.00000018 → **idéntico a `modelo_PRIMERO` a 6 decimales**.
- cpu_control_rep2: 0.68129082 (IC95 [0.6774, 0.6852]), colisiones 0.210; Δ vs oficial -0.00000018 → **idéntico a `modelo_PRIMERO` a 6 decimales**.
- referencia: 0.68129082 (IC95 [0.6774, 0.6852]), colisiones 0.210; Δ vs oficial -0.00000018 → **idéntico a `modelo_PRIMERO` a 6 decimales**.

### Régimen 2 — inferencia (`modelo_PRIMERO`, protocolo del Exp E)

ms por decisión = tiempo de la llamada completa (apilar n observaciones, `predict` determinista, desempaquetar), `perf_counter`, dentro de episodios reales del entorno del protocolo (reflexión, sin domain randomization). Por (condición, n) se agrupan las decisiones de TODAS las corridas; se reporta la mediana agrupada y, entre corchetes, la media. Conjunto por corrida: n=5: 100 eps × 500 pasos; n=10: 20 eps × 500 pasos; n=20: 10 eps × 500 pasos; n=50: 4 eps × 200 pasos; n=100: 2 eps × 100 pasos. Para n ≥ 50 los episodios están truncados y el sorteo de poses cae a la grilla: sólo la latencia es válida ahí, no la cobertura.

**Tabla 2a — protocolo, mediana agrupada [media], ms** (corridas por condición: gpu 2, cpu_control 2, referencia 2):

| n agentes | decisiones/cond. | GPU (torch 2.11+cu128, cuda) | CPU control (torch 2.11+cu128, cpu) | Referencia (torch 2.10+cpu, cpu) | GPU / CPU control (medianas) |
|---|---|---|---|---|---|
| 5 | 100000 | 0.9486 [1.0394] | 0.3916 [0.4259] | 0.4959 [0.5732] | 2.42× |
| 10 | 20000 | 0.9665 [1.0188] | 0.4788 [0.4970] | 0.6274 [0.7259] | 2.02× |
| 20 | 10000 | 1.1244 [1.2149] | 0.6056 [0.6655] | 0.7086 [0.7089] | 1.86× |
| 50 | 1600 | 1.2758 [1.3819] | 0.9257 [0.9102] | 0.8951 [0.8897] | 1.38× |
| 100 | 400 | 1.3618 [1.4810] | 1.1470 [1.1112] | 1.1122 [1.1368] | 1.19× |

**Tabla 2b — por corrida, mediana [media] a n = 5 y n = 100, ms**, con carga media de CPU del sistema:

| Corrida | n=5 | n=100 | sintético n=5 | sintético n=5000 | carga % | control n=5 (cobertura 100 eps) |
|---|---|---|---|---|---|---|
| gpu | 0.9407 [1.0534] | 1.3223 [1.4108] | 0.5110 | 0.8506 | 21.0 | 0.68165370 (Δ +3.6e-04, NO reproduce) |
| gpu_rep2 | 0.9566 [1.0254] | 1.4474 [1.5511] | 0.7383 | 1.0824 | 16.2 | 0.68165370 (Δ +3.6e-04, NO reproduce) |
| cpu_control | 0.4392 [0.4679] | 1.2522 [1.3078] | 0.3463 | 8.0150 | 79.4 | 0.68129082 (Δ -1.8e-07, reproduce) |
| cpu_control_rep2 | 0.3545 [0.3839] | 0.8825 [0.9147] | 0.1941 | 5.7092 | 71.2 | 0.68129082 (Δ -1.8e-07, reproduce) |
| referencia | 0.7483 [0.7854] | 1.2538 [1.3721] | 0.2958 | 9.5121 | 72.8 | 0.68129082 (Δ -1.8e-07, reproduce) |
| referencia_rep2 | 0.3338 [0.3609] | 0.8774 [0.9014] | 0.1604 | 5.1423 | 70.9 | 0.68129082 (Δ -1.8e-07, reproduce) |

Publicado en Exp E (n = 5, CPU, torch 2.10): MADRL 0.757 ms de media (0.734 sólo reflexión); Voronoi+PSO 8.039 ms.

**Tabla 2c — barrido sintético (complementario, NO protocolo)**: `predict` sobre lotes `(n, 24)` aleatorios fijos; mediana de 300 repeticiones (100 para n > 1000), promediada entre corridas, ms:

| n | GPU (torch 2.11+cu128, cuda) | CPU control (torch 2.11+cu128, cpu) | Referencia (torch 2.10+cpu, cpu) | GPU / CPU control |
|---|---|---|---|---|
| 5 | 0.6246 | 0.2702 | 0.2281 | 2.31× |
| 10 | 0.5149 | 0.2800 | 0.2522 | 1.84× |
| 20 | 0.5519 | 0.3000 | 0.2696 | 1.84× |
| 50 | 0.5237 | 0.3480 | 0.3207 | 1.50× |
| 100 | 0.5324 | 0.4216 | 0.4040 | 1.26× |
| 200 | 0.5269 | 0.5909 | 0.5893 | 0.89× |
| 500 | 0.5548 | 0.9124 | 0.9446 | 0.61× |
| 1000 | 0.5852 | 1.5377 | 1.4550 | 0.38× |
| 2000 | 0.6037 | 3.1207 | 2.8062 | 0.19× |
| 5000 | 0.9665 | 6.8621 | 7.3272 | 0.14× |

**Punto de cruce:** AUSENTE en el rango protocolar n ∈ {5..100}: la GPU es más lenta en todos los cardinales. En el barrido sintético, desde n = 200.

