#!/bin/bash
# Cadena del Experimento L: una condición a la vez, nunca dos en paralelo.
cd "/c/Users/velas/OneDrive/Documents/tesis/fase_preliminar2/experimento_L"
VENV="/c/Users/velas/venv_lab4/Scripts/python.exe"
TESIS="python"
echo "INICIO $(date)"
echo "== R1 gpu ==";         "$VENV"  regimen1_entrenamiento.py --condicion gpu         --dispositivo cuda > resultados/r1_gpu.log 2>&1;         echo "fin R1 gpu $(date) rc=$?"
echo "== R1 cpu_control =="; "$VENV"  regimen1_entrenamiento.py --condicion cpu_control --dispositivo cpu  > resultados/r1_cpu_control.log 2>&1; echo "fin R1 cpu_control $(date) rc=$?"
echo "== R1 referencia ==";  "$TESIS" regimen1_entrenamiento.py --condicion referencia  --dispositivo cpu  > resultados/r1_referencia.log 2>&1;  echo "fin R1 referencia $(date) rc=$?"
echo "== R2 gpu ==";         "$VENV"  regimen2_inferencia.py    --condicion gpu         --dispositivo cuda > resultados/r2_gpu.log 2>&1;         echo "fin R2 gpu $(date) rc=$?"
echo "== R2 cpu_control =="; "$VENV"  regimen2_inferencia.py    --condicion cpu_control --dispositivo cpu  > resultados/r2_cpu_control.log 2>&1; echo "fin R2 cpu_control $(date) rc=$?"
echo "== R2 referencia ==";  "$TESIS" regimen2_inferencia.py    --condicion referencia  --dispositivo cpu  > resultados/r2_referencia.log 2>&1;  echo "fin R2 referencia $(date) rc=$?"
echo "FIN $(date)"
