export const meta = {
  name: 'verificar-afirmaciones-fase0',
  description: 'Adversarial read-only check of the qualitative claims in the Phase 0 report and lab protocol against code and data',
  phases: [
    { title: 'Verificar', detail: 'one skeptic per claim group, two for the critical ones' },
  ],
}

const COORD = 'C:\\Users\\velas\\OneDrive\\Documents\\tesis\\primerafase_webots\\controllers\\coordinador_enjambre'
const TESIS = 'C:\\Users\\velas\\OneDrive\\Documents\\tesis'
const REPORTE = TESIS + '\\REPORTE_2026-10-02_obstaculo_fase0.md'
const PROTOCOLO = TESIS + '\\PROTOCOLO_L0_L2.md'

const REGLAS = `
STRICT RULES:
- READ-ONLY. Do NOT modify, create, move or delete any file under ${TESIS}. If you need a helper script, write it ONLY under the scratchpad directory C:\\Users\\velas\\AppData\\Local\\Temp\\claude\\C--Users-velas-OneDrive-Documents-tesis\\cc510369-0bba-489d-9bbd-57ba8af8e5d7\\scratchpad\\verif_wf\\ and run it with python (the thesis Python; numpy available).
- Do NOT start simulations, servers, or test suites (other processes may need the CPU); static reading and small read-only scripts only.
- Your posture is adversarial: try to REFUTE each claim. Mark a claim "confirmed" only if you found direct evidence (file:line or data value). If uncertain, use "uncertain" and say exactly what is missing.
- Files in ${COORD} have MIXED line endings (old files CRLF, new ones LF); count with Python on bytes, not grep.
- Answer in Spanish. Evidence must cite file paths with line numbers.
`

const SCHEMA = {
  type: 'object',
  properties: {
    afirmaciones: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          afirmacion: { type: 'string' },
          veredicto: { type: 'string', enum: ['confirmada', 'refutada', 'parcial', 'incierta'] },
          evidencia: { type: 'string' },
          gravedad: { type: 'string', enum: ['ninguna', 'menor', 'importante', 'critica'] },
          correccion_sugerida: { type: 'string' },
        },
        required: ['afirmacion', 'veredicto', 'evidencia', 'gravedad', 'correccion_sugerida'],
      },
    },
    resumen: { type: 'string' },
  },
  required: ['afirmaciones', 'resumen'],
}

const GRUPOS = [
  {
    key: 'barrera-sin-cambios',
    copias: 2,
    prompt: `Context: thesis demo of a moving obstacle (robot 7) with a CBF safety filter. On 2026-10-02 the "obedience check" of the obstacle was changed after a false positive. The report (${REPORTE}, sections 1, 7.2) claims: (1) only the validity judge changed, NOT the barrier: the obstacle row of the QP receives exactly the same velocity estimate v_hat as before in every case (with an estimate: same value; without estimate: 0, as before); (2) velocidad_obstaculo() now returns None when there is no estimate (instead of 0) and the verification does not judge without an estimate and requires 5 consecutive decisions (N_CONFIRMACION_OBEDIENCIA); (3) the "patada" (kick-start) behaves the same; (4) the predictor (F2), the escape layer and the backup brake see the same velocity as before.
Compare ${COORD}\\demo_obstaculo_movil.py (current) against the backup ${COORD}\\demo_obstaculo_movil_respaldo_20261002_preObediencia.py. Produce a complete diff (e.g. python difflib) and classify EVERY hunk. For every call site of velocidad_obstaculo (and any attribute it feeds), prove whether the value reaching the barrier row, the predictor, the escape normal, the brake and the patada is identical to the old behavior for all inputs (estimate present, absent, stale). Also check that None can never reach arithmetic (TypeError risk) anywhere, including CSV logging. Also read ${TESIS}\\PROPUESTA_obediencia_obstaculo.md and check the implementation matches it.
${REGLAS}`,
  },
  {
    key: 'regla-10s',
    copias: 1,
    prompt: `Context: an existing lab file ${COORD}\\sesion_robotat.py (CRLF) was modified with authorization on 2026-10-02 to fix a false positive in the "sin desplazamiento por 10 s" abort rule inside _correr_episodio. Backup: ${COORD}\\sesion_robotat_respaldo_20261002_preEstancamiento.py. The report (${REPORTE} section 7.1) and ${TESIS}\\PROPUESTA_regla_estancamiento.md claim: (1) the ONLY changes are two constants (MARGEN_RETARDO_ESTANCAMIENTO_S=1.0, CORTE_ORDEN_ESTANCAMIENTO_S=1.0) and the rule in _correr_episodio: t_ref = max(t_mov, t_inicio_orden + 1.0 s) with a 1.0 s hysteresis without command; (2) by construction the new rule can only REMOVE cuts, never add one (new cuts are a subset of old cuts, and a new cut never happens earlier than the old one would); (3) the copy of the rule in _correr_escalon (~line 3317-3326) was left untouched; (4) CRLF preserved on all 3866 lines, no stray LF; (5) agents in gestor.en_retroceso are still skipped as before.
Diff the two files completely (python difflib on bytes decoded), classify every hunk, and try hard to construct a counterexample to claim (2) (e.g. via the con_orden gating, hysteresis reset, t_orden initialization, decisions with |v|<=0.02, or retroceso). Check whether the old rule also only applied with a command; if the old rule cut in situations where the new one does not check at all, that is fine for claim (2) but report it. Also check ${COORD}\\test_regla_estancamiento.py actually exercises the real _correr_episodio (not a copy).
${REGLAS}`,
  },
  {
    key: 'validez-y-sesion-lab',
    copias: 2,
    prompt: `Context: the lab protocol ${PROTOCOLO} and the report ${REPORTE} (section 4, 8, 11) define two validities for lab takes: (a) measurement validity = the take runs complete through the lab loop (_correr_episodio with all its rules) — any abort invalidates it; (b) demo validity = valid AND no intervention of the backup brake AND no agent < 0.15 m from the obstacle AND the obstacle traveled at least half of the commanded path. Principal metric: min agent-obstacle distance per take measured at 10 Hz (d_min_obst_medida). L2 command: python demo_obstaculo_movil.py --modo L2 --tomas 10 --intentos 20 (goal 10 demo-valid takes within 20 attempts). The protocol also lists STOP RULES during the session: (1) contact (some agent < 0.15 m from obstacle) -> stop the session and review; (2) two consecutive takes with brake intervention -> stop and review; (3) obstacle that does not move or brake (obedience abort) -> check robot 7 before the next take. It also says the safe-start ramp exists only in the FIRST take of the session because it counts per channel.
Verify against ${COORD}\\demo_obstaculo_movil.py (functions validez_demo, sesion_demo, main CLI, SupervisorObstaculo) and ${COORD}\\analizar_sesion_demo.py: Does sesion_demo count attempts and stop at 10 demo-valid takes or 20 attempts? Does it count "demo-valid" or "measurement-valid" toward the goal of 10? Are the three stop rules IMPLEMENTED in code (automatic) or only operator procedure? If only operator procedure, does the protocol make that explicit enough for a person running the lab? Is the brake ACTIVE in L1/L2 sessions (not shadow)? Is the 10 Hz metric the one reported? Does analizar_sesion_demo compute both validities exactly as defined? Also check the dry run output in ${COORD}\\resultados_demo_obstaculo\\ensayo_l2_20261002_201318\\ (tomas CSV, resumen) is consistent with those definitions (10 demo-valid in 11 attempts, attempt 2 aborted by pose age > 150 ms).
${REGLAS}`,
  },
  {
    key: 'l0-y-cli',
    copias: 1,
    prompt: `Context: lab protocol ${PROTOCOLO}, stage L0 (obstacle robot 7 alone): command python demo_obstaculo_movil.py --modo L0 (reserve robot: --robot-obstaculo 4). Claimed procedure: the session asks to place robot 7 at (1.5, 0.9) of the env, facing +x, within ±8 cm and ±30°, and verifies it; then 10 starts from rest, each with a kick of 0.08 m/s for <= 1 s, 6 s of motion along the circle (radius 0.60 around (1.5,1.5), 0.05 m/s counterclockwise) and 2 s pause. Criterion: 10/10 starts (each moves >= 3 mm before 1.5 s) and max radial error < 5 cm excluding the first 2 s of each run; also reports the fraction of decisions with saturated omega. L1: --modo L1 --tomas 3 --intentos 6 with robot 7 off and still at (1.5,1.5), agents' targets >= 0.50 m from it.
Verify in ${COORD}\\demo_obstaculo_movil.py (sesion_l0, sesion_demo for L1, main/argparse, constants) and ${COORD}\\config_robotat.py that every number and behavior above matches the code exactly, that --robot-obstaculo 4 correctly switches robot id, marker id and network address (check the marker mapping and IP tables in config_robotat.py), and that L0 really fails/stops when the criterion fails. Report any mismatch between protocol text and code.
${REGLAS}`,
  },
  {
    key: 'texto-del-reporte',
    copias: 1,
    prompt: `Read the full report ${REPORTE}. All its NUMBERS are already verified by a script (verificar_cifras_fase0.py, 160/160) — do not re-verify those. Your job is the QUALITATIVE and MECHANISM claims that the script cannot check. Examples: "En la campaña el freno va en sombra: se registra cuándo habría frenado, pero el obstáculo no frena"; "La rampa de arranque seguro existe sólo en la primera toma de la sesión, porque cuenta por canal"; "el rescate lo deja en 'no acercarse', y el escape lo saca de costado a los ~0.6 s"; "Con el obstáculo quieto es bit a bit la del Exp O, con r = 0.15. Hay prueba que extrae la función del Exp O con ast"; "En el QP, ω cuesta ~3.3 veces menos que v (W_OMEGA = 0.3)"; "Peso de giro 3.0, sólo si ninguna otra fila está cerca de ligar (h < 0.06)"; "τ_c = 0.65 s quedó fijado antes del barrido"; "el robot 7 no va como agente 5: con el índice 5, _correr_episodio daba KeyError en MAPEO_AGENTES[5]"; "la colocación autónoma no ve al 7, porque colocar_enjambre filtra sólo contra los agentes"; "freno de respaldo a 0.25 m"; "el retroceso va sin CBF, y lo cubre el freno a 0.60 m"; "La fuente lee los 6 marcadores en una consulta de lote por decisión"; the parameters of F1 (h = ‖p_i − p_o‖ − 0.33, rhs = −α·h + s/k, s = max(0, n·v̂_o, n·v_cmd), k = 0.40, saturated at 90 %); the description of the confirmation set (fase 2.3 rad, arco 0.45 m, disparo 0.50 m, semillas 420100–420109). Also the citation: Molnar, T. G., Kiss, A. K., Ames, A. D., & Orosz, G. (2023). Safety-critical control with input delay in dynamic environment. IEEE Transactions on Control Systems Technology, 31(4), 1507–1520. https://doi.org/10.1109/TCST.2022.3227451 — check it with WebSearch/WebFetch if available (exact title, authors, volume, issue, pages, DOI).
Check each against ${COORD}\\demo_obstaculo_movil.py, ${COORD}\\correr_fase0_obstaculo.py, ${COORD}\\lib\\filtro_cbf.py (or wherever the CBF filter lives — search), ${COORD}\\sesion_robotat.py, ${COORD}\\test_demo_obstaculo_movil.py and the data under ${COORD}\\resultados_demo_obstaculo\\. Also flag any sentence in the report that is ambiguous, overclaims (this demo is NOT a citable thesis result), or contradicts another section of the report or ${PROTOCOLO}.
${REGLAS}`,
  },
]

const trabajos = GRUPOS.flatMap(g => Array.from({ length: g.copias }, (_, i) => ({ ...g, i })))
log(`${trabajos.length} verificadores sobre ${GRUPOS.length} grupos de afirmaciones`)

const res = await pipeline(
  trabajos,
  t => agent(t.prompt + (t.copias > 1 ? `\n(Independent verifier #${t.i + 1} of ${t.copias}; work on your own.)` : ''),
    { label: `${t.key}#${t.i + 1}`, phase: 'Verificar', schema: SCHEMA }),
)

return trabajos.map((t, k) => ({ grupo: t.key, verificador: t.i + 1, resultado: res[k] }))
