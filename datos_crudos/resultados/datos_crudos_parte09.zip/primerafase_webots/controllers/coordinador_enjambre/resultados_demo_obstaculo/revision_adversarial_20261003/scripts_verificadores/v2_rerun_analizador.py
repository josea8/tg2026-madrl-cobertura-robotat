import sys
sys.dont_write_bytecode = True
from pathlib import Path
src = Path(r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/analizar_sesion_demo.py").read_text(encoding="utf-8")
ns = {"__name__": "analizador_copia"}
exec(compile(src, "analizar_sesion_demo_copia", "exec"), ns)
S = Path(r"C:/Users/velas/AppData/Local/Temp/claude/C--Users-velas-OneDrive-Documents-tesis/cc510369-0bba-489d-9bbd-57ba8af8e5d7/scratchpad/verif_wf/copia")
r = ns["resumir"](S / "20261002_202234_L2_tomas.csv")
print(r)
a = (S / "20261002_202234_L2_resumen.txt").read_bytes()
b = Path(r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_demo_obstaculo/ensayo_l2_20261002_201318/20261002_202234_L2_resumen.txt").read_bytes()
print("resumen identico al de disco:", a == b, len(a), len(b))
