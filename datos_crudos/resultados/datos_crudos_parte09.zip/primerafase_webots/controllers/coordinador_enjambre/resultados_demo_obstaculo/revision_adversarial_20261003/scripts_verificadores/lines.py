D = r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/"
import hashlib
for fn in ("sesion_robotat_respaldo_20261002_preEstancamiento.py","sesion_robotat.py"):
    L = open(D+fn,"rb").read().decode("utf-8").split("\r\n")
    for i,l in enumerate(L,1):
        if "for fila in filas_dec:" in l or "con comando no nulo" in l or "def _correr_escalon" in l or "def _correr_episodio" in l:
            print(fn, i, l.strip())
    # hash of _correr_escalon body
    s = [i for i,l in enumerate(L) if l.startswith("def _correr_escalon")][0]
    e = s+1
    while e < len(L) and not (L[e].startswith("def ") or L[e].startswith("class ")): e+=1
    print(fn, "_correr_escalon lines", s+1, e, hashlib.sha256("\n".join(L[s:e]).encode()).hexdigest()[:16])
    # tabs, trailing whitespace in changed region
