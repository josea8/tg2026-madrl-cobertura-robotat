import difflib
d = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
new = open(d + r"\demo_obstaculo_movil.py", "rb").read()
old = open(d + r"\demo_obstaculo_movil_respaldo_20261002_preObediencia.py", "rb").read()
for name, b in (("new", new), ("old", old)):
    crlf = b.count(b"\r\n"); lf = b.count(b"\n")
    print(name, "bytes", len(b), "CRLF", crlf, "LF-only", lf - crlf)
nl = new.decode("utf-8").replace("\r\n", "\n").split("\n")
ol = old.decode("utf-8").replace("\r\n", "\n").split("\n")
print("lines old", len(ol), "new", len(nl))
diff = list(difflib.unified_diff(ol, nl, "old", "new", lineterm="", n=3))
open("diff_full.txt", "w", encoding="utf-8").write("\n".join(diff))
hunks = [l for l in diff if l.startswith("@@")]
print("hunks", len(hunks))
for h in hunks: print(h)
