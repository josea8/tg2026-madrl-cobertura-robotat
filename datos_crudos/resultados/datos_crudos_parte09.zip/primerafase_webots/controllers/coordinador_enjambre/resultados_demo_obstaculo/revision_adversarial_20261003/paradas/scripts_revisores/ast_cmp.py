import ast, io
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
def load(p):
    return ast.parse(io.open(p, encoding="utf-8").read())
def strip(node):
    node = ast.parse(ast.unparse(node)).body[0] if not isinstance(node, ast.Module) else node
    for n in ast.walk(node):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)):
            b = n.body
            if b and isinstance(b[0], ast.Expr) and isinstance(getattr(b[0], "value", None), ast.Constant) and isinstance(b[0].value.value, str):
                n.body = b[1:] or [ast.Pass()]
    return ast.dump(node, include_attributes=False)
def collect(tree):
    out = {}
    def rec(nodes, prefix):
        for n in nodes:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + n.name
                out[name] = n
                rec(n.body, name + ".")
    rec(tree.body, "")
    return out
A = load(D + r"\demo_obstaculo_movil_respaldo_20261003_preParadas.py")
B = load(D + r"\demo_obstaculo_movil.py")
fa, fb = collect(A), collect(B)
print("Solo en respaldo:", sorted(set(fa) - set(fb)))
print("Solo en actual:", sorted(set(fb) - set(fa)))
changed = [k for k in fa if k in fb and strip(fa[k]) != strip(fb[k])]
print("Cambiados (cuerpo sin docstring):", changed)
same = [k for k in fa if k in fb and strip(fa[k]) == strip(fb[k])]
print("Idénticos:", len(same), "de", len(set(fa)&set(fb)))
# module-level non-def statements
def toplevel(tree):
    res = []
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        if isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str):
            continue
        res.append(ast.dump(n))
    return res
ta, tb = toplevel(A), toplevel(B)
sa, sb = set(ta), set(tb)
print("Top-level solo en respaldo:", [ast.unparse(ast.parse("x")) for _ in []])
for t in ta:
    if t not in sb: print("  - RESPALDO:", t[:200])
for t in tb:
    if t not in sa: print("  + ACTUAL:", t[:200])
# list all names
print("\nTodos los nombres de funciones/clases:")
print(sorted(fb))
