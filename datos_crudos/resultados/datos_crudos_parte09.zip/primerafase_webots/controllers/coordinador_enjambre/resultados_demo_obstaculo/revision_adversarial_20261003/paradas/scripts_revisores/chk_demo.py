import sys, math
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import demo_obstaculo_movil as demo
from coordinador_enjambre import SEMILLAS_LOTE
print("len SEMILLAS_LOTE", len(SEMILLAS_LOTE), SEMILLAS_LOTE[0], SEMILLAS_LOTE[-1])
def semilla(intento):
    return (SEMILLAS_LOTE[intento - 1] if intento <= len(SEMILLAS_LOTE)
            else SEMILLAS_LOTE[0] + intento - 1)
ss = [semilla(i) for i in range(1, 41)]
print("unicas", len(set(ss)) == len(ss), ss[15:22])
par = demo.ParametrosTrayectoria()
print(demo._metricas_l0([], [], par))
print(demo._metricas_l0([], [{"arranque":0,"t_movimiento_s":0.3,"arranco":1}], par))
filas=[{"t":0.5,"error_radial":0.2,"w":par.omega_max},{"t":2.5,"error_radial":-0.03,"w":0.1}]
print(demo._metricas_l0(filas, [], par))
# regla con frenos previos de otra sesion: cuenta reinicia
print(demo.regla_de_parada({"frenos":1}, []))
print(demo.regla_de_parada({"frenos":1}, [{"frenos":1}]))
