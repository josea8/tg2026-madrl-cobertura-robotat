"""Chequeo puro: ¿qué fracción de los traslados de colocación pasan cerca del
obstáculo? Reimplementa (sin importar la tesis) sortear_poses_arranque,
sortear_blancos_demo, fase_arranque_obstaculo y punto_del_circulo.
Inicio de cada traslado = blanco de la toma ANTERIOR (proxy de dónde quedó
el agente; el real es dónde terminó la toma, que se desconoce)."""
import math
import numpy as np

MARGEN = 0.45
SEP = 0.45
SEP_OBST = 0.50
W = 3.0
ID_OBST = 7


def sortear_poses_arranque(n, rng, intentos=400):
    puestos = []
    for _ in range(n):
        for _t in range(intentos):
            c = np.array([rng.uniform(MARGEN, W - MARGEN),
                          rng.uniform(MARGEN, W - MARGEN)])
            if all(np.linalg.norm(c - p) > SEP for p in puestos):
                puestos.append(c)
                break
        else:
            raise RuntimeError
    return {i: p for i, p in enumerate(puestos)}


def blancos_demo(n, semilla, punto):
    rng = np.random.default_rng(int(semilla))
    for _ in range(200):
        b = sortear_poses_arranque(n, rng)
        if all(np.linalg.norm(p - punto[:2]) >= SEP_OBST for p in b.values()):
            return b
    raise RuntimeError


def fase(semilla):
    return float(np.random.default_rng([int(semilla), ID_OBST]).uniform(-math.pi, math.pi))


def punto(f):
    return np.array([1.5 + 0.6 * math.cos(f), 1.5 + 0.6 * math.sin(f)])


def dist_seg(p, a, b):
    ab = b - a
    t = 0.0 if not ab.any() else max(0.0, min(1.0, float((p - a) @ ab / (ab @ ab))))
    return float(np.linalg.norm(a + t * ab - p))


semillas = [420000 + k for k in range(20)]
for modo in ("L1", "L2"):
    cerca38 = cerca50 = total = 0
    anterior = None
    obst_ant = None
    for s in semillas:
        o = np.array([1.5, 1.5]) if modo == "L1" else punto(fase(s))
        b = blancos_demo(5, s, o)
        if anterior is not None:
            # en L2 el obstáculo está, al empezar la colocación, donde quedó
            # (proxy: su punto de arranque anterior); en L1, siempre el centro
            o_ahora = o if modo == "L1" else obst_ant
            for i in range(5):
                total += 1
                d = dist_seg(o_ahora, anterior[i], b[i])
                cerca38 += d < 0.38
                cerca50 += d < 0.50
        anterior, obst_ant = b, o
    print(f"{modo}: traslados {total}; pasan a <0.38 m del centro del "
          f"obstáculo {cerca38} ({100*cerca38/total:.0f} %); a <0.50 m "
          f"{cerca50} ({100*cerca50/total:.0f} %)")

# Blanco de un agente demasiado cerca de la pose ACTUAL del obstáculo (L2):
# el obstáculo arranca la colocación donde quedó, los blancos se separan sólo
# de su PUNTO NUEVO.
bloqueados = 0
tot = 0
for k in range(1, 20):
    s_prev, s = semillas[k - 1], semillas[k]
    o_prev = punto(fase(s_prev))
    o = punto(fase(s))
    b = blancos_demo(5, s, o)
    for i in range(5):
        tot += 1
        bloqueados += np.linalg.norm(b[i] - o_prev) < 0.50
print(f"L2: blancos a <0.50 m de donde el obstáculo arrancó la toma anterior: "
      f"{bloqueados}/{tot}")

# Rumbos: L1 / L2 ¿el segmento del obstáculo (L2) cruza el de algún agente?
def cruzan(a, b, c, d, r=0.30):
    # distancia mínima entre segmentos por muestreo
    ts = np.linspace(0, 1, 41)
    P = a[None, :] + ts[:, None] * (b - a)[None, :]
    Q = c[None, :] + ts[:, None] * (d - c)[None, :]
    return float(np.min(np.linalg.norm(P[:, None, :] - Q[None, :, :], axis=2))) < r

cr = 0
for k in range(1, 20):
    s_prev, s = semillas[k - 1], semillas[k]
    o_prev, o = punto(fase(s_prev)), punto(fase(s))
    b_prev = blancos_demo(5, s_prev, o_prev)
    b = blancos_demo(5, s, o)
    cr += any(cruzan(o_prev, o, b_prev[i], b[i]) for i in range(5))
print(f"L2: tomas cuyo traslado (cuerda) del obstáculo pasa a <0.30 m de la "
      f"trayectoria recta de algún agente: {cr}/19")
