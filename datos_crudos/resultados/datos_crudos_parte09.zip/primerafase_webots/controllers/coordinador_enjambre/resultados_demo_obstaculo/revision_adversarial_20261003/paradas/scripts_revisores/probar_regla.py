"""Chequeos puros de regla_de_parada (sin sockets, sin simulador)."""
import io
import contextlib
import sys
from pathlib import Path

import numpy as np

CARPETA = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots"
               r"\controllers\coordinador_enjambre")
sys.path.insert(0, str(CARPETA))
with contextlib.redirect_stdout(io.StringIO()):
    import demo_obstaculo_movil as demo

R = demo.regla_de_parada


def base(**kw):
    t = {"valido": 1, "motivo": "", "d_min_obst_medida": 0.30, "frenos": 0,
         "obst_motivo_aborto": ""}
    t.update(kw)
    return t


casos = {
    "normal": base(),
    "contacto float": base(d_min_obst_medida=0.149),
    "contacto np.float64": base(d_min_obst_medida=np.float64(0.12)),
    "contacto np.float32": base(d_min_obst_medida=np.float32(0.1499)),
    "contacto str '0.12'": base(d_min_obst_medida="0.12"),
    "contacto str con coma '0,12'": base(d_min_obst_medida="0,12"),
    "d vacio": base(d_min_obst_medida=""),
    "d None": base(d_min_obst_medida=None),
    "d nan": base(d_min_obst_medida=float("nan")),
    "d -inf": base(d_min_obst_medida=float("-inf")),
    "d 0.0": base(d_min_obst_medida=0.0),
    "d negativo": base(d_min_obst_medida=-0.01),
    "sin clave d": {"valido": 0, "motivo": "x"},
    # Camino de retorno temprano de correr_toma (reinicio fallido)
    "reinicio fallido": {"valido": 0, "semilla": 1,
                         "motivo": "no se pudo iniciar la toma",
                         "d_min_obst_medida": "", "frenos": 0,
                         "obst_motivo_aborto": "", "valido_demo": 0},
    "aborto supervisor": base(valido=0, motivo="OBSTÁCULO: x",
                              obst_motivo_aborto="x"),
    "aborto enlace (solo motivo)": base(valido=0, motivo="OBSTÁCULO: enlace"),
    "aborto pose vencida medicion": base(valido=0,
                                         motivo="antigüedad de pose sobre el umbral"),
    "motivo 'OBSTACULO:' sin tilde": base(valido=0, motivo="OBSTACULO: x"),
    "motivo con espacio inicial": base(valido=0, motivo=" OBSTÁCULO: x"),
    "frenos str '1'": base(frenos="1"),
    "frenos float 1.0": base(frenos=1.0),
}
for nombre, t in casos.items():
    try:
        r = R(t, [])
    except Exception as exc:  # noqa: BLE001
        r = f"EXCEPCION {type(exc).__name__}: {exc}"
    print(f"{nombre:35s} -> {r}")

print("\n--- frenos seguidos ---")
F = base(frenos=1)
N = base()
print("F,F            :", R(F, [F]))
print("F,(N),F        :", R(F, [F, N]))
print("F,reinicio,F   :", R(F, [F, casos["reinicio fallido"]]))
print("frenos '1.0'   :", end=" ")
try:
    print(R(base(frenos="1.0"), [base(frenos="1.0")]))
except Exception as exc:  # noqa: BLE001
    print("EXCEPCION", type(exc).__name__, exc)

print("\n--- respuestas ---")
for resp in ["s", "S", " s ", "sí", "si", "SÍ", "", "n", "seguir", "s\r",
             "\ufeffs", "s.", "yes", None, "ｓ"]:
    seguir = str(resp).strip().lower() in ("s", "si", "sí")
    print(f"{resp!r:12} -> {'sigue' if seguir else 'DETENIDA'}")
