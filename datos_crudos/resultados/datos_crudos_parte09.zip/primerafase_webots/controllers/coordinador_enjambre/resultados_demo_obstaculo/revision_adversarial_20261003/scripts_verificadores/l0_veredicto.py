# Replica literal de demo_obstaculo_movil.py:2118-2129 para probar el veredicto
def veredicto(filas, resultados, arranques=10, omega_max=1.0):
    errores = [abs(f["error_radial"]) for f in filas if f["t"] >= 2.0]
    arrancaron = sum(r["arranco"] for r in resultados)
    e_max = max(errores) if errores else float("nan")
    saturadas = (sum(1 for f in filas if abs(f["w"]) >= omega_max - 1e-9) / len(filas) if filas else float("nan"))
    ok = arrancaron == arranques and errores and e_max < 0.05
    return ("OK" if ok else "FALLO"), arrancaron, e_max, saturadas
def filas_con(err_late, err_early=0.0, w=0.08):
    out=[]
    for k in range(10):
        for i in range(60):
            t=i*0.1
            out.append({"t":t,"error_radial":(err_early if t<2.0 else err_late),"w":w})
    return out
todos=[{"arranco":1}]*10
print("10/10, e 0.049:", veredicto(filas_con(0.049), todos))
print("10/10, e 0.050:", veredicto(filas_con(0.050), todos))
print("9/10, e 0.01:", veredicto(filas_con(0.01), [{"arranco":1}]*9+[{"arranco":0}]))
print("10/10, e temprano 0.09 tarde 0.01:", veredicto(filas_con(0.01, 0.09), todos))
print("sin filas:", veredicto([], todos))
print("w saturado siempre:", veredicto(filas_con(0.01, w=1.0), todos))
