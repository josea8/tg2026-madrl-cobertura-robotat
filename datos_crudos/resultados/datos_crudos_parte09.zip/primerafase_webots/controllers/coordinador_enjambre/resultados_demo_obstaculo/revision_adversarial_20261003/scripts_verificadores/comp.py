import ast
D = r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/"
for fn in ("sesion_robotat_respaldo_20261002_preEstancamiento.py","sesion_robotat.py"):
    src = open(D+fn,"rb").read().decode("utf-8")
    code = compile(src, fn, "exec")   # in memory, no .pyc written
    tree = ast.parse(src)
    # module-level assignment of the constants?
    names = [n.target.id for n in tree.body if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)]
    print(fn, "compiles OK;", "MARGEN at module level:", "MARGEN_RETARDO_ESTANCAMIENTO_S" in names, "CORTE:", "CORTE_ORDEN_ESTANCAMIENTO_S" in names)
    # top-level function set equality
    fns = sorted(n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)))
    print("  n top-level defs:", len(fns))
# AST-compare every top-level def except _correr_episodio
def defs(fn):
    src = open(D+fn,"rb").read().decode("utf-8"); t = ast.parse(src)
    return {n.name: ast.dump(n, include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a = defs("sesion_robotat_respaldo_20261002_preEstancamiento.py"); b = defs("sesion_robotat.py")
print("same def names:", set(a)==set(b))
print("defs whose AST differs:", [k for k in a if a[k]!=b.get(k)])
