import sys, time
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import numpy as np
import config_robotat as cfg
import demo_obstaculo_movil as d

f = d.FuentePosesConObstaculo(5)          # sin conectar: no abre sockets
t_ultima = time.perf_counter() - 1.1      # última consulta OK hace 1.1 s (una consulta fallida por timeout de 1 s)
f._obst_pose = np.array([1.5, 0.9, 0.0]); f._obst_instante = t_ultima
for i in range(5):
    f._ultimo_instante[i] = t_ultima
class CanalFalso:
    obstaculo_caido = False; id_robot_obstaculo = 7
    def detener_obstaculo(self): return True
    def enviar_obstaculo(self, v, w): return True
sup = d.SupervisorObstaculo(f, CanalFalso(), modo="movil", vigilar_congelamiento=False)
motivo_sup = sup._chequear(f.pose_obstaculo())
print("supervisor._chequear :", motivo_sup)
print("fuente.agentes_vencidos():", f.agentes_vencidos())
# correr_toma: coord.motivo_aborto_obstaculo != None -> motivo = 'OBSTÁCULO: ...' (pisa 'antigüedad de pose sobre el umbral')
res = {"valido": 0, "frenos": 0, "d_min_obst_medida": 0.40,
       "motivo": f"OBSTÁCULO: {motivo_sup}", "obst_motivo_aborto": motivo_sup,
       "poses_fallidas": 1}
print("regla_de_parada:", d.regla_de_parada(res, []))
