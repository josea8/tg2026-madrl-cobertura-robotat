"""Chequeos puros de regla_de_parada / validez_demo, extraídas con ast (sin
importar el módulo ni abrir sockets). Sólo lectura del archivo de la tesis."""
import ast
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

RUTA = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots"
            r"\controllers\coordinador_enjambre\demo_obstaculo_movil.py")
arbol = ast.parse(RUTA.read_text(encoding="utf-8"))
quiero_f = {"regla_de_parada", "validez_demo"}
quiero_c = {"UMBRAL_CONTACTO_M", "TOMAS_CON_FRENO_SEGUIDAS",
            "FRACCION_RECORRIDO_MIN"}
nodos = [n for n in arbol.body
         if (isinstance(n, ast.FunctionDef) and n.name in quiero_f)
         or (isinstance(n, ast.AnnAssign)
             and getattr(n.target, "id", "") in quiero_c)]
ns: Dict[str, Any] = {"math": math, "Any": Any, "Dict": Dict, "List": List,
                      "Optional": Optional, "Sequence": Sequence,
                      "Tuple": Tuple}
exec(compile(ast.Module(body=nodos, type_ignores=[]), str(RUTA), "exec"), ns)
regla, validez = ns["regla_de_parada"], ns["validez_demo"]
print("constantes:", {k: ns.get(k) for k in quiero_c})


def toma(**kw):
    t = {"valido": 1, "motivo": "", "d_min_obst_medida": 0.30, "frenos": 0,
         "obst_motivo_aborto": "", "obst_modo": "movil",
         "obst_recorrido_m": 2.4, "obst_recorrido_comandado_m": 2.5}
    t.update(kw)
    t["valido_demo"], t["motivo_demo"] = validez(t)
    return t


# 1) Falla ABIERTA si la clave no está (renombre en resumen_obstaculo).
sin_clave = toma(d_min_obst_medida=0.05)
del sin_clave["d_min_obst_medida"]
print("1) contacto 0.05 con clave renombrada ->", regla(sin_clave, []),
      "| validez_demo ->", validez(sin_clave))
print("   con 'd_min_obstaculo_medida'=0.05 ->",
      regla({**sin_clave, "d_min_obstaculo_medida": 0.05}, []))

# 2) Cadena de frenos con un fallo de colocación ENTRE tomas corridas.
f = toma(frenos=1)
fallo_coloc = {"toma": 2, "valido": 0, "valido_demo": 0,
               "motivo": "obstáculo a 12.0 cm de su punto"}
print("2) corridas=[f] ->", regla(f, [f]))
print("   mutante tomas_res=[f, fallo_coloc] ->", regla(f, [f, fallo_coloc]))

# 3) Respuesta a la parada: original vs mutantes, sobre lo que prueban los
#    tests ("" y "s") y sobre respuestas que deberían DETENER.
orig = lambda r: str(r).strip().lower() in ("s", "si", "sí")
mutantes = {
    "no vacía sigue": lambda r: bool(str(r).strip()),
    "empieza con s": lambda r: str(r).strip().lower().startswith("s"),
    "distinto de n": lambda r: str(r).strip().lower() not in ("n", "no"),
}
de_los_tests = ["", "s"]
deben_detener = ["n", "no", "N", "x", "seguir no", "ss", "sino", "\x1b",
                 "None"]
for nombre, m in mutantes.items():
    igual_en_tests = all(m(r) == orig(r) for r in de_los_tests)
    siguen_mal = [r for r in deben_detener if m(r) and not orig(r)]
    print(f"3) mutante '{nombre}': indistinguible por los tests={igual_en_tests}"
          f"; seguiría con {siguen_mal!r}")
print("   original sigue con:",
      [r for r in ["s", "S", " s ", "sí", "Sí", "si", "SI"] if orig(r)],
      "| detiene con:", [r for r in deben_detener if not orig(r)])

# 4) Rótulo / reglas en el camino de reinicio fallido de correr_toma
#    (res sin 'OBSTÁCULO:' y con métricas recién reiniciadas).
reinicio = {"valido": 0, "semilla": 1, "motivo": "no se pudo iniciar la toma",
            "d_min_obst_medida": "", "frenos": 0, "obst_motivo_aborto": "",
            "valido_demo": 0}
print("4) toma que no arrancó (reinicio fallido) ->", regla(reinicio, []))
print("   y rompe la cadena de frenos: regla(f, [f, reinicio]) ->",
      regla(f, [f, reinicio]))

# 5) d_min como texto (fila leída de CSV) y como numpy-like
print("5) d_min '0.12' ->", regla(toma(d_min_obst_medida="0.12"), []) is not None,
      "| d_min nan ->", regla(toma(d_min_obst_medida=float('nan')), []))
