import sys, math, re
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
sys.path.insert(0, D)
for fn in ["demo_obstaculo_movil.py", "config_robotat.py", "sesion_robotat.py", "calibracion_sesion.py"]:
    b = open(D + "\\" + fn, "rb").read()
    crlf = b.count(b"\r\n"); lf = b.count(b"\n") - crlf
    print(fn, "CRLF", crlf, "LF solo", lf)
import config_robotat as cfg
for r in (7, 4):
    print("robot", r, "ip", cfg.ip_de_robot(r), "endpoint", cfg.endpoint_robot(r),
          "marcador", cfg.marcador_fijo_de_robot(r),
          "offset_deg", math.degrees(cfg.offset_rumbo_de_robot(r)), cfg.origen_offset_rumbo(r))
print("marcadores agentes", [a.id_marcador for a in cfg.MAPEO_AGENTES.values()],
      "robots", [a.id_robot for a in cfg.MAPEO_AGENTES.values()])
# punto_del_circulo(-pi/2) replicado
cx, cy, R = 1.5, 1.5, 0.60
f = -math.pi/2
p = (cx + R*math.cos(f), cy + R*math.sin(f)); th = math.atan2(math.sin(f+math.pi/2), math.cos(f+math.pi/2))
print("punto L0", p, "rumbo deg", math.degrees(th))
# ley de seguimiento: robot afuera del circulo (e>0) en la fase -pi/2 mirando +x: debe girar a la izquierda (hacia el centro)
def ley(x,y,th,v_ref,k_rad=3.0,k_rumbo=1.0,wmax=1.0):
    dx,dy=x-cx,y-cy; rho=math.hypot(dx,dy); fase=math.atan2(dy,dx); e=rho-R
    psi=fase+math.pi/2+math.atan(k_rad*e); err=math.atan2(math.sin(psi-th),math.cos(psi-th))
    w=max(-wmax,min(wmax,v_ref/R+k_rumbo*err)); v=v_ref*max(0,math.cos(err)); return v,w,e
print("afuera 5cm:", ley(1.5,0.85,0.0,0.05))
print("adentro 5cm:", ley(1.5,0.95,0.0,0.05))
print("en el circulo:", ley(1.5,0.90,0.0,0.05))
print("patada en el circulo:", ley(1.5,0.90,0.0,0.08))
# rpm a 0.08 m/s y w=0.133
from protocolo_robotat import accion_a_rpm
print("rpm patada", accion_a_rpm(0.08, 0.08/0.6, cfg.RADIO_RUEDA_M, cfg.MEDIO_EJE_M))
print("rpm crucero", accion_a_rpm(0.05, 0.05/0.6, cfg.RADIO_RUEDA_M, cfg.MEDIO_EJE_M))
print("rpm w sat 1.0 con v=0.05", accion_a_rpm(0.05, 1.0, cfg.RADIO_RUEDA_M, cfg.MEDIO_EJE_M))
