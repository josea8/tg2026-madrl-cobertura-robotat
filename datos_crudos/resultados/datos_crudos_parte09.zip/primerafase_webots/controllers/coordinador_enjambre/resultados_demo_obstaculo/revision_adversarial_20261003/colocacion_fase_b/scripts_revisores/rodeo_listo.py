# Copia literal de meta_de_rodeo y auxiliares (colocacion_con_obstaculo.py:176-221)
import math, numpy as np
ARENA=3.0
RADIO_DISCO_RODEO_M=0.45; RADIO_RODEO_M=0.55; ADELANTO_RODEO_RAD=math.radians(60.0); MARGEN_PARED_RODEO_M=0.25
def _envolver(a): return math.atan2(math.sin(a), math.cos(a))
def _tramo_cruza_disco(a,b,o,radio):
    ab=b-a; largo2=float(ab@ab)
    if largo2<1e-12: return False
    t=float((o-a)@ab)/largo2
    if not 0.0<t<1.0: return False
    return float(np.linalg.norm(a+t*ab-o))<radio
def _dentro(p,m): return m<=p[0]<=ARENA-m and m<=p[1]<=ARENA-m
def meta_de_rodeo(p,blanco,p_o,sentido=None):
    a=np.asarray(p,float)[:2]; b=np.asarray(blanco,float)[:2]; o=np.asarray(p_o,float)[:2]
    directo=float(np.linalg.norm(b-a))
    if not _tramo_cruza_disco(a,b,o,RADIO_DISCO_RODEO_M): return None,None,directo
    fa=math.atan2(a[1]-o[1],a[0]-o[0]); fb=math.atan2(b[1]-o[1],b[0]-o[0])
    pref=([sentido,-sentido] if sentido in (1,-1) else ([1,-1] if _envolver(fb-fa)>=0 else [-1,1]))
    resto=max(0.0,float(np.linalg.norm(b-o))-RADIO_RODEO_M)
    for s in pref:
        arco=((fb-fa)%(2*math.pi)) if s>0 else ((fa-fb)%(2*math.pi))
        ang=fa+s*min(ADELANTO_RODEO_RAD,arco)
        w=o+RADIO_RODEO_M*np.array([math.cos(ang),math.sin(ang)])
        if _dentro(w,MARGEN_PARED_RODEO_M): return w,s,RADIO_RODEO_M*arco+resto
    return None,sentido,directo

# L2: obstaculo en la fase -pi/2 del circulo (1.5,1.5) r=0.6 -> (1.5,0.9)
o=np.array([1.5,0.9])
listo=np.array([1.0,0.45])     # blanco valido: en [0.45,2.55]^2 y >=0.65 del obstaculo
print("listo: d al obstaculo", round(float(np.linalg.norm(listo-o)),3))
a=np.array([0.75,1.0]); blanco=np.array([2.2,0.6])
print("blanco movil: d obst", round(float(np.linalg.norm(blanco-o)),3), " d al listo", round(float(np.linalg.norm(blanco-listo)),3))
w,s,m=meta_de_rodeo(a,blanco,o)
print("rodeo:", w, "sentido", s)
print("d(waypoint, listo) =", round(float(np.linalg.norm(w-listo)),3), " (D_ROBOTS sobre punto de mira = 0.25)")
# avanzar a lo largo del arco: puntos de paso sucesivos sobre el circulo 0.55
for ang in np.radians([200,215,230,245,260]):
    q=o+0.55*np.array([math.cos(ang),math.sin(ang)])
    print(f"  arco {math.degrees(ang):.0f} deg: d al listo {np.linalg.norm(q-listo):.3f}")
# el otro lado (por arriba) esta libre?
w2,s2,_=meta_de_rodeo(a,blanco,o,-1); print("otro lado:", w2, s2, "d listo", round(float(np.linalg.norm(w2-listo)),3))

# margen real de los blancos al punto MEDIDO (L2: objetivo = proyeccion; |e_rad|<=0.06)
c=np.array([1.5,1.5])
pm=c+0.66*np.array([0,-1.0])  # obstaculo medido 6 cm afuera del circulo, fase -pi/2
proy=c+0.60*np.array([0,-1.0])
print("blanco a 0.65 de la proyeccion, sobre la recta: d al medido =", round(0.65-0.06,3))
