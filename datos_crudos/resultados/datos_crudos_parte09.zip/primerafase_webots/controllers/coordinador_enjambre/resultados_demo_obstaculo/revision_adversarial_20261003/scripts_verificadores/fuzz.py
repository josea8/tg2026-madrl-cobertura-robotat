"""Ejecuta los fragmentos REALES (extraídos byte a byte de los dos archivos)
de la regla sobre trazas aleatorias idénticas y compara el primer corte."""
import random, textwrap
D = r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/"
def frag(fn, a, b):
    L = open(D+fn,"rb").read().decode("utf-8").split("\r\n")
    return textwrap.dedent("\n".join(L[a-1:b]))
OLD = frag("sesion_robotat_respaldo_20261002_preEstancamiento.py", 2957, 2967)
NEW = frag("sesion_robotat.py", 2977, 3002)
print("OLD fragment:\n"+OLD+"\n\nNEW fragment:\n"+NEW+"\n")
def wrap(body):
    src = "def paso(filas, ahora, t_mov, gestor, t_orden, t_sin_orden):\n    abortado=False; motivo=''\n    for _u in [0]:\n" + textwrap.indent(body, "        ") + "\n    return abortado, motivo\n"
    g = {"MARGEN_RETARDO_ESTANCAMIENTO_S": 1.0, "CORTE_ORDEN_ESTANCAMIENTO_S": 1.0}
    exec(src, g); return g["paso"]
p_old, p_new = wrap(OLD), wrap(NEW)
class G: pass
VS = [0.0, 0.0, 0.0, 0.01, -0.02, 0.02, 0.0200001, -0.021, 0.05, 0.15, -0.15, float("nan")]
random.seed(12345)
stats = dict(trazas=0, ambos=0, solo_viejo=0, solo_nuevo=0, nuevo_antes=0, mismo_paso=0, nuevo_despues=0, agente_distinto=0)
for trial in range(40000):
    n = random.randint(1, 5); N = random.randint(20, 400)
    ahora = 0.0
    t_mov = {}; gestor = G(); to = {}; tso = {}
    pmov = random.choice([0.0, 0.01, 0.05, 0.3, 0.9])
    pret = random.choice([0.0, 0.0, 0.02, 0.2])
    mode = random.choice(["iid", "bursty", "blink", "gaps"])
    vstate = {ag: random.choice(VS) for ag in range(n)}
    cut_old = cut_new = None
    for k in range(N):
        ahora += random.choice([0.1, 0.1, 0.1, random.uniform(0.01, 0.3), random.uniform(0.9, 1.6)])
        for ag in range(n):
            if ag not in t_mov or random.random() < pmov:
                t_mov[ag] = ahora
        gestor.en_retroceso = {ag for ag in range(n) if random.random() < pret}
        filas = []
        for ag in range(n):
            if mode == "iid": v = random.choice(VS)
            elif mode == "bursty":
                if random.random() < 0.05: vstate[ag] = random.choice(VS)
                v = vstate[ag]
            elif mode == "blink": v = 0.15 if (k % random.choice([2,3,5,11,12])) else 0.0
            else: v = 0.0 if (k % 100) >= random.choice([88, 89, 90, 95]) else 0.15
            filas.append({"agente": ag, "v_ejecutada": v})
        if cut_old is None:
            a, m = p_old(filas, ahora, t_mov, gestor, None, None)
            if a: cut_old = (k, m)
        if cut_new is None:
            a, m = p_new(filas, ahora, t_mov, gestor, to, tso)
            if a: cut_new = (k, m)
        if cut_old and cut_new: break
    stats["trazas"] += 1
    if cut_old and cut_new:
        stats["ambos"] += 1
        if cut_new[0] < cut_old[0]: stats["nuevo_antes"] += 1
        elif cut_new[0] == cut_old[0]:
            stats["mismo_paso"] += 1
            if cut_new[1] != cut_old[1]: stats["agente_distinto"] += 1
        else: stats["nuevo_despues"] += 1
    elif cut_old: stats["solo_viejo"] += 1
    elif cut_new: stats["solo_nuevo"] += 1
print(stats)
