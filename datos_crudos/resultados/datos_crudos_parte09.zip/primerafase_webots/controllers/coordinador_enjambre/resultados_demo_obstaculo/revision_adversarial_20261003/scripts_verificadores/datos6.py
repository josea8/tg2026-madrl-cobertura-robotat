import json, os, glob, collections
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo\exploracion_fase0\barrido_tc"
tab=collections.defaultdict(dict)
for d in sorted(glob.glob(os.path.join(R,"*"))):
    p=os.path.join(d,"resultado.json")
    n=os.path.basename(d)
    if not os.path.isfile(p): print("sin resultado", n); continue
    r=json.load(open(p,encoding="utf-8"))
    tab[(r.get("tau_prediccion"))][(r["nombre"],r["tau"])]=(r["verdad_d_min_obst"], r.get("peso_giro_obstaculo"), r.get("decisiones_peso_giro"))
for tc in sorted(tab, key=str):
    v=tab[tc]
    print("tc",tc,"n",len(v),"min", min(x[0] for x in v.values()))
    for k in sorted(v): print("   ",k, round(v[k][0],4), v[k][1:])
