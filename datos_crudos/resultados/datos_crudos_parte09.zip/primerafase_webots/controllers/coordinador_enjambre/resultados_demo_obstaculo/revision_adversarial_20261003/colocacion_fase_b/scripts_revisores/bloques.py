import ast
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
old = open(D + r"\demo_obstaculo_movil_respaldo_20261007_preColocacion.py", encoding="utf-8").read().splitlines()
new = open(D + r"\demo_obstaculo_movil.py", encoding="utf-8").read().splitlines()

# 1) Manual block: old 2443..2477 (1-based) vs new 2541..2575 dedented 4
o = old[2442:2477]
n = [l[4:] if l.startswith("    ") else l for l in new[2540:2575]]
print("manual block lines:", len(o), len(n))
diffs = [(i, a, b) for i, (a, b) in enumerate(zip(o, n)) if a.rstrip() != b.rstrip()]
for d in diffs:
    print("DIFF", d)
# Compare AST of the manual block (normalize via parsing as a function body)
def parse_block(lines):
    import textwrap
    src = "def f():\n" + textwrap.indent(textwrap.dedent("\n".join(lines)), "    ")
    return ast.dump(ast.parse(src))
print("manual block AST equal:", parse_block(o) == parse_block(n))

# 2) aplicar_regla_de_parada body vs old inline block (old 2515..2537)
oi = old[2514:2537]
print("old inline first/last:", oi[0].strip(), "|", oi[-1].strip())
tree = ast.parse("\n".join(new))
fn = [x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "aplicar_regla_de_parada"][0]
body = fn.body[1:]  # skip docstring
print("aplicar body stmts:", len(body))
for s in body:
    print("   ", ast.unparse(s).splitlines()[0][:100])
