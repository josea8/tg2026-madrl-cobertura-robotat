import json, collections
p=r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo\exploracion_fase0\revision_adversarial_resultado.json"
d=json.load(open(p,encoding="utf-8"))
print(d["summary"]); print("agentCount", d["agentCount"])
print(collections.Counter(w.get("type") for w in d["workflowProgress"]))
print([ (w.get("type"), w.get("title")) for w in d["workflowProgress"][:12]])
s=d["result"]["sobreviven"][0]; print(list(s.keys()))
print(collections.Counter(len(x.get("votos",x.get("verificaciones",[]))) for x in d["result"]["sobreviven"]))
for x in d["result"]["sobreviven"]:
    print("-", x.get("categoria"), x.get("severidad"), "|", x.get("titulo","")[:110])
