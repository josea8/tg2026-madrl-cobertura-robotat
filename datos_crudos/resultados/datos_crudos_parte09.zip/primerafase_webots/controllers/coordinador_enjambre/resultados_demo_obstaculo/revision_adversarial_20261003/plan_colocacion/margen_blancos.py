import numpy as np
import cruces_obstaculo as C
sem = [420000 + k for k in range(20)] + [420100 + k for k in range(10)]
for modo in ("L1", "L2"):
    dmin = []
    for s in sem:
        o = np.array([1.5, 1.5]) if modo == "L1" else C.punto(C.fase(s))
        b = C.blancos_demo(5, s, o)
        dmin.append(min(np.linalg.norm(p - o) for p in b.values()))
    dmin = np.array(dmin)
    print(f"{modo}: semillas {len(sem)}; d_min blanco-obstáculo: "
          f"<0.55 en {int((dmin<0.55).sum())}, <0.60 en {int((dmin<0.60).sum())}; "
          f"mín {dmin.min():.3f} m")
