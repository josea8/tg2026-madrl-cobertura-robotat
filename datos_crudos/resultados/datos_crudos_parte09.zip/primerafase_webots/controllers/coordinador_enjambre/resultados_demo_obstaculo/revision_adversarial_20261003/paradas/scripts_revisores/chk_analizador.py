import sys, io, contextlib, tempfile, shutil, math
from pathlib import Path
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import analizar_sesion_demo as A

tmp = Path(tempfile.mkdtemp(prefix="chk_an_"))
cols = ["toma","valido","valido_demo","decisiones","d_min_obst_medida","frenos","obst_recorrido_m","motivo","motivo_demo","regla_parada","parada_respuesta"]
a = tmp/"20261003_100000_L2_tomas.csv"
b = tmp/"20261003_120000_L2_tomas.csv"
# a: take 1 ok, take 2 corrida sin d_min (aborto temprano), take 3 colocacion fallida (sin decisiones)
a.write_text(",".join(cols)+"\n"
  "1,1,1,500,0.30,0,2.4,,,,\n"
  "2,0,0,0,,0,0.0,OBSTÁCULO: no se mueve,toma no válida,ABORTO POR EL OBSTÁCULO: x,detenida\n"
  "3,0,0,,,,,(sin colocar),,,\n", encoding="utf-8")
# b: duplicate 2 (resumed at same attempt), plus 10
b.write_text(",".join(cols)+"\n"
  "2,1,1,500,0.28,0,2.4,,,,\n"
  "10,1,0,500,0.14,0,2.4,,agente a 0.140 m,CONTACTO: y,siguió\n", encoding="utf-8")
out = io.StringIO()
with contextlib.redirect_stdout(out):
    r1 = A.resumir(a)            # Path único
    r2 = A.resumir(str(a))       # str único
    r3 = A.resumir([a, b])
print(r1); print(r2); print(r3)
print(sorted(p.name for p in tmp.iterdir()))
print((tmp/"20261003_100000_L2_combinado_resumen.txt").read_text(encoding="utf-8"))
shutil.rmtree(tmp, ignore_errors=True)
