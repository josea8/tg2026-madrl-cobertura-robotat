import csv, os, glob, math, json
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
def analiza(d, ag="0"):
    rows=[x for x in csv.DictReader(open(os.path.join(d,"decisiones.csv"),encoding="utf-8")) if x["agente"]==ag]
    w=[float(x["w_ejecutada"]) for x in rows]
    th=[float(x["pose_env_th"]) for x in rows]
    sat=sum(1 for v in w if abs(v)>=6.28)
    # unwrap heading
    tot=0; mx=0; cum=0
    for i in range(1,len(th)):
        dth=math.atan2(math.sin(th[i]-th[i-1]), math.cos(th[i]-th[i-1]))
        cum+=dth; tot+=abs(dth)
    # max excursion of cumulative heading
    c=0; lo=hi=0
    for i in range(1,len(th)):
        c+=math.atan2(math.sin(th[i]-th[i-1]), math.cos(th[i]-th[i-1])); lo=min(lo,c); hi=max(hi,c)
    r=json.load(open(os.path.join(d,"resultado.json"),encoding="utf-8"))
    return len(rows), sat, round(tot/(2*math.pi),2), round((hi-lo)/(2*math.pi),2), round(r["verdad_d_min_obst"],4)
for pat in ["fase0_20261002_165649/*propuesta_E2_espaldas_reversa_d+0.00_tau0.85*",
            "fase0_20261002_165649/*propuesta_E2_espaldas_reversa_d+0.00_tau0.45*",
            "fase0_20261002_165649/*guionada_E2_espaldas_reversa_d+0.00_tau0.85_F2",
            "fase0_20261002_165649/*ablacion_E2_espaldas_reversa_d+0.00_sinpeso_tau0.85*",
            "fase0_20261002_165649/*propuesta_E3_quieto_afuera_tau0.85*",
            "fase0_20261002_165649/*guionada_E3_quieto_afuera_tau0.85_F2"]:
    for d in glob.glob(os.path.join(R,pat)):
        print(os.path.basename(d)[:60], "n,satω,vueltas_totales,excursion_vueltas,dmin =", analiza(d))
