import ast, sys

D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
A = D + r"\demo_obstaculo_movil_respaldo_20261007_preColocacion.py"
B = D + r"\demo_obstaculo_movil.py"


def strip(node):
    for n in ast.walk(node):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)):
            if n.body and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], 'value', None), ast.Constant) and isinstance(n.body[0].value.value, str):
                n.body = n.body[1:] or [ast.Pass()]
    return node


def collect(path):
    tree = strip(ast.parse(open(path, encoding="utf-8").read()))
    out = {}
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)):
            out[n.name] = ast.dump(n, include_attributes=False)
            if isinstance(n, ast.ClassDef):
                for m in n.body:
                    if isinstance(m, ast.FunctionDef):
                        out[n.name + "." + m.name] = ast.dump(m, include_attributes=False)
        elif isinstance(n, (ast.Assign, ast.AnnAssign)):
            tgt = n.targets[0] if isinstance(n, ast.Assign) else n.target
            name = ast.unparse(tgt)
            out["<assign> " + name] = ast.dump(n, include_attributes=False)
        else:
            out["<top> " + ast.unparse(n)[:60]] = ast.dump(n, include_attributes=False)
    return out

a, b = collect(A), collect(B)
print("Only in old:", [k for k in a if k not in b])
print("Only in new:", [k for k in b if k not in a])
print("Changed:", [k for k in a if k in b and a[k] != b[k]])
