import difflib
d = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
new = open(d + r"\sesion_robotat.py", "rb").read()
old = open(d + r"\sesion_robotat_respaldo_20261002_preEstancamiento.py", "rb").read()
for name, b in (("new", new), ("old", old)):
    crlf = b.count(b"\r\n"); lf = b.count(b"\n"); print(name, len(b), "CRLF", crlf, "LF solo", lf - crlf)
nl = new.decode("utf-8").split("\r\n"); ol = old.decode("utf-8").split("\r\n")
diff = list(difflib.unified_diff(ol, nl, "old", "new", lineterm="", n=2))
print("\n".join(diff))
