import difflib, sys
D = r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/"
a = open(D+"sesion_robotat_respaldo_20261002_preEstancamiento.py","rb").read()
b = open(D+"sesion_robotat.py","rb").read()
for name, data in (("old",a),("new",b)):
    crlf = data.count(b"\r\n"); lf = data.count(b"\n"); cr = data.count(b"\r")
    print(name, "bytes", len(data), "CRLF", crlf, "LF total", lf, "stray LF", lf-crlf, "stray CR", cr-crlf, "ends with newline", data.endswith(b"\r\n"), "BOM", data[:3]==b"\xef\xbb\xbf")
    print("  lines (split on \n):", len(data.split(b"\n")) - (1 if data.endswith(b"\n") else 0))
    # tabs / trailing ws
A = a.decode("utf-8").split("\r\n")
B = b.decode("utf-8").split("\r\n")
print(len(A), len(B))
sm = difflib.SequenceMatcher(None, A, B, autojunk=False)
for tag,i1,i2,j1,j2 in sm.get_opcodes():
    if tag=="equal": continue
    print("=== %s old[%d:%d] new[%d:%d]" % (tag,i1+1,i2,j1+1,j2))
    for l in A[i1:i2]: print("-", l)
    for l in B[j1:j2]: print("+", l)
