export const meta = {
  name: 'revisar-paradas-demo',
  description: 'Adversarial read-only review of the stop-rule, resume, L0-summary and docstring changes in demo_obstaculo_movil.py',
  phases: [{ title: 'Revisar', detail: 'one skeptic per lens, two on the safety rule' }],
}

const COORD = 'C:\\Users\\velas\\OneDrive\\Documents\\tesis\\primerafase_webots\\controllers\\coordinador_enjambre'
const NUEVO = COORD + '\\demo_obstaculo_movil.py'
const RESP = COORD + '\\demo_obstaculo_movil_respaldo_20261003_preParadas.py'
const TESTS = COORD + '\\test_demo_obstaculo_movil.py'
const ANALIZ = COORD + '\\analizar_sesion_demo.py'
const SCR = 'C:\\Users\\velas\\AppData\\Local\\Temp\\claude\\C--Users-velas-OneDrive-Documents-tesis\\cc510369-0bba-489d-9bbd-57ba8af8e5d7\\scratchpad\\verif_paradas\\'

const CONTEXTO = `Context: thesis lab demo, a 6th Pololu robot (robot 7) moves as a non-cooperative obstacle among 5 agents protected by a CBF safety filter. On 2026-10-03 the user approved four changes to ${NUEVO} (backup of the previous version: ${RESP}):
(1) PRIORITY, SAFETY: automatic stop rules in sesion_demo. After each executed take (valid or not), if (a) contact: measured min agent-obstacle distance d_min_obst_medida < 0.15 m, (b) backup-brake intervention in 2 consecutive executed takes, or (c) the take was aborted because of the obstacle (supervisor/obedience/link) — the session must stop all robots, halt, and continue ONLY on an explicit "s" from the operator; anything else ends it with verdict DETENIDA; the rule and the answer are recorded in the takes CSV. Function regla_de_parada. Also the per-take console line now shows why a take is not valid.
(2) --intento-inicial N to resume a cut session (attempt numbering, seeds and the count against --intentos continue).
(3) L0 always writes a one-row summary CSV (verdict, detail, starts, radial error, saturated omega), also on aborts / connection failure / Ctrl+C; sockets opened inside the try.
(4) outdated docstrings/comments (brake distance 0.25, brake described as a REDUNDANT layer, etc.).
HARD CONSTRAINT stated by the user: none of this may touch the safety barrier (CBF rows, predictor, rescue, escape), the obstacle supervisor's control, or the measurement/demo validity (validez_demo, correr_toma logic). The analyzer ${ANALIZ} was also extended (several CSVs, report stops). New tests were appended at the end of ${TESTS} (classes PruebaReglaDeParada, PruebaSesionReglasDeParada, PruebaResumenL0, PruebaAnalizadorSesion); the full phase suite passes 51/51.`

const REGLAS = `
STRICT RULES:
- READ-ONLY. Do NOT modify any file under C:\\Users\\velas\\OneDrive\\Documents\\tesis. Helper scripts ONLY under ${SCR} (create it), run with python.
- Do NOT run simulations, the session, or the test suites (a real-time simulation is running and needs the CPU). Static reading, diffs, and small pure-Python checks only (you may import demo_obstaculo_movil and call pure functions like regla_de_parada / validez_demo; do not open sockets).
- Adversarial posture: find real defects. Report only concrete, verified problems with file:line evidence and a concrete failure scenario; label severity honestly (critica = can let an unsafe situation pass or crash the lab session; importante = wrong behavior/record; menor = cosmetics/docs). If you find nothing, say so.
- Answer in Spanish.`

const SCHEMA = {
  type: 'object',
  properties: {
    hallazgos: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          titulo: { type: 'string' },
          gravedad: { type: 'string', enum: ['critica', 'importante', 'menor'] },
          evidencia: { type: 'string' },
          escenario: { type: 'string' },
          correccion: { type: 'string' },
        },
        required: ['titulo', 'gravedad', 'evidencia', 'escenario', 'correccion'],
      },
    },
    confirmado: { type: 'string' },
  },
  required: ['hallazgos', 'confirmado'],
}

const LENTES = [
  { key: 'seguridad-paradas', copias: 2, prompt: `${CONTEXTO}
YOUR LENS: can the stop rule fail to stop when it should, or misbehave? Read regla_de_parada and the whole sesion_demo loop in ${NUEVO}, plus what correr_toma returns in every path (including the early-return path when coord._reiniciar_episodio fails, placement-failure entries, takes aborted by other rules, the enlace-caído path, the supervisor abort reasons and how they appear in res['motivo'] / res['obst_motivo_aborto'] — trace resumen_obstaculo / SupervisorObstaculo). Check: every path where an agent got < 0.15 m of the obstacle triggers the stop (is d_min_obst_medida always populated, including aborted takes? units/strings/NaN?); the consecutive-brake count with placement-failure entries in between, and after the operator answers "s"; obstacle aborts of every kind are caught (but ordinary measurement aborts like pose age are not); robots — including the obstacle robot 7 — are really stopped before the prompt (what does canal.detener_todo do for robot 7? is the obstacle possibly still moving?); behavior on Ctrl+C at the prompt (CSV saved? robots stopped?); answer parsing ("S", " s ", "sí", "si", "", "n", "seguir"); the verdict/exit code when stopped; CSV columns written for all takes; any exception path introduced (e.g. float() on odd values, variable shadowing — one shadowing bug of 'estado' was already found and fixed by tests, look for similar ones).
${REGLAS}` },
  { key: 'no-toca-barrera-ni-validez', copias: 1, prompt: `${CONTEXTO}
YOUR LENS: prove or refute the HARD CONSTRAINT. Produce a full diff (python difflib) between ${RESP} and ${NUEVO}, classify EVERY hunk (docstring/comment only; new function; session control; L0; CLI) and state explicitly whether any hunk changes executable code in: the CBF/filter classes, the obstacle row/predictor/rescue/escape, SupervisorObstaculo control or obedience, CanalConObstaculo, FuentePosesConObstaculo, correr_toma's logic, validez_demo's logic, _correr_episodio_medicion, crear_observador. Use the AST to compare function bodies with docstrings stripped (e.g. ast.dump of each FunctionDef/ClassDef with the docstring Expr removed) and list every function whose body changed. Also check the L0 normal-path verdict criterion is behaviorally identical to the backup (10/10 starts within 1.5 s, radial < 5 cm excluding t<2 s, abort > 10 cm), and that the returned dict keys used elsewhere (main, tests, ensayo_l2_simulador.py) still exist.
${REGLAS}` },
  { key: 'reanudar-l0-cli-analizador', copias: 1, prompt: `${CONTEXTO}
YOUR LENS: correctness of changes (2) and (3) and the analyzer. In ${NUEVO}: intento_inicial validation and loop bounds; seed selection for attempts > len(SEMILLAS_LOTE) (import coordinador_enjambre.SEMILLAS_LOTE to check its length); the goal 'tomas' semantics when resuming; the printed REANUDACIÓN note; main(): --intento-inicial wiring, the broadened except (OSError, ses.AbortoEtapa) — could it now swallow an error that previously propagated in a way that hides a problem, or catch errors raised AFTER robots moved, skipping the finally? (check ctx.detener_todo in finally). sesion_l0 restructure: is the summary CSV written in every path (early returns, OSError at connect, KeyboardInterrupt, exception inside loop)? does the finally ever raise and mask the original exception (e.g. escribir_csv / ruta_salida_demo failing, _metricas_l0 on partial rows)? is the robot always stopped (rueda.detener/cerrar semantics in sesion_robotat.ClienteRueda)? any behavior change vs backup in the normal path (prints, returned keys, timing)? Analyzer ${ANALIZ}: multi-CSV merge correctness, the combined output name, duplicate take numbers, the new contact-in-invalid-takes line (what about takes with no d_min → NaN comparisons), backward compatibility with resumir(Path) used by ${COORD}\\ensayo_l2_simulador.py.
${REGLAS}` },
  { key: 'calidad-de-pruebas', copias: 1, prompt: `${CONTEXTO}
YOUR LENS: do the new tests really verify what they claim, especially the safety rule? Read the new test classes at the end of ${TESTS}. The session tests replace demo.correr_toma with a scripted fake: check what real code paths they still exercise (marker check, links, placement guide, start checks, the stop prompt, CSV writing) and which they do NOT (e.g. a real contact produced by the filter, real supervisor aborts, real brake). Is 'self.sim.todos_detenidos()' at prompt time a meaningful check given the fake take never moved the robots? Would the tests catch: the stop happening only for valid takes; the brake rule ignoring placement-failure entries between takes; answer parsing bugs; the CSV not recording the rule; intento_inicial off-by-one? Propose the minimal additional test(s) that would close real gaps (concrete code sketch), especially one where a REAL take (real correr_toma through _correr_episodio against the simulator) triggers the stop — e.g. the existing PruebaFrenoDeRespaldo setup produces a real brake; could two real brake takes in a session be provoked cheaply?
${REGLAS}` },
]

const trabajos = LENTES.flatMap(l => Array.from({ length: l.copias }, (_, i) => ({ ...l, i })))
const res = await pipeline(trabajos, t => agent(
  t.prompt + (t.copias > 1 ? `\n(Independent reviewer #${t.i + 1} of ${t.copias}.)` : ''),
  { label: `${t.key}#${t.i + 1}`, phase: 'Revisar', schema: SCHEMA }))
return trabajos.map((t, k) => ({ lente: t.key, revisor: t.i + 1, resultado: res[k] }))
