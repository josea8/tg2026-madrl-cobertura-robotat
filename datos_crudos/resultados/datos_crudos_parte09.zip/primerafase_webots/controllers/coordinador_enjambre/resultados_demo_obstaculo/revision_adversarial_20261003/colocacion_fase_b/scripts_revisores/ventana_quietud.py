# Replica pura de la ventana de esperar_obstaculo_quieto
# (colocacion_con_obstaculo.py:594-601): muestras con ahora del tope del lazo,
# se conservan las de edad <= 0.35 s y "viejas" = edad >= 0.30 s.
def alguna_vez_hay_viejas(periodo, t_max=3.0):
    muestras = []
    t = 0.0
    while t <= t_max + 1e-9:
        muestras.append(t)
        muestras = [m for m in muestras if t - m <= 0.35]
        viejas = [m for m in muestras if t - m >= 0.3]
        if viejas:
            return True, round(t, 3)
        t += periodo
    return False, None

for delta_ms in (1, 5, 10, 15, 16, 17, 20, 25, 30, 40, 49, 50, 60, 75, 76, 90):
    P = 0.1 + delta_ms / 1000.0
    ok, cuando = alguna_vez_hay_viejas(P)
    print(f"delta={delta_ms:3d} ms  periodo={P:.3f} s  -> quietud confirmable: {ok}  (t={cuando})")
