import ast, textwrap
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
old = open(D + r"\demo_obstaculo_movil_respaldo_20261007_preColocacion.py", encoding="utf-8").read().splitlines()
new = "\n".join(open(D + r"\demo_obstaculo_movil.py", encoding="utf-8").read().splitlines())
blk = textwrap.dedent("\n".join(old[2514:2536]))  # 2515..2536: up to res["parada_respuesta"]
a = [ast.dump(s) for s in ast.parse(blk).body]
fn = [x for x in ast.parse(new).body if isinstance(x, ast.FunctionDef) and x.name == "aplicar_regla_de_parada"][0]
b = [ast.dump(s) for s in fn.body[1:-1]]
print(len(a), len(b), a == b)
