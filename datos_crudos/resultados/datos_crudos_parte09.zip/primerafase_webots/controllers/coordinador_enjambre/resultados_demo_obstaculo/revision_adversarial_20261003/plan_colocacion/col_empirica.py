import csv, glob, statistics as st, collections
R = "C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/"
files = sorted(glob.glob(R+"2026092[2-9]*episodios*.csv")+glob.glob(R+"202609[3]*episodios*.csv"))
ts=[]; mot=collections.Counter(); est=collections.Counter(); errs=[]; errr=[]; listos=collections.Counter()
nfilas=0
for f in files:
    with open(f, encoding="utf-8") as fh:
        rd = csv.DictReader(fh)
        for row in rd:
            if row.get("colocacion")!="auto": continue
            if row.get("col_t_s","")=="": continue
            nfilas+=1
            ts.append(float(row["col_t_s"]))
            mot[row.get("col_motivo","")]+=1
            listos[row.get("col_listos","")]+=1
            for i in range(5):
                e=row.get(f"col_estado_a{i}","")
                est[e]+=1
                if row.get(f"col_err_m_a{i}",""): errs.append(float(row[f"col_err_m_a{i}"]))
                if row.get(f"col_err_rumbo_deg_a{i}",""): errr.append(float(row[f"col_err_rumbo_deg_a{i}"]))
print("archivos", [f.split('/')[-1] for f in files])
print("filas auto", nfilas)
ts.sort()
q=lambda a,p: a[min(len(a)-1,int(p*len(a)))]
print("t_s: med", st.median(ts), "p10",q(ts,.1),"p90", q(ts,.9), "max", max(ts), "n>=90", sum(t>=90 for t in ts))
print("motivos", mot.most_common())
print("estados", est.most_common())
print("listos", listos.most_common())
errs.sort(); errr.sort()
print("err_m: med %.3f p90 %.3f p95 %.3f p99 %.3f max %.3f"%(st.median(errs),q(errs,.9),q(errs,.95),q(errs,.99),max(errs)))
print("err_m > 0.05:", sum(e>0.05 for e in errs), "/", len(errs), " >0.08:", sum(e>0.08 for e in errs))
print("err_rumbo: med %.1f p90 %.1f p95 %.1f max %.1f"%(st.median(errr),q(errr,.9),q(errr,.95),max(errr)))
print("err_rumbo >20:", sum(e>20 for e in errr), " >30:", sum(e>30 for e in errr))
