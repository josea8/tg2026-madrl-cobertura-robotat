import sys, io, contextlib, time
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import demo_obstaculo_movil as d

class SockFalso:
    def __init__(self): self.enviado = []
    def setsockopt(self, *a): pass
    def sendall(self, b): self.enviado.append(b)
    def close(self): pass

llamadas = []
def conexion_ok(addr, timeout=None):
    llamadas.append(("ok", time.perf_counter())); return SockFalso()
def conexion_falla(addr, timeout=None):
    llamadas.append(("falla", time.perf_counter())); raise OSError("timed out")

orig = d.socket.create_connection
try:
    # A) enlace del 7 cayó en la última decisión (send falló -> _sock_obst None)
    #    y el robot sigue escuchando: la detención de fin de episodio lo reabre.
    c = d.CanalConObstaculo(5, None, conectar_obstaculo=True)
    c._sock_obst = None; c.obstaculo_envios_fallidos = 1
    d.socket.create_connection = conexion_ok
    with contextlib.redirect_stdout(io.StringIO()) as out:
        c.detener_todo()   # = canal.detener_todo() al final de _correr_episodio
    print("A) obstaculo_caido tras la detención de fin de episodio:", c.obstaculo_caido,
          "| reconexiones:", c.obstaculo_reconexiones)
    print("   => correr_toma:1872 ve obstaculo_caido=False: no atribuye 'OBSTÁCULO:'")

    # B) robot inalcanzable: detener_todo de fin de episodio intenta reabrir;
    #    el de sesion_demo:2417 (ms después) NO lo intenta (espaciado 1 s).
    llamadas.clear()
    c2 = d.CanalConObstaculo(5, None, conectar_obstaculo=True)
    c2._sock_obst = None
    d.socket.create_connection = conexion_falla
    with contextlib.redirect_stdout(io.StringIO()) as out2:
        c2.detener_todo()          # fin de _correr_episodio
        n1 = len(llamadas)
        c2.detener_todo()          # sesion_demo:2417, antes del cartel
        n2 = len(llamadas)
    txt = out2.getvalue()
    print("B) intentos de reconexión: fin de episodio =", n1, "| en 2417 =", n2 - n1)
    print("   cartel 'NO SE PUDO CONFIRMAR LA DETENCIÓN DEL OBSTÁCULO' impreso:",
          txt.count("NO SE PUDO CONFIRMAR LA DETENCIÓN DEL OBSTÁCULO"), "veces")
    print("   obstaculo_detencion_fallida:", c2.obstaculo_detencion_fallida)
finally:
    d.socket.create_connection = orig
