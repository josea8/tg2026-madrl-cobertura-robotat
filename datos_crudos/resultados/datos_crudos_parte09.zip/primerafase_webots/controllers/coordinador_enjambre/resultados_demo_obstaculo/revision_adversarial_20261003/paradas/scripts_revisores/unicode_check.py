import re, unicodedata
p = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\demo_obstaculo_movil.py"
src = open(p, encoding="utf-8").read()
for m in re.finditer(r'"OBST[^"]{0,6}:', src):
    s = m.group(0)
    line = src.count("\n", 0, m.start()) + 1
    print(line, repr(s), [hex(ord(c)) for c in s[5:8]], unicodedata.is_normalized("NFC", s))
print("non-NFC lines:", [i+1 for i, l in enumerate(src.splitlines()) if not unicodedata.is_normalized("NFC", l)][:20])
a = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\analizar_sesion_demo.py"
s2 = open(a, encoding="utf-8").read()
print("analyzer non-NFC:", [i+1 for i, l in enumerate(s2.splitlines()) if not unicodedata.is_normalized("NFC", l)][:20])
