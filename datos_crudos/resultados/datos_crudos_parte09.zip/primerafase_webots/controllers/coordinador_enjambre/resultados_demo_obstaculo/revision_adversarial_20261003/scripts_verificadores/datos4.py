import json, os, glob
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
for c in ["fase0_conf2_20261002_195453/065_conf_guionada_C5_encierro_trio_sinrampa_tau0.85_F2",
          "fase0_conf2_20261002_195453/064_conf_guionada_C5_encierro_trio_tau0.85_F2",
          "fase0_conf2_20261002_195453/025_conf_guionada_C5_encierro_B_corrido_sinrampa_tau0.45_F2",
          "fase0_20261002_165649/173_guionada_E5_encierro_A_quieto_B_hacia_A_sinrampa_tau0.85_F2",
          "fase0_20261002_165649/172_guionada_E5_encierro_A_quieto_B_hacia_A_tau0.85_F2",
          "fase0_20261002_165649/337_mixto_E5_encierro_A_quieto_B_hacia_A_tob0.45_tau0.85_F2"]:
    r=json.load(open(os.path.join(R,c,"resultado.json"),encoding="utf-8"))
    print(c.split("/")[1], {k:r[k] for k in r if k.startswith("verdad_") or k in ("d_min_obst_a0","d_min_obst_a1","d_min_obst_a2")})
