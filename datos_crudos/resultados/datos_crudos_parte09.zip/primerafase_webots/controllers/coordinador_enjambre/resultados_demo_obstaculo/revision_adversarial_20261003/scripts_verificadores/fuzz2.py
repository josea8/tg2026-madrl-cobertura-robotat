import io, contextlib, random, sys
import numpy as np
sys.argv = ["x"]
exec(open("fuzz1.py", encoding="utf-8").read().split("class FakeFuente")[0])
ver_old = ns["old"]["_verificar_obediencia"]; ver_new = ns["new"]["_verificar_obediencia"]

class F:
    def __init__(self): self.v = None
    def velocidad_obstaculo(self): return None if self.v is None else self.v.copy()
class FOld(F):
    def velocidad_obstaculo(self): return np.zeros(2) if self.v is None else self.v.copy()
class S:
    def __init__(self, old=False):
        self._fuente = FOld() if old else F(); self._clase_mando = None; self._t_cambio_mando = 0.0
        self._decisiones_desobediencia = 0; self.decisiones_sin_estimacion = 0

rng = random.Random(7)
res = {"ambos_abortan_mismo_paso": 0, "nuevo_mas_tarde": 0, "solo_viejo": 0,
       "solo_nuevo": 0, "ninguno": 0, "nuevo_antes": 0}
ejemplos = {}
for it in range(60000):
    so, sn = S(True), S()
    t = 100.0
    ab_o = ab_n = None
    clase = None
    for k in range(80):
        dt = 0.1 if rng.random() > 0.05 else rng.uniform(0.3, 0.6)
        t += dt
        # orden de la decisión anterior (como en paso(): verificar antes de _mandar)
        r = rng.random()
        if k > 0:
            nueva = clase if r > 0.08 else rng.choice(["marcha", "parado"])
            if nueva != clase:
                for s in (so, sn): s._clase_mando = nueva; s._t_cambio_mando = t_prev
            clase = nueva
        q = rng.random()
        if q < 0.15: v = None
        elif q < 0.45: v = np.zeros(2)
        elif q < 0.6: v = np.array([0.015, 0.0])
        else: v = np.array([rng.choice([0.005, 0.03, 0.05, 0.08]), 0.0])
        so._fuente.v = v; sn._fuente.v = v
        with contextlib.redirect_stdout(io.StringIO()):
            mo = ver_old(so, t) if ab_o is None else None
            mn = ver_new(sn, t) if ab_n is None else None
        if mo is not None and ab_o is None: ab_o = (k, mo)
        if mn is not None and ab_n is None: ab_n = (k, mn)
        t_prev = t
    if ab_o and ab_n:
        if ab_o[0] == ab_n[0]: res["ambos_abortan_mismo_paso"] += 1
        elif ab_n[0] > ab_o[0]: res["nuevo_mas_tarde"] += 1
        else: res["nuevo_antes"] += 1; ejemplos.setdefault("nuevo_antes", (ab_o, ab_n))
    elif ab_o: res["solo_viejo"] += 1
    elif ab_n: res["solo_nuevo"] += 1; ejemplos.setdefault("solo_nuevo", (ab_o, ab_n))
    else: res["ninguno"] += 1
print(res); print(ejemplos)
