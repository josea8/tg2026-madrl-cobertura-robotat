# Cinemática pura: ley_nominal + meta_de_rodeo, SIN filtro, SIN retardo, SIN simulador.
import sys, math
import numpy as np
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import colocacion_con_obstaculo as C
from colocacion_autonoma import ley_nominal
o = np.array([1.5, 1.5]); blanco = np.array([2.25, 1.5])
p = np.array([0.75, 1.5, 0.0]); sentido = None; dt = 0.01
rmin = 9.0; t_rmin = 0; modos = set()
for k in range(int(60 / dt)):
    w, s, _m = C.meta_de_rodeo(p, blanco, o, sentido)
    if w is not None:
        sentido = s; meta = w; modos.add("rodeo")
    else:
        meta = blanco; modos.add("directo")
    d = float(np.linalg.norm(blanco - p[:2]))
    (v, om), fase = ley_nominal(p, meta, 0.0, d <= 0.05)
    if fase == "listo":
        break
    p = p + dt * np.array([v * math.cos(p[2]), v * math.sin(p[2]), om])
    r = float(np.linalg.norm(p[:2] - o))
    mira = p[:2] + 0.05 * np.array([math.cos(p[2]), math.sin(p[2])])
    if r < rmin:
        rmin, t_rmin, hmin = r, k * dt, float(np.linalg.norm(mira - o)) - 0.33
print(f"sin barrera: r_min centro-centro = {rmin:.3f} m a t = {t_rmin:.1f} s; h(mira) = {hmin:+.3f}; modos {modos}; fin t={k*dt:.1f}s fase={fase}")
print("R*cos(60deg) =", 0.55 * math.cos(math.radians(60)))
# float32: ¿V_MIN recto y W_MIN en el lugar quedan bajo el umbral de la zona muerta?
import struct
from protocolo_robotat import accion_a_rpm
import config_robotat as cfg
def ida_vuelta(v, w):
    ri, rd, _ = accion_a_rpm(v, w, cfg.RADIO_RUEDA_M, cfg.MEDIO_EJE_M)
    ri = struct.unpack(">f", struct.pack(">f", ri))[0]; rd = struct.unpack(">f", struct.pack(">f", rd))[0]
    r_, l_ = 0.016, 0.048
    pd, pi = rd * 2 * math.pi / 60, ri * 2 * math.pi / 60
    return r_ * (pd + pi) / 2, r_ * (pd - pi) / (2 * l_)
print("radio/medio eje cfg:", cfg.RADIO_RUEDA_M, cfg.MEDIO_EJE_M)
for v, w in [(0.03, 0.0), (0.0, 0.35), (0.0, -0.35), (0.03, 0.1)]:
    vv, ww = ida_vuelta(v, w)
    print((v, w), "->", repr(vv), repr(ww), "retenido_desde_parado:", (vv != 0 or ww != 0) and abs(vv) < 0.03 and abs(ww) < 0.35)
