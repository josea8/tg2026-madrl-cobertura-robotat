import csv, os, json, glob
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
for carp in ["fase0_conf2_20261002_195453","fase0_20261002_165649"]:
  for d in sorted(glob.glob(os.path.join(R,carp,"*"))):
    n=os.path.basename(d)
    if not (("C5_" in n or "E5_encierro_A_quieto" in n) and "_F2" in n): continue
    if not os.path.isfile(os.path.join(d,"resultado.json")): continue
    r=json.load(open(os.path.join(d,"resultado.json"),encoding="utf-8"))
    if r["verdad_d_min_obst"]>0.25: continue
    ag=str(r["verdad_agente_min"])
    rows=[x for x in csv.DictReader(open(os.path.join(d,"decisiones.csv"),encoding="utf-8")) if x["agente"]==ag]
    # paso del minimo medido 10 Hz
    dm=[(float(x["d_obst_medida"]),int(x["paso"])) for x in rows if x["d_obst_medida"]!=""]
    dmin,pmin=min(dm)
    neg=[int(x["paso"]) for x in rows if x["h_obst_eq"]!="" and float(x["h_obst_eq"])<0]
    esc=[int(x["paso"]) for x in rows if x["en_escape"]=="1"]
    # first escape after first neg
    f_neg=neg[0] if neg else None
    esc_after=[p for p in esc if f_neg is not None and p>=f_neg]
    print(carp[:14], n[:60], "ag",ag,"dmin10Hz %.4f@%d"%(dmin,pmin),"primer heq<0:",f_neg,"escapes(pasos):", (esc[0], esc[-1], len(esc)) if esc else None, "1er escape tras heq<0:", esc_after[0] if esc_after else None)
