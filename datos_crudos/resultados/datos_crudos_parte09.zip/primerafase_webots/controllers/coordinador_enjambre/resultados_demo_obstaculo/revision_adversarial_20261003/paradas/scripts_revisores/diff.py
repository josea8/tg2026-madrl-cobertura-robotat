import difflib, io
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
a = io.open(D + r"\demo_obstaculo_movil_respaldo_20261003_preParadas.py", encoding="utf-8").read().splitlines()
b = io.open(D + r"\demo_obstaculo_movil.py", encoding="utf-8").read().splitlines()
d = list(difflib.unified_diff(a, b, "respaldo", "actual", n=3, lineterm=""))
io.open("full.diff", "w", encoding="utf-8").write("\n".join(d))
print(len(d), "lines;", sum(1 for l in d if l.startswith("@@")), "hunks")
