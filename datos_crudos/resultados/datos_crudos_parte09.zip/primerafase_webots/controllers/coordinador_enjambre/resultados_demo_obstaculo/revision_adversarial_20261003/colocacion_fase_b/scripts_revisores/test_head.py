import hashlib
p = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\test_demo_obstaculo_movil.py"
L = open(p, "rb").read().split(b"\n")
objetivo = "ed0e64b2fee8c006788bad68bde4f4b0b92492e1605458c279b74886750798d7"
# L is 0-based; line k (1-based) = L[k-1]
cola_opts = [b"\n\nif __name__ == \"__main__\":\n    unittest.main(verbosity=2)\n",
             b"\n\n\nif __name__ == \"__main__\":\n    unittest.main(verbosity=2)\n",
             b"\n\nif __name__ == \"__main__\":\n    unittest.main(verbosity=2)",
             b"\nif __name__ == \"__main__\":\n    unittest.main(verbosity=2)\n"]
for quitar_doc in [(30, 38), (29, 38), (30, 39)]:
    a, b = quitar_doc
    cabeza = L[:a-1] + L[b:1389]
    for cola in cola_opts:
        datos = b"\n".join(cabeza) + cola
        h = hashlib.sha256(datos).hexdigest()
        if h == objetivo:
            print("MATCH", quitar_doc, repr(cola))
print("done")
print(L[28:29], L[38:39])
