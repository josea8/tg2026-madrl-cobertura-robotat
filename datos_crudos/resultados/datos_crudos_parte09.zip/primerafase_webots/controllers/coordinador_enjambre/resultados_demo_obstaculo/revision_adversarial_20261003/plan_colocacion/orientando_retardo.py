# Fase 'orientando' de colocacion_autonoma.ley_nominal con retardo PURO tau.
# (a) el robot es el ultimo pendiente: el lazo corta en el primer 'listo'
#     (finally (0,0)) y el robot sigue girando lo que tenia en vuelo;
# (b) el lazo sigue (otros pendientes 5 s mas): se re-evalua la fase.
import math
K_W=1.2; W_MIN=0.35; W_COL=1.0; TOL=math.radians(20); HZ=10
def env(a): return math.atan2(math.sin(a), math.cos(a))
def w_nom(e):
    if abs(e)<=TOL: return 0.0
    return math.copysign(min(max(K_W*abs(e),W_MIN),W_COL),e)
def sim(e0,tau,seguir_s):
    th=0.0; rumbo=e0   # error = rumbo - th
    cola=[]; t=0.0; dt=0.001; k=0; corte=None
    sub=int(1/HZ/dt)
    while True:
        if k%sub==0:
            e=env(rumbo-th)
            w=w_nom(e)
            if corte is None:
                if w==0.0:
                    corte=t
                cola.append((t,w))
            else:
                if t-corte<seguir_s: cola.append((t,w))
                else: cola.append((t,0.0))
        we=0.0
        for te,w in cola:
            if te+tau<=t: we=w
            else: break
        th+=we*dt; t+=dt; k+=1
        if corte is not None and t>corte+seguir_s+tau+0.2: break
        if t>60: break
    return math.degrees(env(rumbo-th)), corte
for tau in (0.45,0.65,0.85):
    fila=[]
    for e0 in (30,60,90,180):
        ea,_=sim(math.radians(e0),tau,0.0)
        eb,_=sim(math.radians(e0),tau,5.0)
        fila.append(f"e0={e0:3d}: corte {ea:+5.1f}° / sigue {eb:+5.1f}°")
    print(f"tau={tau:.2f}  "+"  ".join(fila))
