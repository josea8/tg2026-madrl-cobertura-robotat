"""
¿El detener_todo de la regla de parada reintenta reabrir el enlace caído del
obstáculo? Sin red: socket.create_connection queda parcheado para que falle
y registre cada intento (no se abre ningún socket).
"""
import contextlib
import io
import socket
import sys
import time
from pathlib import Path

CARPETA = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots"
               r"\controllers\coordinador_enjambre")
sys.path.insert(0, str(CARPETA))
with contextlib.redirect_stdout(io.StringIO()):
    import demo_obstaculo_movil as demo

intentos = []


def falso_create_connection(direccion, timeout=None, *a, **k):
    intentos.append((time.perf_counter(), direccion))
    raise ConnectionRefusedError("parcheado: sin red")


socket.create_connection = falso_create_connection

canal = demo.CanalConObstaculo(5, None, conectar_obstaculo=True)
# Estado tras un envío fallido a mitad de toma: socket del obstáculo None.
canal._sock_obst = None
salida = io.StringIO()
with contextlib.redirect_stdout(salida):
    # 1) el supervisor aborta y frena (primer intento de reabrir)
    t0 = time.perf_counter()
    canal.detener_obstaculo()
    n1 = len(intentos)
    # 2) ~0.1 s después, el detener_todo del final de _correr_episodio
    time.sleep(0.1)
    canal.detener_todo()
    n2 = len(intentos)
    # 3) ~0.3 s después, el detener_todo de la regla de parada
    time.sleep(0.2)
    canal.detener_todo()
    n3 = len(intentos)
print("intentos de reabrir: tras abortar", n1, "· fin de toma", n2 - n1,
      "· regla de parada", n3 - n2)
print("obstaculo_detencion_fallida =", canal.obstaculo_detencion_fallida)
print("--- consola ---")
print(salida.getvalue())
# 4) el forzado sí intenta
antes = len(intentos)
with contextlib.redirect_stdout(io.StringIO()):
    canal.reintentar_enlace_obstaculo()
print("reintentar_enlace_obstaculo (forzado) intentó:", len(intentos) - antes)
