import json, os, glob, collections
base = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
for run in ("fase0_conf2_20261002_195453", "fase0_20261002_165649"):
    c = collections.Counter(); ce = collections.Counter(); motivos = collections.Counter()
    for d in sorted(glob.glob(os.path.join(base, run, "*", "resultado.json"))):
        j = json.load(open(d, encoding="utf-8"))
        bl = j.get("bloque", "?")
        c[(bl, j.get("lazo"))] += 1
        if j.get("corte_estancamiento_paso") not in ("", None): ce[bl] += 1
        if str(j.get("motivo", "")): motivos[str(j.get("motivo"))[:90]] += 1
    print(run); print("  bloque/lazo:", dict(c)); print("  corte_estancamiento:", dict(ce)); print("  motivos:", dict(motivos))
