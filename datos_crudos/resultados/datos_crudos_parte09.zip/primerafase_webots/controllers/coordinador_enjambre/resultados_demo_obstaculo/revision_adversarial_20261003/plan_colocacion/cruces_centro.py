# L1: obstaculo fijo en (1.5,1.5). Fraccion de trayectos rectos (ley_nominal va
# en linea recta) inicio->blanco que pasan a menos de r del centro, con inicio y
# blanco uniformes en [0.45,2.55]^2 a >=0.50 del centro (aprox. del final de una toma).
import numpy as np
rng=np.random.default_rng(1); c=np.array([1.5,1.5])
def punto():
    while True:
        p=rng.uniform(0.45,2.55,2)
        if np.linalg.norm(p-c)>=0.5: return p
def dseg(a,b,p):
    ab=b-a; t=np.clip(np.dot(p-a,ab)/np.dot(ab,ab),0,1); return np.linalg.norm(a+t*ab-p)
N=20000
d=np.array([dseg(punto(),punto(),c) for _ in range(N)])
for r in (0.33,0.38,0.43):
    f=np.mean(d<r); print(f"r={r:.2f}: por agente {f:.3f}; al menos 1 de 5: {1-(1-f)**5:.3f}")
f=np.mean(d<0.05); print(f"casi de frente (< 5 cm del centro): por agente {f:.3f}; al menos 1 de 5: {1-(1-f)**5:.3f}")
