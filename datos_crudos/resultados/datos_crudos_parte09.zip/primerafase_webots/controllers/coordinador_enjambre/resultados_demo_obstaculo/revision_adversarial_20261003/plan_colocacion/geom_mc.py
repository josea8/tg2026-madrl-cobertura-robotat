"""Chequeo geometrico PURO (sin simular robots): cruces de caminos rectos con
el obstaculo, margen de la separacion 0.50 y camino del obstaculo."""
import csv, glob, math, collections
import numpy as np
R = "C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/"
# --- poses finales reales de episodios (30-sep) ---
finales=[]
for f in sorted(glob.glob(R+"20260930_sesion-evaluacion_etapa7_decisiones*.csv")):
    ult=collections.OrderedDict()
    with open(f, encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            ult[(row["episodio"],int(row["agente"]))]=(float(row["pose_env_x"]),float(row["pose_env_y"]))
    eps=collections.defaultdict(dict)
    for (e,a),p in ult.items(): eps[e][a]=p
    for e,d in eps.items():
        if len(d)==5: finales.append([np.array(d[a]) for a in range(5)])
print("conjuntos de poses finales reales:", len(finales))
# --- replica de los sorteos ---
MARGEN=0.45; DSEP=0.45; W=3.0
def sortear_poses_arranque(n, rng, intentos=400):
    puestos=[]
    for _ in range(n):
        for _t in range(intentos):
            c=np.array([rng.uniform(MARGEN,W-MARGEN), rng.uniform(MARGEN,W-MARGEN)])
            if all(float(np.linalg.norm(c-p))>DSEP for p in puestos):
                puestos.append(c); break
        else: raise RuntimeError
    return {i:p for i,p in enumerate(puestos)}
def sortear_blancos_demo(n, semilla, P, sep=0.50, intentos=200):
    rng=np.random.default_rng(int(semilla))
    for _ in range(intentos):
        b=sortear_poses_arranque(n, rng)
        if all(float(np.linalg.norm(p-P[:2]))>=sep for p in b.values()): return b
    raise RuntimeError
def fase(semilla, id_obst=7):
    return float(np.random.default_rng([int(semilla), id_obst]).uniform(-math.pi, math.pi))
def punto(ph):
    return np.array([1.5+0.6*math.cos(ph), 1.5+0.6*math.sin(ph)])
def segdist(p,a,b):
    d=b-a; L2=float(d@d)
    t=0.0 if L2==0 else max(0.0,min(1.0,float((p-a)@d)/L2))
    return float(np.linalg.norm(a+t*d-p))
SEMILLAS=[420000+i for i in range(60)]
rng_e=np.random.default_rng(1)
# errores empiricos de 'listo' (de col_empirica): usar la de los listo
errs=[]
for f in sorted(glob.glob(R+"202609[23]*episodios*.csv")):
    with open(f, encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            if row.get("colocacion")!="auto": continue
            for i in range(5):
                if row.get(f"col_estado_a{i}")=="listo" and row.get(f"col_err_m_a{i}"):
                    errs.append(float(row[f"col_err_m_a{i}"]))
errs=np.array(errs); print("errores 'listo': n=%d med %.3f p90 %.3f p99 %.3f max %.3f"%(len(errs),np.median(errs),np.quantile(errs,.9),np.quantile(errs,.99),errs.max()))
def err_vec():
    e=rng_e.choice(errs); a=rng_e.uniform(-math.pi,math.pi); return e*np.array([math.cos(a),math.sin(a)])

for modo in ("L1","L2"):
    print("\n=====",modo)
    margen_cnt=collections.Counter(); falla_check=0; ntot=0
    cruce={0.25:0,0.33:0,0.38:0}; tomas_con_cruce={0.25:0,0.33:0,0.38:0}; nag=0; ntomas=0
    obst_bloq_A={0.25:0,0.33:0}; obst_bloq_B={0.25:0,0.33:0}; nob=0
    agentes_en_punto=0
    for k,s in enumerate(SEMILLAS):
        P = np.array([1.5,1.5]) if modo=="L1" else punto(fase(s))
        b = sortear_blancos_demo(5, s, P)
        dmin=min(float(np.linalg.norm(p-P)) for p in b.values())
        for m in (0.05,0.08,0.10,0.15):
            if dmin < 0.50+m: margen_cnt[m]+=1
        # chequeo con errores de llegada empiricos (todos 'listo')
        for _ in range(200):
            Po=P+err_vec()
            ntot+=1
            if any(float(np.linalg.norm(p+err_vec()-Po))<0.50 for p in b.values()): falla_check+=1
        # cruces: poses finales reales -> blancos, obstaculo quieto en P (orden A: obstaculo primero)
        for fin in finales:
            ntomas+=1
            hay={d:False for d in cruce}
            for i in range(5):
                nag+=1
                dd=segdist(P, fin[i], b[i])
                for d in cruce:
                    if dd<d: cruce[d]+=1; hay[d]=True
            for d in cruce: tomas_con_cruce[d]+= hay[d]
            # agente parado DENTRO del punto del obstaculo (bloquea al obstaculo en orden A)
            if any(float(np.linalg.norm(fin[i]-P))<0.33 for i in range(5)): agentes_en_punto+=1
            if modo=="L2":
                # camino del obstaculo: desde una fase final aleatoria del circulo a P
                ph_end=rng_e.uniform(-math.pi,math.pi); Pend=punto(ph_end); nob+=1
                for d in obst_bloq_A:
                    # orden A (obstaculo primero): agentes en sus poses finales
                    if any(segdist(fin[i],Pend,P)<d for i in range(5)): obst_bloq_A[d]+=1
                    # orden B (agentes primero): agentes en sus blancos
                    if any(segdist(b[i],Pend,P)<d for i in range(5)): obst_bloq_B[d]+=1
    print("semillas con algun blanco a < 0.50+m del punto del obstaculo:", {m:f"{c}/{len(SEMILLAS)}" for m,c in sorted(margen_cnt.items())})
    print("P(chequeo >=0.50 falla con TODOS 'listo', errores empiricos) = %.3f"%(falla_check/ntot))
    print("fraccion de agentes cuyo camino recto pasa a < d del centro del obstaculo:", {d:round(c/nag,3) for d,c in cruce.items()})
    print("fraccion de colocaciones con >=1 agente cruzando:", {d:round(c/ntomas,3) for d,c in tomas_con_cruce.items()})
    print("fraccion con un agente (pose final) a <0.33 del punto del obstaculo (bloquea orden A):", round(agentes_en_punto/ntomas,3))
    if modo=="L2":
        print("obstaculo bloqueado (cuerda) orden A [agentes en poses finales]:", {d:round(c/nob,3) for d,c in obst_bloq_A.items()})
        print("obstaculo bloqueado (cuerda) orden B [agentes en blancos]:", {d:round(c/nob,3) for d,c in obst_bloq_B.items()})
