"""Verificación de sólo lectura del ensayo L2 (dry run)."""
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path

D = Path(r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers"
         r"\coordinador_enjambre\resultados_demo_obstaculo\ensayo_l2_20261002_201318")
tomas = list(csv.DictReader(open(D / "20261002_202234_L2_tomas.csv", encoding="utf-8")))


def f(x):
    try:
        return float(x)
    except Exception:
        return float("nan")


print("=== Tomas ===")
cols = ["toma", "valido", "motivo", "decisiones", "duracion_s", "ciclos_sobre_100ms",
        "ciclo_p95_ms", "d_min_obst_medida", "frenos", "obst_freno_activo", "obst_modo",
        "obst_recorrido_m", "obst_recorrido_comandado_m", "obst_motivo_aborto",
        "decisiones_freno", "valido_demo", "motivo_demo", "corte_estancamiento_paso",
        "lazo", "decisiones_obst_015", "semilla"]
for t in tomas:
    print({c: t.get(c) for c in cols})

# Recalcular validez de demo de forma independiente, según el protocolo
print("\n=== Recalculo independiente de validez_demo ===")
for t in tomas:
    val = int(f(t["valido"])) == 1
    sin_freno = int(f(t["frenos"]) or 0) == 0
    d = f(t["d_min_obst_medida"])
    sin_contacto = math.isfinite(d) and d >= 0.15
    med, com = f(t["obst_recorrido_m"]), f(t["obst_recorrido_comandado_m"])
    recorrio = med >= 0.5 * com
    demo = int(val and sin_freno and sin_contacto and recorrio)
    print(t["toma"], "valido", int(val), "sin_freno", sin_freno, "sin_contacto", sin_contacto,
          f"recorrido {med:.4f}/{com:.4f} frac {med / com if com else float('nan'):.3f}",
          "demo_recalc", demo, "demo_csv", t["valido_demo"],
          "OK" if str(demo) == t["valido_demo"] else "DISCREPA")

# Conteo de la sesión: ¿para al llegar a 10 demo-válidas?
acum = 0
for t in tomas:
    acum += int(f(t["valido_demo"]))
    print("intento", t["toma"], "acumuladas demo", acum)

validas = [t for t in tomas if t["valido"] == "1"]
ds = sorted(f(t["d_min_obst_medida"]) for t in validas)
print("\nd_min sobre válidas:", ds)
print("min", ds[0], "max", ds[-1], "mediana upper (analizador)", ds[len(ds) // 2],
      "mediana estadistica", statistics.median(ds))
print("recorrido medio válidas", statistics.mean(f(t["obst_recorrido_m"]) for t in validas))
print("duracion total s", sum(f(t["duracion_s"]) for t in tomas))

# Cruce con la traza del obstáculo (10 Hz)
print("\n=== Traza del obstáculo ===")
obs = list(csv.DictReader(open(D / "20261002_202234_L2_obstaculo.csv", encoding="utf-8")))
print("filas", len(obs), "columnas", list(obs[0].keys()))
por_toma = defaultdict(list)
for o in obs:
    por_toma[o["toma"]].append(o)
for k, filas in por_toma.items():
    dmin = min((f(o["d_min_agente_medida"]) for o in filas if o["d_min_agente_medida"] != ""),
               default=float("nan"))
    estados = defaultdict(int)
    for o in filas:
        estados[o["estado"]] += 1
    en_freno = sum(int(o["en_freno"]) for o in filas)
    pasos = [int(o["paso"]) for o in filas]
    ts = [f(o["t"]) for o in filas]
    dts = [b - a for a, b in zip(ts, ts[1:])]
    # recorrido desde la traza
    med = 0.0
    prev = None
    com = 0.0
    for o in filas:
        if o["x"] != "" and o["y"] != "":
            p = (f(o["x"]), f(o["y"]))
            if prev is not None:
                med += math.hypot(p[0] - prev[0], p[1] - prev[1])
            prev = p
        if o["v_cmd"] != "":
            com += abs(f(o["v_cmd"])) * 0.1
    print(f"toma {k}: n={len(filas)} pasos {min(pasos)}..{max(pasos)} dmin_traza {dmin:.4f} "
          f"en_freno {en_freno} estados {dict(estados)} dt_med {statistics.median(dts):.4f} "
          f"dt_max {max(dts):.4f} rec_med {med:.4f} rec_com {com:.4f}")
    # Primeras decisiones: ¿rampa? (espera)
    primeras = [o["estado"] for o in filas[:60]]
    n_espera = sum(1 for e in primeras if e == "espera")
    print(f"    decisiones 'espera' en las primeras 60: {n_espera}")
