import ast, io, math, random
from typing import Any, Dict, List, Optional, Sequence, Tuple
from dataclasses import dataclass
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
src = io.open(D + r"\demo_obstaculo_movil.py", encoding="utf-8").read()
tree = ast.parse(src)
want = {"regla_de_parada", "validez_demo", "_metricas_l0"}
consts = {"UMBRAL_CONTACTO_M", "TOMAS_CON_FRENO_SEGUIDAS", "FRACCION_RECORRIDO_MIN"}
ns = {"ParametrosTrayectoria": object, "math": math, "Any": Any, "Dict": Dict, "List": List, "Optional": Optional,
      "Sequence": Sequence, "Tuple": Tuple}
mod = ast.Module(body=[n for n in tree.body if (isinstance(n, ast.FunctionDef) and n.name in want)
       or (isinstance(n, ast.AnnAssign) and getattr(n.target, "id", None) in consts)], type_ignores=[])
exec(compile(mod, "demo_extract", "exec"), ns)
regla, validez, metr = ns["regla_de_parada"], ns["validez_demo"], ns["_metricas_l0"]

def caso(desc, res, ant=()):
    try:
        v = validez(res) if 'valido' in res else '-'
    except Exception as e:
        v = f"EXC {type(e).__name__}"
    print(f"{desc:55s} -> regla={regla(res, list(ant))!r}  validez={v}")

caso("contacto 0.149", {"valido": 1, "frenos": 0, "d_min_obst_medida": 0.149})
caso("contacto 0.15 exacto", {"valido": 1, "frenos": 0, "d_min_obst_medida": 0.15})
caso("d vacío", {"valido": 1, "frenos": 0, "d_min_obst_medida": ""})
caso("d str '0.12' (desde CSV)", {"valido": 1, "frenos": 0, "d_min_obst_medida": "0.12"})
caso("d None", {"valido": 1, "frenos": 0, "d_min_obst_medida": None})
caso("d ausente", {"valido": 0, "motivo": "no se pudo iniciar la toma"})
caso("freno sólo en ésta", {"valido": 1, "frenos": 1}, [{"frenos": 0}])
caso("freno 2 seguidas", {"valido": 1, "frenos": 1}, [{"frenos": 2}])
caso("freno 2 con hueco", {"valido": 1, "frenos": 1}, [{"frenos": 1}, {"frenos": 0}])
caso("freno 1a toma sin anteriores", {"valido": 1, "frenos": 3}, [])
caso("aborto OBSTÁCULO: prefijo", {"valido": 0, "motivo": "OBSTÁCULO: enlace caído"})
caso("aborto obst_motivo_aborto", {"valido": 0, "motivo": "x", "obst_motivo_aborto": "no obedece"})
caso("frenos='' (fila de colocación)", {"valido": 0, "frenos": ""}, [{"frenos": 1}])
caso("frenos str '1'", {"valido": 1, "frenos": "1"}, [{"frenos": "1"}])
caso("d nan", {"valido": 1, "frenos": 0, "d_min_obst_medida": float("nan")})
caso("d 'nan' str", {"valido": 1, "frenos": 0, "d_min_obst_medida": "nan"})
caso("d inf", {"valido": 1, "frenos": 0, "d_min_obst_medida": float("inf")})
# validez d nan behaviour (unchanged function) vs regla
try:
    print("validez con d=-1:", validez({"valido": 1, "frenos": 0, "d_min_obst_medida": -1.0}), regla({"d_min_obst_medida": -1.0}, []))
except Exception as e:
    print("err", e)

# ---- L0: equivalencia del veredicto normal ----
@dataclass
class Par:
    omega_max: float = 1.2
def viejo(filas, resultados, arranques, par):
    errores = [abs(f["error_radial"]) for f in filas if f["t"] >= 2.0]
    arrancaron = sum(r["arranco"] for r in resultados)
    e_max = max(errores) if errores else float("nan")
    ok = arrancaron == arranques and errores and e_max < 0.05
    return ("OK" if ok else "FALLO"), arrancaron, e_max
def nuevo(filas, resultados, arranques, par):
    m = metr(filas, resultados, par)
    e_max = m["error_radial_max"]
    ok = (m["arranques_ok"] == arranques and math.isfinite(e_max) and e_max < 0.05)
    return ("OK" if ok else "FALLO"), m["arranques_ok"], e_max
random.seed(1)
par = Par()
diff = 0
N = 200000
for k in range(N):
    arr = random.choice([0, 1, 9, 10, 10, 10])
    resultados = [{"arranco": int(random.random() < 0.97)} for _ in range(arr)]
    filas = []
    for _ in range(random.choice([0, 0, 1, 5, 40])):
        e = random.choice([random.uniform(-0.08, 0.08), 0.05, -0.05, 0.0499999, float("nan")]) if random.random() < 0.3 else random.uniform(-0.04, 0.04)
        filas.append({"t": random.choice([0.0, 1.99, 2.0, 3.5, 5.9]), "error_radial": e, "w": random.uniform(-1.3, 1.3)})
    a = viejo(filas, resultados, 10, par); b = nuevo(filas, resultados, 10, par)
    same_e = (a[2] == b[2]) or (math.isnan(a[2]) and math.isnan(b[2]))
    if a[0] != b[0] or a[1] != b[1] or not same_e:
        diff += 1
        if diff < 5: print("DIFERENCIA", a, b, filas[:3])
print(f"L0: {diff} diferencias en {N} casos aleatorios")
