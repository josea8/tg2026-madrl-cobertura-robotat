"""Evaluacion PUNTUAL (sin integrar en el tiempo) del filtro de colocacion con
una fila agente-obstaculo, para ver que (v, w) sale cuando el robot apunta a su
blanco y el obstaculo esta en el camino. No toca el arbol de la tesis (-B)."""
import sys, math, warnings
sys.path.insert(0, r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre")
warnings.simplefilter("ignore")
import numpy as np
import colocacion_autonoma as ca
from lib.filtro_cbf import RestriccionLineal
f = ca.FiltroColocacion()
O = np.array([1.5, 1.5])
def fila(pose, D, frac):
    p = f._punto_de_mira(pose); G = f._matriz_G(float(pose[2]))
    d = p - O; dist = float(np.linalg.norm(d))
    return ca._no_empeorar(RestriccionLineal(c=(d/dist)@G, h=frac*(dist-D), nombre="obst"))
print("D=0.33 (D_OBSTACULO_M), robot apuntando a un blanco 1 m detras del obstaculo")
print(" beta = angulo entre el rumbo y la direccion al centro del obstaculo")
for frac in (1.0, 0.5):
    print(f"--- responsabilidad h = {frac}*(dist-D)")
    for h in (0.04, 0.01, 0.0):
        fila_txt=[]
        for beta_deg in (0, 3, 6, 10, 15, 20, 30, 40):
            b = math.radians(beta_deg)
            # punto de mira a distancia D+h del centro, con el centro a angulo beta del rumbo
            th = 0.0
            dist = 0.33 + h
            # p_a = O - dist*[cos(beta), sin(beta)] rotado: centro esta a +beta del rumbo
            pa = O - dist*np.array([math.cos(b), math.sin(b)])
            pose = np.array([pa[0]-ca.ELE_A, pa[1], th])
            # blanco: 1 m adelante en la direccion del rumbo (err = 0)
            blanco = pose[:2] + np.array([1.2, 0.0])
            u_nom, fase = ca.ley_nominal(pose, blanco, 0.0, False)
            r = f.filtrar(pose, np.array(u_nom), [fila(pose, 0.33, frac)])
            u = r.u_seguro if r.exito_qp else np.zeros(2)
            fila_txt.append(f"b{beta_deg:>2}:v={u[0]:.3f},w={u[1]:+.2f}")
        print(f" h={h:.2f}  " + "  ".join(fila_txt))
print("\nzona muerta: V_MIN=%.2f m/s, W_MIN=%.2f rad/s (colocacion_autonoma)" % (ca.V_MIN, ca.W_MIN))
