import textwrap
exec(open(r"C:/Users/velas/AppData/Local/Temp/claude/C--Users-velas-OneDrive-Documents-tesis/cc510369-0bba-489d-9bbd-57ba8af8e5d7/scratchpad/verif_wf/fuzz.py").read().split("class G: pass")[0].replace('print("OLD','pass #'))
class G: en_retroceso=set()
def run(ciclo, gap, N=3000, dt=0.1):
    t_mov={0:0.0}; to={}; tso={}; co=cn=None
    for k in range(1,N):
        ahora=k*dt
        v = 0.0 if (k % ciclo) >= ciclo-gap else 0.15
        f=[{"agente":0,"v_ejecutada":v}]
        if co is None and p_old(f,ahora,t_mov,G,None,None)[0]: co=k
        if cn is None and p_new(f,ahora,t_mov,G,to,tso)[0]: cn=k
    return co, cn
for ciclo,gap in [(110,11),(110,10),(115,11),(120,11),(121,11),(130,15),(60,2)]:
    print("ciclo",ciclo,"decisiones; sin orden",gap,"-> corte viejo, nuevo:", run(ciclo,gap))
