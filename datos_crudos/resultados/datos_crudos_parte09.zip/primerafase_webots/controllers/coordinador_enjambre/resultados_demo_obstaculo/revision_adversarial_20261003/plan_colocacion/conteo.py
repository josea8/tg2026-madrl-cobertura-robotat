import csv, glob, math, collections
R = "C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/"
por=collections.defaultdict(lambda:[0,0,0,[]])
for f in sorted(glob.glob(R+"202609[23]*episodios*.csv")):
    dia=f.split("\\")[-1][:8]
    with open(f, encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            if row.get("colocacion")!="auto" or row.get("col_t_s","")=="": continue
            por[dia][0]+=1
            dead=False
            for i in range(5):
                if row.get(f"col_estado_a{i}")!="no avanza" or not row.get(f"x0_a{i}"): continue
                p=(float(row[f"x0_a{i}"]),float(row[f"y0_a{i}"]))
                dmin=min(math.hypot(p[0]-float(row[f"x0_a{j}"]),p[1]-float(row[f"y0_a{j}"])) for j in range(5) if j!=i and row.get(f"x0_a{j}"))
                if dmin<0.32: dead=True
            if dead: por[dia][1]+=1
            if row["col_motivo"]!="todos listos": por[dia][2]+=1
            por[dia][3].append(float(row["col_t_s"]))
for d,(n,dd,nt,ts) in sorted(por.items()):
    ts.sort()
    print(d, "colocaciones",n,"con bloqueo mutuo (no avanza a <0.32 m de otro)",dd, "no 'todos listos'",nt, "t med %.1f max %.1f"%(ts[len(ts)//2],ts[-1]))
