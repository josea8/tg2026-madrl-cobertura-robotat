import json, os, glob
base = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
def load(run):
    out = {}
    for p in glob.glob(os.path.join(base, run, "*", "spec.json")):
        s = json.load(open(p, encoding="utf-8"))
        if str(s.get("bloque", "")).startswith("conf"):
            key = (s.get("bloque"), s.get("nombre"), s.get("tau"), s.get("sin_rampa"))
            out[key] = (s, os.path.basename(os.path.dirname(p)))
    return out
a = load("fase0_20261002_165649"); b = load("fase0_conf2_20261002_195453")
print(len(a), len(b), "mismas claves:", set(a) == set(b))
dif = []
for k in sorted(a, key=str):
    if k in b:
        sa, sb = a[k][0], b[k][0]
        ka = set(sa) | set(sb)
        dk = [x for x in ka if sa.get(x) != sb.get(x)]
        if dk: dif.append((k, dk, {x: (sa.get(x), sb.get(x)) for x in dk if x not in ("carpeta", "salida", "puerto", "puertos")}))
print("specs con diferencias:", len(dif))
from collections import Counter
print(Counter(tuple(sorted(d[1])) for d in dif))
for d in dif[:3]: print(d)
