import io, re, unicodedata
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
src = io.open(D + r"\demo_obstaculo_movil.py", encoding="utf-8").read()
for m in re.finditer(r"OBST.{1,2}CULO:", src):
    s = m.group(0)
    ln = src.count("\n", 0, m.start()) + 1
    print(ln, [hex(ord(c)) for c in s[4:6]], unicodedata.is_normalized("NFC", s))
print("NFC whole file:", unicodedata.is_normalized("NFC", src))
