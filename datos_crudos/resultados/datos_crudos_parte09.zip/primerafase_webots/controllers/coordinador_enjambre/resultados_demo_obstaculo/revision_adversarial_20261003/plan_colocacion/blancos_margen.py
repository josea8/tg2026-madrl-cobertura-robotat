# Replica pura de sortear_blancos_demo / arranque_obstaculo (demo_obstaculo_movil.py
# 2042-2073) y sortear_poses_arranque (sesion_robotat.py 2316-2348).
import math, numpy as np
MARGEN=0.45; DSEP=0.45; W=3.0; SEP_OBS=0.50
def sortear_poses_arranque(n, rng, intentos=400):
    puestos=[]
    for _ in range(n):
        for _t in range(intentos):
            c=np.array([rng.uniform(MARGEN,W-MARGEN), rng.uniform(MARGEN,W-MARGEN)])
            if all(np.linalg.norm(c-p)>DSEP for p in puestos):
                puestos.append(c); break
        else: raise RuntimeError
    return {i:p for i,p in enumerate(puestos)}
def blancos_demo(n, semilla, punto):
    rng=np.random.default_rng(int(semilla))
    for _ in range(200):
        b=sortear_poses_arranque(n,rng)
        if all(np.linalg.norm(p-punto[:2])>=SEP_OBS for p in b.values()): return b
    raise RuntimeError
def arranque(semilla, modo):
    if modo=="L1": return np.array([1.5,1.5])
    fase=float(np.random.default_rng([int(semilla),7]).uniform(-math.pi,math.pi))
    return np.array([1.5+0.6*math.cos(fase),1.5+0.6*math.sin(fase)])
SEM=[42*10000+i for i in range(18)]
for modo in ("L1","L2"):
    n_riesgo=0; filas=[]
    for k in range(1,21):
        s=SEM[k-1] if k<=18 else SEM[0]+k-1
        p=arranque(s,modo); b=blancos_demo(5,s,p)
        d=min(float(np.linalg.norm(q-p)) for q in b.values())
        if d<0.60: n_riesgo+=1
        filas.append(f"{d:.3f}")
    print(modo, "dist min blanco-obstaculo por intento 1..20:", " ".join(filas))
    print(f"   intentos con algun blanco a < 0.60 m (margen 0.50 + 2x5 cm de tolerancia): {n_riesgo}/20")
