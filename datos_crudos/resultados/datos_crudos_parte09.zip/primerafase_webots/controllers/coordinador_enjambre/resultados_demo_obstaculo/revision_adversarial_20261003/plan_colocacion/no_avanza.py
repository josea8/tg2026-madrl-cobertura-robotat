import csv, glob, math
R = "C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_sesion/"
files = sorted(glob.glob(R+"202609[23]*episodios*.csv"))
def seg_dist(p,a,b):
    ax,ay=a; bx,by=b; px,py=p
    dx,dy=bx-ax,by-ay; L2=dx*dx+dy*dy
    t=0 if L2==0 else max(0,min(1,((px-ax)*dx+(py-ay)*dy)/L2))
    return math.hypot(ax+t*dx-px, ay+t*dy-py)
for f in files:
    with open(f, encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            if row.get("colocacion")!="auto" or row.get("col_t_s","")=="": continue
            for i in range(5):
                e=row.get(f"col_estado_a{i}","")
                if e in ("listo",""): continue
                x0=row.get(f"x0_a{i}","")
                info=f"{f.split(chr(92))[-1][:8]} ep{row['episodio']} r{row.get(f'robot_a{i}')} {e} err={row.get(f'col_err_m_a{i}')} t={row['col_t_s']} motivo={row['col_motivo'][:30]} valido={row['valido']}"
                if x0=="":
                    print(info, "(sin x0)"); continue
                p=(float(x0),float(row[f"y0_a{i}"])); b=(float(row[f"blanco_x_a{i}"]),float(row[f"blanco_y_a{i}"]))
                dmin=min((math.hypot(p[0]-float(row[f"x0_a{j}"]),p[1]-float(row[f"y0_a{j}"])),j) for j in range(5) if j!=i and row.get(f"x0_a{j}",""))
                # other robots near the straight path to target
                bloq=[ (round(seg_dist((float(row[f"x0_a{j}"]),float(row[f"y0_a{j}"])),p,b),2),j) for j in range(5) if j!=i and row.get(f"x0_a{j}","")]
                bloq=[x for x in bloq if x[0]<0.35]
                dpared=min(p[0],3-p[0],p[1],3-p[1])
                print(info, f"pose=({p[0]:.2f},{p[1]:.2f}) d_blanco={math.dist(p,b):.2f} vecino_mas_cerca={dmin[0]:.2f}(a{dmin[1]}) d_pared={dpared:.2f} vecinos_en_camino={bloq}")
