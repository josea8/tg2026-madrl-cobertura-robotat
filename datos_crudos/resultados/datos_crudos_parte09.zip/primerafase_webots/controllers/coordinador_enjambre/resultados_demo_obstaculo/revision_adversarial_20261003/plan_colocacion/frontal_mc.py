"""Fraccion de agentes cuyo camino recto (punto de mira ~ centro) pasa a menos
de e del CENTRO del obstaculo (aproximacion casi frontal: el QP no gira lo
suficiente, ver qp_estatico.py), y de blancos que forman 'bolsillo' con el
obstaculo (a < 0.33+0.25 = 0.58 m)."""
import math, collections
import numpy as np
exec(open("geom_mc.py", encoding="utf-8").read().split("SEMILLAS=")[0])  # reusa funciones y 'finales'
SEMILLAS=[420000+i for i in range(60)]
for modo in ("L1","L2"):
    for filtrar_centro in ((False, True) if modo=="L1" else (False,)):
        F=[fin for fin in finales if not filtrar_centro or all(np.linalg.norm(p-np.array([1.5,1.5]))>=0.33 for p in fin)]
        cnt=collections.Counter(); tomas=collections.Counter(); nag=0; nt=0; bolsillo=0
        for s in SEMILLAS:
            P=np.array([1.5,1.5]) if modo=="L1" else punto(fase(s))
            b=sortear_blancos_demo(5,s,P)
            if min(np.linalg.norm(p-P) for p in b.values())<0.58: bolsillo+=1
            for fin in F:
                nt+=1; hay=collections.Counter()
                for i in range(5):
                    nag+=1
                    # solo cuenta si el obstaculo esta ENTRE el agente y su blanco
                    a, t = fin[i], b[i]
                    d=t-a; L=np.linalg.norm(d)
                    proy=float((P-a)@d)/L if L>0 else -1
                    if not (0.33 < proy < L): continue
                    e=segdist(P,a,t)
                    for thr in (0.06,0.10):
                        if e<thr: cnt[thr]+=1; hay[thr]=1
                for thr in (0.06,0.10): tomas[thr]+=hay[thr]
        tag=modo+(" (poses finales a >=0.33 del centro)" if filtrar_centro else "")
        print(tag, "conjuntos", len(F))
        print("  agentes casi frontales:", {k:round(v/nag,3) for k,v in cnt.items()},
              " colocaciones con >=1:", {k:round(v/nt,3) for k,v in tomas.items()})
        print("  semillas con un blanco a <0.58 m del obstaculo (bolsillo con D_o+D_robots):", f"{bolsillo}/{len(SEMILLAS)}")
