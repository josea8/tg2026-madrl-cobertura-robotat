import math, numpy as np
from cruces_obstaculo import blancos_demo, fase, punto, dist_seg
semillas = [420000 + k for k in range(20)]
ARCO = 0.05 * 45.0 / 0.6   # rad recorridos en una toma (crucero 0.05 m/s, ~45 s tras la rampa)
bloq = tot = 0; cerca = 0
for k in range(1, 20):
    sp, s = semillas[k-1], semillas[k]
    o_fin = punto(fase(sp) + ARCO)          # donde quedó el obstáculo
    o_new = punto(fase(s))
    b_prev = blancos_demo(5, sp, punto(fase(sp)))
    b = blancos_demo(5, s, o_new)
    for i in range(5):
        tot += 1
        bloq += np.linalg.norm(b[i] - o_fin) < 0.50
        cerca += dist_seg(o_fin, b_prev[i], b[i]) < 0.38
print(f"arco por toma {ARCO:.2f} rad; blancos a <0.50 m de donde QUEDÓ el obstáculo: {bloq}/{tot}; "
      f"traslados de agentes a <0.38 m de él: {cerca}/{tot}")
# per-take probability in L1 at least one agent crosses
from cruces_obstaculo import dist_seg as ds
import itertools
