ARCHIVO NUEVO replica_con_obstaculo.py (LF, en español, sin tocar nada existente) + test_replica_con_obstaculo.py. Rutas relativas a primerafase_webots/controllers/coordinador_enjambre/.

0. IMPORTABLE. Nada a nivel de módulo salvo constantes, clases y funciones: argparse y simulador sólo dentro de main(argv) y del guard __main__. Es condición para las pruebas (a1) y (b). Contraejemplo: replica_con_capas.py:73-86.

1. IMPORTS (qué viene de dónde)
- config_robotat as cfg; calibracion_sesion as calib (aplicar_a_config); coordinador_enjambre as ce (CBF_ACTIVO, ESCAPE_ACTIVO).
- demo_obstaculo_movil as demo: construir_con_obstaculo, CoordinadorConObstaculo, SupervisorObstaculo, crear_observador, correr_toma, TAU_PREDICCION_S.
- lanzar_robotat.leer_poses_estables.
- simulador_robotat: SimuladorRobotat, FallasSimulador.
- protocolo_robotat: lab_a_env, heading_desde_cuaternion (ida y vuelta).
- campana_obstaculo: Campana, ErrorCampana, inclusion_campana, ARCHIVOS_CONGELADOS, hashes_congelados.
- analizar_campana_l2 (main protegido en :1029): cargar_hw, leer_csv, _es_uno, COLUMNAS_REPLICA, SEGURIDAD, TAU_PRINCIPAL, TAU_SENSIBILIDAD, CONDICIONES_PLAN.

2. CONSTANTES
- ID_OBSTACULO = 4 (nunca el 7 por defecto: demo:170).
- PUERTO_POR_DEFECTO = 48830, con ruedas en puerto+260. Distinto de 18830/19090 (el ensayo en curso, demo --simulador) y de los rangos de las pruebas.
- ESTACIONAMIENTO_ENV = (-6.0, 1.5, 0.0), que es lab (-7.5, 0.0): fuera de ±5 m, así que la fuente lo rechaza (protocolo_robotat.py:321).
- ARCHIVOS_PILA = ARCHIVOS_CONGELADOS + ('simulador_robotat.py', 'replica_con_obstaculo.py', 'calibracion_medida.json').
- UMBRAL_CIERRE_B_M = 1e-3, UMBRAL_RUMBO_RAD = 1e-6, UMBRAL_MOVIMIENTO_M = 1e-4.
- EXTRAS = columnas informativas que el análisis ignora (PLAN §9:154): formato, error_pose_inicial_m, error_rumbo_inicial_rad, factor, rpm_aborto, tau_prediccion_s, duracion_s, ciclo_p95_ms, ciclos_sobre_100ms, frenos_sombra_detalle, cierre_b_n, cierre_b_n_mov, cierre_b_err_th_rad, cierre_b_mandos_iguales.

3. FUNCIONES PURAS (copias de replica_con_capas, con la misma aritmética; (a1) las compara por AST)
- imponer_identidad(): el bloque de replica_con_capas.py:120-125, llamado DESPUÉS de calib.aplicar_a_config().
- env_a_lab(x, y, th, id_robot): igual a :215-222.
- previas_por_suma(filas, clave_orden): la regla de :199-203. Suma 'decisiones' de las filas anteriores de la misma sesión y saltea las vacías.
- verificar_ida_y_vuelta(tomas): igual a :241-255, para los agentes y el 4 (traza[0]); assert < 1e-9.

4. CARGA. @dataclass TomaReplica con: formato; campana; fuente_tomas; id_sesion; intento; semilla; decisiones; decisiones_previas; factor; rpm_aborto; tau_prediccion_s; poses_iniciales {i: (x,y,th) env}; traza_obstaculo (lista ordenada por paso con paso, x, y, th, v_cmd, w_cmd, estado, error_radial; None en a3); avisos.
- cargar_campana(base, nombre, dir_hw): Campana(Campana.carpeta_de(base, nombre)). Si la plataforma es 'hw' y no está cerrada, NEGARSE (§8). hw = analizar_campana_l2.cargar_hw(campana, dir_hw, ensayo=(plataforma != 'hw')); eso da la selección, el cruce libro↔CSV y el régimen (analizar_campana_l2.py:253-349, 233-249). Se replican las k con _es_uno(resultados[k]['incluida']). De la fila del CSV de tomas: x0/y0/th0_a{i}, decisiones_previas (cruzada con previas_por_suma de las filas de la misma id_sesion), factor, rpm_aborto, tau_prediccion_s, semilla. La traza sale de glob('*_L2_obstaculo*.csv'), con id_sesion igual y toma == k. Nunca derivar el nombre con replace('_tomas', …): en 121157 los sellos difieren en 1 s. fuente_tomas = resultados[k]['archivo_tomas'].
- cargar_carpeta_vieja(carpeta) (07-10, sólo para probar la tubería): exactamente un *_L2_tomas*, un *_L2_decisiones* y un *_L2_obstaculo*. Incluidas = inclusion_campana(fila)[0] == 1. Previas = previas_por_suma, ordenando por toma. x0 de las filas paso == 0 y episodio == toma del CSV de decisiones. Robot del obstáculo de resumen_ensayo.json. rpm_aborto = 200 y τ_c = 0.65, con aviso explícito. campana, id_sesion y fuente_tomas sintéticos (nombre de la carpeta y prefijo del CSV).
- cargar_episodios_3009(csv) (sólo para a3): filas válidas, x0 de las columnas, previas = previas_por_suma por episodio, intento = episodio, traza = None.
- auditar(tomas), antes de levantar nada:
  - traza con pasos densos 0..decisiones-1 y sin vacíos en x, y, th, v_cmd, w_cmd;
  - decisiones iguales en todas;
  - con R = max(0, cfg.DECISIONES_ARRANQUE − previas), filas 0..R-1 en {espera, freno} y fila R distinta de 'espera';
  - robots == MAPEO_AGENTES;
  - informar |x0 − paso 0| y |obst_*_med − traza[0]| (en plataforma simulador, ≤ 1 mm obligatorio).

5. class _RobotsSinReproducido(dict): values() devuelve los estados de todos menos el excluido. La física (simulador_robotat.py:253) no lo integra; las poses y las ruedas, que acceden por clave (365, 435), sí lo ven.
class SimuladorReplay(SimuladorRobotat):
- __init__(*a, id_reproducido=4, **kw): super(); después self.robots = _RobotsSinReproducido(self.robots, 4); colocaciones = 0.
- teletransportar_env(poses_env): con self._lock, para cada robot dado: est.x, est.y, est.yaw = env_a_lab(...). Después, para TODOS (dict.values): rpm_izq = rpm_der = rpm_izq_ruedas = rpm_der_ruedas = 0 y en_camino.clear().
- fijar_pose_env(rid, x, y, th): lo mismo, sólo para el 4 (vacía su en_camino, que con τ > 0 crecería sin límite); colocaciones += 1.
- Nunca llamar a pose_de_robot con el cerrojo tomado.

6. class SupervisorReplay(demo.SupervisorObstaculo)
- __init__(fuente, canal, colocar): fijar self._colocar y self._traza_hw = [] ANTES de super().__init__(fuente, canal, modo='movil', freno_activo=False, vigilar_congelamiento=False), porque la base llama a reiniciar_toma en :983.
- cargar_traza(filas): valida y guarda.
- reiniciar_toma(): super(); si hay traza, self._colocar(*traza[0][x, y, th]).
- _verificar_obediencia(): devuelve None.
- paso(poses_agentes, en_retroceso, factor_arranque, ahora, paso), sobrescrito ENTERO, sin super().paso, que mandaría la ley del círculo (:1142, 1158):
  1. self._ahora_paso = ahora; pose = self._fuente.pose_obstaculo();
  2. si ya abortó: (0,0) como en :1073-1076;
  3. motivo = self._chequear(pose) (sin pose, vencida > 0.15 s, enlace, fuera de la arena: las reglas del hw). Si no hay motivo pero falta la fila paso en la traza: 'RÉPLICA: traza sin la decisión k';
  4. con motivo: _abortar, mando (0,0), _anotar y return (como :1080-1086);
  5. freno en SOMBRA: copia literal de :1095-1115 con freno_activo=False;
  6. f = traza[paso]; self.estado = f['estado']; contar patada/marcha según el rótulo;
  7. mando = self._mandar(f['v_cmd'], f['w_cmd']); así pasa por canal.enviar_obstaculo y el historial y la v_cmd de la barrera (demo:1619-1632) quedan los del hw;
  8. self._anotar(paso, ahora, pose, mando, f['error_radial'], poses_agentes);
  9. si existe traza[paso+1], self._colocar(x, y, th de esa fila);
  10. return mando.

7. evaluar_cierre_b(traza_rep, traza_hw) -> dict (función pura)
- n = filas de la réplica. Si n == 0: ok=0, err='inf', desfase='nan'.
- e_k = hypot de (x, y) réplica − hw en el mismo paso; inf si falta la pose. err_max = max e_k. err_th = max |envolver(th_rep − th_hw)|.
- Mandos iguales (==) en las filas cuyo estado no es 'abortado'.
- M = pasos donde el 4 del hw se movió más de 1e-4 m respecto del paso vecino. Para L en {−1, 0, +1}: E(L) = media sobre k en M de ‖rep_k − hw_{k+L}‖. desfase = argmin; empate o M vacío → 0.
- ok = int(err_max ≤ 1e-3 y desfase == 0 y err_th ≤ 1e-6 y mandos iguales y pasos de la réplica == 0..n-1).
- Devuelve también n y n_mov.

8. armar_pila(puerto, poses_iniciales_lab) -> (sim, fuente, canal, entorno, coord, supervisor, registro, estado)
- Probar connect a 127.0.0.1:puerto y a base+ids: si alguien responde, abortar (SO_REUSEADDR en simulador_robotat.py:279 y 392 no avisa del choque).
- sim = SimuladorReplay({agentes: marcadores, 4: 4}, poses, FallasSimulador(), puerto_poses=…, puerto_base=…); sim.iniciar().
- fuente, canal, entorno = demo.construir_con_obstaculo(5, True, 4, 4).
- supervisor = SupervisorReplay(fuente, canal, lambda x, y, th: sim.fijar_pose_env(4, x, y, th)).
- coord = demo.CoordinadorConObstaculo(fuente, canal, entorno, 5, 10, supervisor=None, formulacion='F2', tau_prediccion_s=TAU_PREDICCION_S).
- registro = []; estado = {'episodio': 0}; coord._observador_paso = demo.crear_observador(coord, canal, registro, estado).
- assert de los invariantes (intervalo 10, consulta en 'lote').
- Separar fabricar_coordinador(fuente, canal, entorno), que acepta adaptadores inyectados, para la prueba (a1).

9. correr_una(pila, toma, condicion, tau, rep, pasada) -> (fila_contrato, filas_decisiones, filas_traza)
- inicio = datetime.now().isoformat(timespec='seconds').
- sim.fallas.retardo_actuacion_s = tau.
- canal.detener_todo(silencioso=True); sleep 0.2; sim.teletransportar_env(agentes x0 + el 4: traza[0] si es con obstáculo, ESTACIONAMIENTO_ENV si es sin); sleep 0.2.
- fuente.reiniciar(); medidas = leer_poses_estables(fuente, 5); calcular el error xy y θ contra x0. Si pasa 1 mm o 1e-6 rad, se detiene el proceso.
- canal.historial_mandos_obstaculo.clear(); canal.ultimo_mando_obstaculo = (0.0, 0.0).
- canal.decisiones_enviadas = previas; canal.factor_operativo = factor; coord.tau_prediccion_s = τ_c.
- coord.supervisor = supervisor si es con obstáculo (antes, supervisor.cargar_traza(toma.traza_obstaculo)); None si es sin.
- estado['episodio'] = intento.
- try: res = demo.correr_toma(coord, canal, fuente, entorno, semilla, decisiones, registro, rpm_aborto, lazo='evaluacion'). except RuntimeError: canal.detener_todo(); res = {'valido': 0, 'motivo': 'RÉPLICA: …'}.
- traza_rep = list(supervisor.traza) si es con obstáculo; cierre = evaluar_cierre_b(traza_rep, toma.traza_obstaculo).
- Fila del contrato, en el orden de COLUMNAS_REPLICA:
  - campana, fuente_tomas, id_sesion, intento_campana, semilla: de la toma;
  - condicion, tau_s (TAU_PRINCIPAL o TAU_SENSIBILIDAD), rep, pasada, inicio, sha256_pila;
  - decisiones_previas = la del hw;
  - valido = int(res['valido']), nunca valido_demo; motivo;
  - decisiones = res.get('decisiones', 0); cobertura_aoi = res.get(…, '');
  - d_min_obst_medida = res[...] con obstáculo, '' sin;
  - SEGURIDAD = res.get(c, '');
  - frenos_sombra = res['frenos'] con obstáculo, '' sin;
  - cierre_b_ok, cierre_b_err_max_m, cierre_b_desfase con obstáculo (también en las inválidas), '' sin;
  - después, EXTRAS.
- Las filas de decisiones son registro[:] más la clave (intento_campana, condicion, tau_s, rep, pasada, inicio). En sin_obstaculo, d_obst_medida sale '' por el estacionamiento. Después, registro.clear().

10. ESCRITURA Y --reanudar
- Por lanzamiento, en --salida, archivos NUEVOS: <AAAAmmdd_HHMMSS>_replica_tomas.csv, _replica_decisiones.csv y _replica_obstaculo.csv (traza de la réplica con la clave, para que verificar recalcule (b) desde el crudo), más _replica_pila.json (huella por archivo).
- Agregado fila a fila con csv.DictWriter: columnas fijas desde la cabecera, lineterminator '\\n', floats con repr como demo.escribir_csv (demo:2192-2200), flush y os.fsync.
- Orden por corrida: decisiones, traza y al final la fila de tomas (que confirma la corrida).
- sha256_pila = sha256 del json.dumps(hashes_congelados(ARCHIVOS_PILA), sort_keys=True). Si falta algún archivo, negarse. Se recalcula después de cada corrida y el proceso se detiene si cambió.
- --reanudar: claves hechas (intento, condicion, τ, rep) de TODOS los *_replica_tomas.csv de la carpeta. Si alguno no termina en '\\n', negarse con un mensaje. Sin --reanudar y con claves presentes, negarse.
- Salidas: para la campaña, base/replica_campana/<nombre>/, el default del analizador (analizar_campana_l2.py:959). Para las pruebas y a3, una carpeta propia: nunca ensayo_campana_20261008_200039/replica_campana/ensayo/, donde la FALSA vieja detiene el análisis con código 3.

11. ORDEN Y ALCANCE
- Normal: for rep in 1..3: for toma en las incluidas: for (cond, τ) in [(con, 0.0), (sin, 0.0), (con, 0.45)]. Las condiciones de una toma quedan juntas en el tiempo; es posible porque el teletransporte vacía las colas.
- --suplementaria: sólo los grupos con 0 válidas en la normal, rep desde 4 y pasada='suplementaria'.
- a3: --episodios-3009 CSV, que fuerza (sin, 0.0) × 3 repeticiones, en una carpeta aparte.
- --verificar: secciones 4 y 3, sin simulador.
- finally: canal.cerrar(); fuente.cerrar(); sim.detener(); atexit.unregister(coord._detener_seguro).
- Lanzar desacoplado (Start-Process), en serie y nunca con hardware ni con otro simulador corriendo.

12. PRUEBAS (test_replica_con_obstaculo.py)
- (a1-AST): extraer de replica_con_capas.py env_a_lab, decisiones_previas y las 6 asignaciones de :120-125, y los argumentos de ses._correr_episodio de :343-345. Comparar, bit a bit sobre entradas aleatorias y sobre el CSV de episodios del 30-09, con env_a_lab, previas_por_suma e imponer_identidad del archivo nuevo. Con un espía sobre ses._correr_episodio, demo.correr_toma tiene que pasarle los mismos 11 argumentos posicionales y diag=None.
- (a1-decisión, sin red ni tiempo real): pila A = ce.CoordinadorEnjambre sobre FuentePosesRobotat, CanalActuacionRobotat y un EntornoEjecucionRobotat cuyo avanzar sólo incrementa _k. Pila B = fabricar_coordinador sobre FuentePosesConObstaculo y CanalConObstaculo, con el 4 estacionado.
  - En las dos: sin conectar(); _un_viaje por instancia devuelve la matriz de la decisión k (poses pose_env de un episodio del 30-09 pasadas a lab con env_a_lab y el cuaternión); _enviar_crudo registra; agentes_vencidos devuelve [].
  - Comparar con np.array_equal, por decisión y agente: observacion, accion_nominal, accion_ejecutada, en_escape, cbf_intervino y las rpm enviadas.
  - En B, espías: 0 llamadas a demo.predecir_pose y a SupervisorObstaculo.paso; filas_obstaculo siempre vacío.
- (b-pura): trazas corridas en L dan L; trazas iguales dan error ~0 y desfase 0; un 4 quieto da desfase 0 con n_mov 0; una fila 'abortado' no rompe los mandos iguales.
- (b-tubería, en tiempo real, sólo con la máquina libre): la toma 1 de 200039, con obstáculo y τ=0, da ok=1 y error ~1e-16. Control negativo: una subclase que coloca hw[k] en paso(k) da desfase −1 y unos 5 mm. sim.pose_de_robot(4) no cambia entre colocaciones aunque comandos_recibidos suba 1 por decisión. La toma 6 de 121157 reproduce v_cmd = 0 en los pasos 327-393.

FUERA DE ALCANCE: a2, MonitorVerdad, reproducir retrocesos o filas rechazadas del 4, tocar demo, analizar o replica_con_capas.

DECISIONES ABIERTAS PARA JOSÉ:
- el número de la regla de a3 y si son 12 o 50 episodios;
- si cierre_b_ok incluye el rumbo y los mandos (propuesto que sí);
- la convención de una corrida con 0 decisiones (propuesto ok=0, err='inf', desfase='nan');
- cuántas repeticiones lleva la pasada suplementaria (propuesto: 3, desde la 4);
- el puerto (propuesto 48830).