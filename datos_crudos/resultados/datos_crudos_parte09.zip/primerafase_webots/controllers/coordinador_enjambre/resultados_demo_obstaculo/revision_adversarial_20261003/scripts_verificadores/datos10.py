import json, os, glob
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
for carp in ["fase0_20261002_165649","fase0_conf2_20261002_195453"]:
  for d in sorted(glob.glob(os.path.join(R,carp,"*"))):
    n=os.path.basename(d)
    if ("E6_" in n or "C4_" in n or "C6_" in n) and os.path.isfile(os.path.join(d,"resultado.json")):
        r=json.load(open(os.path.join(d,"resultado.json"),encoding="utf-8"))
        print(carp[:10], n[:70], "disparo:", repr(r.get("disparos_guion")), "dmin", round(r["verdad_d_min_obst"],4), "ang", round(r["verdad_angulo_min_deg"],1), "ag", r["verdad_agente_min"])
