# Modelo 1D de cabeza: dos robots que se acercan en linea recta, cada uno con
# su barrera c*u >= -alfa*share*max(h,0) (h recortado a >=0 como FiltroColocacion),
# h = d - D sobre la distancia entre los puntos de mira. Comando a 10 Hz,
# retardo de actuacion PURO tau. Nominal: avanzar a V_COL hacia el otro.
import math
V_COL=0.08; ALFA=2.0; HZ=10.0; DT=1.0/HZ
def correr(share, tau, ambos_mueven=True, d0=1.0, D=0.25, sub=100):
    d=d0
    cola=[]  # (t_envio, u1, u2)
    t=0.0; hmin=1e9
    dt=DT/sub
    k=0
    while t<20.0:
        if k%sub==0:
            h=d-D
            lim=ALFA*share*max(h,0.0)
            u1=min(V_COL,lim)
            u2=min(V_COL,lim) if ambos_mueven else 0.0
            cola.append((t,u1,u2))
        # mando vigente = el ultimo enviado con t_envio+tau<=t
        e1=e2=0.0
        for te,a,b in cola:
            if te+tau<=t: e1,e2=a,b
            else: break
        d-= (e1+e2)*dt
        hmin=min(hmin,d-D)
        t+=dt; k+=1
    return hmin
for tau in (0.0,0.45,0.65,0.85):
    print(f"tau={tau:.2f}  ambos 50/50: hmin={correr(0.5,tau):+.3f}  "
          f"ambos completa: hmin={correr(1.0,tau):+.3f}  "
          f"uno solo completa (otro quieto): hmin={correr(1.0,tau,False):+.3f}  "
          f"uno solo 50/50: hmin={correr(0.5,tau,False):+.3f}")
