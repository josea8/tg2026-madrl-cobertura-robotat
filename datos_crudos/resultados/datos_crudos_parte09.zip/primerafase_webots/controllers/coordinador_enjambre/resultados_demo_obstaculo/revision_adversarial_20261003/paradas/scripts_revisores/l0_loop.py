import ast, io
D = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
def fn(path, name):
    t = ast.parse(io.open(path, encoding="utf-8").read())
    return next(n for n in t.body if isinstance(n, ast.FunctionDef) and n.name == name)
class Norm(ast.NodeTransformer):
    # resultado = X ; return resultado  ->  return X
    def generic_visit(self, node):
        super().generic_visit(node)
        for field in ("body", "orelse", "finalbody"):
            b = getattr(node, field, None)
            if isinstance(b, list):
                out = []
                i = 0
                while i < len(b):
                    s = b[i]
                    if (i + 1 < len(b) and isinstance(s, ast.Assign) and len(s.targets) == 1
                        and isinstance(s.targets[0], ast.Name) and s.targets[0].id == "resultado"
                        and isinstance(b[i+1], ast.Return) and isinstance(b[i+1].value, ast.Name)
                        and b[i+1].value.id == "resultado"):
                        out.append(ast.Return(value=s.value)); i += 2; continue
                    out.append(s); i += 1
                setattr(node, field, out)
        return node
def loops(f):
    f = Norm().visit(f)
    res = {}
    for n in ast.walk(f):
        if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == "k":
            res["for_k"] = ast.dump(n)
        if isinstance(n, ast.FunctionDef) and n.name == "pose_env":
            res["pose_env"] = ast.dump(n)
        if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id != "k":
            res.setdefault("otros_for", []).append(ast.dump(n))
        if isinstance(n, ast.While):
            res.setdefault("while", []).append(ast.dump(n))
    return res
a = loops(fn(D + r"\demo_obstaculo_movil_respaldo_20261003_preParadas.py", "sesion_l0"))
b = loops(fn(D + r"\demo_obstaculo_movil.py", "sesion_l0"))
for k in sorted(set(a) | set(b)):
    print(k, "IDENTICO" if a.get(k) == b.get(k) else "DISTINTO")
# also the signature/defaults
fa = fn(D + r"\demo_obstaculo_movil_respaldo_20261003_preParadas.py", "sesion_l0")
fb = fn(D + r"\demo_obstaculo_movil.py", "sesion_l0")
print("args idénticos:", ast.dump(fa.args) == ast.dump(fb.args))
fa = fn(D + r"\demo_obstaculo_movil_respaldo_20261003_preParadas.py", "sesion_demo")
fb = fn(D + r"\demo_obstaculo_movil.py", "sesion_demo")
print("sesion_demo args (respaldo):", [x.arg for x in fa.args.args])
print("sesion_demo args (actual):  ", [x.arg for x in fb.args.args])
