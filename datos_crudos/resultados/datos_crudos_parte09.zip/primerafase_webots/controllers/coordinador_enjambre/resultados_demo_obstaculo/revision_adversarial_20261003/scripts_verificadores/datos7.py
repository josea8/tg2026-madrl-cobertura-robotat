import json, collections
p=r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo\exploracion_fase0\revision_adversarial_resultado.json"
d=json.load(open(p,encoding="utf-8"))
def walk(o, depth=0, path=""):
    if depth>2: return
    if isinstance(o, dict):
        for k,v in o.items():
            t=type(v).__name__
            ln=len(v) if hasattr(v,'__len__') else ''
            print("  "*depth+f"{path}.{k}: {t} {ln}")
            walk(v, depth+1, path+"."+k)
    elif isinstance(o, list) and o:
        print("  "*depth+f"{path}[0]: {type(o[0]).__name__}")
        walk(o[0], depth+1, path+"[0]")
walk(d)
