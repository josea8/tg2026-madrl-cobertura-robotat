import csv, glob, os
R=r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo\ensayo_l2_20261002_201318"
f=glob.glob(os.path.join(R,"*_L2_tomas.csv"))[0]
rows=list(csv.DictReader(open(f,encoding="utf-8")))
print(len(rows))
for r in rows:
    print(r["toma"], "valido",r["valido"], "demo",r.get("valido_demo"), "frenos",r.get("frenos"), "obst_freno_activo", r.get("obst_freno_activo"), "lazo", r.get("lazo"), "form", r.get("formulacion"), "dec", r.get("decisiones"), "dmin", r.get("d_min_obst_medida","")[:6], "rec %s/%s"%(r.get("obst_recorrido_m","")[:5], r.get("obst_recorrido_comandado_m","")[:5]), "motivo:", r.get("motivo","")[:80], "| demo:", r.get("motivo_demo",""), "sem", r.get("semilla"))
print(open(glob.glob(os.path.join(R,"*_resumen.txt"))[0],encoding="utf-8").read()[:2500])
