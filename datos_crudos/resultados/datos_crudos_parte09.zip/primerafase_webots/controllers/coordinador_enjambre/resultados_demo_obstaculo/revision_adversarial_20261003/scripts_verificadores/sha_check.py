import hashlib, os, re
base = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots"
cc = os.path.join(base, "controllers", "coordinador_enjambre")
res = os.path.join(cc, "resultados_demo_obstaculo")
def sha(p):
    return hashlib.sha256(open(p,"rb").read()).hexdigest()
for man in ["sha256_codigo_congelado_20261002.txt","sha256_codigo_conf2_20261002.txt"]:
    print("==", man)
    for line in open(os.path.join(res, man), encoding="utf-8"):
        if line.startswith("#") or not line.strip(): continue
        h, rest = line.split(None, 1)
        f = rest.strip().split(" ")[0]
        p = os.path.join(cc, f)
        print(f, "OK" if os.path.exists(p) and sha(p)==h else "DIFFERS", )
print("== manifiesto pre 20261001")
changed=[]; missing=[]; n=0
for line in open(os.path.join(res,"manifiesto_sha256_pre_20261001.txt"), encoding="utf-8"):
    if not line.strip() or line.startswith("#"): continue
    h, rel = line.split(None,1); rel=rel.strip()
    p = os.path.join(base, rel)
    n+=1
    if not os.path.exists(p): missing.append(rel)
    elif sha(p)!=h: changed.append(rel)
print("entries",n,"changed",changed,"missing",missing)
