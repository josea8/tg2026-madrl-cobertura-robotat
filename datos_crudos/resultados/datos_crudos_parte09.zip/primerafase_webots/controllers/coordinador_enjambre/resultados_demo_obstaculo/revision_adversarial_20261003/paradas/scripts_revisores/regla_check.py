import sys, math
sys.path.insert(0, r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre")
import numpy as np
import demo_obstaculo_movil as d
R = d.regla_de_parada
base = {"valido": 1, "frenos": 0, "d_min_obst_medida": 0.30, "motivo": "", "obst_motivo_aborto": ""}
def t(**kw):
    x = dict(base); x.update(kw); return x
casos = {
 "np.float64 0.149": t(d_min_obst_medida=np.float64(0.149)),
 "str '0.149'": t(d_min_obst_medida="0.149"),
 "str ' 0.149 '": t(d_min_obst_medida=" 0.149 "),
 "None": t(d_min_obst_medida=None),
 "nan": t(d_min_obst_medida=float("nan")),
 "'nan'": t(d_min_obst_medida="nan"),
 "-0.0": t(d_min_obst_medida=-0.0),
 "0.0": t(d_min_obst_medida=0.0),
 "missing key": {k: v for k, v in base.items() if k != "d_min_obst_medida"},
 "motivo OBSTÁCULO sin espacio": t(valido=0, motivo="OBSTÁCULO:x"),
 "motivo obstáculo minúscula": t(valido=0, motivo="obstáculo: x"),
 "obst_motivo_aborto None": t(obst_motivo_aborto=None),
 "motivo None": t(motivo=None),
}
for k, v in casos.items():
    try:
        print(f"{k:32s} -> {R(v, [])!r}")
    except Exception as e:
        print(f"{k:32s} -> EXC {type(e).__name__}: {e}")
# frenos odd values
for fv in [1, "1", 1.0, "1.0", None, "", True, np.int64(2)]:
    try:
        print("frenos", repr(fv), "->", R(t(frenos=fv), [t(frenos=1)]))
    except Exception as e:
        print("frenos", repr(fv), "-> EXC", type(e).__name__, e)
# parsing
for r in ["S", " s ", "sí", "si", "SÍ", "Sí", "", "n", "seguir", "s\r", "si\u0301", "yes", "S\n", None]:
    print(repr(r), str(r).strip().lower() in ("s", "si", "sí"))
