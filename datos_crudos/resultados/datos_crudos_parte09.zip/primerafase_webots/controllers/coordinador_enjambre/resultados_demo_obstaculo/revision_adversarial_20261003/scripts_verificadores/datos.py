import csv, json, os, glob, math
base = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
for run in ("fase0_conf2_20261002_195453", "fase0_20261002_165649"):
    dirs = sorted(d for d in glob.glob(os.path.join(base, run, "*")) if os.path.isdir(d))
    tot = vac = 0; vac_runs = {}; first_only = 0; sin_est = {}; nan_txt = 0; vac_pos = {}
    hdr = None
    for d in dirs:
        p = os.path.join(d, "obstaculo.csv")
        if not os.path.exists(p): continue
        with open(p, newline="", encoding="utf-8") as fh:
            r = list(csv.DictReader(fh))
        if hdr is None and r: hdr = list(r[0].keys())
        if not r or "v_hat_x" not in r[0]: continue
        for i, f in enumerate(r):
            tot += 1
            if f["v_hat_x"] == "":
                vac += 1; vac_runs[os.path.basename(d)] = vac_runs.get(os.path.basename(d), 0) + 1
                vac_pos.setdefault(os.path.basename(d), []).append(i)
            if f["v_hat_x"].lower() in ("nan", "inf", "-inf"): nan_txt += 1
        rj = os.path.join(d, "resultado.json")
        if os.path.exists(rj):
            j = json.load(open(rj, encoding="utf-8"))
            k = j.get("obst_decisiones_sin_estimacion_v")
            sin_est[k] = sin_est.get(k, 0) + 1
    print(run, "carpetas", len(dirs), "filas obst", tot, "v_hat vacías", vac, "en", len(vac_runs), "corridas; textos nan", nan_txt)
    print("  obst_decisiones_sin_estimacion_v:", sin_est)
    pos = {}
    for k, v in vac_pos.items():
        key = tuple(v[:5]); pos[key] = pos.get(key, 0) + 1
    print("  posiciones (índice de fila) de las vacías, primeras 5 por corrida -> nº corridas:", dict(list(pos.items())[:10]))
    print("  header:", hdr)
