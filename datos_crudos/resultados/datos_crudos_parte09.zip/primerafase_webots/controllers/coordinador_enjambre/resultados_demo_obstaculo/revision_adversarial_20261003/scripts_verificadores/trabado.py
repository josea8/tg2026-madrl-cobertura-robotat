import io, contextlib
import numpy as np
exec(open("fuzz2.py", encoding="utf-8").read().split("rng = random.Random(7)")[0])
def corre(vseq, dt=0.1):
    so, sn = S(True), S()
    for s in (so, sn): s._clase_mando = "marcha"; s._t_cambio_mando = 0.0
    out = {}
    for k, v in enumerate(vseq, start=1):
        t = round(k * dt, 10)
        for nom, s, f in (("old", so, ns["old"]["_verificar_obediencia"]), ("new", sn, ns["new"]["_verificar_obediencia"])):
            if nom in out: continue
            s._fuente.v = v
            with contextlib.redirect_stdout(io.StringIO()):
                m = f(s, t)
            if m: out[nom] = (round(t, 2), m)
    return out
print("trabado (v=0 siempre):", corre([np.zeros(2)] * 40))
print("arranque lento (v=0 hasta 1.7 s):", corre([np.zeros(2)] * 17 + [np.array([0.05, 0.0])] * 23))
print("hipo como el 02-10 (None en 1.6 s, resto en marcha):", corre([np.array([0.05,0.0])]*15 + [None] + [np.array([0.05,0.0])]*20))
print("lazo lento 2.5 Hz trabado:", corre([np.zeros(2)] * 20, dt=0.4))
