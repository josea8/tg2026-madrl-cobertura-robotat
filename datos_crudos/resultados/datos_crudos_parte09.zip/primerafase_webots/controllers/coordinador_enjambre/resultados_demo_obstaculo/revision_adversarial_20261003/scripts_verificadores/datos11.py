import json, os, glob
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
def specs(carp):
    out={}
    for d in glob.glob(os.path.join(R,carp,"*")):
        p=os.path.join(d,"spec.json")
        if os.path.isfile(p) and "interrumpida" not in d:
            s=json.load(open(p,encoding="utf-8"))
            if s["bloque"] in ("conf_guionada","conf_tomas"):
                out[(s["nombre"],s["tau"])]=s
    return out
a=specs("fase0_20261002_165649"); b=specs("fase0_conf2_20261002_195453")
print(len(a),len(b), "same keys", set(a)==set(b))
diff=[k for k in a if a[k]!=b.get(k)]
print("specs differ:", len(diff), diff[:3])
