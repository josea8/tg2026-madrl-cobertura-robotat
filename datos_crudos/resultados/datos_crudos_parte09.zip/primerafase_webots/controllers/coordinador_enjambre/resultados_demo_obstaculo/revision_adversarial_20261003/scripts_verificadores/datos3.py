import csv, os, sys
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
carp = sys.argv[1]; a0=int(sys.argv[2]); a1=int(sys.argv[3]); AG=sys.argv[4] if len(sys.argv)>4 else "0"
rows=list(csv.DictReader(open(os.path.join(R,carp,"decisiones.csv"),encoding="utf-8")))
print(rows[0].keys())
for r in rows:
    p=int(r["paso"])
    if r["agente"]==AG and a0<=p<=a1:
        print(p, "esc",r["en_escape"],"cbf",r["cbf_intervino"], "v_nom %.3f w_nom %.2f v_ej %.3f w_ej %.2f"%(float(r["v_nominal"]),float(r["w_nominal"]),float(r["v_ejecutada"]),float(r["w_ejecutada"])), "d_obst",r["d_obst_medida"][:6],"hgeom",r["h_obst_geom"][:6],"heq",r["h_obst_eq"][:6],"hpred",r["h_obst_pred"][:6],"th %.2f"%float(r["pose_env_th"]), "x %.3f y %.3f"%(float(r["pose_env_x"]),float(r["pose_env_y"])))
