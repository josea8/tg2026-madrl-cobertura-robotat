import csv, math, statistics
from collections import defaultdict
D = r"C:/Users/velas/OneDrive/Documents/tesis/primerafase_webots/controllers/coordinador_enjambre/resultados_demo_obstaculo/ensayo_l2_20261002_201318/"
T = D + "20261002_202234_L2_tomas.csv"
O = D + "20261002_202234_L2_obstaculo.csv"
DEC = D + "20261002_202233_L2_decisiones.csv"
raw = open(T,'rb').read()
print("tomas CRLF", raw.count(b'\r\n'), "LF", raw.count(b'\n'))
tomas = list(csv.DictReader(open(T, newline='', encoding='utf-8')))
print("n filas", len(tomas))
def f(x):
    try: return float(x)
    except: return float('nan')
def validez(res):
    if not int(f(res.get('valido',0)) or 0): return 0, 'toma no válida'
    if int(f(res.get('frenos',0)) or 0): return 0, 'freno'
    d = res.get('d_min_obst_medida','')
    if d != '' and float(d) < 0.15: return 0, 'contacto'
    if res.get('obst_modo') == 'movil':
        med = f(res.get('obst_recorrido_m',0) or 0); com = f(res.get('obst_recorrido_comandado_m',0) or 0)
        if com >= 0.20 and med < 0.5*com: return 0, 'recorrido'
    return 1, ''
for t in tomas:
    dm = [f(t[f'd_min_obst_a{i}']) for i in range(5)]
    v, m = validez(t)
    print(t['toma'], 'val', t['valido'], 'demo', t['valido_demo'], 'recalc', v, m, '| motivo', repr(t['motivo']), '| motivo_demo', repr(t['motivo_demo']),
          '| dec', t['decisiones'], 'dur', round(f(t['duracion_s']),2), 'Hz', round(f(t['decisiones'])/f(t['duracion_s']),3),
          '| dmin', t['d_min_obst_medida'], 'min_a', min(dm)==f(t['d_min_obst_medida']),
          '| frenos', t['frenos'], 'dec_freno', t['decisiones_freno'], 'freno_activo', t['obst_freno_activo'], 'modo', t['obst_modo'],
          '| rec', round(f(t['obst_recorrido_m']),3), '/', round(f(t['obst_recorrido_comandado_m']),3), 'ratio', round(f(t['obst_recorrido_m'])/f(t['obst_recorrido_comandado_m']),3),
          '| patada', t['decisiones_patada'], 'marcha', t['decisiones_marcha'], 'sinEst', t['obst_decisiones_sin_estimacion_v'], 'aborto_obst', repr(t['obst_motivo_aborto']),
          '| ciclos>100', t['ciclos_sobre_100ms'], 'p95', round(f(t['ciclo_p95_ms']),1), 'semilla', t['semilla'])
val = [t for t in tomas if int(f(t['valido']))==1]
demo = [t for t in val if int(f(t['valido_demo']))==1]
ds = sorted(f(t['d_min_obst_medida']) for t in val)
print('validas', len(val), 'demo', len(demo), 'intentos', len(tomas))
print('sorted d', [round(x,4) for x in ds])
print('min', ds[0], 'upper-median idx', ds[len(ds)//2], 'statistics.median', statistics.median(ds), 'max', ds[-1])
print('sum duracion', sum(f(t['duracion_s']) for t in tomas))
# obstacle trace
obs = list(csv.DictReader(open(O, newline='', encoding='utf-8')))
print('obst cols', list(obs[0].keys()))
por = defaultdict(list)
for r in obs: por[r['toma']].append(r)
for k, rs in por.items():
    est = defaultdict(int)
    for r in rs: est[r['estado']] += 1
    dmins = [f(r['d_min_agente_medida']) for r in rs if r['d_min_agente_medida']!='']
    nfreno = sum(int(r['en_freno']) for r in rs)
    ts = [f(r['t']) for r in rs]
    dts = [b-a for a,b in zip(ts, ts[1:])]
    # recompute recorrido medido and comandado
    med=0; prev=None; com=0
    for r in rs:
        if r['x']!='' and r['y']!='':
            p=(float(r['x']),float(r['y']))
            if prev: med+=math.hypot(p[0]-prev[0],p[1]-prev[1])
            prev=p
        if r['v_cmd']!='': com+=abs(float(r['v_cmd']))*0.1
    first_move = next((int(r['paso']) for r in rs if r['estado'] in ('patada','marcha')), None)
    print('toma', k, 'n', len(rs), dict(est), 'min d_agente_medida(pre)', round(min(dmins),4) if dmins else None, 'en_freno', nfreno,
          'dt med', round(statistics.median(dts),4), 'dt max', round(max(dts),4), 'rec', round(med,3), round(com,3), 'primer paso movil', first_move,
          'paso range', rs[0]['paso'], rs[-1]['paso'])
# decisions csv min d_obst_medida per episodio
mind = defaultdict(lambda: float('inf')); cnt = defaultdict(int)
with open(DEC, newline='', encoding='utf-8') as fh:
    rd = csv.DictReader(fh)
    for r in rd:
        cnt[r['episodio']] += 1
        if r['d_obst_medida'] != '':
            mind[r['episodio']] = min(mind[r['episodio']], float(r['d_obst_medida']))
for k in sorted(mind, key=int):
    print('dec episodio', k, 'filas', cnt[k], 'min d_obst_medida', round(mind[k],5))
