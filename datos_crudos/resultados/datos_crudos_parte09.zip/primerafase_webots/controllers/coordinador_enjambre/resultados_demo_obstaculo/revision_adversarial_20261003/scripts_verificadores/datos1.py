import json, os, glob, collections
R = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre\resultados_demo_obstaculo"
def cargar(carp):
    out=[]
    for d in sorted(glob.glob(os.path.join(R,carp,"*"))):
        p=os.path.join(d,"resultado.json")
        if os.path.isfile(p):
            r=json.load(open(p,encoding="utf-8")); r["_c"]=os.path.basename(d); out.append(r)
    return out
for carp in ["fase0_conf2_20261002_195453","fase0_20261002_165649"]:
    rs=cargar(carp)
    print("=====",carp,len(rs))
    print("obst_freno_activo values:", collections.Counter(r.get("obst_freno_activo") for r in rs))
    print("freno spec:", collections.Counter(r.get("freno") for r in rs))
    print("lazo:", collections.Counter((r.get("bloque"),r.get("lazo")) for r in rs))
    # brake events
    for r in rs:
        if r.get("frenos"):
            print("  FRENO", r["bloque"], r["nombre"], r["tau"], r.get("frenos_detalle"))
    # consultas por decision
    q=[(r.get("consultas_fuente",0), r.get("decisiones",0), r.get("peticiones_pose_sim",0)) for r in rs]
    ratios=[a/b for a,b,c in q if b]
    print("consultas/decision min,max", min(ratios), max(ratios))
    ratios2=[c/a for a,b,c in q if a]
    print("peticiones_sim/consultas min,max", min(ratios2), max(ratios2))
    # worst per block
    por=collections.defaultdict(list)
    for r in rs:
        key=(r["bloque"], r["tau"], r.get("tau_obstaculo",""), r.get("sin_rampa"))
        por[key].append((r.get("verdad_d_min_obst"), r["nombre"]))
    for k in sorted(por, key=str):
        v=sorted(por[k], key=lambda x: x[0])
        bajo=sum(1 for d,_ in v if d<0.15)
        print("  ",k, "n=",len(v),"min",round(v[0][0],4), v[0][1], "| 2nd", round(v[1][0],4) if len(v)>1 else "", v[1][1] if len(v)>1 else "", "bajo015",bajo)
