"""Chequeo puro 1D: dos robots que se acercan de frente bajo la barrera de
colocación (alfa = 2, h recortado a >= 0, caja v <= V_COL = 0.08), con
retardo de actuación puro tau y decisión a 10 Hz. Compara el reparto de
responsabilidad: 50/50 (colocar_enjambre), los DOS con responsabilidad
completa (lo que propone el plan para L2) y obstáculo quieto + agente con
responsabilidad completa. Devuelve el h mínimo (m) del par."""
import numpy as np

ALFA = 2.0
V = 0.08
DT = 0.001
PERIODO = 0.1


def correr(tau, pesos, h0=0.40, t_fin=12.0):
    """pesos: fracción de h que usa cada robot (0 = quieto)."""
    n = len(pesos)
    h = h0
    en_vuelo = [[(-1.0, V if w > 0 else 0.0)] for w in pesos]  # (t_aplica, v)
    v_ruedas = [V if w > 0 else 0.0 for w in pesos]
    t = 0.0
    prox = 0.0
    h_min = h
    while t < t_fin:
        if t >= prox - 1e-12:
            for i, w in enumerate(pesos):
                if w <= 0:
                    continue
                lim = ALFA * w * max(h, 0.0)       # c·u >= -alfa·(w·h)
                cmd = min(V, lim)
                en_vuelo[i].append((t + tau, cmd))
            prox += PERIODO
        for i in range(n):
            while en_vuelo[i] and en_vuelo[i][0][0] <= t:
                v_ruedas[i] = en_vuelo[i].pop(0)[1]
        h -= sum(v_ruedas) * DT
        h_min = min(h_min, h)
        t += DT
    return h_min


for tau in (0.0, 0.45, 0.65, 0.85):
    a = correr(tau, [0.5, 0.5])
    b = correr(tau, [1.0, 1.0])
    c = correr(tau, [1.0, 0.0])
    print(f"tau={tau:.2f}  h_min: 50/50 {a*100:+6.1f} cm · ambos completos "
          f"{b*100:+6.1f} cm · uno quieto {c*100:+6.1f} cm")
