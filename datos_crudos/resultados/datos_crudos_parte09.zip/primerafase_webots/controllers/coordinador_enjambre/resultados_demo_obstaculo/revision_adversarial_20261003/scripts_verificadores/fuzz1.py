import ast, math, contextlib, random, textwrap
from typing import Optional
import numpy as np
d = r"C:\Users\velas\OneDrive\Documents\tesis\primerafase_webots\controllers\coordinador_enjambre"
SRC = {"new": open(d + r"\demo_obstaculo_movil.py", encoding="utf-8").read(),
       "old": open(d + r"\demo_obstaculo_movil_respaldo_20261002_preObediencia.py", encoding="utf-8").read()}

def get(src, cls, meth):
    tree = ast.parse(src)
    for node in tree.body:
        if cls is None and isinstance(node, ast.FunctionDef) and node.name == meth:
            return ast.get_source_segment(src, node)
        if isinstance(node, ast.ClassDef) and node.name == cls:
            for f in node.body:
                if isinstance(f, ast.FunctionDef) and f.name == meth:
                    return textwrap.dedent(ast.get_source_segment(src, f))
    return None

def const(src, name):
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, ast.AnnAssign) and getattr(node.target, "id", None) == name:
            return ast.literal_eval(node.value)
        if isinstance(node, ast.Assign) and any(getattr(t, "id", None) == name for t in node.targets):
            return ast.literal_eval(node.value)

ns = {}
for k in ("new", "old"):
    g = {"np": np, "math": math, "Optional": Optional, "__name__": "x"}
    for c in ("VENTANA_VELOCIDAD_S", "ZONA_MUERTA_VELOCIDAD_M_S", "T_VERIFICACION_OBEDIENCIA_S",
              "N_CONFIRMACION_OBEDIENCIA", "V_SIN_MOVIMIENTO_M_S", "V_NO_FRENA_M_S"):
        v = const(SRC[k], c)
        if v is not None: g[c] = v
    exec("from __future__ import annotations\n" + get(SRC[k], "FuentePosesConObstaculo", "velocidad_obstaculo"), g)
    exec("from __future__ import annotations\n" + get(SRC[k], "SupervisorObstaculo", "_verificar_obediencia"), g)
    if k == "new":
        exec("from __future__ import annotations\n" + get(SRC[k], None, "_velocidad_o_cero"), g)
    ns[k] = g
print({k: {c: ns[k].get(c) for c in ("VENTANA_VELOCIDAD_S","ZONA_MUERTA_VELOCIDAD_M_S","T_VERIFICACION_OBEDIENCIA_S","N_CONFIRMACION_OBEDIENCIA","V_SIN_MOVIMIENTO_M_S","V_NO_FRENA_M_S")} for k in ns})

class FakeFuente:
    def __init__(self, hist):
        self._cerrojo = contextlib.nullcontext()
        self._obst_historial = list(hist)

vel_old = ns["old"]["velocidad_obstaculo"]
vel_new = ns["new"]["velocidad_obstaculo"]
cero = ns["new"]["_velocidad_o_cero"]
rng = random.Random(12345)
stats = {"none": 0, "zeros_deadzone": 0, "est": 0, "lt2": 0, "gap": 0}
N = 300000
for it in range(N):
    n = rng.choice([0, 1, 2, 2, 3, 4, 6, 10, 20, 64])
    t = 100.0 + rng.random()
    hist = []
    x, y = rng.uniform(0, 3), rng.uniform(0, 3)
    mode = rng.random()
    for j in range(n):
        r = rng.random()
        if r < 0.1: dt = rng.uniform(0.3, 0.6)      # hipo
        elif r < 0.15: dt = rng.uniform(0.0, 0.05)
        else: dt = rng.gauss(0.1, 0.01)
        t += max(dt, 1e-4)
        if mode < 0.3: pass                          # quieto
        elif mode < 0.5: x += rng.gauss(0, 0.0005); y += rng.gauss(0, 0.0005)  # zona muerta
        else: x += rng.gauss(0.005, 0.003); y += rng.gauss(0, 0.003)
        hist.append((t, x, y))
    f = FakeFuente(hist)
    vo = vel_old(f); vn = vel_new(f)
    # barrera
    vb = cero(vn)
    assert isinstance(vo, np.ndarray) and isinstance(vb, np.ndarray)
    assert vo.dtype == vb.dtype and vo.shape == vb.shape and vo.tobytes() == vb.tobytes(), (hist, vo, vb)
    # patada / disparo
    ro = float(np.linalg.norm(vo)); rn = float(np.linalg.norm(vn)) if vn is not None else 0.0
    assert ro == rn
    if vn is None:
        stats["none"] += 1
        assert vo.tobytes() == np.zeros(2).tobytes()
        if len(hist) < 2: stats["lt2"] += 1
        else: stats["gap"] += 1
    else:
        assert vn.tobytes() == vo.tobytes()
        if not np.any(vn): stats["zeros_deadzone"] += 1
        else: stats["est"] += 1
print("fuzz velocidad OK", N, stats)
